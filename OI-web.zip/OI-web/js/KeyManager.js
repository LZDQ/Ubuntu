function KeyManager(){
	this.keys = [];
}

document.addEventListener('contextmenu',function(e) {e.preventDefault();});
document.onkeydown=KeyManager.handleKeyDown;
document.onkeyup=KeyManager.handleKeyUp;
document.onmousedown=function(e){
	if()
}
