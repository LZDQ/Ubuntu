function Game(){
	this.players = [];
}
