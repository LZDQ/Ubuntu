FunUI.layouts["myClan"] =
	'<div id="myClan" class="F-Window" data-modal="true">' +
	    '<h2 class="title">_(myClan.title)</h2>' +
	    '<ul class="F-TabPage content">' +
	        '<li class="F-TabSubPage membersPage">' +
	            '<h3 class="title">_(myClan.tab.members.title)</h3>' +
	            '<div class="content">' +
	                '<div class="searchBar">' +
	                    '<div class="F-TextInput searchInput" data-placeholder="_(myClan.search.placeholder)"></div>' +
	                    '<div class="F-Button search"></div>' +
	                '</div>' +
	                '<ul class="F-List" id="myClan_memberList">' +
	                    '<li class="F-ItemRenderer">' +
	                        '<div>' +
	                            '<h4 class="name"></h4>' +
	                            '<div class="role"></div>' +
	                        '</div>' +
	                        '<div class="F-Button remove" data-tooltip-data="_(myClan.tooltip.remove)"></div>' +
	                        '<div class="F-Button demote" data-tooltip-data="_(myClan.tooltip.demote)"></div>' +
	                        '<div class="F-Button promote" data-tooltip-data="_(myClan.tooltip.promote)"></div>' +
	                        '<div class="F-Button info" data-tooltip-data="_(myClan.tooltip.profile)"></div>' +
	                    '</li>' +
	                '</ul>' +
	            '</div>' +
	        '</li>' +
	        '<li class="F-TabSubPage requestsPage">' +
	            '<h3 class="title" onclick="renderClanApps();">_(myClan.tab.requests.title)</h3>' +
	            '<div class="content">' +
	                '<div class="searchBar">' +
	                    '<div class="F-TextInput searchInput" data-placeholder="_(myClan.search.placeholder)"></div>' +
	                    '<div class="F-Button search"></div>' +
	                '</div>' +
	                '<ul class="F-List" id="myClan_requestList">' +
	                    '<li class="F-ItemRenderer">' +
	                        '<h4 class="name"></h4>' +
	                        '<div class="F-Button reject" data-tooltip-data="_(myClan.tooltip.decline)"></div>' +
	                        '<div class="F-Button accept" data-tooltip-data="_(myClan.tooltip.approve)"></div>' +
	                        '<div class="F-Button info" data-tooltip-data="_(myClan.tooltip.profile)"></div>' +
	                    '</li>' +
	                '</ul>' +
	            '</div>' +
	        '</li>' +
	    '</ul>' +
	    '<div class="F-Button close"></div>' +
	'</div>';
