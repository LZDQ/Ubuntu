FunUI.layouts["resourceBar"] =
	'<div id="resourceBar">' +
		'<div class="resource gem">' +
			'<div class="icon"></div>' +
			'<div class="value"></div>' +
			'<div class="F-Button buy buy-gem"></div>' +
		'</div>' +
		'<div class="resource gold">' +
			'<div class="icon"></div>' +
			'<div class="value"></div>' +
			'<div class="F-Button buy buy-gold"></div>' +
		'</div>' +
		'<ul id="resourceBar_chestsList" class="F-List">' +
			'<li class="F-ItemRenderer chest_1">' +
				'<div class="icon"></div>' +
				'<div class="amount">6</div>' +
				'<div class="countdown">' +
					'<span class="label">-</span>' +
				'</div>' +
				'<div class="F-Button open">_(chests.open)</div>' +
			'</li>' +
		'</ul>' +
		'<ul id="resourceBar_dailyQuestSidebar" class="F-List">' +
			'<li class="F-ItemRenderer quest_1">' +
				'<div class="bgimg">' +
					'<div class="questTitle"></div>' +
					'<div class="haveQuest">' +
						'<img class="icon" width="56" height="38" />' +
						'<label class="amount">6<label>' +
					'</div>' +
					'<img class="completed" />' +
				'</div>' +
				'<div class="hover"></div>' +
			'</li>' +
		'</ul>' +
	'</div>';
