(function(window, slayOne, document){

var clickableClassName = "withClickSound";

/**
 * Clickable Widget
 * Add sound effect when the target is clicked by player
 *
 * @param parentNode: dom element to append to
 */
function clickable(targetNode) {
    addClassToDom(targetNode, clickableClassName);
}

//export
if(!slayOne.widgets) {
    slayOne.widgets = {};
}

slayOne.widgets.clickable = clickable;

window.document.addEventListener("click", function(e){
    var node = e.target;
    var hasClickableClass = false;
    // Trace from node to the document root, look for the "withClickSound" class
    var depth = 0;
    var maxDetectDepth = 5;
    while(depth < maxDetectDepth && node != null) {
        depth += 1;
        if(node.className && (node.className.indexOf(clickableClassName) >= 0)) {
            hasClickableClass = true;
            break;
        }
        node = node.parentNode;
    }
    if(hasClickableClass) {
        window.soundManager.playSound(window.SOUND.CLICK);
    }
});

})(window, window.slayOne, window.document);//end main closure