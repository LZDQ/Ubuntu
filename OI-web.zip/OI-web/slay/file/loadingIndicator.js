(function(window, slayOne, document){

/**
 * Loading indicator
 *
 * @param parentNode: dom element to append to
 * @param options:
 *                  width: css property string with units
 *                  height: css property string with units
 */
function loadingIndicator(parentNode, options) {

    var domContainer = document.createElement("div");
    domContainer.className = "loadingIndicator";

	// steamInitWait(domContainer);

    if(options && options.width) {
        domContainer.style.width = options.width;
    }

    if(options && options.height) {
        domContainer.style.height = options.height;
    }

    var domDotsWrapper = document.createElement("div");
    domDotsWrapper.className = "dotsWrapper";
    domContainer.appendChild(domDotsWrapper);

    var domDots = [];
    var dotsCount = 4;
    for(var i = 0; i < dotsCount; i++) {
        var domDot = document.createElement("div");
        domDot.className = "dot";
        domDots.push(domDot);
        domDotsWrapper.appendChild(domDot);
    }

    parentNode.appendChild(domContainer);

    domContainer.animationInterval = -1;

    domContainer.startAnimation = function(){
        domContainer.stopAnimation();
        domContainer.setDotOffset(0);
        domContainer.animationInterval = setInterval(function(){
            domContainer.setDotOffset((domContainer.dotOffset + 1) % dotsCount);
        }, 125);
    };

    domContainer.stopAnimation = function(){
        if(domContainer.animationInterval == -1) {
            return;
        }
        clearInterval(domContainer.animationInterval);
        domContainer.animationInterval = -1;
    };

    domContainer.setDotOffset = function(dotOffset){
        domContainer.dotOffset = dotOffset;
        domContainer.updateDotClasses();
    };

    domContainer.updateDotClasses = function(){
        for(var i = 0; i < dotsCount; i++) {
            domDots[i].className = "dot dot" + ((dotsCount - domContainer.dotOffset + i) % dotsCount).toString();
        }
    };

    return domContainer;
}

//export
if(!slayOne.widgets) {
    slayOne.widgets = {};
}

slayOne.widgets.loadingIndicator = loadingIndicator;

})(window, window.slayOne, window.document);//end main closure
