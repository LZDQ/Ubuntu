/**
 * View renders the "Options" UI
 *
 */
(function(window, slayOne, document){

var viewKey = "optionsScreen";

function renderVolumeSelector_ (parentNode, viewModel) {

	var domWrapper = document.createElement('div');

	viewModel.rsVolume = slayOne.widgets.rangeSelection(domWrapper, {
		min: 0,
		max: 1,
		step: 0.01,
		value: window.sound_volume,
        customClassName: "clickableDuringGame",
		onChange: function(val){
			window.sound_volume = parseFloat(val);
			window.localStorage.setItem("sound_volume", window.sound_volume);
		}
	});

	parentNode.appendChild(slayOne.widgets.topLabelled({
		customClassName: "optionsRangeField",
		label: slayOne.widgets.lang.get("options.volume.label"),
		content: domWrapper
	}));
}

function renderMinimapSizeSelector_ (parentNode, viewModel) {

	var domWrapper = document.createElement('div');

	viewModel.rsMinimapSize = slayOne.widgets.rangeSelection(domWrapper, {
		min: 0.5,
		max: 2,
		step: 0.01,
		value: window.minimapSizeFactor,
        customClassName: "clickableDuringGame",
		onChange: function(val){
			window.minimapSizeFactor = parseFloat(val);
			window.localStorage.setItem("minimapSizeFactor", window.minimapSizeFactor);
		}
	});

	parentNode.appendChild(slayOne.widgets.topLabelled({
		customClassName: "optionsRangeField",
		label: slayOne.widgets.lang.get("options.minimap_size.label"),
		content: domWrapper
	}));
}

function renderGraphicsEffectCheckbox_ (parentNode, viewModel) {
	viewModel.cbFX = slayOne.widgets.checkbox(parentNode, {
		selected: (window.graphicSettings == 0),
        label: slayOne.widgets.lang.get("options.graphic.label"),
        labelClassName: "",
        tipAlign: "center",
        tipMultiline: true,
        tipWidth: "350px",
        customClassName: "optionsCheckbox",
        onChange: function(selected){
        	window.graphicSettings = selected ? 0 : 10;
			window.localStorage.setItem("graphicSettings", window.graphicSettings);
			if (game) {
				game.isLowGraphicEffect = selected;
			}
        },
	});
}

function renderWeaponsUnclickableCheckbox_ (parentNode, viewModel) {
    viewModel.cbFX = slayOne.widgets.checkbox(parentNode, {
        selected: window.weaponsUnclickable,
        label: slayOne.widgets.lang.get("options.weaponsUnclickable.label"),
        labelClassName: "",
        tipAlign: "center",
        tipMultiline: true,
        tipWidth: "350px",
        customClassName: "optionsCheckbox",
        onChange: function(selected){
            window.weaponsUnclickable = selected;
            window.localStorage.setItem("weaponsUnclickable", selected|0);
        },
    });
}

function renderForcePlayerNameColor_ (parentNode, viewModel) {
    viewModel.cbFX = slayOne.widgets.checkbox(parentNode, {
        selected: window.forcePlayerNameColor,
        label: slayOne.widgets.lang.get("options.forcePlayerNameColor.label"),
        labelClassName: "",
        tipAlign: "left",
        tipMultiline: true,
        tipWidth: "350px",
        customClassName: "optionsCheckboxExt",
        onChange: function(selected){
            window.forcePlayerNameColor = selected;
            window.localStorage.setItem("forcePlayerNameColor", selected|0);
        },
    });
}

function renderInGameChatCheckbox_ (parentNode, viewModel) {
	viewModel.cbHideChats = slayOne.widgets.checkbox(parentNode, {
		selected: (window.localStorage.getItem("hideChat") == "true"),
        label: slayOne.widgets.lang.get("options.hide_chat.label"),
        labelClassName: "",
        customClassName: "optionsCheckbox",
        onChange: function(selected){
        	window.localStorage.setItem("hideChat", selected);
			document.getElementById("chatDisplayDiv").style.display = selected ? "none" : "block";
        },
	});
}

function renderDropLists_ (parentNode, viewModel) {
	renderLanguageSwitch_(parentNode, viewModel);
	renderServerSwitch_(parentNode, viewModel);
}

function renderLanguageSwitch_ (parentNode, viewModel) {

	var domWrapper = document.createElement('div');
	domWrapper.className = "optionsDDLContainer";

    var initIndex = 0;

	var languageOptions = [];
	for (var languageKey in slayOne.widgets.lang.supportedLocales) {
        if(slayOne.widgets.lang.locale == languageKey) {
            initIndex = languageOptions.length;
        }
		languageOptions.push({
			label: slayOne.widgets.lang.supportedLocales[languageKey],
			value: languageKey
		});
	}

	viewModel.ddlLanguage = slayOne.widgets.dropdownMenu(domWrapper, {
        customClassName: "optionsDdl",
        customButtonClassName: "optionsDdlBtn",
        customButtonWidth: "242px",
        selectOptions: languageOptions,
        initIndex: initIndex,
        onSwitch: function(languageOption) {

            if(isInGame()) {
                slayOne.viewHelpers.showFloatTip({
                    tipType: 'error',
                    content: slayOne.widgets.lang.get("options.msg.operation_forbidden")
                });
                viewModel.ddlLanguage.selectOption(initIndex);
                return;
            }

            // show confirmation
            var promptWnd = slayOne.viewHelpers.showPrompt({
                title: slayOne.widgets.lang.get("options.language.prompt.title"),
                content: slayOne.widgets.lang.get("options.language.prompt.content"),
                buttons: ['cancel', 'ok'],
                onClick: function(btnName) {
                    if(btnName == 'ok') {
                        slayOne.widgets.lang.setPreferredLocale(languageOption.value);
                        setTimeout(function(){
                            window.location.reload();
                        }, 250);
                    } else if (btnName == 'cancel') {
                        // Set items back
                        viewModel.ddlLanguage.selectOption(initIndex);
                    }
                    promptWnd.close();
                }
            });
        }
    });

	parentNode.appendChild(slayOne.widgets.topLabelled({
		label: slayOne.widgets.lang.get("options.language.label"),
		content: domWrapper
	}));
}

function renderEmptyCell_(parentNode) {
    parentNode.style.width = "283px";
}

function renderServerSwitch_ (parentNode, viewModel) {

	var domWrapper = document.createElement('div');
	domWrapper.className = "optionsDDLContainer";

	var serverOptions = [];
    var initIndex = 0;
    for(var i = 0; i < SERVER_ADDRESSES.length; i++)
    {
        serverOptions.push({
            label: SERVER_ADDRESSES[i].name,
            value: i
        });
        
        if(network.connectedServerIndex == i)
            initIndex = serverOptions.length - 1;
    }
    
	viewModel.ddlServer = slayOne.widgets.dropdownMenu(domWrapper, {
        customClassName: "optionsDdl",
        customButtonClassName: "optionsDdlBtn",
        customButtonWidth: "242px",
        selectOptions: serverOptions,
        initIndex: initIndex,
        onSwitch: function(serverOption) {

            if(isInGame()) {
                slayOne.viewHelpers.showFloatTip({
                    tipType: 'error',
                    content: slayOne.widgets.lang.get("options.msg.operation_forbidden")
                });
                viewModel.ddlServer.selectOption(initIndex);
                return;
            }

            // show confirmation
            var promptWnd = slayOne.viewHelpers.showPrompt({
                title: slayOne.widgets.lang.get("options.server.prompt.title"),
                content: slayOne.widgets.lang.get("options.server.prompt.content"),
                buttons: ['cancel', 'ok'],
                onClick: function(btnName) {
                    if(btnName == 'ok')
                    {
                        // Set flag to tell front-end temporarily connecting to some server on next start
                        window.localStorage.setItem("chooseServerOnStart", serverOption.value);
                        setTimeout(function(){
                            window.location.reload();
                        }, 250);
                    }
                    else if(btnName == 'cancel')
                        viewModel.ddlServer.selectOption(initIndex);
                    
                    promptWnd.close();
                }
            });
        }
    });

	parentNode.appendChild(slayOne.widgets.topLabelled({
		label: slayOne.widgets.lang.get("options.server.label"),
		content: domWrapper
	}));
}

function renderButtons_ (parentNode, viewModel) {

	viewModel.btnCtrls = slayOne.widgets.labelButton(parentNode, {
		label: slayOne.widgets.lang.get("options.btn_ctrl.label"),
        tipAlign: "left",
        theme: "HugeNormal",
        customClassName: "",
        onClick: function(){
            slayOne.views.hotkeyScreen.showWindow({});
        }
	});

	viewModel.btnLoadReplay = slayOne.widgets.labelButton(parentNode, {
		label: slayOne.widgets.lang.get("options.btn_replay.label"),
        tipAlign: "left",
        theme: "HugeNormal",
        customClassName: "",
        onClick: function(){

            if(isInGame()) {
                slayOne.viewHelpers.showFloatTip({
                    tipType: 'error',
                    content: slayOne.widgets.lang.get("options.msg.operation_forbidden")
                });
                return;
            }

        	loadReplay();
        }
	});

	viewModel.btnFullScreen = slayOne.widgets.labelButton(parentNode, {
		label: slayOne.widgets.lang.get("options.btn_fullscreen.label") + "[F8]",
        // tip: slayOne.widgets.lang.get("options.btn_fullscreen.tooltip"),
        tipAlign: "left",
        theme: "HugeNormal",
        customClassName: "",
		onClick: () => {
        	toggleFullscreen(document.documentElement);
        }
	});

	if (playerData && !playerData.steam_bind) {
		viewModel.btnSteamBind = slayOne.widgets.labelButton(parentNode, {
			label: slayOne.widgets.lang.get('options.btn_binding.label'),
    	    // tip: 'steam bind tip',
    	    tipAlign: "left",
    	    theme: "HugeNormal",
    	    customClassName: "",
			onClick: function() {
				if (isSteam) {
					steamTrans();
				} else {
					F$('steamBindEnd').show();
				}
    	    }
		});
	}
}

function showWindow(options){

	Skin.close();

    var domContent = document.createElement('div');
    domContent.className = "optionsView";

    var viewModel = {
    	rsVolume: null,
    	rsMinimapSize: null,
    	cbFX: null,
    	cbHideChats: null,
    	btnCtrls: null,
    	btnLoadReplay: null,
    	btnFullScreen: null,
		btnSteamBind: null,
    	ddlLanguage: null,
    	ddlServer: null,
    };

    var aRows = [
        [ { renderMethod: renderVolumeSelector_ }, { renderMethod: renderMinimapSizeSelector_ }],
        [ { renderMethod: renderGraphicsEffectCheckbox_ }, { renderMethod: renderInGameChatCheckbox_ } ],
		[ { renderMethod: renderWeaponsUnclickableCheckbox_}, { renderMethod: renderEmptyCell_ }],
        [ { renderMethod: renderForcePlayerNameColor_} ],
        [ { renderMethod: renderDropLists_ }, { renderMethod: renderButtons_ } ]
    ];

    for ( var i = 0; i < aRows.length; i++ ) {
        var aCells = aRows[i];
        var domTable = document.createElement("div");
        var domRow = document.createElement("div");
        domTable.className = "mainLayoutTable";
        domRow.style.display = "table-row";
        domTable.style.marginBottom = "10px";

        for ( var j = 0; j < aCells.length; j++ ) {
            var layoutCell = aCells[j];
            var domCell = document.createElement("div");
            var renderMethod = layoutCell.renderMethod ? layoutCell.renderMethod.bind(this): null;
            domCell.className  = "mainLayoutCell";
            domRow.appendChild( domCell );
            renderMethod( domCell, viewModel );
        }

        domTable.appendChild( domRow );
        domContent.appendChild( domTable );
    }

    slayOne.viewHelpers.showPopup(viewKey, {
    	theme: 'standard',
    	title: slayOne.widgets.lang.get("options.title"),
        content: domContent,
        onClose: options.onClose
    });
}

function hideWindow() {
    slayOne.viewHelpers.hidePopup(viewKey);
}

//export
slayOne.views[viewKey] = {
    showWindow: showWindow,
    hideWindow: hideWindow
};

})(window, window.slayOne, window.document);//end main closure
