var rAF = (function(){
	return window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || function(callback){ window.setTimeout(callback, 16); };
})();

var slayOne = {
	views: {},
	functions: {}
};

function Z$(s) {
    return document.querySelector(s);
}

var forceQuit = false;
var forceQuitConfirm = false;

window.addEventListener("beforeunload", function (e) {

	if(forceQuitConfirm || !(game && game.map != map1))
		return;

	if(isDesktop && !forceQuit)
	{
		forceQuit = true;
		forceQuitConfirm = false;
		attemptExitGame();
	}

	(e || window.event).returnValue = false;
	return false;
});

function time() {
	return (Date.now() / 1000)|0;
};

var SteamTransData;
function steamTrans() {
	if (!SteamInfo) {
		console.log('no steam info when steamTrans');
		return;
	}
	if (SteamTransData && SteamTransData.trans_ts < (time() - 3600)) {
		SteamTransData = false;
	}
	if (SteamTransData) {
		NetworkRespondMsgJson.steamTrans(false);
	} else {
		network.send('steamTrans$' + SteamInfo.user.steamId);
	}
};

function ajax(url, callback) {
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
		if(xmlhttp.readyState == XMLHttpRequest.DONE)
			callback(xmlhttp.responseText);
	};
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
};

function isInGame() {
	return (game && game.map != map1);
};

function trim(s) {
	return String.prototype.trim ? s.trim() : s.replace(/^\s+|\s+$/gm,'');
};

function capitalize(str) {
    return str[0].toUpperCase() + str.substr(1);
};

function now() {
	return (Date.now() / 1000)|0;
};

function addClass(current, toAdd) {
	if(!current) {
		current = '';
	}
	var classes = current.split(' ');
	if(classes.indexOf(toAdd) >= 0) {
		return current;
	}
	classes.push(toAdd);
	return classes.join(' ');
};

function removeClass(current, toRemove) {
	if(!current) {
		current = '';
	}
	return current.split(' ').filter(function(cn){
		return cn != toRemove;
	}).join(' ');
};

function addClassToDom(dom, toAdd) {
	dom.className = addClass(dom.className, toAdd);
};

function removeClassFromDom(dom, toRemove) {
	dom.className = removeClass(dom.className, toRemove);
};

// convert game cooords to read coords (x)
function g2rx(x)
{
	return (x - game.cameraX) * FIELD_SIZE;
};

// convert game cooords to read coords (y)
function g2ry(y)
{
	return (y - game.cameraY) * FIELD_SIZE;
};

function escapeHtml(text)
{
	return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
};

var circleX = [0, Math.SQRT1_2, 1, Math.SQRT1_2, 0, -Math.SQRT1_2, -1, Math.SQRT1_2];
var circleY = [-1, -Math.SQRT1_2, 0, Math.SQRT1_2, 1, Math.SQRT1_2, 0, -Math.SQRT1_2];

function getMouseGamePlayX()
{
	if(window.KeyManager && window.game)
        return KeyManager.x / FIELD_SIZE + game.cameraX;
    
	return 0;
};

function getMouseGamePlayY()
{
    if(window.KeyManager && window.game)
		return KeyManager.y / FIELD_SIZE + game.cameraY + ((game.playingPlayer && game.playingPlayer.weapon && game.playingPlayer.weapon.addHeight) ? SHOT_HEIGHT : 0);
	
	return 0;
};

function getAngle(x, y, x2, y2)
{
	var angle = Math.atan((y2 - y) / (x2 - x));
	angle -= x2 - x < 0 ? Math.PI : 0;
	angle += angle < -Math.PI ? Math.PI * 2 : 0;
	angle -= angle > Math.PI ? Math.PI * 2 : 0;
	return angle;
};

function getDirectionFromAgle(x, y, x2, y2)
{
	var angle = getAngle(x, y, x2, y2);

	var direction = 0;

	if(angle >= Math.PI * 3 / 8 && angle <= Math.PI * 5 / 8)
		direction = 0;
	else if(angle <= -Math.PI * 3 / 8 && angle >= -Math.PI * 5 / 8)
		direction = 4;
	else if(angle >= Math.PI * 7 / 8 || angle <= -Math.PI * 7 / 8)
		direction = 2;
	else if((angle <= Math.PI * 1 / 8 && angle >= 0) || (angle >= -Math.PI * 1 / 8 && angle <= 0))
		direction = 6;
	else if(angle <= Math.PI * 7 / 8 && angle >= Math.PI * 5 / 8)
		direction = 1;
	else if(angle <= Math.PI * 3 / 8 && angle >= Math.PI * 1 / 8)
		direction = 7;
	else if(angle >= -Math.PI * 7 / 8 && angle <= -Math.PI * 5 / 8)
		direction = 3;
	else
		direction = 5;

	return direction;
};

function getDirectionFromAgle16(x, y, x2, y2)
{
	var angle = getAngle(x, y, x2, y2);

	var direction = 0;

	if(angle <= -Math.PI * 7 / 16 && angle >= -Math.PI * 9 / 16)
		direction = 0;
	else if(angle <= -Math.PI * 5 / 16 && angle >= -Math.PI * 7 / 16)
		direction = 1;
	else if(angle <= -Math.PI * 3 / 16 && angle >= -Math.PI * 5 / 16)
		direction = 2;
	else if(angle <= -Math.PI * 1 / 16 && angle >= -Math.PI * 3 / 16)
		direction = 3;
	else if(angle <= Math.PI * 1 / 16 && angle >= -Math.PI * 1 / 16)
		direction = 4;
	else if(angle <= Math.PI * 3 / 16 && angle >= Math.PI * 1 / 16)
		direction = 5;
	else if(angle <= Math.PI * 5 / 16 && angle >= Math.PI * 3 / 16)
		direction = 6;
	else if(angle <= Math.PI * 7 / 16 && angle >= Math.PI * 5 / 16)
		direction = 7;
	else if(angle <= Math.PI * 9 / 16 && angle >= Math.PI * 7 / 16)
		direction = 8;
	else if(angle <= Math.PI * 11 / 16 && angle >= Math.PI * 9 / 16)
		direction = 9;
	else if(angle <= Math.PI * 13 / 16 && angle >= Math.PI * 11 / 16)
		direction = 10;
	else if(angle <= Math.PI * 15 / 16 && angle >= Math.PI * 13 / 16)
		direction = 11;
	else if(angle <= -Math.PI * 15 / 16 || angle >= Math.PI * 15 / 16)
		direction = 12;
	else if(angle <= -Math.PI * 13 / 16 && angle >= -Math.PI * 15 / 16)
		direction = 13;
	else if(angle <= -Math.PI * 11 / 16 && angle >= -Math.PI * 13 / 16)
		direction = 14;
	else if(angle <= -Math.PI * 9 / 16 && angle >= -Math.PI * 11 / 16)
		direction = 15;

	return direction;
};

function getGameTickRng(from, to, seed)
{
	if(typeof seed === "undefined")
		seed = game ? game.ticksCounter : 0;

	return from + (((seed * 93071 + 49297) % 233280) / 233280) * (to - from);
};

function getGameTickRng2(from, to, seed)
{
	if(typeof seed === "undefined")
		seed = game ? game.ticksCounter : 0;

	return from + (((seed * 34873 + 49297) % 233280) / 233280) * (to - from);
};

function getStreakByKills(kills)
{
	var k = 999;

	while(kills > 0)
	{
		if(killStreaks[kills])
			return killStreaks[kills];

		kills--;
		k--;

		if(k < 0)
			return null;
	}

	return null;
};

function sortBy(arr2, func)
{
	var arr = arr2.slice();

	for(var i = 0; i < arr.length - 1; i++)
		if(arr[i] && arr[i + 1] && func(arr[i + 1]) < func(arr[i]))
		{
			var el = arr[i];
			arr[i] = arr[i + 1];
			arr[i + 1] = el;
			i -= 2;
		}

	return arr;
};

function extend(a, b)
{
	for(var field in b)
		a[field] = b[field];
};

function createPoundSmoke(x, y, size, count, alpha, startAngle, finishAngle)
{
	if(game.fastForward)
		return;

	var step = count ? (Math.PI * 4 / count) : 0.5;

	var startAngle = startAngle ? startAngle : 0;
	var finishAngle = finishAngle ? finishAngle : (Math.PI * 2);

	// create side smoke effects (big dust clouds that go sideways)
	for(var i = startAngle; i < finishAngle; i += Math.random() * step)
		new Sprite({
			x: x,
			y: y,
			img: imgCoords.dust1,
			scaleFunction: function(){ return this.r1; },
			alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.6 * this.alpha_; },
			age: (1.7 + Math.random()) * 20,
			r1: (Math.random() * 5 + 2.5) * size,
			r2: Math.cos(i) * size,
			r3: Math.sin(i) * size,
			_size: size,
			alpha_: alpha ? alpha : 1,
			zFunction: function(age){ return 1; },
			xFunction: function(age){ return (-1 / (age / 4 + 0.3) + this._size + 2) * this.r2; },
			yFunction: function(age){ return (-1 / (age / 4 + 0.3) + this._size + 2) * this.r3; }
		});
};

function createExplosionGreen(x, y, size)
{
	if(game.fastForward)
		return;

	soundManager.playSound(SOUND.CRAWLER_IMPACT, x, y, 0.8);

	game.addCircle(x, y, imgCoords.whiteCircle);

	var dist = Math.sqrt(Math.pow(x - (game.cameraX + (WIDTH / FIELD_SIZE) / 2), 2) + Math.pow(y - (game.cameraY + (HEIGHT / FIELD_SIZE) / 2), 2));
	var screenSpan = ((WIDTH / FIELD_SIZE) / 2 + (HEIGHT / FIELD_SIZE) / 2) / 2;
	var power = (dist > screenSpan) ? (1 - (dist / screenSpan - 1) * 0.75) : 1;

	if(power > 0)
	{
		var now = Date.now();
		game.rumbleUntil = now + 500;
		game.rumblePower = size * 0.05 * power;
		game.rumbleStart = now;
	}

	var pos = new Field(x, y);

	for(var i = 0; i < graphics[graphicSettings].exposionParticles * 0.5; i++)
	{
		var field = pos.add2(Math.random() * Math.PI * 2, Math.random());

		new Sprite({
			x: field.x,
			y: field.y,
			img: imgCoords.particleGreen,
			scaleFunction: function(){ return this.r0 * this._size; },
			age: (2.2 + Math.random()) * 20,
			r0: Math.random() * 2.5 + 2,
			r1: Math.random() * 2 + 1,
			r2: Math.random() * 4 - 2,
			r3: Math.random() * 4 - 2,
			_size: size * 0.5,
			zFunction: function(age){ return this._size * 1.2 * Math.max(0.3, Math.abs(Math.sin((age + this.r1) / 2)) / Math.max(1, age * 0.2)); },
			xFunction: function(age){ return (-1 / (Math.min(age, this.ticksToLive - 35) / 40 + 0.12) + 5) * this.r2 * this._size; },
			yFunction: function(age){ return (-1 / (Math.min(age, this.ticksToLive - 35) / 40 + 0.12) + 5) * this.r3 * this._size; }
		});
	}

	// create big fire and smoke effects
	for(var i = 0; i < Math.PI * 2; i += Math.random() * 1)
	{
		var field = new Field(x, y, true).add2(Math.random() * Math.PI * 2, Math.random() * 0.25 * size);

		new Sprite({
			x: field.x,
			y: field.y,
			img: imgCoords["fireGreen" + (Math.floor(Math.random() * 4) + 1)],
			scaleFunction: function(age){ return ((1 / ((age / 4) + 0.25) + (age / 4) - 4) * (-2) + this.r1) * this._size; },
			alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.5; },
			r1: 1 + Math.random() * 2,
			r2: Math.cos(i) * Math.random(),
			r3: Math.sin(i) * Math.random(),
			_size: size * 0.5,
			zFunction: function(age){ return age * 0.07 * this._size; },
			xFunction: function(age){ return (-1 / (age / 4 + 0.3) + 2) * this.r2 * this._size; },
			yFunction: function(age){ return (-1 / (age / 4 + 0.3) + 2) * this.r3 * this._size; }
		});
	}

	// create side smoke effects (big dust clouds that go sideways)
	for(var i = 0; i < Math.PI * 2; i += Math.random() * 0.5)
		new Sprite({
			x: pos.x,
			y: pos.y,
			img: imgCoords.poisonFog1,
			scaleFunction: function(){ return this.r1 * this._size; },
			alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.6; },
			age: (1.7 + Math.random()) * 20,
			r1: Math.random() * 5 + 1.5,
			r2: Math.cos(i),
			r3: Math.sin(i),
			_size: size * 0.13,
			zFunction: function(age){ return 0.5; },
			xFunction: function(age){ return (-1 / (age / 4 + 0.3) + 4) * this.r2 * this._size; },
			yFunction: function(age){ return (-1 / (age / 4 + 0.3) + 4) * this.r3 * this._size; }
		});

	// light
	new Sprite({
		x: pos.x,
		y: pos.y - 0.5,
		img: imgCoords.light_green,
		scaleFunction: function(age){ return 2 * Math.max(0.9 - age / this.ticksToLive, 0) * this._size; },
		alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.5; },
		age: (1.2 + Math.random() * 0.4) * 20,
		_size: size * 2
	});

	// light
	new Sprite({
		x: pos.x,
		y: pos.y - 1.0,
		img: imgCoords.light_green,
		scaleFunction: function(){ return 2 * this._size; },
		alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.5; },
		age: (0.25 + Math.random() * 0.05) * 20,
		_size: size * 3.5
	});
};

function createExplosion(x, y, size, sootAlpha, red)
{
	if(game.fastForward)
		return;

	game.addCircle(x, y, imgCoords.whiteCircle);

	var dist = Math.sqrt(Math.pow(x - (game.cameraX + (WIDTH / FIELD_SIZE) / 2), 2) + Math.pow(y - (game.cameraY + (HEIGHT / FIELD_SIZE) / 2), 2));
	var screenSpan = ((WIDTH / FIELD_SIZE) / 2 + (HEIGHT / FIELD_SIZE) / 2) / 2;
	var power = (dist > screenSpan) ? (1 - (dist / screenSpan - 1) * 0.75) : 1;

	if(power > 0)
	{
		var now = Date.now();
		game.rumbleUntil = now + 1000;
		game.rumblePower = size * 0.1 * power;
		game.rumbleStart = now;
	}

	var pos = new Field(x, y);

	if(!red)
		for(var i = 0; i < graphics[graphicSettings].exposionParticles; i++)
		{
			var field = pos.add2(Math.random() * Math.PI * 2, Math.random());

			new Sprite({
				x: field.x,
				y: field.y,
				img: imgCoords.particle,
				scaleFunction: function(){ return this.r0 * this._size; },
				age: (2.2 + Math.random()) * 20,
				r0: Math.random() * 2.5 + 2,
				r1: Math.random() * 2 + 1,
				r2: Math.random() * 4 - 2,
				r3: Math.random() * 4 - 2,
				_size: size * 0.5,
				zFunction: function(age){ return this._size * 1.2 * Math.max(0.3, Math.abs(Math.sin((age + this.r1) / 2)) / Math.max(1, age * 0.2)); },
				xFunction: function(age){ return (-1 / (Math.min(age, this.ticksToLive - 35) / 40 + 0.12) + 5) * this.r2 * this._size; },
				yFunction: function(age){ return (-1 / (Math.min(age, this.ticksToLive - 35) / 40 + 0.12) + 5) * this.r3 * this._size; }
			});
		}
	
	// create big fire and smoke effects
	for(var i = 0; i < Math.PI * 2; i += Math.random() * 1)
	{
		var field = new Field(x, y, true).add2(Math.random() * Math.PI * 2, Math.random() * 0.25 * size);

		new Sprite({
			x: field.x,
			y: field.y,
			img: imgCoords["fire" + (Math.floor(Math.random() * 4) + 1) + (red ? "red" : "")],
			scaleFunction: function(age){ return ((1 / ((age / 4) + 0.25) + (age / 4) - 4) * (-2) + this.r1) * this._size; },
			alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.5; },
			r1: 1 + Math.random() * 2,
			r2: Math.cos(i) * Math.random(),
			r3: Math.sin(i) * Math.random(),
			_size: size * 0.5,
			zFunction: function(age){ return age * 0.07 * this._size; },
			xFunction: function(age){ return (-1 / (age / 4 + 0.3) + 2) * this.r2 * this._size; },
			yFunction: function(age){ return (-1 / (age / 4 + 0.3) + 2) * this.r3 * this._size; }
		});
	}
	
	// create side smoke effects (big dust clouds that go sideways)
	for(var i = 0; i < Math.PI * 2; i += Math.random() * 0.5)
		new Sprite({
			x: pos.x,
			y: pos.y,
			img: imgCoords["dust1" + (red ? "red" : "")],
			scaleFunction: function(){ return this.r1 * this._size; },
			alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.6; },
			age: (1.7 + Math.random()) * 20,
			r1: Math.random() * 5 + 1.5,
			r2: Math.cos(i),
			r3: Math.sin(i),
			_size: size * 0.5,
			zFunction: function(age){ return 0.5; },
			xFunction: function(age){ return (-1 / (age / 4 + 0.3) + 4) * this.r2 * this._size; },
			yFunction: function(age){ return (-1 / (age / 4 + 0.3) + 4) * this.r3 * this._size; }
		});

	// light
	new Sprite({
		x: pos.x,
		y: pos.y - 0.5,
		img: red ? imgCoords.light_red : imgCoords.light_yellow,
		scaleFunction: function(age){ return 2 * Math.max(0.9 - age / this.ticksToLive, 0) * this._size; },
		alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.5; },
		age: (1.2 + Math.random() * 0.4) * 20,
		_size: size * 2
	});

	// light
	new Sprite({
		x: pos.x,
		y: pos.y - 1.0,
		img: imgCoords.light_white,
		scaleFunction: function(){ return 2 * this._size; },
		alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.5; },
		age: (0.25 + Math.random() * 0.05) * 20,
		_size: size * 3.5
	});

	// create soot (only if no water)
	if(game.pathingArray[Math.floor(x)] && game.pathingArray[Math.floor(x)][Math.floor(y)] != 9)
		for(var j = 0; j < game.groundCanvas.length; j++)
		{
			game.groundCanvas[j].getContext('2d').globalAlpha = sootAlpha ? sootAlpha : 0.65;
			game.groundCanvas[j].getContext('2d').drawImage(imgs.miscSheet, imgCoords.soot.x, imgCoords.soot.y, imgCoords.soot.w, imgCoords.soot.h, x * FIELD_SIZE / SCALE_FACTOR - imgCoords.soot.w / 2 - game.groundMinX * 16, y * FIELD_SIZE / SCALE_FACTOR - imgCoords.soot.h / 2 - game.groundMinY * 16, imgCoords.soot.w, imgCoords.soot.h);
			game.groundCanvas[j].getContext('2d').globalAlpha = 1;
		}
};

function createBlinkEffect(x, y)
{
	if(game.fastForward)
		return;

	createPoundSmoke(x, y + 0.5, 0.5, 9, 0.4);

	for(var i = 0; i < 10; i++)
		new Sprite({
			x: x + Math.random() * 1.4 - 0.7,
			y: y + Math.random() * 1.4 - 0.7 - 0.5,
			img: imgCoords.whiteLine,
			scaleFunction: function(){ return Math.random() * 2.5; },
			alphaFunction: function(){ return 0.8 - Math.random() * 0.3; },
			age: 4 + Math.random() * 2,
			r0: Math.random() * 0.05 - 0.025,
			r1: Math.random() * 0.05 - 0.025,
			zFunction: function(age){ return age * this.r0; },
			xFunction: function(age){ return age * this.r1; }
		});

	for(var i = 0; i < 7; i++)
		new Sprite({
			x: x + Math.random() * 1.4 - 0.7,
			y: y + Math.random() * 1.0 - 0.5 - 0.5,
			z: Math.random() * 1 + 0.3,
			img: imgCoords.particleWhite,
			alphaFunction: function(){ return (this.ticksLeft > 10) ? 0.5 : (this.ticksLeft * 0.5 / 10); },
			age: 40 + Math.random() * 20,
			scaleFunction: function(){ return this.scale; },
			scale: 1.2 + Math.random() * 0.6,
			zFunction: function(age){ return Math.max(-Math.pow(age * 0.07, 2), -this.z); }
		});

	new Sprite({
		x: x,
		y: y - 0.5,
		img: imgCoords.light_white,
		alphaFunction: function(age) { return age <= 6 ? (Math.random() * 0.66) : (Math.min(0.2, this.ticksLeft * 0.025) * (Math.random() * 0.3 + 0.85)); },
		age: 40 + Math.random() * 20,
		scale: 5,
		scaleFunction: function(){ return this.scale; }
	});
};

function createBlinkEffectSmall(x, y)
{
	if(game.fastForward)
		return;

	for(var i = 0; i < 7; i++)
		new Sprite({
			x: x + Math.random() * 1.4 - 0.7,
			y: y + Math.random() * 1.4 - 0.7 - 0.5,
			img: imgCoords.whiteLine,
			scaleFunction: function(){ return Math.random() * 2.5; },
			alphaFunction: function(){ return 0.8 - Math.random() * 0.3; },
			age: 4 + Math.random() * 2,
			r0: Math.random() * 0.05 - 0.025,
			r1: Math.random() * 0.05 - 0.025,
			zFunction: function(age){ return age * this.r0; },
			xFunction: function(age){ return age * this.r1; }
		});

	for(var i = 0; i < 4; i++)
		new Sprite({
			x: x + Math.random() * 1.4 - 0.7,
			y: y + Math.random() * 1.0 - 0.5 - 0.5,
			z: Math.random() * 1 + 0.3,
			img: imgCoords.particleWhite,
			alphaFunction: function(){ return (this.ticksLeft > 10) ? 0.5 : (this.ticksLeft * 0.5 / 10); },
			age: 40 + Math.random() * 20,
			scaleFunction: function(){ return this.scale; },
			scale: 1.2 + Math.random() * 0.6,
			zFunction: function(age){ return Math.max(-Math.pow(age * 0.07, 2), -this.z); }
		});

	new Sprite({
		x: x,
		y: y - 0.5,
		img: imgCoords.light_white,
		alphaFunction: function(age) { return age <= 6 ? (Math.random() * 0.66) : (Math.min(0.2, this.ticksLeft * 0.025) * (Math.random() * 0.3 + 0.85)); },
		age: 12 + Math.random() * 7,
		scale: 3.5,
		scaleFunction: function(){ return this.scale; }
	});
};

function createBlinkEffectVerySmall(x, y)
{
	if(game.fastForward)
		return;

	for(var i = 0; i < 4; i++)
		new Sprite({
			x: x + Math.random() * 1.4 - 0.7,
			y: y + Math.random() * 1.4 - 0.7 - 0.5,
			img: imgCoords.whiteLine,
			scaleFunction: function(){ return Math.random() * 2.5; },
			alphaFunction: function(){ return 0.8 - Math.random() * 0.3; },
			age: 4 + Math.random() * 2,
			r0: Math.random() * 0.05 - 0.025,
			r1: Math.random() * 0.05 - 0.025,
			zFunction: function(age){ return age * this.r0; },
			xFunction: function(age){ return age * this.r1; }
		});

	for(var i = 0; i < 2; i++)
		new Sprite({
			x: x + Math.random() * 1.4 - 0.7,
			y: y + Math.random() * 1.0 - 0.5 - 0.5,
			z: Math.random() * 1 + 0.3,
			img: imgCoords.particleWhite,
			alphaFunction: function(){ return (this.ticksLeft > 10) ? 0.5 : (this.ticksLeft * 0.5 / 10); },
			age: 30 + Math.random() * 10,
			scaleFunction: function(){ return this.scale; },
			scale: 1.2 + Math.random() * 0.6,
			zFunction: function(age){ return Math.max(-Math.pow(age * 0.07, 2), -this.z); }
		});

	new Sprite({
		x: x,
		y: y - 0.5,
		img: imgCoords.light_white,
		alphaFunction: function(age) { return age <= 6 ? (Math.random() * 0.66) : (Math.min(0.2, this.ticksLeft * 0.025) * (Math.random() * 0.3 + 0.85)); },
		age: 8 + Math.random() * 4,
		scale: 2.5,
		scaleFunction: function(){ return this.scale; }
	});
};

function drawCircle(x, y, size, color, fillColor, yScale, lineWidth)
{
	var yScale_ = yScale ? yScale : 1;
	c.scale(1, yScale_);
	c.lineWidth = SCALE_FACTOR * (lineWidth ? lineWidth : 1);
	c.beginPath();
	c.arc(x, y / yScale_, size, 0, 2 * Math.PI, false);

	if(color)
	{
		c.strokeStyle = color;
		c.stroke();
	}

	if(fillColor)
	{
		c.fillStyle = fillColor;
		c.fill();
	}

	c.scale(1, 1 / yScale_);
};

// draw wrapped text (returns the number of drawed lines)
function drawText(ctx, text, color, size, x, y, w, align, alpha, fillStyle, height, maxWidth, shadowColor, shadowBlur, fontFamily)
{
	if (!fontFamily) {
        if (drawText.fontFamily == undefined) {
            drawText.fontFamily = window.getComputedStyle(document.documentElement)["font-family"];
        }

        fontFamily = drawText.fontFamily;
	}
	var text2 = text;
	var w2 = w ? w : 99999;
	alpha = alpha ? alpha : 1;
	var returnValue = 1; // number of lines we used to draw the text

	ctx.font = "bold " + size + "px " + fontFamily;
	ctx.textAlign = align ? align : "left";
	ctx.shadowColor = shadowColor ? shadowColor : "black";
	// ctx.shadowBlur = shadowBlur ? shadowBlur : 2;
	ctx.shadowBlur = 0;

	// check if text fits in line, if not, recursively call for next line
	if(ctx.measureText(text).width > w2)
	{
		var words = text.split(" ");

		var line = words[0];
		var lastFittingLine;
		var i = 1;

		while(ctx.measureText(line).width <= w2 && i < words.length)
		{
			lastFittingLine = line;
			line = line + " " + words[i];
			i++;
		}

		text2 = lastFittingLine ? lastFittingLine : line;

		words.splice(0, Math.max(i - 1, 1));

		if(words.length > 0)
			returnValue += drawText(ctx, words.join(" "), color, size, x, y + height + 4, w2, align, alpha, fillStyle, height, maxWidth, shadowColor, shadowBlur, fontFamily);
	}

	var textWidth = ctx.measureText(text2).width;

	// round
	var x2 = Math.floor(x);
	var y2 = Math.floor(y);

	// fillrect, if fillstyle parameter passed
	if(fillStyle)
	{
		var x3 = x2;

		if(align == "center")
			x3 -= (textWidth + 6) / 2;

		else if(align == "right")
			x3 -= (textWidth + 6);

		ctx.globalAlpha = alpha;
		ctx.fillStyle = fillStyle;
		ctx.fillRect(x3, y2 - height * 0.9, textWidth + 6, height * 1.1);
	}

	// draw text
	if(alpha)
		ctx.globalAlpha = alpha;
	ctx.fillStyle = color;

	if(maxWidth)
		ctx.fillText(text2, x2, y2, maxWidth);
	else
		ctx.fillText(text2, x2, y2);

	ctx.globalAlpha = 1;

	ctx.shadowBlur = 0;

	return returnValue;
};

function fpsColor(i)
{
	return numColor(i, 40, 20);
}

function pingColor(i)
{
	i = 1000 - i;
	return numColor(i, 900, 700);
}

function numColor(i, fine, poor)
{
	var s = '255, 255, 128'; // yellow, middle
	
	if(i > fine)
		s = '192, 255, 192'; // green, fine
	
	else if(i < poor)
		s = '255, 192, 192'; // red, poor
	
	return 'rgba(' + s + ', 0.8)';
}

function cameraReset()
{
	KeyManager.x = (WIDTH / 2)|0;
	KeyManager.y = (HEIGHT / 2)|0;
};

function switchSpec(inc)
{
	soundManager.playSound(SOUND.SWITCH, undefined, undefined, 0.7);

	if(game.players.length == 0)
		game.specPlayer = null;

	else
	{
		if(!game.specPlayer)
			game.specPlayer = inc > 0 ? game.players[0] : game.players[game.players.length - 1];

		else
		{
			var found = false;

			for(var i = 0; i < game.players.length; i++)
				if(game.players[i] == game.specPlayer)
				{
					i += inc;

					if(game.players[i])
						game.specPlayer = game.players[i];
					else
						game.specPlayer = null;

					i = game.players.length;

					found = true;
				}

			if(!found)
				game.specPlayer = null;
		}
	}

	if(game.specPlayer)
		game.interface_.setMainKillMsg(slayOne.widgets.lang.get("game.msg.spectate.follow", { playerName: game.specPlayer.unsafeName }), "#BEBEBE", "textInGrey");

	else
		game.interface_.setMainKillMsg(slayOne.widgets.lang.get("game.msg.spectate.free"), "#BEBEBE", "textInGrey");

	return;
};

function attemptExitApp()
{
	return Desktop.close();
	
    var promptWnd = slayOne.viewHelpers.showPrompt({
        title: slayOne.widgets.lang.get("msg.exitApp.confirm.title"),
        content: slayOne.widgets.lang.get("msg.exitApp.confirm.content"),
        buttons: ['cancel', 'ok'],
        onClick: function(btnName) {
            promptWnd.close();
            if (btnName == 'ok') {
				Desktop.close();
            }
        }
    });
}

function attemptExitGame()
{
	if(game.editor || game.replayMode)
	{
		exitGame();
		return;
	}
	
	function doExitGame()
	{
        network.send("leave-game");
        uiManager.hideDeathScreen();
        window.leavingGame = true;
        window.leaveGameLeftTicks = game.ticksCounter;
        window.leaveGameFloatTip = slayOne.viewHelpers.showFloatTip({
            tipType: 'error',
            content: slayOne.widgets.lang.get("msg.leave_game", {
                seconds: ''
            }),
            duration: -1
        });
	}
	
	if(game.ticksCounter < 0 || !game.playingPlayer)
		return doExitGame();
	
    var promptWnd = slayOne.viewHelpers.showPrompt({
        title: slayOne.widgets.lang.get("msg.leave_game.confirm.title"),
        content: slayOne.widgets.lang.get("msg.leave_game.confirm.content"),
        buttons: ['cancel', 'ok'],
        onClick: function(btnName) {
            promptWnd.close();
            if(btnName == 'ok')
            {
				if(forceQuit)
				{
					forceQuitConfirm = true;
					window.close();
				}
				if(isTutorialMap(game.mapId))
					gaEventOnce('player-stopped-tutorial');
				
                doExitGame();
			}
			else
			{
				forceQuit = false;
				forceQuitConfirm = false;
			}
        }
    });
};

function preExitGame()
{
    if(window.leavingGame)
    {
        window.leavingGame = false;
        slayOne.viewHelpers.hideFloatTip(window.leaveGameFloatTip);
        window.leaveGameFloatTip = -1;
        window.leaveGameLeftTicks = 0;
    }

    uiManager.hideDeathScreen();
};

function exitGame()
{
	soundManager.playSound(SOUND.CLICK);
	document.getElementById("optionsWindow").style.display = "none";

	if(playerData.authLevel >= AUTH_LEVEL.PLAYER)
		F$('resourceBar').show();

	var isTutorial = game.isTutorial();

	game = new Game(map1);

	if(document.getElementById('editorElementsDiv'))
		document.getElementById('editorElementsDiv').style.display = "none";
	if(document.getElementById('editorDiv2'))
		document.getElementById('editorDiv2').style.display = "none";

	F$('rankInGame').hide();

	if(game.editor)
		game.editor.refreshItemInfo();

	document.getElementById("editorItemInfo").style.display = "none";

    slayOne.viewHelpers.showAd();

    uiManager.refreshMenuButtons();
    if(!playerData.db_id && isTutorial)
    	uiManager.showAccountWindow(1);
	else
        uiManager.showMainScene();
};

function createTile(o)
{
	var type = tileTypes[o.id];

	if(!type)
		type = tileTypes[0];

	var tile = {
		x: o.x,
		y: o.y,
		type: type
	};
	
	if(type.editable)
		for(var i = 0; i < type.editable.length; i++)
			tile[type.editable[i]] = parseFloat(typeof o[type.editable[i]] !== "undefined" ? o[type.editable[i]] : type[type.editable[i]]);

	return tile;
};

function iHaveItem(item)
{
    return playerData.skinsUnlocked.split(";").contains(item.id);
};

function parseChests(str1)
{
    var chests = {};
    var a1 = str1.split(';');
    for(var i = 0; i < a1.length; i++)
    {
        if(a1[i])
        {
            var a2 = a1[i].split(',');
            var id = parseInt(a2[0]);
            chests[id] = {
                count: parseInt(a2[1]),
                openTime: parseInt(a2[2])
            };
        }
    }
    return chests;
};

function getChestName(id) {
	return F_('chest.name.' + id);
};

function modPlInfo(plID)
{
	game.interface_.addMsg("request sent", "red");
	
	if(game && game.map != map1)
	{
		network.send("chat/plinfo " + plID);
	}
	
	else
	{
		network.send("chat/plinfo$ " + plID);
	}
};

function initBan(plID)
{
	if(game && game.map != map1)
	{
		var el = document.getElementById("chatInputDiv");
		var el2 = document.getElementById("chatInput");
		var el3 = document.getElementById("chatlog");
		var el4 = document.getElementById("chatloginner");
	
		if(el.style.display != "inline")
		{
			el.style.display = "inline";
			el3.style.display = "inline";
			el4.scrollTop = el4.scrollHeight;
		}
		
		el2.value = "/ban " + plID + " ";
		el2.focus();
	}
	
	else
	{
		slayOne.viewHelpers.showFloatTip({
			tipType: 'success',
			content: "Only works ingame",
			duration: 2000
		});
	}
};

function initBanGuest(name)
{
	if(game && game.map != map1)
	{
		var el = document.getElementById("chatInputDiv");
		var el2 = document.getElementById("chatInput");
		var el3 = document.getElementById("chatlog");
		var el4 = document.getElementById("chatloginner");
	
		if(el.style.display != "inline")
		{
			el.style.display = "inline";
			el3.style.display = "inline";
			el4.scrollTop = el4.scrollHeight;
		}
		
		el2.value = "/banguest " + name + " ";
		el2.focus();
	}
	
	else
	{
		slayOne.viewHelpers.showFloatTip({
			tipType: 'success',
			content: "Only works ingame",
			duration: 2000
		});
	}
};

function watchLaddergame(id)
{
	network.send("wlg$" + id);
};

function showLadderList(arr)
{
	var str = "<div class='title'>Recent Ranked matches</div><table><tr><td>Player 1</td><td>Player 2</td><td>Date</td><td></td><td></td></tr>";
	
	for(var i = 2; i < arr.length; i += 8)
	{
		var d = new Date(parseInt(arr[i + 5]));
		str += "<tr>";
		str += "<td><a class='pseudoLink yellow withClickSound' onclick='clickPlayerNameInLadderList(\"" + arr[i + 1] + "\");'>" + arr[i + 3] + "</a></td>";
		str += "<td><a class='pseudoLink yellow withClickSound' onclick='clickPlayerNameInLadderList(\"" + arr[i + 2] + "\");'>" + arr[i + 4] + "</a></td>";
		str += "<td>" + d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear() + "</td>";
		
		if(((arr[i + 6] == "1" && arr[1] == arr[i + 1]) || (arr[i + 6] == "2" && arr[1] == arr[i + 2])))
			str += "<td style='color: #5fac1c;'>win</td>";
		
		else if(((arr[i + 6] == "2" && arr[1] == arr[i + 1]) || (arr[i + 6] == "1" && arr[1] == arr[i + 2])))
			str += "<td style='color: #a82323;'>loss</td>";
		
		else
			str += "<td style='color: #d1d52b;'>draw</td>";
		
		str += "<td>" + (arr[i + 7] == "1" ? "(<a class='pseudoLink yellow withClickSound' onclick='watchLaddergame(" + arr[i] + ");'>watch</a>)" : "") + "</td>";
		
		str += "</tr>";
	}
	str += "</table>";
	
	var box = document.createElement('div');
	box.id = 'ladderList';
	box.className = 'F-Window light';
	
	var content = document.createElement('div');
	content.className = 'content';
	content.id = 'nameColorContent';
	content.innerHTML = str;
	box.appendChild(content);
	
	var close = document.createElement('div');
	close.className = 'F-Button close';
	box.appendChild(close);
	
	var bg = document.createElement('div');
	bg.className = 'bg';
	box.appendChild(bg);
	
	document.body.appendChild(box);
	
	close.onclick = function(){
		soundManager.playSound(SOUND.CLICK);
		this.parentNode.parentNode.removeChild(this.parentNode);
	};
};

function clickPlayerNameInLadderList(id)
{
	uiManager.showPlayerInfoById(id);
	var ladderListDiv = document.getElementById("ladderList");
	ladderListDiv.parentNode.removeChild(ladderListDiv);
};

function getClanObj(arr)
{
	return {
		tag : arr[1],
		name : arr[2],
		countMembers : parseInt(arr[3]),
		clan_role : arr[4],
		elo : parseInt(arr[5]),
		id : parseInt(arr[6]),
		appsCount : parseInt(arr[7]),
		description : arr[8]
	};
};

function setHat(i)
{
	if(iHaveItem(hats[i]))
	{
		network.send("setHat$" + i);
		playerData.skin = hats[i];
	}

};

function joinTeam(team)
{
	if(team == -1)
	{
        game.iAmSpec = true;
        network.send("spectate");
		F$('rankInGame').hide();
		return;
	}

    game.iAmSpec = false;
	network.send("joinTeam$" + team);
};

function getMapThumbnail(mapId, mapVersion) {
	return window.mapPath + '/' + mapId + "." + mapVersion + ".jpg";
};

function holdPlaceMapThumbnail(event)
{
	var img = event.currentTarget;
	if(event.type != 'load' || (img.naturalWidth == 1 && img.naturalHeight == 1))
        img.src = 'imgs/main_ui/map_placeholder.png';
};

function toggleFullscreen(element)
{
    if (isDesktop) {
        Desktop.toggleFullscreen();
        return;
    }

	if(element.requestFullScreenWithKeys)
	{
		if(!document.fullScreen)
			element.requestFullScreenWithKeys();
		else
			document.exitFullScreen();
	}

	if(element.requestFullScreen)
	{
		if(!document.fullScreen)
			element.requestFullscreen();
		else
			document.exitFullScreen();
	}

	else if(element.mozRequestFullScreen)
	{
		if(!document.mozFullScreen)
			element.mozRequestFullScreen();
		else
			document.mozCancelFullScreen();
	}

	else if(element.webkitRequestFullScreen)
	{
		if(!document.webkitIsFullScreen)
			element.webkitRequestFullScreen(element.ALLOW_KEYBOARD_INPUT);
		else
			document.webkitCancelFullScreen();
	}

	resize();
};

Array.prototype.erease = function(element)
{
	var i = this.indexOf(element);
	if(i >= 0)
	{
		this.splice(i, 1);
		return true;
	}
	return false;
};

Array.prototype.contains = function(element)
{
	for(var i = 0; i < this.length; i++)
		if(this[i] == element)
			return true;
	
	return false;
};

function acceptAGB()
{
	network.send("i-accept-agb");
	soundManager.playSound(SOUND.CLICK);
};

function showPlayerInfo(p)
{
	network.send("plInfo$" + p);
};

var check = false;
(function(a){if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0,4)))check = true;})(navigator.userAgent||navigator.vendor||window.opera);
isMobile = check;

// when window gets resized, this is called
function resize()
{
	WIDTH = window.innerWidth;
	HEIGHT = window.innerHeight;
	canvas.width = WIDTH;
	canvas.height = HEIGHT;

	FIELD_SIZE = Math.sqrt(WIDTH * HEIGHT) * SCALE_CONST;
	FIELD_SIZE_BASE = Math.sqrt(WIDTH * HEIGHT) * SCALE_CONST_BASE;

	SCALE_FACTOR = FIELD_SIZE / 16;
	SCALE_FACTOR_BASE = FIELD_SIZE_BASE / 16;

	c.mozImageSmoothingEnabled = false;
    c.msImageSmoothingEnabled = false;
	c.imageSmoothingEnabled = false;

	// document.body.style.fontSize = (SCALE_FACTOR_BASE * 0.18 * 16) + "px";

	var el = document.getElementById("chatDisplayDiv");
	if(el)
	{
		el.style.left = (87 * (FIELD_SIZE / 16)) + "px";
		el.style.right = ((FIELD_SIZE / 16) * 70) + "px";
		el.style.bottom = ((FIELD_SIZE / 16) * 2) + "px";
	}
};

function ban(name)
{
	network.send("ban$" + name);
};

function playerIsBeeingIgnored(name)
{
	name = name.toLowerCase();
	return ignoreList.indexOf(name) >= 0 || ignoreListTemp.indexOf(name) >= 0;
}

function toggleIgnore(button, name, isGuest)
{
	var el = document.getElementById("button_ignore_" + name);

	name = name.toLowerCase();

	for(var i = 0; i < ignoreList.length; i++)
		if(ignoreList[i] == name)
		{
			ignoreList.splice(i, 1);
			localStorage.ignoreList = ignoreList.join(";");
			if(el)
				el.innerHTML = "ignore";
			game.interface_.addMsg(slayOne.widgets.lang.get("game.msg.ignore.off", { playerName: name}), "white");
			return ;
		}

	for(var i = 0; i < ignoreListTemp.length; i++)
		if(ignoreListTemp[i] == name)
		{
			ignoreListTemp.splice(i, 1);
			if(el)
				el.innerHTML = "ignore";
			game.interface_.addMsg(slayOne.widgets.lang.get("game.msg.ignore.off", { playerName: name }), "white");
			return;
		}

	(isGuest ? ignoreListTemp : ignoreList).push(name);
	localStorage.ignoreList = ignoreList.join(";");

	if(el)
		el.innerHTML = "unignore";

	game.interface_.addMsg(slayOne.widgets.lang.get("game.msg.ignore.on", { playerName: name }), "white");
};

function saveReplay()
{
	var blob = new Blob([JSON.stringify(["replay-version=4"].concat(window.replayFile))], {type: "text/plain;charset=utf-8"});
	var d = new Date();
	saveAs(blob, "replay-" + d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate() + ".json");
	soundManager.playSound(SOUND.CLICK);
};

function loadReplay()
{
	// create new input and simulate a click on it and set function
	var fileInput = document.createElement("input");
	fileInput.type = "file";
	fileInput.click();

	fileInput.onchange = function()
	{
		var file = fileInput.files[0];
		if(file)
		{
			slayOne.views.optionsScreen.hideWindow();
			
			var reader = new FileReader();
			reader.readAsText(file);
			reader.onload = function(e){

				setTimeout(function(){

					startReplay0(JSON.parse(e.target.result));

				}, 50);
			};
		}
	};
	
	soundManager.playSound(SOUND.CLICK);
};

function startReplay0(r)
{
	if(r[0] && r[0].split && r[0].split("=")[0] == "replay-version")
	{
		r.splice(0, 1);
		playingReplay = r;
		playingReplayVersion = parseInt(r[0].split("=")[1]);
	}

	else // replay v1
	{
		playingReplay = r;
		playingReplayVersion = 1;
	}

	startReplay();
};

function startReplay()
{
	var el = document.getElementById("ladderList");
	
	if(el)
		el.parentNode.removeChild(el);
	
	el = document.getElementById("popupWndContainer");
	
	if(el)
		el.parentNode.removeChild(el);
	
	el = document.querySelector(".F-popUpLayer");
	
	if(el)
		el.parentNode.removeChild(el);
	
	for(var i = 0; i < playingReplay.length; i++)
	{
		var row = playingReplay[i];
		var splitMsg = row.split("$");
		
		var map_ = null;
		try
		{
			map_ = JSON.parse(splitMsg[3]);
		}
		catch(e)
		{
			map_ = null;
		}
		
		if(map_ && typeof map_ === 'object')
		{
			cancelLadder();
            enterGame(splitMsg);
            game = new Game(map_);
            game.replayMode = true;
            game.iAmSpec = true;
            game.init(splitMsg, playingReplay[i]);
            game.interface_.analyzeReplay(playingReplay);

            uiManager.refreshMenuButtons();
            
            return;
		}
		
		var cmd = splitMsg[0];
		
		if(cmd == 'initPreload')
		{
			var json = row.substr(row.indexOf('$') + 1);
			json = JSON.parse(json);
			NetworkRespondMsgJson.initPreload(json);
			continue;
		}

		if(cmd == "init")
		{
        	cancelLadder();
            // enterGame(splitMsg);
            game = new Game(JSON.parse(splitMsg[1]));
            game.replayMode = true;
            game.iAmSpec = true;
            game.init(splitMsg, playingReplay[i]);
            game.interface_.analyzeReplay(playingReplay);

            uiManager.refreshMenuButtons();

			return;
		}
	}
};

function sendRespawn()
{
	network.send("respawn");
	uiManager.hideDeathScreen();
	slayOne.viewHelpers.hideAd();
};

function logout()
{
	if(isSteam)
		return Desktop.close();

	soundManager.playSound(SOUND.CLICK);
	network.send("logout");
    F$('resourceBar').hide();
    initPlayerObj();
    localStorage.setItem("autologin", "");
	uiManager.showMainScene();
	uiManager.refreshMenuButtons();

    if(pl_daily_quests_refesh_timeout_id)
    {
		clearTimeout(pl_daily_quests_refesh_timeout_id);
		pl_daily_quests_refesh_timeout_id = null;
	}
};

function launchEditor()
{
	soundManager.playSound(SOUND.CLICK);
	
	cancelLadder();
	enterGame();

	var map = {
		x: 32,
		y: 32,
		maxPlayers: 10,
		name: "New map",
		description: "",
		tiles: [],
		defaultTiles: 0,
		groundTiles: [],
		type: MAP_TYPE.DEATHMATCH
	};

	game = new Game(map, true);
	game.editor = new Editor();
	game.startEditingMode();

	uiManager.refreshMenuButtons();
};

function getCanvasFromImgObj(img, sheet, size)
{
	var cv = document.createElement("canvas");
	var scale = size / Math.max(img.w, img.h);
	cv.width = img.w * scale;
	cv.height = img.h * scale;
	cv.getContext("2d").mozImageSmoothingEnabled = false;
    cv.getContext("2d").msImageSmoothingEnabled = false;
	cv.getContext("2d").imageSmoothingEnabled = false;
	cv.getContext("2d").drawImage(sheet, img.x, img.y, img.w, img.h, 0, 0, img.w * scale, img.h * scale);
	return cv;
};

function ticks2TimeStr(ticks)
{
	var time = Math.floor(ticks / 20);
	return humanizeSeconds(time);
}

function formatCountdown(deadline)
{
    var seconds = Math.round((deadline - serverTime()) / 1000);
    return humanizeSeconds(seconds);
}

function humanizeSeconds(seconds)
{
    if(seconds >= 0)
    {
    	var hour = Math.floor(seconds / 3600);
        var min = Math.floor(seconds / 60) % 60;
        var sec = seconds % 60;
        
        var str = "";
        if(hour > 0)
        {
            hour = hour < 10 ? ("0" + hour) : hour;
            str = hour + ":";
		}
		
        min = min < 10 ? ("0" + min) : min;
        sec = sec < 10 ? ("0" + sec) : sec;
        
        return str + min + ":" + sec;
    }
    else
        return "--:--";
}

function serverTime()
{
    return Date.now() + serverTimeDiff;
}

function changeReplaySpeed(inc)
{
	if(game.fastForward || game.interface_.fastForwardTo >= 0)
	{
		game.fastForward = false;
		game.interface_.fastForwardTo = -1;

		window.oldReplayOptionsIndex = window.replayOptionsIndex;
		window.replayOptionsIndex = window.replayOptions.length - 1;
		window.replayOption = window.replayOptions[window.replayOptionsIndex];

		return;
	}

	window.replayOptionsIndex = Math.max(Math.min(window.replayOptionsIndex + inc, window.replayOptions.length - 2), 0);
	window.replayOption = window.replayOptions[window.replayOptionsIndex];
	window.lastReplaySpeedChange = Date.now();
};

// logic loop (for replay)
function replayLoop()
{
	if(typeof game !== "undefined" && game && game.replayMode)
	{
		for(var k = 0; k < window.replayOption.loops; k++)
			for(var i = game.replayIndex; i < playingReplay.length; i++)
			{
				// almost reached target position, stop fast forwarding
				if(game.fastForward && (game.interface_.fastForwardTo - 200) <= game.interface_.replayTimer)
				{
					game.fastForward = false;
					window.replayOptionsIndex = window.replayOptions.length - 3;
					window.replayOption = window.replayOptions[window.replayOptionsIndex];
				}
				
				// reached target position, back to normal speed
				if(game.interface_.fastForwardTo == game.interface_.replayTimer)
				{
					game.interface_.fastForwardTo = -1;
					window.replayOptionsIndex = window.oldReplayOptionsIndex;
					window.replayOption = window.replayOptions[window.replayOptionsIndex];
				}
				
				var splitMsg = playingReplay[i].split("$");
				handleNetworkMsg(playingReplay[i]);
				game.replayIndex = i + 1;
				
				if(splitMsg[0] == "upd")
				{
					game.interface_.replayTimer++;
					i = playingReplay.length;
				}
			}
	}
	
	window.setTimeout(replayLoop, window.replayOption.tickTime);
};
replayLoop();

// main loop, gets called by the imageLoaded() function, when all images are loaded and the game is ready
function mainLoop()
{
	rAF(mainLoop);

	// time stuff and fps output
	newTime = Date.now();
	timeDiff = newTime - timestamp;
	timestamp = newTime;

	if(game)
	{
		tickDiff = game.ticksCounter - lastFramesTick;
		lastFramesTick = game.ticksCounter;
		exactTickDiff = game.ticksCounter + Math.min((Date.now() - lastUpdate) / window.replayOption.tickTime, 1) - lastFramesExactTick;
		lastFramesExactTick = game.ticksCounter + Math.min((Date.now() - lastUpdate) / window.replayOption.tickTime, 1);

		if(game.mapWelcome)
		{
			if(Math.floor(newTime / 50) > Math.floor((newTime - timeDiff) / 50))
				game.receiveUpdate([]);

			if(game.cameraX < 0 || game.cameraY < 0 || game.cameraX2 > game.map.x || game.cameraY2 > game.map.y || (game.camFlyX == 0 && game.camFlyY == 0))
			{
				var angle = Math.random() * Math.PI * 2;

				game.camFlyX = Math.cos(angle) * 0.001;
				game.camFlyY = Math.sin(angle) * 0.001;
				game.cameraX = Math.random() * (game.map.x - WIDTH / FIELD_SIZE);
				game.cameraY = Math.random() * (game.map.y - HEIGHT / FIELD_SIZE);
			}

			else
			{
				game.cameraX += game.camFlyX * timeDiff;
				game.cameraY += game.camFlyY * timeDiff;
			}
		}
	}

	else
	{
		c.fillStyle = "black";
		c.fillRect(0, 0, WIDTH, HEIGHT);
	}

	if(document.getElementById("optionsWindow").style.display != "none")
		for(var i = 0; document.getElementById("hats_canvas_" + i); i++)
			refreshHatCanvasOld(document.getElementById("hats_canvas_" + i), hats[i]);

	if(game && game.mapWelcome && uiManager.canvasChangeSkinsButton)
        refreshHatCanvas(uiManager.canvasChangeSkinsButton, playerData.skin);

	// fps calculation
	timestampArchives.push(timestamp);
	if(Math.random() < 0.1)
		fps = Math.floor(10 * 1000 / (timestamp - timestampArchives[0]));
	timestampArchives.splice(0, 1);

	// draw everything
	if(game)
		yale();
	
	// ladder button
	if(searchingLadder)
	{
		let div = document.getElementById("ladderDivInner2");
		let countDots = (timestamp % 1000) / 251;
		let dotsStr = "";
		for(let i = 0; i < countDots; i++)
			dotsStr += ".";
		div.innerHTML = dotsStr + " searching " + dotsStr;
	}
};

function cancelLadder()
{
	if(searchingLadder)
	{
		soundManager.playSound(SOUND.CLICK);
		network.send("cancelLadder");
	}
	
	hideLadderButton();
};

function hideLadderButton()
{
	searchingLadder = false;
	document.getElementById("ladderDiv").style.display = "none";
};

function refreshHatCanvas(ca_, hat)
{
    ca_.width  = ca_.offsetWidth;
    ca_.height = ca_.offsetHeight;

	var
        imgs = window.imgs,
        noAnimate = ca_.getAttribute("data-no-animate") == "yes",
        c_ = ca_.getContext("2d"),
        baseSize = 32,
        scale = 3.7,
        scaledSize = Math.max(1, Math.round(baseSize * scale)),
        xOffset = -Math.round(baseSize/ 2),
        yOffset = -Math.round(baseSize/ 3),
        direction = 2,
        frame = noAnimate ? 1 : parseInt((window.newTime / 66 * 0.6) % 8);

	c_.mozImageSmoothingEnabled = false;
    c_.msimageSmoothingEnabled = false;
    c_.imageSmoothingEnabled = false;

    try {
        c_.drawImage(imgs.shadow, 0, 0, scaledSize, scaledSize, xOffset, yOffset, scaledSize, scaledSize); // shadow
	} catch (err) {

	}
	c_.drawImage(imgs.weaponsMinus, direction * baseSize, 0, baseSize, baseSize, ( Math.sin(frame * (Math.PI / 2)) * scale / 3 ) + xOffset, (-(frame % 2) * scale / 2) + yOffset, scaledSize, scaledSize); // weapons minuz
	c_.drawImage(imgs.legs, frame * baseSize, baseSize * direction + hat.legs * 288, baseSize, baseSize, xOffset, yOffset, scaledSize, scaledSize); // legz

	if(hat.hatOnly)
        c_.drawImage(imgs.heads, direction * baseSize, 0, baseSize, baseSize, xOffset, ( 0 - (frame % 2) * scale / 2 ) + yOffset, scaledSize, scaledSize); // head / hat

	c_.drawImage(imgs.heads, direction * baseSize, baseSize * hat.offset, baseSize, baseSize, xOffset, (0 - (frame % 2) * scale / 2) + yOffset, scaledSize, scaledSize); // head / hat
	c_.drawImage(imgs.weaponsPlus, direction * baseSize, 0, baseSize, baseSize, ( Math.sin(frame * (Math.PI / 2)) * scale / 2 ) + xOffset, (-(frame % 2) * scale / 1.8) + yOffset, scaledSize, scaledSize); // weapons pluz
}

function refreshHatCanvasOld(ca_, hat)
{
	var noAnimate = ca_.getAttribute("data-no-animate") == "yes";
	ca_.width = 164;
	ca_.height = 164;
	var c_ = ca_.getContext("2d");
	var scale = 5;

	c_.mozImageSmoothingEnabled = false;
    c_.msImageSmoothingEnabled = false;
	c_.imageSmoothingEnabled = false;

	// var direction = noAnimate ? 2 : (parseInt(newTime / 1933) % 8);
	var direction = 2;
	var frame = noAnimate ? 1 : parseInt((newTime / 66 * 0.6) % 8);

	c_.drawImage(imgs.shadow, 0, 0, 32 * scale, 32 * scale); // shadow
	c_.drawImage(imgs.weaponsMinus, direction * 32, 0, 32, 32, Math.sin(frame * (Math.PI / 2)) * scale / 3, -(frame % 2) * scale / 2, 32 * scale, 32 * scale); // weapons minuz
	c_.drawImage(imgs.legs, frame * 32, 32 * direction + hat.legs * 288, 32, 32, 0, 0, 32 * scale, 32 * scale); // legz
	if(hat.hatOnly)
		c_.drawImage(imgs.heads, direction * 32, 0, 32, 32, 0, 0 - (frame % 2) * scale / 2, 32 * scale, 32 * scale); // head / hat
	c_.drawImage(imgs.heads, direction * 32, 32 * hat.offset, 32, 32, 0, 0 - (frame % 2) * scale / 2, 32 * scale, 32 * scale); // head / hat
	c_.drawImage(imgs.weaponsPlus, direction * 32, 0, 32, 32, Math.sin(frame * (Math.PI / 2)) * scale / 2, -(frame % 2) * scale / 1.8, 32 * scale, 32 * scale); // weapons pluz
};

function imageTransforms()
{
	// create greyscaled miscsheet
	var canv = document.createElement('canvas');
	canv.height = imgs.miscSheet.height;
	canv.width = imgs.miscSheet.width;
	var ctx = canv.getContext('2d');
	ctx.drawImage(imgs.miscSheet, 0, 0);
	var imgData = ctx.getImageData(0, 0, canv.width, canv.height);

	for(var i = 0; i < imgData.data.length; i += 4)
	{
		var newValue = (imgData.data[i] + imgData.data[i + 1] + imgData.data[i + 2]) / 3;
		imgData.data[i] = newValue;
		imgData.data[i + 1] = newValue;
		imgData.data[i + 2] = newValue;
	}

	ctx.putImageData(imgData, 0, 0);
	imgs.miscSheetGrey = canv;

	// create whitescaled miscsheet
	canv = document.createElement('canvas');
	canv.height = imgs.miscSheet.height;
	canv.width = imgs.miscSheet.width;
	ctx = canv.getContext('2d');
	ctx.drawImage(imgs.miscSheet, 0, 0);
	imgData = ctx.getImageData(0, 0, canv.width, canv.height);

	for(var i = 0; i < imgData.data.length; i += 4)
	{
		imgData.data[i] = 255;
		imgData.data[i + 1] = 255;
		imgData.data[i + 2] = 255;
	}

	ctx.putImageData(imgData, 0, 0);
	imgs.miscSheetWhite = canv;

	var imgs_ = ["heads", "hands", "legs", "zombieDeath", "tileSheet", "rangedZombie", "crawler"];

	for(var k = 0; k < imgs_.length; k++)
	{
		var img = imgs[imgs_[k]];
		canv = document.createElement('canvas');
		ctx = canv.getContext('2d');
		canv.height = img.height;
		canv.width = img.width;
		ctx.drawImage(img, 0, 0);
		imgData = ctx.getImageData(0, 0, canv.width, canv.height);

		for(var i = 0; i < imgData.data.length; i += 4)
			if(imgData.data[i + 3] > 0)
			{
				imgData.data[i] = 0;
				imgData.data[i + 1] = 0;
				imgData.data[i + 2] = 0;
			}

		ctx.putImageData(imgData, 0, 0);

		imgs[imgs_[k] + "Black"] = canv;

		// white
		canv = document.createElement('canvas');
		ctx = canv.getContext('2d');
		canv.height = img.height;
		canv.width = img.width;

		for(var i = 0; i < imgData.data.length; i += 4)
			if(imgData.data[i + 3] > 0)
			{
				imgData.data[i] = 255;
				imgData.data[i + 1] = 255;
				imgData.data[i + 2] = 255;
			}

		ctx.putImageData(imgData, 0, 0);

		imgs[imgs_[k] + "White"] = canv;
	}

	// make tiles avg colors (for minimap)
	for(var i = 0; i < tileTypes.length; i++)
		if(!tileTypes[i].hideOnMinimap)
		{
			var img = tileTypes[i].img;
			canv = document.createElement('canvas');
			ctx = canv.getContext('2d');
			canv.width = img.w;
			canv.height = img.h;
			ctx.drawImage(imgs.tileSheet, img.x, img.y, img.w, img.h, 0, 0, img.w, img.h);

			imgData = ctx.getImageData(0, 0, canv.width, canv.height);

			var r_ = 0;
			var g_ = 0;
			var b_ = 0;
			var counter_ = 0;

			for(var k = 0; k < imgData.data.length; k += 8)
				if(imgData.data[k + 3] > 0)
				{
					r_ += imgData.data[k];
					g_ += imgData.data[k + 1];
					b_ += imgData.data[k + 2];
					counter_++;
				}

			if(counter_ > 0)
				tileTypes[i].avgColor = "rgb(" + Math.floor(r_ / counter_) + ", " + Math.floor(g_ / counter_) + ", " + Math.floor(b_ / counter_) + ")";
		}
};

// loads an image and returns the image object. Also increments the ressourcesToLoad variable. This gets decremented when img is loaded, so we can check this variable and only start the game when its 0
function loadImage(imgFile)
{
    ressourcesToLoad++;

    var img = new Image();

    img.onload = function() { ressourceLoaded(img); };
    img.crossOrigin = "Anonymous";
    img.src = imgFile;
    img.srcCpy = imgFile; // in case we must load img again, store the path

    return img;
};

function isTutored(tutorialId) {
	return false;
};

function startTutorial() {
    var respTimeout = setTimeout(function () {
        clearTimeout(respTimeout);
        slayOne.viewHelpers.showFloatTip({
            tipType: 'error',
            content: slayOne.widgets.lang.get('msg.error_wait_too_long')
        });
    }, 10000);

    var respFailCb = function (failMessage) {
        clearTimeout(respTimeout);
    };
    
    var respSuccessCb = function () {
        clearTimeout(respTimeout);
    };

    window.joinGamePurpose = 'play';
	network.send([
		"create-game",
		TUTORIALS[1].mapId,
		1,
		1,
		TUTORIALS[1].mapType
	].join("$"));
};

// decreses the ressourcesToLoad counter and and starts the game if all ress are loaded
function ressourceLoaded(img)
{
	// if not loaded, try again
	if(img && (!img.complete || !(img.width > 0))) {
		img.src = "";
		img.src = img.srcCpy;
		return;
	}

	ressourcesToLoad--;

	// if all images are loaded, do some final stuff and then start the game
	if(ressourcesToLoad == 0) {
		// initialize langualge object nad then start game flow
		slayOne.widgets.lang.initialize(function(){
			imageTransforms();
			renderMainMenu_(document.body);
			game = new Game(map1);
			network = new Network();
			rAF(mainLoop);
		});
	}
};

function copyInput(input) {
    input.select();

    try {
        var successful = document.execCommand('copy');
        if (successful) {
            slayOne.viewHelpers.showFloatTip({
                tipType: 'success',
                content: slayOne.widgets.lang.get("msg.copy_ok"),
                duration: 2000
            });
        } else {
            slayOne.viewHelpers.showFloatTip({
                tipType: 'error',
                content: slayOne.widgets.lang.get("msg.copy_fail"),
            });
        }
    } catch (err) {
        slayOne.viewHelpers.showFloatTip({
            tipType: 'error',
            content: slayOne.widgets.lang.get("msg.copy_fail_with_reason", {
                reason: err.toString()
            }),
        });
    }
};

function shareToTwiter(link)
{
    if(!link)
        return;
    
    window.open(
        'http://twitter.com/share?text=' + encodeURIComponent(F_("slogan.twitter")) + '&url=' + encodeURIComponent(link),
        'tweet',
        'height=300,width=550,resizable=1'
    );
};

function shareToFacebook(link)
{
    if(!link)
    	return;
	
	var fbShareUrl = "https://www.facebook.com/dialog/share?app_id=353276591718040&display=popup&href=" + encodeURIComponent(link);
	var rect = document.body.getBoundingClientRect();
	window.open(fbShareUrl, 'fbShareWindow', 'height=450, width=550, top=' + (rect.height / 2 - 275) + ', left=' + (rect.width / 2 - 225) + ', toolbar=0, location=0, menubar=0, directories=0, scrollbars=0');
};

function getClanLink(clanTag)
{	/*
    if(FacebookUtils.embeddedInCanvas)
        return FacebookUtils.appURL + "?clan=" + clanTag;
    else
    */
        return window.location.origin + "/?clan=" + clanTag;
};

function getCurrentGameLink()
{
    if(game && game.map != map1)
    {
    	var url;
    	/*
        if(FacebookUtils.embeddedInCanvas)
        	url = FacebookUtils.appURL;
		else
		*/
        	url = window.location.href;
        
		url += "?server=" + network.connectedServerIndex + "&game=" + game.id;
        // if(game.mode)
        //    url = url + "&mode=" + game.mode;
        
        return url;
    }
    
    return "";
};

function openGameShare()
{
	F$('gameShare').show();
};

function floatEqual(a, b) {
    var tolerant = 0.0001;
    var diff = a - b;
    return diff < tolerant && diff > -tolerant;
};

var docCookies = {
    getItem: function (sKey) {
        if (!sKey) { return null; }
        return decodeURIComponent(document.cookie.replace(new RegExp("(?:(?:^|.*;)\\s*" + encodeURIComponent(sKey).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\=\\s*([^;]*).*$)|^.*$"), "$1")) || null;
    },
    setItem: function (sKey, sValue, vEnd, sPath, sDomain, bSecure) {
        if (!sKey || /^(?:expires|max\-age|path|domain|secure)$/i.test(sKey)) { return false; }
        var sExpires = "";
        if (vEnd) {
            switch (vEnd.constructor) {
                case Number:
                    sExpires = vEnd === Infinity ? "; expires=Fri, 31 Dec 9999 23:59:59 GMT" : "; max-age=" + vEnd;
                    break;
                case String:
                    sExpires = "; expires=" + vEnd;
                    break;
                case Date:
                    sExpires = "; expires=" + vEnd.toUTCString();
                    break;
            }
        }
        document.cookie = encodeURIComponent(sKey) + "=" + encodeURIComponent(sValue) + sExpires + (sDomain ? "; domain=" + sDomain : "") + (sPath ? "; path=" + sPath : "") + (bSecure ? "; secure" : "");
        return true;
    },
    removeItem: function (sKey, sPath, sDomain) {
        if (!this.hasItem(sKey)) { return false; }
        document.cookie = encodeURIComponent(sKey) + "=; expires=Thu, 01 Jan 1970 00:00:00 GMT" + (sDomain ? "; domain=" + sDomain : "") + (sPath ? "; path=" + sPath : "");
        return true;
    },
    hasItem: function (sKey) {
        if (!sKey) { return false; }
        return (new RegExp("(?:^|;\\s*)" + encodeURIComponent(sKey).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\=")).test(document.cookie);
    },
    keys: function () {
        var aKeys = document.cookie.replace(/((?:^|\s*;)[^\=]+)(?=;|$)|^\s*|\s*(?:\=[^;]*)?(?:\1|$)/g, "").split(/\s*(?:\=[^;]*)?;\s*/);
        for (var nLen = aKeys.length, nIdx = 0; nIdx < nLen; nIdx++) { aKeys[nIdx] = decodeURIComponent(aKeys[nIdx]); }
        return aKeys;
    }
};

function drawHat(canvas, hat, scale, direction, width, height)
{
	if(!window.imgs)
		return;
	
    var frame = 1;
    
    canvas.fillStyle = "rgba(0, 0, 0, 0)";
    canvas.clearRect(0, 0, width, height);
    canvas.drawImage(imgs.shadow, 0, 0, 32 * scale, 32 * scale); // shadow
    canvas.drawImage(imgs.weaponsMinus, direction * 32, 0, 32, 32, Math.sin(frame * (Math.PI / 2)) * scale / 3, -(frame % 2) * scale / 2, 32 * scale, 32 * scale); // weapons minuz
    canvas.drawImage(imgs.legs, frame * 32, 32 * direction + hat.legs * 288, 32, 32, 0, 0, 32 * scale, 32 * scale); // legz
    if (hat.hatOnly)
        canvas.drawImage(imgs.heads, direction * 32, 0, 32, 32, 0, 0 - (frame % 2) * scale / 2, 32 * scale, 32 * scale); // default head (if required)
    canvas.drawImage(imgs.heads, direction * 32, 32 * hat.offset, 32, 32, 0, 0 - (frame % 2) * scale / 2, 32 * scale, 32 * scale); // head / hat
    canvas.drawImage(imgs.weaponsPlus, direction * 32, 0, 32, 32, Math.sin(frame * (Math.PI / 2)) * scale / 2, -(frame % 2) * scale / 1.8, 32 * scale, 32 * scale); // weapons plu
};
