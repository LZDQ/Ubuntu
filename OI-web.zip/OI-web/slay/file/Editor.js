function Editor()
{
	this.currentObj = null;
	this.selectedUnits = [];
	this.ammo = [];
	this.scroll = false;
	this.currentAddedFields = [];
	this.noClick = false;
	this.brushSize = 1;
	if(game.map.ammo)
		for(var i = 0; i < game.map.ammo.length; i++)
			this.ammo.push({
				weapon: game.map.ammo[i].weapon,
				x: game.map.ammo[i].x,
				y: game.map.ammo[i].y
			});

	// create div that contains all the elements
	if(!document.getElementById("editorElementsDiv"))
	{
		var div = document.createElement("div");
		div.id = "editorElementsDiv";
		document.body.appendChild(div);
		div.setAttribute("data-noclick", 'yes');
		div.innerHTML = "<div data-noclick='yes'>Ground Textures</div><div data-noclick='yes' id='editorElementsDivGround'></div>";
		div.innerHTML += "<div data-noclick='yes'>Map Objects</div><div data-noclick='yes' id='editorElementsDivTiles'></div>";
		div.innerHTML += "<div data-noclick='yes'>Ammo</div><div data-noclick='yes' id='editorElementsDivAmmo'></div>";
		div.innerHTML += "<div data-noclick='yes'>Items</div><div data-noclick='yes' id='editorElementsDivItems'></div>";

		var editorElementsDivGround = document.getElementById("editorElementsDivGround");
		var editorElementsDivTiles = document.getElementById("editorElementsDivTiles");
		var editorElementsDivAmmo = document.getElementById("editorElementsDivAmmo");
		var editorElementsDivItems = document.getElementById("editorElementsDivItems");

		for(var i = 0; i < tileTypes.length; i++)
			if(!tileTypes[i].noShow)
			{
				var cv = getCanvasFromImgObj(tileTypes[i].img, imgs.tileSheet, 58);
				uiManager.createButton("<img class='pixelated' src='" + cv.toDataURL() + "' />", "editorButton", function(){
					game.editor.currentObj = tileTypes[this.name.split("_")[1]];
					document.getElementById('editorElementsDiv').style.display = "none";
				}, null, tileTypes[i].ground ? editorElementsDivGround : editorElementsDivTiles, null, function(){ uiManager.showEditorInfo(this.getAttribute('data-att1')); }, uiManager.hideEditorInfo, "obj_" + i, tileTypes[i].name);
			}

		for(var i = 0; i < weapons.length; i++)
			if(weapons[i].clipSize)
			{
				var cv = getCanvasFromImgObj(imgCoords[weapons[i].img], imgs.miscSheet, 58);
				uiManager.createButton("<img class='pixelated' src='" + cv.toDataURL() + "' />", "editorButton", function(){
					game.editor.currentObj = this.name;
					document.getElementById('editorElementsDiv').style.display = "none";
				}, null, editorElementsDivAmmo, null, function(){ uiManager.showEditorInfo(this.getAttribute('data-att1')); }, uiManager.hideEditorInfo, "ammo_" + i, weapons[i].name);
			}

		for(var i = 0; i < itemTypes.length; i++)
		{
			var cv = getCanvasFromImgObj(itemTypes[i].img, imgs.miscSheet, 58);
			uiManager.createButton("<img class='pixelated' src='" + cv.toDataURL() + "' />", "editorButton", function(){
				game.editor.currentObj = this.name;
				document.getElementById('editorElementsDiv').style.display = "none";
			}, null, editorElementsDivItems, null, function(){ uiManager.showEditorInfo(this.getAttribute('data-att1')); }, uiManager.hideEditorInfo, "ammo_" + (i + 1000), itemTypes[i].name);
		}

		var cv = getCanvasFromImgObj(imgCoords.spawningPoint, imgs.tileSheet, 58);
		uiManager.createButton("<img class='pixelated' src='" + cv.toDataURL() + "' />", "editorButton", function(){
			game.editor.currentObj = "spawningPoint";
			document.getElementById('editorElementsDiv').style.display = "none";
		}, null, editorElementsDivItems, null, function(){ uiManager.showEditorInfo(this.getAttribute('data-att1')); }, uiManager.hideEditorInfo, null, "Spawning Point");

		cv = getCanvasFromImgObj(imgCoords.spawningPointRed, imgs.tileSheet, 58);
		uiManager.createButton("<img class='pixelated' src='" + cv.toDataURL() + "' />", "editorButton", function(){
			game.editor.currentObj = "spawningPointRed";
			document.getElementById('editorElementsDiv').style.display = "none";
		}, null, editorElementsDivItems, null, function(){ uiManager.showEditorInfo(this.getAttribute('data-att1')); }, uiManager.hideEditorInfo, null, "Spawning Point Red");

		cv = getCanvasFromImgObj(imgCoords.spawningPointBlue, imgs.tileSheet, 58);
		uiManager.createButton("<img class='pixelated' src='" + cv.toDataURL() + "' />", "editorButton", function(){
			game.editor.currentObj = "spawningPointBlue";
			document.getElementById('editorElementsDiv').style.display = "none";
		}, null, editorElementsDivItems, null, function(){ uiManager.showEditorInfo(this.getAttribute('data-att1')); }, uiManager.hideEditorInfo, null, "Spawning Point Blue");

		cv = getCanvasFromImgObj(imgCoords.waypoint, imgs.tileSheet, 58);
		uiManager.createButton("<img class='pixelated' src='" + cv.toDataURL() + "' />", "editorButton", function(){
			game.editor.currentObj = "waypoint";
			document.getElementById('editorElementsDiv').style.display = "none";
		}, null, editorElementsDivItems, null, function(){ uiManager.showEditorInfo(this.getAttribute('data-att1')); }, uiManager.hideEditorInfo, null, "Waypoint (for bots)");

		var div2 = document.createElement("div");
		div2.id = "editorDiv2";
		document.body.appendChild(div2);

		uiManager.createButton("Select [<span class='red'>R</span>]", "editorButton2", function(){ game.editor.currentObj = null; soundManager.playSound(SOUND.CLICK); }, null, div2);
		uiManager.createButton("New map", "editorButton2", function(){ game.editor.showNewMapWindow(); }, null, div2);
		uiManager.createButton("Map Settings", "editorButton2", function(){ game.editor.showMapSettingsWindow(); }, null, div2);
		uiManager.createButton("Upload map", "editorButton2", function(){ game.editor.uploadMap(); }, null, div2);
		uiManager.createButton("Load map", "editorButton2", function(){ showLoadMapWindow(); }, null, div2);
		uiManager.createButton("Objects [<span class='red'>Q</span>]", "editorButton2", function(){
			document.getElementById("editorElementsDiv").style.display = (document.getElementById("editorElementsDiv").style.display != "block") ? "block" : "none";
		}, null, div2);
		uiManager.createButton("Save to file", "editorButton2", function(){ game.editor.save(); }, null, div2);
	}

	else
	{
		document.getElementById("editorDiv2").style.display = "block";
	}
};

Editor.prototype.showNewMapWindow = function() {
	this.fillMapSettingsWindow(true);
	uiManager.createButton("create", null, game.editor.createMap, null, mapSettingsWindow, "mapSettingsCloseButton");
	document.getElementById("mapSettingsWindow").style.display = "inline";
};

Editor.prototype.showMapSettingsWindow = function() {
	this.fillMapSettingsWindow();
	uiManager.createButton("save", null, game.editor.saveMapSettings, null, mapSettingsWindow, "mapSettingsCloseButton");
	document.getElementById("mapSettingsWindow").style.display = "inline";
};

Editor.prototype.fillMapSettingsWindow = function(newMap) {
	var noBorderChecked = (!newMap && game.map.noBorder) ? " checked='checked' " : "";
	var invisChecked = (!newMap && game.map.invisible) ? " checked='checked' " : "";
	var closedChecked = (!newMap && game.map.closed) ? " checked='checked' " : "";

	var str = "Name <input type='text' id='mapNameInput' value='" + (newMap ? "unnamed" : game.map.name) + "' /><br /><textarea style='width: 350px; height: 150px;' id='mapDescriptionInput'>";
	str += (newMap ? "" : game.map.description )+ "</textarea><br />X: <input id='mapX' class='mapSizeInput' type='text' value='" + (newMap ? 48 : game.map.x) + "' /> Y: ";
	str += "<input id='mapY' class='mapSizeInput' type='text' value='" + (newMap ? 48 : game.map.y) + "' /><br /><label title='If this is checked, the map will have no wall border by default.'>";
	str += "No border: <input type='checkbox' " + noBorderChecked + " id='mapNoBorder' /></label><br />";
	str += "<label title='Invisible maps can not be seen by anyone but you. You can use this for \"work in progress\" maps for exmaple.'>Invisible: <input type='checkbox' " + invisChecked + " id='mapInvisible' /></label><br />";
	str += "<label title='Closed maps can not be loaded in the map editor by other players.'>Closed: <input type='checkbox' " + closedChecked + " id='mapClosed' /></label><br />";
	str += "Max players: <input id='mapMaxPlayers' class='mapSizeInput' type='text' value='" + ((newMap || !game.map.maxPlayers) ? 10 : game.map.maxPlayers) + "' /><br />";
	mapSettingsWindow.innerHTML = str;

	var dd = document.createElement("select");
	dd.id = "mapTypeDD";
	for(var i = 0; i < MAP_TYPE_SETTINGS.length; i++)
		dd.innerHTML += "<option " + ((!newMap && game.map.type == i) ? " selected='selected' " : "") + ">" + MAP_TYPE_SETTINGS[i].name + "</option>";

	mapSettingsWindow.appendChild(dd);
	mapSettingsWindow.appendChild(uiManager.createCloseButton());
};

Editor.prototype.saveMapSettings = function()
{
	var oldBorderState = game.map.noBorder;

	document.getElementById("mapSettingsWindow").style.display = "none";
	game.map.name = document.getElementById("mapNameInput").value;
	game.map.description = document.getElementById("mapDescriptionInput").value;
	game.map.x = Math.min(Math.max(parseInt(document.getElementById("mapX").value), CONST.MIN_MAP_SIZE), CONST.MAX_MAP_SIZE);
	game.map.y = Math.min(Math.max(parseInt(document.getElementById("mapY").value), CONST.MIN_MAP_SIZE), CONST.MAX_MAP_SIZE);
	game.map.maxPlayers = Math.min(Math.max(parseInt(document.getElementById("mapMaxPlayers").value), 1), 24);
	game.map.closed = document.getElementById("mapClosed").checked;
	game.map.invisible = document.getElementById("mapInvisible").checked;
	game.map.noBorder = document.getElementById("mapNoBorder").checked;
	game.map.type = document.getElementById("mapTypeDD").selectedIndex;
	game.createGroundCanvas();
	game.createBlockArray();
	soundManager.playSound(SOUND.CLICK);

	if(game.map.noBorder && !oldBorderState)
	{
		for(var k = 0; k < game.tiles.length; k++)
			if(tileIsBorder(game.tiles[k]))
			{
				game.tiles.splice(k, 1);
				k--;
			}

		game.generateTilesCanvasses();
	}

	if(!game.map.noBorder && oldBorderState)
	{
		game.createDefaultBorder();
		game.generateTilesCanvasses();
	}
};

Editor.prototype.createMap = function()
{
	document.getElementById("mapSettingsWindow").style.display = "none";
	soundManager.playSound(SOUND.CLICK);

	var map = {
		x: Math.max(parseInt(document.getElementById("mapX").value), 8),
		y: Math.max(parseInt(document.getElementById("mapY").value), 8),
		maxPlayers: Math.min(Math.max(parseInt(document.getElementById("mapMaxPlayers").value), 1), 16),
		closed: document.getElementById("mapClosed").checked,
		invisible: document.getElementById("mapInvisible").checked,
		name: document.getElementById("mapNameInput").value,
		description: document.getElementById("mapDescriptionInput").value,
		noBorder: document.getElementById("mapNoBorder").checked,
		tiles: [],
		defaultTiles: 0,
		groundTiles: [],
		type: document.getElementById("mapTypeDD").selectedIndex
	};

	game = new Game(map, true);
	game.editor = new Editor();
	game.startEditingMode();

	uiManager.refreshMenuButtons();
};

Editor.prototype.uploadMap = function()
{
    slayOne.viewHelpers.showFloatTip({
        tipType: 'success', content: "Request uploading map"
    });
    var that = this;

    F$ajax.options("/map/" + game.map.name, function(res) {
	    if(res.status >= 200 && res.status < 300 && res.getResponseHeader("Allow").split(/\s*,\s*/).indexOf("PUT") >= 0)
			that.uploadMap2(res.getResponseHeader("ETag"));
		else
            slayOne.viewHelpers.showFloatTip({
                tipType: 'error', content: res.responseText
            });
	});

	// network.send("map-upl-1$" + game.map.name);
	soundManager.playSound(SOUND.CLICK);
};

Editor.prototype.killMap = function(mapName)
{
    slayOne.viewHelpers.showFloatTip({
        tipType: 'success', content: "Request deleting map"
    });
    var that = this;
    this.map2Kill = mapName;

    F$ajax.options("/map/" + game.editor.map2Kill, function(res) {
	    if(res.status >= 200 && res.status < 300 && res.getResponseHeader("Allow").split(/\s*,\s*/).indexOf("PUT") >= 0)
			that.killMap2(res.getResponseHeader("ETag"));
		else
            slayOne.viewHelpers.showFloatTip({
                tipType: 'error', content: res.responseText
            });
	});

	// network.send("map-upl-1$" + game.map.name);
	soundManager.playSound(SOUND.CLICK);
};

Editor.prototype.killMap2 = function(lastVersion)
{
    slayOne.viewHelpers.showFloatTip({
        tipType: 'success', content: "Deleting map."
    });

    var headers = {
        "Content-type": 'application/json'
	};

    if(lastVersion)
    	headers["If-Match"] = lastVersion;

    F$ajax.put("/map/" + game.editor.map2Kill,
		function(res)
		{
        	if(res.status == 204)
                slayOne.viewHelpers.showFloatTip({
                    tipType: 'success', content: "No change"
                });
			else if(res.status == 201)
                slayOne.viewHelpers.showFloatTip({
                    tipType: 'success', content: "Map uploaded"
                });
			else
                slayOne.viewHelpers.showFloatTip({
                    tipType: 'error', content: res.responseText
                });
    	},
		"kill",
        headers
	);
};

Editor.prototype.uploadMap2 = function(lastVersion)
{
    slayOne.viewHelpers.showFloatTip({
        tipType: 'success', content: "Uploading map, it will take about 10 - 20 seconds."
    });

    var headers = {
        "Content-type": 'application/json'
	};

    if (lastVersion) {
    	headers["If-Match"] = lastVersion;
	}

    F$ajax.put("/map/" + game.map.name,
		function(res)
		{
        	if(res.status == 204)
                slayOne.viewHelpers.showFloatTip({
                    tipType: 'success', content: "No change"
                });
			else if(res.status == 201)
                slayOne.viewHelpers.showFloatTip({
                    tipType: 'success', content: "Map uploaded"
                });
			else
                slayOne.viewHelpers.showFloatTip({
                    tipType: 'error', content: res.responseText
                });
    	},
		game.editor.export_(),
        headers
	);
};

function showLoadMapWindow()
{
	soundManager.playSound(SOUND.CLICK);
	// network.send("req-map-list");

    F$ajax.get("/map/", function(res) {
        if (res.status == 200) {
            showLoadMapWindow2(JSON.parse(res.responseText));
        } else {
            slayOne.viewHelpers.showFloatTip({
                tipType: 'error', content: res.responseText
            });
        }
    });

};

function showLoadMapWindow2(data)
{
	var div = document.getElementById("logindiv");

	var str = "<div id='maps_inner'><table class='basicTable' style='margin-top: 20px;'>";
	for(var i = 0; i < data.length; i ++)
		str += "<tr><td>" + data[i].name + " (" + data[i].id + ")</td><td><button class='withClickSound' onclick='requestMap4Editor(" + data[i].id + ");'>load</button></td></tr>";

	div.innerHTML = str + "</div></table>";

	if(game && game.editingMode)
		div.appendChild(uiManager.createCloseButton());

	else
		uiManager.createButton("back", "backButton", function(){
			uiManager.showMainScene();
		}, null, div);

	// Load External Map Button
	uiManager.createButton("Load external", null, function(){

		// create new input and simulate a click on it and set function
		var fileInput = document.createElement("input");
		fileInput.type = "file";
		fileInput.click();

		fileInput.onchange = function()
		{
			var file = fileInput.files[0];
			if(file)
			{
				var reader = new FileReader();
				reader.readAsBinaryString(file);
				reader.onload = function(e){

					setTimeout(function(){

						var map = JSON.parse(e.target.result);

						game = new Game(map, true);
						game.editor = new Editor();
						game.startEditingMode();

						game.map.description = map.description;
						game.map.name = map.name;

						uiManager.refreshMenuButtons();

						document.getElementById("logindiv").style.display = "none";

					}, 50);
				};
			}
		};
	
	}, null, div, "loadExternalButton");
	
	div.className = "basicWindow logindiv1";
	div.style.display = "inline";
};

function requestMap4Editor(mapID) {
    F$ajax.get("/map/" + mapID, function(res) {
        if (res.status == 200) {
            map4Editor(res.responseText);
            // showLoadMapWindow2(JSON.parse(res.responseText));
        } else {
            slayOne.viewHelpers.showFloatTip({
                tipType: 'error', content: res.responseText
            });
        }
    });
	// network.send("req-map-4-e$" + mapID);
};

function map4Editor(data)
{
    enterGame();

    var map = null;

    try
    {
        map = JSON.parse(data);
    }
    catch(e)
    {
        console.log(e);
        return;
    }

    game = new Game(map, true);
    game.editor = new Editor();
    game.startEditingMode();

    uiManager.refreshMenuButtons();
};

function enterGame(msg)
{
    window.slayOne.views.homeScreen.hideWindow();
    F$('resourceBar').hide();
	document.getElementById("optionsWindow").style.display = "none";
	uiManager.hideDeathScreen();
	slayOne.viewHelpers.hideAd();
	window.focus();
};

Editor.prototype.export_ = function()
{
	var map_ = {
		name : game.map.name,
		description: game.map.description,
		x: game.map.x,
		y: game.map.y,

		maxPlayers: game.map.maxPlayers,
		closed: game.map.closed,
		invisible: game.map.invisible,

		defaultTiles: 0,

		tiles: [],
		groundTiles: [],
		noGridTiles: [],

		spawningPoints: game.spawningPoints,
		spawningPointsRed: game.spawningPointsRed,
		spawningPointsBlue: game.spawningPointsBlue,

		waypoints: game.waypoints,

		tutorialMessages: game.map.tutorialMessages,
		special: game.map.special,

		type: game.map.type,

		ammo: this.ammo,

		noBorder: game.map.noBorder

	};

	for(var i = 0; i < game.groundTiles.length; i++)
		map_.groundTiles.push(createTileForExport(game.groundTiles[i]));

	for(var i = 0; i < game.tiles.length; i++)
		if(!tileIsBorder(game.tiles[i]))
			map_.tiles.push(createTileForExport(game.tiles[i]));

	if(game.noGridTiles)
		for(var i = 0; i < game.noGridTiles.length; i++)
			map_.noGridTiles.push(createTileForExport(game.noGridTiles[i]));

    var minimap = new Minimap(game);
    map_.thumbnail = minimap.canvas.toDataURL('image/jpeg', 0.9);

	return JSON.stringify(map_);
};

function tileIsBorder(tile)
{
	return (((tile.x == -1 || tile.x == game.map.x) && tile.y >= -1 && tile.y <= game.map.y) || ((tile.y == -1 || tile.y == game.map.y) && tile.x >= -1 && tile.x <= game.map.x)) && tile.type.isBorder;
};

function createTileForExport(o)
{
	var tile = {
		x: o.x,
		y: o.y,
		id: o.type.id
	};

	if(o.type.editable)
		for(var i = 0; i < o.type.editable.length; i++)
			tile[o.type.editable[i]] = parseFloat(typeof o[o.type.editable[i]] !== "undefined" ? o[o.type.editable[i]] : o.type[o.type.editable[i]]);

	return tile;
};

Editor.prototype.save = function()
{
	var blob = new Blob([this.export_()], {type: "text/plain;charset=utf-8"});
	saveAs(blob, "map.js");
	soundManager.playSound(SOUND.CLICK);
};

Editor.prototype.key = function(key, el)
{
	if(key == commandKeys[COMMAND.UP] || key == commandKeys[COMMAND.DOWN] || key == commandKeys[COMMAND.LEFT] || key == commandKeys[COMMAND.RIGHT])
		this.scroll = true;

	if(key == KEY.Q)
	{
		document.getElementById("editorElementsDiv").style.display = (document.getElementById("editorElementsDiv").style.display != "block") ? "block" : "none";
		soundManager.playSound(SOUND.CLICK);
	}

	if(key == KEY.R)
	{
		this.currentObj = null;
		soundManager.playSound(SOUND.CLICK);
	}

	// key brush sizes
	if(key == KEY.NUM1)
	{
		this.brushSize = 1;
		soundManager.playSound(SOUND.SWITCH, undefined, undefined, 0.7);
	}

	else if(key == KEY.NUM2)
	{
		this.brushSize = 2;
		soundManager.playSound(SOUND.SWITCH, undefined, undefined, 0.7);
	}

	else if(key == KEY.NUM3)
	{
		this.brushSize = 3;
		soundManager.playSound(SOUND.SWITCH, undefined, undefined, 0.7);
	}

	else if(key == KEY.NUM4)
	{
		this.brushSize = 4;
		soundManager.playSound(SOUND.SWITCH, undefined, undefined, 0.7);
	}

	else if(key == KEY.NUM5)
	{
		this.brushSize = 5;
		soundManager.playSound(SOUND.SWITCH, undefined, undefined, 0.7);
	}

	else if(key == KEY.E)
	{
		if(this.selectedUnits.length > 0)
			soundManager.playSound(SOUND.PLACE);

		for(var i = 0; i < this.selectedUnits.length; i++)
		{
			var found = false;

			for(var k = 0; k < game.tiles.length; k++)
				if(game.tiles[k] == this.selectedUnits[i])
				{
					game.tiles.splice(k, 1);

					if(this.selectedUnits[i].type.blockVision)
					{
						for(var j = 0; j < game.objectsToDraw.length; j++)
							if(this.selectedUnits[i] == game.objectsToDraw[j].tile)
							{
								game.objectsToDraw.splice(j, 1);
								j = game.objectsToDraw.length;
							}
					}
					else
						game.refreshBlockingTilesCanvas(this.selectedUnits[i].y + this.selectedUnits[i].type.h - 1);

					this.selectedUnits.splice(i, 1);
					k = game.tiles.length;
					i--;
					found = true;
					game.createBlockArray();
				}

			if(!found)
				for(var k = 0; k < game.groundTiles.length; k++)
					if(game.groundTiles[k] == this.selectedUnits[i])
					{
						game.groundTiles.splice(k, 1);
						this.selectedUnits.splice(i, 1);
						k = game.groundTiles.length;
						i--;
						game.createGroundCanvas();
						found = true;
						game.createBlockArray();
					}

			if(!found)
				for(var k = 0; k < game.objectsToDraw.length; k++)
					if(game.objectsToDraw[k] == this.selectedUnits[i])
					{
						game.noGridTiles.erease(game.objectsToDraw[k]);
						game.objectsToDraw.splice(k, 1);
						this.selectedUnits.splice(i, 1);
						k = game.objectsToDraw.length;
						i--;
						found = true;
					}

			if(!found)
				for(var k = 0; k < game.spawningPoints.length; k++)
					if(game.spawningPoints[k] == this.selectedUnits[i])
					{
						game.spawningPoints.splice(k, 1);
						this.selectedUnits.splice(i, 1);
						k = game.spawningPoints.length;
						i--;
						found = true;
					}

			if(!found)
				for(var k = 0; k < game.spawningPointsRed.length; k++)
					if(game.spawningPointsRed[k] == this.selectedUnits[i])
					{
						game.spawningPointsRed.splice(k, 1);
						this.selectedUnits.splice(i, 1);
						k = game.spawningPointsRed.length;
						i--;
						found = true;
					}

			if(!found)
				for(var k = 0; k < game.spawningPointsBlue.length; k++)
					if(game.spawningPointsBlue[k] == this.selectedUnits[i])
					{
						game.spawningPointsBlue.splice(k, 1);
						this.selectedUnits.splice(i, 1);
						k = game.spawningPointsBlue.length;
						i--;
						found = true;
					}

			if(!found)
				for(var k = 0; k < game.waypoints.length; k++)
					if(game.waypoints[k] == this.selectedUnits[i])
					{
						game.waypoints.splice(k, 1);
						this.selectedUnits.splice(i, 1);
						k = game.waypoints.length;
						i--;
					}

			if(!found)
				for(var k = 0; k < this.ammo.length; k++)
					if(this.ammo[k] == this.selectedUnits[i])
					{
						this.ammo.splice(k, 1);
						this.selectedUnits.splice(i, 1);
						k = this.ammo.length;
						i--;
					}
		}
	}

	this.refreshItemInfo();
};

Editor.prototype.addTile = function(pos)
{
	this.currentAddedFields.push({x: pos.x, y: pos.y});

	if(typeof this.currentObj === 'string')
	{
		if(this.currentObj == "waypoint")
			game.waypoints.push({x: pos.x, y: pos.y});

		else if(this.currentObj == "spawningPoint")
			game.spawningPoints.push({x: pos.x, y: pos.y});

		else if(this.currentObj == "spawningPointRed")
			game.spawningPointsRed.push({x: pos.x, y: pos.y});

		else if(this.currentObj == "spawningPointBlue")
			game.spawningPointsBlue.push({x: pos.x, y: pos.y});

		else if(this.currentObj.substr(0, 4) == "ammo")
			this.ammo.push({
				x: pos.x,
				y: pos.y,
				weapon: parseInt(this.currentObj.split("_")[1])
			});
	}

	else if(this.currentObj.noGrid)
	{
		var x = game.cameraX + KeyManager.x / FIELD_SIZE;
		var y = game.cameraY + KeyManager.y / FIELD_SIZE;

		new Tile(x, y, this.currentObj);
	}

	else if(this.currentObj.ground)
	{
		for(var x = -this.brushSize + 1; x < this.brushSize; x++)
			for(var y = -this.brushSize + 1; y < this.brushSize; y++)
				if(true)
				{
					var obj = this.currentObj.collection ? (tileTypes[this.currentObj.id + this.currentObj.collection[Math.floor(Math.random() * this.currentObj.collection.length)]]) : this.currentObj;

					// wenn voll (also komplett 16x16 verdeckend), dann andere ground tiles auf dieser posi löschen, damit nicht mehrere übereinander
					if(!obj.isNotFull)
						for(var i = 0; i < game.groundTiles.length; i++)
							if(game.groundTiles[i].x == (pos.x + x) && game.groundTiles[i].y == (pos.y + y))
							{
								game.groundTiles.splice(i, 1);
								i--;
							}

					game.groundTiles.push(createTile({
						x: pos.x + x,
						y: pos.y + y,
						id: obj.id
					}));
				}

		game.createGroundCanvas();
		game.createBlockArray();
	}

	else
	{
		var obj = this.currentObj.collection ? (tileTypes[this.currentObj.id + this.currentObj.collection[Math.floor(Math.random() * this.currentObj.collection.length)]]) : this.currentObj;

		game.tiles.push(createTile({
			x: pos.x,
			y: pos.y,
			id: obj.id
		}));

		if(obj.blockVision)
			game.createVisionTile(game.tiles[game.tiles.length - 1]);
		else
			game.refreshBlockingTilesCanvas(pos.y + obj.h - 1);

		game.createBlockArray();
	}

	soundManager.playSound(SOUND.PLACE);
};

Editor.prototype.mouseMove = function()
{
	if(this.noClick)
		return;

	if(this.currentObj)
	{
		var pos = this.getObjPosFromMousePos();

		for(var i = 0; i < this.currentAddedFields.length; i++)
			if(Math.floor(pos.x) == this.currentAddedFields[i].x && Math.floor(pos.y) == this.currentAddedFields[i].y)
				return;

		this.addTile(pos);
	}
};

Editor.prototype.click = function()
{
	this.currentAddedFields = [];
	var pos = this.getObjPosFromMousePos();

	if(this.currentObj)
		this.addTile(pos);

	else
	{
		var selectedUnits = [];

		for(var i = 0; i < game.noGridTiles.length; i++)
		{
			var t = game.noGridTiles[i];

			var x = game.cameraX + KeyManager.x / FIELD_SIZE;
			var y = game.cameraY + KeyManager.y / FIELD_SIZE;

			if(t.isTile && (t.x - 0.5 * t.img.w / 16) <= x && (t.x + 0.5 * t.img.w / 16) >= x && (t.y - 0.5 * t.img.h / 16) <= y && (t.y + 0.5 * t.img.h / 16) >= y)
			{
				selectedUnits.push(t);
				i = game.noGridTiles.length;
			}
		}

		for(var i = 0; i < game.tiles.length; i++)
			if(game.tiles[i].x == pos.x && game.tiles[i].y == pos.y)
				selectedUnits.push(game.tiles[i]);

		if(selectedUnits.length == 0)
			for(var i = 0; i < this.ammo.length; i++)
				if(this.ammo[i].x == pos.x && this.ammo[i].y == pos.y)
					selectedUnits.push(this.ammo[i]);

		if(selectedUnits.length == 0)
			for(var i = 0; i < game.waypoints.length; i++)
				if(game.waypoints[i].x == pos.x && game.waypoints[i].y == pos.y)
					selectedUnits.push(game.waypoints[i]);

		if(selectedUnits.length == 0)
			for(var i = 0; i < game.spawningPoints.length; i++)
				if(game.spawningPoints[i].x == pos.x && game.spawningPoints[i].y == pos.y)
					selectedUnits.push(game.spawningPoints[i]);

		if(selectedUnits.length == 0)
			for(var i = 0; i < game.spawningPointsRed.length; i++)
				if(game.spawningPointsRed[i].x == pos.x && game.spawningPointsRed[i].y == pos.y)
					selectedUnits.push(game.spawningPointsRed[i]);

		if(selectedUnits.length == 0)
			for(var i = 0; i < game.spawningPointsBlue.length; i++)
				if(game.spawningPointsBlue[i].x == pos.x && game.spawningPointsBlue[i].y == pos.y)
					selectedUnits.push(game.spawningPointsBlue[i]);

		if(selectedUnits.length == 0)
			for(var i = 0; i < game.groundTiles.length; i++)
				if(game.groundTiles[i].x == pos.x && game.groundTiles[i].y == pos.y)
					selectedUnits.push(game.groundTiles[i]);

		if(selectedUnits.length > 0)
			this.selectedUnits = selectedUnits;
	}

	this.refreshItemInfo();
};

Editor.prototype.refreshItemInfo = function()
{
	if(this.selectedUnits.length <= 0)
	{
		document.getElementById("editorItemInfo").style.display = "none";
		return;
	}

	var o = this.selectedUnits[0];
	var t = o.type;

	var str = "<div>" + t.name + "</div>";
	str += "<div>X: " + o.x + ", Y: " + o.y + "</div>";

	if(t.editable)
		for(var i = 0; i < t.editable.length; i++)
			str += "<div>" + t.editableCaption[i] + ": <input id='editorInput" + i + "' name='" + t.editable[i] + "' oninput='game.editor.setAttribute();' class='mapSizeInput' type='text' value='" + o[t.editable[i]] + "' /></div>";

	document.getElementById("editorItemInfo").style.display = "block";
	document.getElementById("editorItemInfo").innerHTML = str;
};

Editor.prototype.setAttribute = function()
{
	var i = 0;
	while(document.getElementById("editorInput" + i))
	{
		var el = document.getElementById("editorInput" + i);
		this.selectedUnits[0][el.name] = el.value;
		i++;
	}
};

Editor.prototype.getObjPosFromMousePos = function()
{
	if(this.currentObj && this.currentObj.noGrid)
		return {
			x: game.cameraX + KeyManager.x / FIELD_SIZE,
			y: game.cameraY + KeyManager.y / FIELD_SIZE
		};

	return {
		x: Math.floor(game.cameraX + KeyManager.x / FIELD_SIZE),
		y: Math.floor(game.cameraY + KeyManager.y / FIELD_SIZE)
	};
};

Editor.prototype.draw = function()
{
	if(this.scroll)
	{
		if(KeyManager.keys[commandKeys[COMMAND.UP]])
			game.cameraY -= timeDiff * 0.019;

		if(KeyManager.keys[commandKeys[COMMAND.DOWN]])
			game.cameraY += timeDiff * 0.019;

		if(KeyManager.keys[commandKeys[COMMAND.LEFT]])
			game.cameraX -= timeDiff * 0.019;

		if(KeyManager.keys[commandKeys[COMMAND.RIGHT]])
			game.cameraX += timeDiff * 0.019;
	}

	if(this.currentObj)
	{
		if(typeof this.currentObj !== 'string')
		{
			var obj = this.currentObj;
			var size = obj.ground ? this.brushSize : 1;
			var img = imgCoords[obj.img] ? imgCoords[obj.img] : obj.img;
			var coords = this.getObjPosFromMousePos();

			for(var x = -size + 1; x < size; x++)
				for(var y = -size + 1; y < size; y++)
				{
					var x_ = 0;
					var y_ = 0;

					if(obj.noGrid)
					{
						x_ = (coords.x + x - game.cameraX) * FIELD_SIZE - obj.img.w * 0.5 * SCALE_FACTOR;
						y_ = (coords.y + y - game.cameraY) * FIELD_SIZE - obj.img.h * 0.5 * SCALE_FACTOR;
					}

					else
					{
						x_ = (Math.floor(coords.x) + x - game.cameraX) * FIELD_SIZE + (obj.w * 8 - img.w / 2) * SCALE_FACTOR;
						y_ = (Math.floor(coords.y) + y - game.cameraY) * FIELD_SIZE + (obj.h * 16 + (this.currentObj.ground ? 0 : 4) - img.h) * SCALE_FACTOR;
					}

					c.globalAlpha = 0.5;
					c.drawImage(imgs.tileSheet, img.x, img.y, img.w, img.h, x_, y_, img.w * SCALE_FACTOR, img.h * SCALE_FACTOR);
					c.globalAlpha = 1;
				}
		}
	}

	else
	{
		for(var i = 0; i < this.selectedUnits.length; i++)
		{
			var u = this.selectedUnits[i];
			var ut = u.type;
			var x = (ut && ut.noGrid) ? (u.x - ut.img.w / 16 / 2) : u.x;
			var y = (ut && ut.noGrid) ? (u.y - ut.img.h / 16 / 2) : u.y;
			var w = (ut && ut.noGrid) ? (ut.img.w / 16) : (ut ? ut.w : 1);
			var h = (ut && ut.noGrid) ? (ut.img.h / 16) : (ut ? ut.h : 1);

			c.strokeStyle = "rgba(190, 190, 230, 0.75)";
			c.lineWidth = SCALE_FACTOR;

			c.strokeRect((x - game.cameraX) * FIELD_SIZE, (y - game.cameraY) * FIELD_SIZE, FIELD_SIZE * w, FIELD_SIZE * h);
		}
	}

	// mark blocked fields / areas
	if(!KeyManager.keys[KEY.ALT])
	{
		c.fillStyle = "rgba(130, 100, 100, 0.45)";
		for(var x = Math.floor(game.cameraX); x <= game.cameraX2; x++)
			for(var y = Math.floor(game.cameraY); y <= game.cameraY2; y++)
				if(game.getFieldPath(x, y) < 10)
					c.fillRect((x - game.cameraX) * FIELD_SIZE, (y - game.cameraY) * FIELD_SIZE, FIELD_SIZE, FIELD_SIZE);

		// spawning points
		for(var i = 0; i < game.spawningPoints.length; i++)
		{
			var obj = imgCoords.spawningPoint;

			var x = (game.spawningPoints[i].x - game.cameraX) * FIELD_SIZE + (8 - obj.w / 2) * SCALE_FACTOR;
			var y = (game.spawningPoints[i].y - game.cameraY) * FIELD_SIZE + (16 - obj.h) * SCALE_FACTOR;

			c.drawImage(imgs.tileSheet, obj.x, obj.y, obj.w, obj.h, x, y, obj.w * SCALE_FACTOR, obj.h * SCALE_FACTOR);
		}

		// spawning points red
		for(var i = 0; i < game.spawningPointsRed.length; i++)
		{
			var obj = imgCoords.spawningPointRed;

			var x = (game.spawningPointsRed[i].x - game.cameraX) * FIELD_SIZE + (8 - obj.w / 2) * SCALE_FACTOR;
			var y = (game.spawningPointsRed[i].y - game.cameraY) * FIELD_SIZE + (16 - obj.h) * SCALE_FACTOR;

			c.drawImage(imgs.tileSheet, obj.x, obj.y, obj.w, obj.h, x, y, obj.w * SCALE_FACTOR, obj.h * SCALE_FACTOR);
		}

		// spawning points blue
		for(var i = 0; i < game.spawningPointsBlue.length; i++)
		{
			var obj = imgCoords.spawningPointBlue;

			var x = (game.spawningPointsBlue[i].x - game.cameraX) * FIELD_SIZE + (8 - obj.w / 2) * SCALE_FACTOR;
			var y = (game.spawningPointsBlue[i].y - game.cameraY) * FIELD_SIZE + (16 - obj.h) * SCALE_FACTOR;

			c.drawImage(imgs.tileSheet, obj.x, obj.y, obj.w, obj.h, x, y, obj.w * SCALE_FACTOR, obj.h * SCALE_FACTOR);
		}

		// waypoints
		for(var i = 0; i < game.waypoints.length; i++)
		{
			var p = game.waypoints[i];
			var obj = imgCoords.waypoint;

			var x = (p.x - game.cameraX) * FIELD_SIZE + (8 - obj.w / 2) * SCALE_FACTOR;
			var y = (p.y - game.cameraY) * FIELD_SIZE + (16 - obj.h) * SCALE_FACTOR;

			c.drawImage(imgs.tileSheet, obj.x, obj.y, obj.w, obj.h, x, y, obj.w * SCALE_FACTOR, obj.h * SCALE_FACTOR);
		}
	}

	// ammo
	for(var i = 0; i < this.ammo.length; i++)
	{
		var a = this.ammo[i];
		var img = weapons[a.weapon] ? imgCoords[weapons[a.weapon].img] : imgCoords[itemTypes[a.weapon - 1000].img];

		var scale = weapons[a.weapon] ? SCALE_FACTOR * 0.6 : SCALE_FACTOR;

		var x = (a.x - game.cameraX) * FIELD_SIZE + (8 - img.w / 2) * scale;
		var y = (a.y - game.cameraY) * FIELD_SIZE + (16 - img.h) * scale;

		c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, x, y, img.w * scale, img.h * scale);
	}
};
