Corpse.prototype = new Humanoid();
function Corpse(id, x, y, z, burned, direction, bouncePoints, scale)
{
	this.id = id;
	this.x = x;
	this.y = y;
	this.z = z;
	this.x0 = x;
	this.y0 = y;
	this.z0 = z;
	this.x00 = x;
	this.y00 = y;
	this.z00 = z;
	this.burned = burned;
	if(direction >= 1)
		direction = 1;
	this.direction = direction;
	this.bouncePoints = bouncePoints ? bouncePoints : [];
	this.spillBloodUntil = -99999;
	this.bloodX = 0;
	this.bloodY = 0;
	this.scale = scale ? scale : 1;
	this.isCorpse = true;
	
	game.addToObjectsToDraw(this);
};

Corpse.prototype.update = function()
{
	this.updateBounce();
	if(this.spillBloodUntil >= game.ticksCounter)
		this.updateBlood();
	return true;
};

Corpse.prototype.hpUpdate = function(hp, armor, splash, attacker)
{
	this.spillBlood(attacker);
};

Corpse.prototype.spillBlood = function(source)
{
	this.spillBloodUntil = game.ticksCounter + 5;
	this.bloodX = source.x - this.x;
	this.bloodY = source.y - this.y;
};

Corpse.prototype.updateBlood = function()
{
	if(this.x + 3 >= game.cameraX && this.y + 3 >= game.cameraY && this.x - 3 <= game.cameraX2 && this.y - 3 <= game.cameraY2)
	{
		var vecX = this.bloodX;
		var vecY = this.bloodY;
		
		var len = Math.sqrt(vecX * vecX + vecY * vecY);
		vecX *= 0.015 / len;
		vecY *= 0.015 / len;
		
		new Blood(this.x + vecX, this.y + vecY, -vecX, -vecY, null, false, function(age){ return 0.8 + -Math.pow(age * 0.05 - 0.5, 2); }, true, 0.4);
		new Blood(this.x + vecX, this.y + vecY, -vecX + Math.random() - 0.5, -vecY + Math.random() - 0.5, null, true, function(age){ return 0.5 + -Math.pow(age * 0.05 - 0.5); }, true, 0.4);
		new Blood(this.x + vecX, this.y + vecY, -vecX, -vecY, imgCoords.particleWhite, true, function(age){ return 0.8 + -Math.pow(age * 0.05 - 0.5, 2); }, true, 0.4);
	}
};

Corpse.prototype.draw = function(exactTicks, x1, y1, x2, y2, percentageOfCurrentTickPassed)
{
	if(!(this.x + 3 >= x1 && this.y + 3 >= y1 && this.x - 3 <= x2 && this.y - 3 <= y2))
		return;
	
	var scale = SCALE_FACTOR * 1.4 * this.scale;
	
	var x = (this.x0 + percentageOfCurrentTickPassed * (this.x - this.x0) - game.cameraX) * FIELD_SIZE;
	var y = (this.y0 + percentageOfCurrentTickPassed * (this.y - this.y0) - game.cameraY) * FIELD_SIZE;
	var h = (this.z0 + percentageOfCurrentTickPassed * (this.z - this.z0)) * FIELD_SIZE;
	
	var x_ = x - 32 / 2 * scale;
	var y_ = y - (32 - 12) * scale;
	
	var blackness = this.burned ? 0.9 : 0;
	
	if(this.bouncePoints.length > 0)
		this.direction = (this.x > this.x0) ? 0 : 1;
	
	// shadow
	c.drawImage(imgs.shadow, x_, y_, 32 * scale, 32 * scale);
    
    var yFrame = this.direction;
    var xFrame = 7;
    
    c.drawImage(imgs.zombieDeath, xFrame * 32, 32 * yFrame, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
    
    if(blackness)
    {
        c.globalAlpha = blackness;
        c.drawImage(imgs.zombieDeathBlack, xFrame * 32, 32 * yFrame, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
        c.globalAlpha = 1;
    }
};