// set size and resize
resize();
window.onresize = resize;

var network = null;
var game = null;
var inBattle = false;
var KeyManager = isMobile ? new KeyManagerMobile() : new KeyManager();
F_ = slayOne.widgets.lang.get.bind(slayOne.widgets.lang);

/**
 * detect adblock.
 */
if(typeof blockAdBlock !== 'undefined') {
    blockAdBlock.onDetected(function () {
        blockAdBlock = undefined;
    });
    blockAdBlock.check(true);
}

var uiManager = new UIManager();

var imgs = {
    legs: loadImage("imgs/legs.png?15552165"),
    heads: loadImage("imgs/heads.png?15552165"),
    hands: loadImage("imgs/hands.png"),
    throwHands: loadImage("imgs/throw_hands.png"),
    shadow: loadImage("imgs/shadow.png"),
    miscSheet: loadImage("imgs/miscSheet.png"),
    tileSheet: loadImage("imgs/tileSheet.png?15552165"),
    weaponsPlus: loadImage("imgs/weaponsPlus.png"),
    weaponsMinus: loadImage("imgs/weaponsMinus.png"),
    weaponsBodyPlus: loadImage("imgs/weaponsBodyPlus.png"),
    weaponsBodyMinus: loadImage("imgs/weaponsBodyMinus.png"),
    zombieDeath: loadImage("imgs/zombie-death.png"),
    turnZombie: loadImage("imgs/turn-zombie.png"),
    rangedZombie: loadImage("imgs/rangedZombie.png"),
    crawler: loadImage("imgs/spider.png"),
    humanBoss: loadImage("imgs/human_boss.png"),
    zombieBoss: loadImage("imgs/zombie_boss.png")
};
ressourceLoaded();

var soundManager = new SoundManager();

// GA
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-78888548-1', 'auto');
ga('send', 'pageview');

var gaLastEventTime = {};
var gaEventOnce = function (action) {
    if (!action) {
        console.error('gaEventOnce: invalid action');
        return;
    }

    var category = 'default';
    
    /*
    if (FacebookUtils.embeddedInCanvas) {
        category = 'facebook';
    }
	*/
	
    var key = category + ':' + action;
    if (gaLastEventTime[key] && Date.now() - gaLastEventTime[key] < 10000) {
        return;
    }
    if (localStorage.getItem(key)) {
        return;
    }

    var udid = localStorage.getItem("udid");
    if (udid && udid.length > 4) {
        if (udid[3] != '#') {
            return;
        }
    }

    gaLastEventTime[key] = Date.now();
    var params = {
        hitCallback: function () {
            localStorage.setItem(key, true);
        }
    };
    ga('send', 'event', category, action, params);
};

var isTutorialMap = function (mapId) {
    return mapId == 1;
};

slayOne.viewHelpers.showAd();