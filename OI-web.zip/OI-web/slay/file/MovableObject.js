function MovableObject(id, x, y, x0, y0, type, hp)
{
	this.id = parseInt(id);
	
	this.x = x;
	this.y = y;
	this.x0 = x0 ? x0 : x;
	this.y0 = y0 ? y0 : y;
	this.x00 = x0;
	this.y00 = y0;
	this.dieAt = 0;
	this.maxHP = type.hp ? type.hp : 999999;
	this.hp = hp ? hp : this.maxHP;
	
	this.dieAt = 0;
	this.finallyRemoveAt = 999999;
	this.noDraw = false;
	this.isMovableObject = true;
	this.lastHit = -99999;
	
	this.z = 0;
	this.vz = 0;
	this.z0 = 0;
	this.lastPosUpdate = -999;
	this.smokeTimeOffset = Math.floor(Math.random() * 10);
	this.type = type;
	
	game.addToObjectsToDraw(this);
};

MovableObject.prototype.blink = function(x, y)
{
	this.x = parseFloat(x);
	this.y = parseFloat(y);
	
	this.x0 = this.x;
	this.y0 = this.y;
	
	var vecX = this.x - this.x00;
	var vecY = this.y - this.y00;
	
	var dist = Math.sqrt(Math.pow(vecX, 2) + Math.pow(vecY, 2));
	var x = this.x00;
	var y = this.y00;
	
	vecX *= 1 / dist;
	vecY *= 1 / dist;
	
	if(!game.fastForward)
	{
		for(var i = 0; i < dist; i += 0.75)
		{
			x += vecX;
			y += vecY;
			
			new Sprite({
				x: x + Math.random() * 0.6 - 0.3,
				y: y + Math.random() * 0.6 - 0.3 - 0.5,
				img: imgCoords.dust1,
				scaleFunction: function(age){ return this.scale_ - age * 0.01; },
				scale_: Math.random() + 1.25,
				alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.25; },
				age: (1.7 + Math.random()) * 20
			});
			
			new Sprite({
				x: x + Math.random() * 0.6 - 0.3,
				y: y + Math.random() * 0.6 - 0.3 - 0.5,
				img: imgCoords.particleWhite,
				scaleFunction: function(age){ return this.scale_ - age * 0.01; },
				scale_: Math.random() + 1.55,
				alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.8; },
				age: Math.random() * 4 + 10
			});
		}
		
		soundManager.playSound(SOUND.BLINK, this.x00, this.y00);
		createBlinkEffect(this.x00, this.y00);
		createBlinkEffect(this.x, this.y);
	}
};

MovableObject.prototype.update = function()
{
	this.z0 = this.z;
	
	if(this.z > 0)
	{
		this.z = Math.max(this.z + this.vz, 0);
		this.vz -= CONST.GRAVITY;
	}
	
	if(this.lastPosUpdate < game.ticksCounter)
	{
		if(Math.sqrt(Math.pow(this.x - this.x0, 2) + Math.pow(this.y - this.y0, 2)) < 0.005)
		{
			this.x0 = this.x;
			this.y0 = this.y;
		}
		
		var x0 = this.x;
		var y0 = this.y;
		
		this.x += this.x - this.x0;
		this.y += this.y - this.y0;
		
		this.x0 = x0;
		this.y0 = y0;
	}
	
	if(this.dieAt && this.dieAt + 1 == game.ticksCounter && this.x + 3 >= game.cameraX && this.y + 3 >= game.cameraY && this.x - 3 <= game.cameraX2 && this.y - 3 <= game.cameraY2)
	{
		createPoundSmoke(this.x, this.y + 0.6, 0.45, 9);
		soundManager.playSound(SOUND.WOODCRACK, this.x, this.y, 0.8);
		
		for(var i = 0; i < 5; i++)
			new Sprite({
				x: this.x + Math.random() * 1.2 - 0.6,
				y: this.y + Math.random() * 1.2 - 0.6,
				img: imgCoords.dust1,
				scaleFunction: function(age){ return this.scale_ - age * 0.01; },
				scale_: Math.random() + 1.5,
				alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.17; },
				age: (1.7 + Math.random()) * 20,
				z_: Math.random() * 40 + 32,
				zFunction: function(age){ return age / this.z_; }
			});
	}
	
	return this.finallyRemoveAt > game.ticksCounter;
};

MovableObject.prototype.getYDrawingOffset = function()
{
	return this.y;
};

MovableObject.prototype.hpUpdate = function(hp, armor, splash, attacker)
{
	this.hp = parseFloat(hp);
	
	this.lastHit = game.ticksCounter;
	
	if(attacker && (attacker.isZombie || attacker.isHumanZombie))
		soundManager.playSound(SOUND.MECH_IMPACT, this.x, this.y, 0.7);
	
	if(this.hp <= 0)
	{
		this.finallyRemoveAt = game.ticksCounter + 30;
		
		if(this.hp == -55)
		{
			new Splash(this.x, this.y, imgCoords.splash, 2.5);
			this.finallyRemoveAt = game.ticksCounter;
		}
		
		this.dieAt = game.ticksCounter;
	}
};

MovableObject.prototype.draw = function(exactTicks, x1, y1, x2, y2, percentageOfCurrentTickPassed)
{
	if(!(this.x + 3 >= x1 && this.y + 3 >= y1 && this.x - 3 <= x2 && this.y - 3 <= y2) || this.noDraw)
		return;
	
	var scale = SCALE_FACTOR * 1.0;
	var scale_shadow = SCALE_FACTOR * 1.6;
	
	var x = (this.x0 + percentageOfCurrentTickPassed * (this.x - this.x0) - game.cameraX) * FIELD_SIZE;
	var y = (this.y0 + percentageOfCurrentTickPassed * (this.y - this.y0) - game.cameraY) * FIELD_SIZE;
	var h = (this.z0 + percentageOfCurrentTickPassed * (this.z - this.z0)) * FIELD_SIZE;
	
	var img = this.type.img;
	
	if(this.hp < this.maxHP * 0.33)
		img = this.type.img3;
	
	else if(this.hp < this.maxHP * 0.66)
		img = this.type.img2;
	
	if(this.dieAt && this.dieAt <= exactTicks)
	{
		var deathFrame = Math.max(Math.floor((exactTicks - 4 - this.dieAt) * 0.3), 0);
		img = this.type["deathImg" + (deathFrame + 1)];
		
		if(!img)
			return;
	}
	
	if(!img)
		img = this.type.img;
	
	var x_ = x - img.w / 2 * scale;
	var y_ = y - (img.h - 12) * scale;
	
	var shiftX = 0;
	var shiftY = 0;
	
	if(this.z <= 0)
	{
		var shift = game.shiftArray[Math.floor(this.x)] ? game.shiftArray[Math.floor(this.x)][Math.floor(this.y)] : null;
		
		if(shift && shift[0])
			shiftX = shift[0];
		
		if(shift && shift[1])
			shiftY = shift[1];
	}
	
	// running smoke effect
	if((Math.abs(this.x0 + shiftX - this.x) > 0.01 || Math.abs(this.y0 + shiftY - this.y) > 0.01) && !game.fastForward && tickDiff > 0 && game.ticksCounter >= 0 && (game.ticksCounter + this.smokeTimeOffset) % 6 == 1)
		new Sprite({
			x: this.x + Math.random() * 0.6 - 0.3,
			y: this.y + Math.random() * 0.6 - 0.3,
			img: imgCoords.dust1,
			scaleFunction: function(age){ return this.scale_ - age * 0.01; },
			scale_: Math.random() + 0.75,
			alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.23; },
			age: (1.7 + Math.random()) * 20,
			z_: Math.random() * 40 + 32,
			zFunction: function(age){ return age / this.z_; }
		});
	
	// shadow
	c.drawImage(imgs.shadow, x - 32 / 2 * scale_shadow, y - (32 - 12) * scale_shadow, 32 * scale_shadow, 32 * scale_shadow);
	
	var sheet = (this.lastHit + 1 >= game.ticksCounter) ? imgs.tileSheetWhite : imgs.tileSheet;
	
	c.drawImage(imgs.tileSheet, img.x, img.y, img.w, img.h, x_, y_ - h, img.w * scale, img.h * scale);
	
	if(game.ticksCounter > 0 && this.lastHit + 1 >= game.ticksCounter)
	{
		c.globalAlpha = 0.7 + (game.ticksCounter % 2) % 10;
		c.drawImage(imgs.tileSheetWhite, img.x, img.y, img.w, img.h, x_, y_ - h, img.w * scale, img.h * scale);
		c.globalAlpha = 1;
	}
};