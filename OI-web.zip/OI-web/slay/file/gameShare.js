(function(){
    FunUI.traits.gameShare = {
        _gameLink : null,
        _linkInput : null,
        __init__: function () {
            this._linkInput = this.querySelector('.inviteLink');
        },
        show : function() {
            this.open();
            this._gameLink = getCurrentGameLink();
            this._linkInput.value = this._gameLink;
        },
        "<Observer event='click' selector='.F-Button.link' />" : function() {
            copyInput(this._linkInput);
        },
        "<Observer event='click' selector='.F-Button.fb' />" : function() {
            shareToFacebook(this._gameLink);
        },
        "<Observer event='click' selector='.F-Button.tw' />" : function() {
            shareToTwiter(this._gameLink);
        }
    };
})();