(function(){
    FunUI.traits.goRoom = {
		transCode: null,
		isSubmit: false,
        __init__: function () {
			this.transCode = 0;
        },
		"<Observer event='keypress' selector='.content > input' />": function(e) {
            if (e.keyCode == 13) {
                this.submit();
            }
        },
		"<Observer event='click' selector='.content > .F-Button' />": function(e) {
            this.submit();
		},
        "<Observer event='click' selector='.close' />": function () {
            FunUI.managers.PopUpManager.removePopUp(this);
        },
		submit: function() {
			if (isSteamBindSend) {
				return;
			}

			var code = this.querySelector('input[type=text]').value.trim();

			var pattern = /https?:\/\/slay\.one\/\?server=[0-9a-zA-Z\-]+&game=\d+&mode=\d+/;

			if(!pattern.test(code))
			{
				this.message(F_('steam.goRoom.error'));
				return;
			}

			this.message(F_('steam.goRoom.pass'), true);

			var btn = this.querySelector('.content .F-Button');
			btn.className = btn.className + ' disabled';

			location.href = code;
		},
		message: function(s, isNotice) {
			var o = document.getElementById('goRoomFeedback');
			o.innerText = s;
			if(isNotice)
				o.style.color = '#fff';
		},
        show: function()
        {
			slayOne.views.optionsScreen.hideWindow();
            FunUI.managers.PopUpManager.addPopUp(this, false, FunUI.utils.LAYER_TOP);
        }
    };
})();