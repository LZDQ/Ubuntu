/**
 * Place to store rendering methods that are used by multiple views
 *
 */
(function(slayOne, document){

var

    domMain = document.getElementById("mainUI"),
    //map cell types to css class
    cellTypeToClass = {
        label: "labelCell"
    },
    cellTypeToMethod = {
        activeButton: renderButton_
    };

function renderLayoutGrid_( parentNode, options ){

    var
        domGrid = document.createElement("div"),
        layoutRows = options.layoutRows,
        beforeAddCell = options.beforeAddCell;

    domGrid.className = "mainLayoutTable";

    //render a row for each element in layoutRows
    for(var i = 0; i < layoutRows.length; i++)
    {
        var
            layoutCells = layoutRows[i],
            domRow = document.createElement("div");

        domRow.className = "layoutRow";

        for(var j = 0; j < layoutCells.length; j++)
        {
            var
                cellSettings = layoutCells[j],
                domCell = document.createElement("div"),
                cellContent = cellSettings.cellContent,
                cellType = cellSettings.cellType;

            domCell.className = "mainLayoutCell";

            //if "cellType" is defined, and has a css class mapped to it, add that class to the cell
            if(cellTypeToClass[cellType])
                domCell.className += " " + cellTypeToClass[cellType];

            if(cellTypeToMethod[cellType])
                cellTypeToMethod[cellType](domCell, cellSettings);

            if(beforeAddCell)
                beforeAddCell(cellSettings, domCell);
            
            if(cellContent)
            {
                if(typeof cellContent === "string")
                    domCell.innerHTML = cellContent;
                else
                    domCell.appendChild(cellContent);
            }
            
            domRow.appendChild(domCell);
        }

        domGrid.appendChild(domRow);
    }

    parentNode.appendChild( domGrid );
};

function renderButton_( parentNode, cellSettings ){

    var
        button = document.createElement("div"),
        cellType = cellSettings.cellType;

    button.innerHTML = cellSettings.buttonLabel;

    if ( cellType === "activeButton" ){

        button.className = "buttonActive";
    }

    parentNode.appendChild( button );
}

function renderHeaderLabel_( parentNode, viewSettings ){

    var
        domContainer = document.createElement("div"),
        imgLabel = document.createElement("img"),
        imgName = viewSettings.labelImage,

        layoutCells = [
            {
                cellKey: "borderLeft",
                cssClass: "regularHeaderLabelLeft"
            },
            {
                cellKey: "label",
                cssClass: "regularHeaderLabelLeftCenter"
            },
            {
                cellKey: "borderRight",
                cssClass: "regularHeaderLabelRight"
            }
        ],
        //will store elements here, we we can reference them without reading the DOM
        oCellByKey = {};

    domContainer.className = "regularHeaderLabelContainer";

    //append elements to the container
    for ( var i = 0; i < layoutCells.length; i++ ){

        var
            layoutCell = layoutCells[i],
            domCell = document.createElement("div");

        domCell.className =  layoutCell.cssClass;

        domContainer.appendChild( domCell );

        oCellByKey[layoutCell.cellKey] = domCell;
    }

    //if we're using an image, rathern than text, on the header label
    if ( imgName ){

        imgLabel.src = "imgs/main_ui/" + imgName + ".png";
        imgLabel.className = "headerLabelImage";
    }

    if( viewSettings.headerLabel ){

        oCellByKey.label.innerHTML = viewSettings.headerLabel;

    } else {

        oCellByKey.label.appendChild( imgLabel );
    }

    parentNode.appendChild( domContainer );
}

/**
 * Multiple UIs use the same style of header; so we use this method to consolidate that logic
 *
 * @private
 */
function renderHeader_( parentNode, viewSettings ){

    var
        domHeader = document.createElement("div"),
        buttonClose = document.createElement("button"),
        layoutCells = [
            {
                cellKey: "topLeft",
                cssClass: "regularViewTopLeft"
            },
            {
                cellKey: "topMiddle",
                cssClass: "regularViewTopCenter"
            },
            {
                cellKey: "topRight",
                cssClass: "regularViewTopRight"
            }
        ],
        //will store elements here, we we can reference them without reading the DOM
        oCellByKey = {};

    for ( var i = 0; i < layoutCells.length; i++ ){

        var
            layoutCell = layoutCells[i],
            domCell = document.createElement("div");

        domCell.className =  layoutCell.cssClass;

        domHeader.appendChild( domCell );

        oCellByKey[layoutCell.cellKey] = domCell;
    }

    renderHeaderLabel_( parentNode, viewSettings );

    //add close button
    buttonClose.className = "regularViewCloseWindow";

    buttonClose.onclick = function(){

        viewSettings.onClose();
    };

    domHeader.appendChild( buttonClose );

    parentNode.appendChild( domHeader );

}

/**
 * Multiple UIs use the same style of header; so we use this method to consolidate that logic
 *
 * @private
 */
function renderFooter_( parentNode, viewSettings ){

    var
        domContainer = document.createElement("div"),
        layoutCells = [
            {
                cellKey: "topLeft",
                cssClass: "regularViewBottomLeft"
            },
            {
                cellKey: "topMiddle",
                cssClass: "regularViewBottomCenter"
            },
            {
                cellKey: "topRight",
                cssClass: "regularViewBottomRight"
            }
        ],
        //will store elements here, we we can reference them without reading the DOM
        oCellByKey = {};

    for ( var i = 0; i < layoutCells.length; i++ ){

        var
            layoutCell = layoutCells[i],
            domCell = document.createElement("div");

        domCell.className =  layoutCell.cssClass;

        domContainer.appendChild( domCell );

        oCellByKey[layoutCell.cellKey] = domCell;
    }

    parentNode.appendChild( domContainer );
}

/**
 * Renders the part of the UI that is unique to particular view, and append to @parentNode
 *
 * @param parentNode
 * @param viewSettings
 * @private
 */
function renderContent_( parentNode, viewSettings ){

    var domContainer = document.createElement("div");

    domContainer.className = "regularViewContent";

    if(viewSettings.layoutGrids)
        for(var i = 0; i < viewSettings.layoutGrids.length; i++ )
            renderLayoutGrid_(domContainer, viewSettings.layoutGrids[i]);

    //if a content element was passed in, append it to the content area of our pop-up window
    if(viewSettings.domContent)
        domContainer.appendChild(viewSettings.domContent);

    parentNode.appendChild(domContainer);

}

function hideWindow()
{
    FunUI.managers.PopUpManager.removePopUp(domMain);
}

var domPopUps = null;

function showPopup(windowName, options) {
    hidePopup(windowName);

    if (!domPopUps) {
        domPopUps = document.createElement("div");
        domPopUps.id = "popupWndContainer";
    }

    var themeOption = (options && options.theme) ? options.theme : 'light';
	
    switch(themeOption) {
        case 'light': {
            var wnd = slayOne.widgets.popupWindow(domPopUps, {
                windowName: windowName,
                theme: themeOption,
                content: options.content,
                onClose: function(){
                    // sendWindowEvent();
                    domPopUps.removeChild(wnd);
                    if(domPopUps.children.length <= 0) {
                        FunUI.managers.PopUpManager.removePopUp(domPopUps);
                    }
                    options.onClose && options.onClose();
                }
            });
            break;
        }
        case 'standard': {
            var wnd = slayOne.widgets.popupWindow(domPopUps, {
                windowName: windowName,
                theme: themeOption,
                title: options.title,
                content: options.content,
                onClose: function(){
                    // sendWindowEvent();
                    domPopUps.removeChild(wnd);
                    if(domPopUps.children.length <= 0) {
                        FunUI.managers.PopUpManager.removePopUp(domPopUps);
                    }
                    options.onClose && options.onClose();
                }
            });
            break;
        }
        case 'tabbed': {
            var wnd = slayOne.widgets.popupWindow(domPopUps, {
                windowName: windowName,
                theme: themeOption,
                title: options.title,
                tabs: options.tabs,
                initTabIndex: options.initTabIndex,
                onClose: function(){
                	// if(typeof sendWindowEvent != undefined)
                    //	sendWindowEvent();
                    domPopUps.removeChild(wnd);
                    if(domPopUps.children.length <= 0) {
                        FunUI.managers.PopUpManager.removePopUp(domPopUps);
                    }
                    options.onClose && options.onClose();
                }
            });
            break;
        }
        case 'prompt': {
            var wnd = slayOne.widgets.popupWindow(domPopUps, {
                windowName: windowName,
                theme: themeOption,
                content: options.content,
                hideCloseBtn: true,
                onClose: function(){
                    // sendWindowEvent();
                    domPopUps.removeChild(wnd);
                    if(domPopUps.children.length <= 0) {
                        FunUI.managers.PopUpManager.removePopUp(domPopUps);
                    }
                    options.onClose && options.onClose();
                }
            });
            break;
        }
    }

    FunUI.managers.PopUpManager.addPopUp(domPopUps);
}

function getPopup(windowName)
{
    var domPopup = document.getElementById(windowName);
    return domPopup;
}

function hidePopup(windowName)
{
    var domPopup = document.getElementById(windowName);
    if(domPopup)
        domPopup.closePopUp();
}

/**
 * Render content of a particular view in our standard pop-up window
 *
 * @param viewSettings
 * @public
 */
function showWindow(viewSettings)
{
	Skin.close();

    //clear element where we print this content
    domMain.innerHTML = "";
    domMain.className = "regularView";

    renderHeader_( domMain, viewSettings );
    renderContent_( domMain, viewSettings );
    renderFooter_( domMain, viewSettings );

    FunUI.managers.PopUpManager.addPopUp(domMain);
};

var floatTipZIndex = 1000000;
var floatTipsCache = {};
/**
 * Show Float Tip
 *
 * @param options:
 *                  tipType: string enum, success | error
 *                  content: string
 *                  duration: number in miliseconds, <=0 means never disappear; default 4000
 * @return floatTipId, which is used in hideFloatTip() for manually hide a float tip
 */
function showFloatTip (options) {
    // Generate ID
    var floatTipId = floatTipZIndex++;
    // Create float tip
    var domTip = slayOne.widgets.floatTip(options);
    domTip.style.zIndex = floatTipId;
    floatTipsCache[floatTipId] = domTip;
    // Append to display list
    var domContainer = document.getElementById("floatTipsLayer");
    domContainer.appendChild(domTip);
    // Animate
    domTip.startShowAnimation(function(){
        removeFloatTip(domTip);
    });
    // Return ID
    return floatTipId;
}

function getFloatTip(floatTipId) {
    return floatTipsCache[floatTipId];
}

function hideFloatTip (floatTipId) {
    var domTip = floatTipsCache[floatTipId];
    if(!domTip) {
        return;
    }
    // Animate
    floatTipsCache[floatTipId] = null;
    domTip.startHideAnimation();
}

function removeFloatTip (domTip) {
    var domContainer = document.getElementById("floatTipsLayer");
    domContainer.removeChild(domTip);
}

/**
* Show prompt to user
* @param promptOptions, refer to js/widgets/prompt.js

* @return window handle with interfaces:
*                  close(): close this window
*/
var promptId = 0;
function showPrompt(promptOptions) {
    promptId += 1;
    var promptWndName = "promptWnd" + promptId.toString();
    slayOne.viewHelpers.showPopup(promptWndName, {
        theme: 'prompt',
        content: slayOne.widgets.prompt(promptOptions)
    });
    // Returns prompt handle for callbacks
    return {
        close: function(){
            slayOne.viewHelpers.hidePopup(promptWndName);
        },
    };
}

function showAd() {
    if (isDesktop) {
		return;
    }
    document.getElementById('adContainer').style.display = 'block';

	if (game && game.playingPlayer) {
		return;
	}

	var itch = document.getElementById('itchBanner');
	if (itch) {
    	itch.style.display = 'block';
	}

	var greenlight = document.getElementById('greenlight-button');
	if (greenlight) {
   		greenlight.style.display = 'block';
	}

	var steam = document.getElementById('steam-addon');
	if (steam) {
   		steam.style.display = 'block';
	}
}

function hideAd()
{
    document.getElementById('adContainer').style.display = 'none';
	var itch = document.getElementById('itchBanner');
	if(itch)
    	itch.style.display = 'none';
    	
	var greenlight = document.getElementById('greenlight-button');
	if(greenlight)
   		greenlight.style.display = 'none';
	
	var steam = document.getElementById('steam-addon');
	if(steam)
   		steam.style.display = 'none';
}

/**
* Shows a lightweight info screen
* @param options:
*                  title: string
*                  content: string
*/
function showInfoScreen (options) {
    slayOne.views.infoScreen.render(options.title, options.content);
};

//export
slayOne.viewHelpers = {
    showWindow: showWindow,
    hideWindow: hideWindow,
    showPopup: showPopup,
    getPopup: getPopup,
    hidePopup: hidePopup,
    showFloatTip: showFloatTip,
    getFloatTip: getFloatTip,
    hideFloatTip: hideFloatTip,
    showPrompt: showPrompt,
    showInfoScreen: showInfoScreen,
    showAd: showAd,
    hideAd: hideAd
};

})(window.slayOne, window.document);//end main closure
