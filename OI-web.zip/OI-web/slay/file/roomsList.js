(function(window, slayOne, document){

var viewKey = "roomsListScreen";

var domRoomList = null;

function renderGameModeSwitcher_(parentNode)
{
    var gameModeFilterOptions = [{ label: slayOne.widgets.lang.get("config.mode.all.label"), value: '-1' }];
    
	for(var i = 0; i < MAP_TYPE_SETTINGS.length; i++)
		if(!MAP_TYPE_SETTINGS[i].hidden)
			gameModeFilterOptions.push({
				label: slayOne.widgets.lang.get(MAP_TYPE_SETTINGS[i].langLabel),
            	value : MAP_TYPE_SETTINGS[i].id
			});
	
    slayOne.widgets.dropdownMenu(parentNode, {
        customClassName: "gameModeSwitcherDdl",
        customButtonClassName: "gameModeSwitcherBtn",
        customButtonWidth: "262px",
        customButtonHeight: "44px",
        selectOptions: gameModeFilterOptions,
        initIndex: 0,
        mainButtonTip: slayOne.widgets.lang.get("lobby.views.browse.mode_filter.tooltip"),
        onSwitch: function(gameModeOption) {
            window.roomListViewModel.filterGameMode = gameModeOption.value;
            listFilterUpdate_();
        }
    });
}

function renderNameFilter_(parentNode)
{
    window.roomListViewModel.tiFilterName = slayOne.widgets.standardTextInput(parentNode, {
        size: 10,
        placeholder: slayOne.widgets.lang.get("lobby.views.browse.name_filter.placeholder"),
        cssId: "inputGameNameMap",
        skin: "standard",
        customClassName: "gameNameTextInput",
        onSubmit: function(val) {
            window.roomListViewModel.filterName = val;
            listFilterUpdate_();
        },
    });
    slayOne.widgets.iconButton(parentNode, {
        customClassName: "nameFilterSearchBtn",
        iconClassName: 'nameFilterSearchBtnIcon',
        theme: 'small',
        onClick: function(){
            window.roomListViewModel.filterName = window.roomListViewModel.tiFilterName.value;
            listFilterUpdate_();
        }
    });
}

function renderRoomList_(parentNode)
{
    // List wrapper
    var domList = document.createElement('div');
    domList.className = "roomListWrapper";
	
    // List empty indicator
    var domListEmpty = document.createElement('div');
    domListEmpty.className = "roomListEmpty";
    var listEmptyHTML = '';
    listEmptyHTML += '<p>' + slayOne.widgets.lang.get("lobby.views.browse.error.no_games.no_game_found") + '</p>';
    listEmptyHTML += '<img src="imgs/windows/room/icon_no_room.png">';
    listEmptyHTML += '<p>' + slayOne.widgets.lang.get("lobby.views.browse.error.no_games.be_first_to_create") + '</p>';
    domListEmpty.innerHTML = listEmptyHTML;
    var domListEmptyCreateBtnWrapper = document.createElement('div');
    slayOne.widgets.labelButton(domListEmptyCreateBtnWrapper, {
        label: slayOne.widgets.lang.get("lobby.views.browse.error.no_games.create_btn.label"),
        theme: "HugeNormal",
        onClick: function(){
            slayOne.viewHelpers.getPopup('lobby').selectTab(1);
        }
    });
    domListEmpty.appendChild(domListEmptyCreateBtnWrapper);
    domList.appendChild(domListEmpty);

    // List content - scrollable
    var domContent = document.createElement('div');
    domContent.className = "roomListContent";

    var domTableHeader = document.createElement('div');
    domTableHeader.className = "roomListHeader";

    var domHeaderCreator = document.createElement('div');
    domHeaderCreator.className = "roomListHeaderField roomFieldID";
    domHeaderCreator.innerText = slayOne.widgets.lang.get('clanMembers.head.level');
    domTableHeader.appendChild(domHeaderCreator);

    var domHeaderMap = document.createElement('div');
    domHeaderMap.className = "roomListHeaderField roomFieldMapName";
    domHeaderMap.innerText = slayOne.widgets.lang.get("lobby.views.browse.list.header.map.label");
    domTableHeader.appendChild(domHeaderMap);

    var domHeaderPlayers = document.createElement('div');
    domHeaderPlayers.className = "roomListHeaderField roomFieldPlayers";
    domHeaderPlayers.innerText = slayOne.widgets.lang.get("lobby.views.browse.list.header.players.label");
    domTableHeader.appendChild(domHeaderPlayers);

    var domHeaderMode = document.createElement('div');
    domHeaderMode.className = "roomListHeaderField roomFieldMode";
    domHeaderMode.innerText = slayOne.widgets.lang.get("lobby.views.browse.list.header.mode.label");
    domTableHeader.appendChild(domHeaderMode);

    var domHeaderOperations = document.createElement('div');
    domHeaderOperations.className = "roomListHeaderField roomFieldOperations";
    domTableHeader.appendChild(domHeaderOperations);

    domContent.appendChild(domTableHeader);

    var domTableBody = document.createElement('div');
    domTableBody.className = "roomListBody";
    domContent.appendChild(domTableBody);

    domList.appendChild(domContent);
    
    slayOne.widgets.tooltip(domHeaderMap, {tip: slayOne.widgets.lang.get("lobby.views.browse.list.header.map.tooltip")});
    slayOne.widgets.tooltip(domHeaderPlayers, {tip: slayOne.widgets.lang.get("lobby.views.browse.list.header.players.tooltip")});
    slayOne.widgets.tooltip(domHeaderMode, {tip: slayOne.widgets.lang.get("lobby.views.browse.list.header.mode.tooltip")});
    
    window.roomListViewModel.domList = domList;
    window.roomListViewModel.domEmpty = domListEmpty;
    window.roomListViewModel.domContent = domContent;
    window.roomListViewModel.domTableHeader = domTableHeader;
    window.roomListViewModel.domTableBody = domTableBody;

    parentNode.appendChild(domList);
}

function listInit_(roomsList)
{
    listClear_(window.roomListViewModel);
    for(var i = 0; i < roomsList.length; i++)
    {
        window.roomListViewModel.rooms[roomsList[i].roomId] = roomsList[i];
        listInsertOne_(roomsList[i]);
    }
    listFilterUpdate_();
}

function listInsertOne_(roomData)
{
    var domRow = document.createElement('div');
    domRow.className = "roomListRow";
    domRow.dataset.slayOneRoomId = roomData.roomId.toString();
    var rowHTML = '';
    rowHTML += '<span class="roomListField roomFieldID">' + (roomData.tag == 'veteran' ? (CONST.VETERAN_LVL + '+') : ('1-' + (CONST.VETERAN_LVL - 1))) + '</span>';
    rowHTML += '<span class="roomListField roomFieldMapName">' + roomData.mapName + '</span>';
    rowHTML += '<span class="roomListField roomFieldPlayers"><object class="roomFieldPlayersCurrent">' + roomData.numPlayers + '</object>/' + roomData.numPlayersMax + '</span>';
    rowHTML += '<span class="roomListField roomFieldMode">' + slayOne.widgets.lang.get(MAP_TYPE_SETTINGS[roomData.mode].langLabel) + '</span>';
    domRow.innerHTML = rowHTML;
    var domOperations = document.createElement('span');
    domOperations.className = "roomListField roomFieldOperations";
    var mismatch = playerData.lvl < CONST.VETERAN_LVL && roomData.tag == 'veteran' || playerData.lvl >= CONST.VETERAN_LVL && roomData.tag != 'veteran';
    slayOne.widgets.labelButton(domOperations, {
        label: slayOne.widgets.lang.get((roomData.mode == 3 || (MAP_TYPE_SETTINGS[roomData.mode].unlockLevel || 0) > playerData.lvl || mismatch) ?
            "lobby.views.browse.list.row.watch_btn.label" :"lobby.views.browse.list.row.join_btn.label"),
        theme: "SmallNormal",
        onClick: function(){
            listClickHandler_(roomData);
        }
    });
    domRow.appendChild(domOperations);
    window.roomListViewModel.domTableBody.appendChild(domRow);

    var domRoomTip = document.createElement('div');
    domRoomTip.className = "roomListTip";
    domRoomTip.style.display = "none";

    var roomTipHTML = '<div class="mapMetaThumbnail">';
    roomTipHTML += '<div class="mapMetaTitle">' + roomData.mapName + '</div>';
    roomTipHTML += '<div class="mapMetaDesc">';
    roomTipHTML += '<div class="mapMetaPlayers">' + slayOne.widgets.lang.get("lobby.views.browse.list.row.tooltip.player.header") + ': <span class="mapMetaPlayersCurrent">';
    roomTipHTML += roomData.numPlayers + '</span><span>/</span><span class="mapMetaPlayersMax">' + roomData.numPlayersMax + '</span></div>';
    roomTipHTML += '<div class="mapMetaPlayers">';
    roomTipHTML += '<span>' + slayOne.widgets.lang.get("lobby.views.browse.list.row.tooltip.requirement")  + '</span>';
    roomTipHTML += '<span class="mapMetaPlayersCurrent">' + (roomData.tag == 'veteran' ? (CONST.VETERAN_LVL + '+') : ('1-' + (CONST.VETERAN_LVL - 1))) + '</span>';
    roomTipHTML += '</div>';
    roomTipHTML += '<div class="mapMetaMode">' + slayOne.widgets.lang.get(MAP_TYPE_SETTINGS[roomData.mode].langLabel) + '</div>';
    roomTipHTML += '</div>';
    roomTipHTML += '<img src="' + roomData.mapThumbnail + '" onerror="holdPlaceMapThumbnail(event);"  onload="holdPlaceMapThumbnail(event);">';
    roomTipHTML += '<div class="mapMetaSize">' + roomData.mapW + 'x' + roomData.mapH + '</div>';
    roomTipHTML += '</div>';

    domRoomTip.innerHTML = roomTipHTML;
    domRow.appendChild(domRoomTip);

    domRow.addEventListener("mouseover", function(){
        domRoomTip.style.display = "flex";
    });

    domRow.addEventListener("mouseout", function(){
        domRoomTip.style.display = "none";
    });

    if(shouldHideRoom_(roomData))
        domRow.style.display = "none";
    else
        domRow.style.display = "block";
}

function listClickHandler_(roomData)
{
    var mismatch = playerData.lvl < CONST.VETERAN_LVL && roomData.tag == 'veteran' || playerData.lvl >= CONST.VETERAN_LVL && roomData.tag != 'veteran';
    window.joinGamePurpose = (roomData.mode == 3 || (MAP_TYPE_SETTINGS[roomData.mode].unlockLevel || 0) > playerData.lvl || mismatch) ? 'spectate' : null;
    window.network.send("join-game$" + roomData.roomId);
    
    slayOne.viewHelpers.hidePopup("lobby");
}

function listUpdateOne_(roomData)
{
    var roomDom = getDomByRoomId_(roomData.roomId);
    if(roomDom == null)
    {
        listInsertOne_(roomData);
        window.roomListViewModel.rooms[roomData.roomId] = roomData;
        listFilterUpdate_();
    }
    else
    {
        // Partial update
        roomDom.querySelector(".roomFieldPlayersCurrent").innerText = roomData.numPlayers;
        roomDom.querySelector(".mapMetaPlayersCurrent").innerText = roomData.numPlayers;
        window.roomListViewModel.rooms[roomData.roomId].numPlayers = roomData.numPlayers;
    }
}

function listDeleteOne_(roomId)
{
    var roomDom = getDomByRoomId_(roomId);
    if(roomDom == null)
        return;
    
    window.roomListViewModel.domTableBody.removeChild(roomDom);
    delete window.roomListViewModel.rooms[roomId];
    listFilterUpdate_();
}

function getDomByRoomId_(roomId)
{
    var doms = window.roomListViewModel.domTableBody.children;
    var domsCount = doms.length;
    for(var i = 0; i < domsCount; i++)
        if(doms[i].dataset.slayOneRoomId == roomId.toString())
            return doms[i];
    return null;
}

function listFilterUpdate_()
{
    var hasVisibleRooms = false;
    var doms = window.roomListViewModel.domTableBody.children;
    var domsCount = doms.length;
    for(var i = 0; i < domsCount; i++)
    {
        var roomData = window.roomListViewModel.rooms[doms[i].dataset.slayOneRoomId];
        if(shouldHideRoom_(roomData))
            doms[i].style.display = "none";
        else
        {
            hasVisibleRooms = true;
            doms[i].style.display = "block";
        }
    }
    if(hasVisibleRooms)
    {
        window.roomListViewModel.domContent.style.display = "block";
        window.roomListViewModel.domEmpty.style.display = "none";
    }
    else
    {
        window.roomListViewModel.domContent.style.display = "none";
         window.roomListViewModel.domEmpty.style.display = "block";
    }
}

function shouldHideRoom_(roomData)
{
    if(window.roomListViewModel.filterGameMode >= 0 && roomData.mode != window.roomListViewModel.filterGameMode)
    	return true;
    
    if(window.roomListViewModel.filterName && window.roomListViewModel.filterName.length > 0)
    {
        if(roomData.mapName.toLowerCase().indexOf(window.roomListViewModel.filterName.toLowerCase()) >= 0)
            return false;
        
        return true;
    }
    return false;
}

function listClear_()
{
    window.roomListViewModel.rooms = {};
    window.roomListViewModel.domTableBody.innerHTML = '';
}

function getRoomsList_()
{
    window.network.send("req-games-list");
    if(window.roomListViewModel.roomWatching)
        setTimeout(getRoomsList_, 10000, window.roomListViewModel);
}

function render(parentNode)
{
    var domContent = document.createElement('div');
    domContent.className = "roomTabView roomsListView";

    window.roomListViewModel = {
        filterGameMode: -1,
        filterName: '',
        rooms: {}, // {roomId -> roomData}
        domList: null,
        domEmpty: null,
        domContent: null,
        domTableHeader: null,
        domTableBody: null,
        tiFilterName: null
    };

    var aRows = [
        [ { renderMethod: renderGameModeSwitcher_ }, { renderMethod: renderNameFilter_ } ],
        [ { renderMethod: renderRoomList_ } ]
    ];

    // render layout rows
    for(var i = 0; i < aRows.length; i++)
    {
        var aCells = aRows[i];
        var domTable = document.createElement("div");
        var domRow = document.createElement("div");
        domTable.className = "mainLayoutTable";
        domRow.style.display = "table-row";
		
        for(var j = 0; j < aCells.length; j++)
        {
            var layoutCell = aCells[j];
            var domCell = document.createElement("div");
            var renderMethod = layoutCell.renderMethod ? layoutCell.renderMethod.bind(this): null;
            domCell.className  = "mainLayoutCell roomListLayoutCell";
            renderMethod(domCell);
            domRow.appendChild(domCell);
        }

        domTable.appendChild(domRow);
        domContent.appendChild(domTable);
    }
    
    domContent.onShow = function(initData){
        window.roomListViewModel.roomWatching = true;
        window.roomListViewModel.domContent.style.display = 'none';
        window.roomListViewModel.domEmpty.style.display = 'none';
        window.roomListViewModel.networkInitCb = function(roomsData)
        {
            listInit_(roomsData);
        };
        
        getRoomsList_(window.roomListViewModel);
    };
    
    domContent.onHide = function(){
        window.roomListViewModel.roomWatching = false;
        window.roomListViewModel.networkInitCb = null;
    };
    
    parentNode.appendChild(domContent);
    
    return domContent;
}

//export
slayOne.views[viewKey] = {
    render: render,
    listInit_: listInit_
};

})(window, window.slayOne, window.document); //end main closure