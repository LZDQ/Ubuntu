/**
 * View renders the "Login" UI
 *
 */
(function (window, slayOne, document) {

    var viewKey = "loginScreen";

    function renderUserNameInput_(parentNode, viewModel)
    {
        var domContainer = document.createElement('div');
        domContainer.className = "userInputRow";

        var domTextInput = slayOne.widgets.standardTextInput(domContainer, {
            size: 10,
            placeholder: slayOne.widgets.lang.get("account.views.login.name.placeholder"),
            cssId: "inputUserName",
            skin: "standard",
            customClassName: "userLoginRegTextInput userNameTextInput",
            iconClassName: "iconUserName",
            onSubmit: function (val) {
                commitLogin_(viewModel);
            },
        });
        
        viewModel.tiUserName = domTextInput;
        parentNode.appendChild(domContainer);
    }

    function renderUserPassInput_(parentNode, viewModel)
    {
        var domContainer = document.createElement('div');
        domContainer.className = "userInputRow";

        var domTextInput = slayOne.widgets.standardTextInput(domContainer, {
            size: 10,
            inputType: 'password',
            placeholder: slayOne.widgets.lang.get("account.views.login.password.placeholder"),
            cssId: "inputUserPass",
            skin: "standard",
            customClassName: "userLoginRegTextInput userPassTextInput",
            iconClassName: "iconUserPass",
            onSubmit: function (val) {
                commitLogin_(viewModel);
            },
        });
        
        viewModel.tiUserPass = domTextInput;
        parentNode.appendChild(domContainer);
    }

    function renderStayLoggedInCheckBox_(parentNode, viewModel)
    {
        var domCheckBox = slayOne.widgets.checkbox(parentNode, {
            selected: true,
            label: slayOne.widgets.lang.get("account.views.login.stay_logged_in.label"),
            labelClassName: "userStayLoggedInCb",
            onChange: function (selected) {

            },
        });
        viewModel.cbStayLoggedIn = domCheckBox;
    }

    function renderLoginButton_(parentNode, viewModel)
    {
        slayOne.widgets.labelButton(parentNode, {
            label: slayOne.widgets.lang.get("account.views.login.buttons.submit.label"),
            tipAlign: "center",
            theme: "LargeNormal",
            customClassName: "userLoginRegBtn",
            onClick: function () {
                commitLogin_(viewModel);
            }
        });
    }

    function renderFbSignUpButton_(parentNode)
    {
        slayOne.widgets.labelButton(parentNode, {
            label: slayOne.widgets.lang.get("account.views.login.buttons.fbLogin.label"),
            tipAlign: "center",
            theme: "LargeFBNormal",
            onClick: function () {
                FacebookUtils.loginFbThenGame(function (res) {
                    if (res.result == 0) {
                        slayOne.viewHelpers.hidePopup("account");
                    }
                });
            }
        });
    }

    function commitLogin_(viewModel)
    {
        var name = document.getElementById("inputUserName").value;
        var pw = document.getElementById("inputUserPass").value;
		
        if(!name || name.length <= 0)
        {
            slayOne.viewHelpers.showFloatTip({
                tipType: 'error',
                content: slayOne.widgets.lang.get("account.views.login.name.warning")
            });
            return null;
        }

        if(!pw || pw.length <= 0)
        {
            slayOne.viewHelpers.showFloatTip({
                tipType: 'error',
                content: slayOne.widgets.lang.get("account.views.login.password.warning")
            });
            return null;
        }
        
        network.send("login$" + name + "$" + pw);
        
        // autologin
        if(viewModel.cbStayLoggedIn.getSelected())
        	localStorage.setItem("autologin", name + "$" + pw);
        
        else
        	localStorage.setItem("autologin", "");
    }
    
    function render(parentNode)
    {
        var domContent = document.createElement('div');
        domContent.className = "loginRegView";
		
        var mapsModel = {
            tiUserName: null,
            tiUserPass: null,
            cbStayLoggedIn: null,
        };
		
        var aRows = [
            [{renderMethod: renderUserNameInput_}],
            [{renderMethod: renderUserPassInput_}],
            [{renderMethod: renderStayLoggedInCheckBox_}],
            (function() {
                var buttons = [ { renderMethod: renderLoginButton_ } ];
                !isDesktop && buttons.push({renderMethod: renderFbSignUpButton_});
                return buttons;
            })(),
        ];
        
        for(var i = 0; i < aRows.length; i++)
        {
            var aCells = aRows[i];
            var domTable = document.createElement("div");
            var domRow = document.createElement("div");
            domTable.className = "mainLayoutTable";
            domRow.style.display = "table-row";
            domTable.style.marginBottom = "10px";
            
            for(var j = 0; j < aCells.length; j++)
            {
                var layoutCell = aCells[j];
                var domCell = document.createElement("div");
                var renderMethod = layoutCell.renderMethod ? layoutCell.renderMethod.bind(this) : null;
                domCell.className = "mainLayoutCell";
                renderMethod(domCell, mapsModel);
                domRow.appendChild(domCell);
            }
            
            domTable.appendChild(domRow);
            domContent.appendChild(domTable);
        }
        
        parentNode.appendChild(domContent);
        
        return domContent;
    }
    
	// export
    slayOne.views[viewKey] = {
        render: render
    };

})(window, window.slayOne, window.document);//end main closure
