FunUI.layouts["changeNick"] =
	'<div id="changeNick" class="F-Prompt">' +
		'<div class="title"></div>' +
		'<div class="content"></div>' +
		'<h2 class="titleText">_(changeNick.title)</h2>' +
		'<div class="nickBar">' +
			'<div class="F-TextInput"></div>' +
			'<div class="dateLimit"></div>' +
			'<div class="tips">Use 3 - 15 characters. Only letters, numers, space and underscore. You can change your name once every 6 days.</div>' +
		'</div>' +
		'<div class="buttonBar">' +
			'<div class="F-Button green tiny no">_(prompt.btn_cancel.label)</div>' +
			'<div class="F-Button green tiny yes">_(prompt.btn_ok.label)</div>' +
		'</div>' +
	'</div>';