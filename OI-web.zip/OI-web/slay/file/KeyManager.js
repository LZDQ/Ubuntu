// input manager, manages all the inputs
function KeyManager()
{
	this.x = 0;
	this.y = 0;
	this.leftMouse = false;
	this.keys = [];

	this.activeAbility = null;
};

if(!isMobile)
{
	document.addEventListener('contextmenu', function(e) {e.preventDefault();});

	document.documentElement.onkeyup = function(e)
	{
		var key = KeyManager.getKeyCode(e);
		var keyCode = keyCodes[key];

		KeyManager.keys[key] = false;

		if(key == KEY.T || key == KEY.TAB) {
            F$('rankInGame').hide();
		}

		else if(key == commandKeys[COMMAND.FIRE_2])
			game.fire2Up();

		else if(keyCode)
		{
			if(commandKeys[COMMAND.STAND] == key)
				network.send("kup$" + COMMAND.STAND);
			else
				network.send("kup$" + keyCode);
		}

		return false;
	};

	document.documentElement.onkeydown = function(e)
	{
		return KeyManager.handleInput(KeyManager.getKeyCode(e), e);
	};

	KeyManager.prototype.getKeyCode = function(e)
	{
		return e.which || e.keyCode;
	};

	function MouseWheelHandler(e)
	{
		if(document.getElementById("chatInputDiv").style.display == "inline")
			return;

		var e = window.event || e;
		e = e.wheelDelta || -e.detail;

		// set zoom level
		if(game && game.editingMode)
		{
			zoom(e > 0 ? 1.2 : (1 / 1.2));
			return;
		}

		if(game && game.iAmSpec)
		{
			zoom(e > 0 ? 1.1 : (1 / 1.1), 0.035);
			game.specX = game.cameraX;
			game.specY = game.cameraY;
			return;
		}

		// switch wpn
		if(game && game.playingPlayer && game.playingPlayer.weapon && !game.playingPlayer.dieAt)
		{
			var step = Math.sign(-e);

			var currentNr = (game.playingPlayer.weapon.id + weapons.length) % weapons.length;
			var nr = (currentNr + weapons.length + step) % weapons.length;

			while(weapons[nr].noWeapon || (game.playingPlayerClips[nr] + game.playingPlayerAmmo[nr] <= 0 && nr != 0))
				nr = (nr + step) % weapons.length;

			game.switchWeapon(nr);
		}
	};

	window.ondragover = function(e)
	{
		e.preventDefault();
	};

	// IE9, Chrome, Safari, Opera
	document.addEventListener("mousewheel", MouseWheelHandler, false);

	// Firefox
	document.addEventListener("DOMMouseScroll", MouseWheelHandler, false);

	function zoom(direction, minZoom)
	{
		var x = game.cameraX + (WIDTH / 2) / FIELD_SIZE;
		var y = game.cameraY + (HEIGHT / 2) / FIELD_SIZE;

		SCALE_CONST *= direction;
		SCALE_CONST = Math.min(Math.max(SCALE_CONST, minZoom ? minZoom : 0.009), 0.30);

		resize();

		game.cameraX = x - (WIDTH / 2) / FIELD_SIZE;
		game.cameraY = y - (HEIGHT / 2) / FIELD_SIZE;
	}

	document.documentElement.onmousedown = function(e)
	{
		window.focus();
        if(e.currentTarget == canvas)
            return;

		var key = KeyManager.getKeyCode(e);

		if(key == 1 && KeyManager.leftMouse) // leftmouse already pressed, no need to do anything
			return;

		if(key == 1)
			KeyManager.leftMouse = true;

		else if(key == 3) // rightmouse
		{
			e.preventDefault();
			return KeyManager.handleInput(KEY.RIGHTMOUSE, e);
		}

		if(!game || game.map == map1)
			return;

		if(game.editingMode)
			game.editor.noClick = true;

		if(e.target && (e.target.getAttribute("data-noclick") == "yes" || (e.target.parentNode && e.target.parentNode.getAttribute("data-noclick") == "yes") || (e.target.parentNode.parentNode && e.target.parentNode.parentNode.getAttribute("data-noclick") == "yes")))
			return;

		if(game.editingMode)
		{
			game.editor.noClick = false;
			game.editor.click();
			return;
		}

		if((game && game.map != map1) && !(e.target && (e.target.id == "gameLink" || e.target.className.indexOf("clickableDuringGame") >= 0)))
			return false;
	};

	KeyManager.prototype.handleInput = function(key, e)
	{
		var now = Date.now();
		var keyCode = keyCodes[key];
		var oldState = KeyManager.keys[key];
		KeyManager.keys[key] = true;
		
		if(document.getElementById("chatInputDiv").style.display == "inline" && key != KEY.ENTER)
			return;
		
		if(key == KEY.F7)
		{
			cameraReset();
			return;
		}
		
		if(key == KEY.ESC)
		{
			if(isSteam && win.isFullscreen)
				Desktop.toggleFullscreen();
			return;
		}
		
		if(key == KEY.F8)
		{
			window.soundManager.playSound(SOUND.CLICK);
			toggleFullscreen(document.documentElement);
			return;
		}
		
		if(key == KEY.F10)
		{
			window.soundManager.playSound(SOUND.CLICK);
			toggleOptionsMenu();
			return;
		}
		
		if((key == KEY.PLUS || key == KEY.Y) && game && game.replayMode)
		{
			window.soundManager.playSound(SOUND.CLICK);
			changeReplaySpeed(1);
			return;
		}
		
		if((key == KEY.MINUS || key == KEY.X) && game && game.replayMode)
		{
			window.soundManager.playSound(SOUND.CLICK);
			changeReplaySpeed(-1);
			return;
		}
		
		// hotkeys set
		if(document.getElementById("hotkeyScreen") && document.getElementById("hotkeyScreen").style.display != "none")
		{
			var active_hotkey_buttons = document.getElementsByClassName("hotkey_button_active");

			if(active_hotkey_buttons && active_hotkey_buttons.length > 0)
			{
				var active_hotkey_button = active_hotkey_buttons[0];
				active_hotkey_button.style.color = "";
				active_hotkey_button.className = "hotkey_button";
				active_hotkey_button.innerHTML = getKeyName(key);
				commandKeys[active_hotkey_button.getAttribute("data-key")] = key;

				soundManager.playSound(SOUND.CLICK);
				refreshKeyCodes();

				var hotkeyStr = "";
				for(var attribute in commandNames)
    				if(commandNames.hasOwnProperty(attribute))
    					hotkeyStr += attribute + ":" + commandKeys[attribute] + "_";

    			localStorage.setItem("hotkeys", hotkeyStr);

				return false;
			}
		}

		else if(game && game.editingMode)
		{
			game.editor.scroll = false;

			if(e.target && (e.target.getAttribute("data-noclick") == "yes" || (e.target.parentNode && e.target.parentNode.getAttribute("data-noclick") == "yes") ||
			(e.target.parentNode.parentNode && e.target.parentNode.parentNode.getAttribute && e.target.parentNode.parentNode.getAttribute("data-noclick") == "yes")))
				return;

			game.editor.key(key);

			return;
		}

		else if(game && game.map != map1)
		{
			if(key == commandKeys[COMMAND.JUMP])
			{
				network.send("m2");

				if(KeyManager.activeAbility)
				{
					soundManager.playSound(SOUND.SWITCH);
					KeyManager.activeAbility = null;
				}
			}

			else if(key == commandKeys[COMMAND.FIRE_2] && game.playingPlayer && game.playingPlayer.weapon.mode2Weapon)
			{
                game.fire2Down();
			}

			else if(key == KEY.T || key == KEY.TAB)
			{
                F$('rankInGame').show();
				e.preventDefault();
				return false;
			}

			else if(key == commandKeys[COMMAND.PICK_UPGRADE] && game.interface_.upgradeChoicesAvailable && (game.interface_.upgNotificationStart > 0 || game.interface_.currentUpgChoicesEnd < now)) // show upgrades
				game.interface_.shopUpgrades();

			else if(key == commandKeys[COMMAND.PICK_UPGRADE] && game.interface_.upgNotificationStart < 0 && game.interface_.currentUpgChoices.length > 0 && game.interface_.currentUpgChoicesEnd > now) // hide upgrades
				game.interface_.hideUpgrades();

			else if(key == KEY.ENTER)
			{
				var el = document.getElementById("chatInputDiv");
				var el2 = document.getElementById("chatInput");
				var el3 = document.getElementById("chatlog");
				var el4 = document.getElementById("chatloginner");

				if(el.style.display != "inline")
				{
					el.style.display = "inline";
					el3.style.display = "inline";
					el4.scrollTop = el4.scrollHeight;
					el2.focus();
				}

				else
				{
					var msg = el2.value;

					if(msg && msg.length > 0)
						network.send("chat" + msg);

					el2.value = "";
					el.style.display = "none";
					el3.style.display = "none";
				}
			}

			else if(commandKeys[COMMAND.ABILITY1] == key)
				game.interface_.initAbility(pl_active_abilities[0], 0);

			else if(commandKeys[COMMAND.ABILITY2] == key)
				game.interface_.initAbility(pl_active_abilities[1], 1);

			else if(commandKeys[COMMAND.UP] == key || commandKeys[COMMAND.DOWN] == key || commandKeys[COMMAND.LEFT] == key || commandKeys[COMMAND.RIGHT] == key || commandKeys[COMMAND.RELOAD] == key ||
				(commandKeys[COMMAND.STAND] == key && game.playingPlayer && game.playingPlayer.weapon && game.playingPlayer.weapon.requiredStandTime))
			{
				if(oldState != KeyManager.keys[key])
				{
					if(commandKeys[COMMAND.STAND] == key)
						network.send("kdn$" + COMMAND.STAND);
					else
						network.send("kdn$" + keyCode);
				}
			}

			else if(game.playingPlayer && !game.playingPlayer.isHumanZombie)// switch weapon
				for(var i = 0; i < weapons.length; i++)
					if(!weapons[i].noWeapon && key == commandKeys[COMMAND["WPN" + (i + 1)]])
					{
						var totalAmmo = game.playingPlayerClips[i] + game.playingPlayerAmmo[i];

						if((game.playingPlayerClips[i] + game.playingPlayerAmmo[i]) > 0 || game.playingPlayer.weapon == weapons[i])
							game.switchWeapon(i);

						else
						{
							game.interface_.setMainKillMsg("you don't have this weapon", "grey", "textInGrey");
							soundManager.playSound(SOUND.EMPTY_CLIP, game.playingPlayer.x, game.playingPlayer.y, 0.75);
						}

						i = weapons.length;
					}
		}
	};

	document.documentElement.onmouseup = function(e)
	{
		var key = KeyManager.getKeyCode(e);

		if(key == 1)
			KeyManager.leftMouse = false;

		// leftmouse
		if(game && game.playingPlayer && key == 1) {
			game.mouseUp();
		}
	};

	// this prevents the context menu when shift right clicking
	document.documentElement.onclick = function(e)
	{
		var b = KeyManager.getKeyCode(e);

		if(b == 2 || b == 3)
		{
			e.preventDefault();
			e.stopPropagation();
			return false;
		}
	};

	canvas.onclick = function(e)
	{
		e.preventDefault();
		e.stopPropagation();
		return false;
	};

	canvas.addEventListener("mousedown", function (e) {

        var x = getMouseGamePlayX();
        var y = getMouseGamePlayY();

        var key = KeyManager.getKeyCode(e);

        // leftmouse
        if(key == 1)
        {
            if(game.interface_.click())
                return;

            if(game.iAmSpec)
            {
                switchSpec(1);
                return;
            }

            if(game.playingPlayer && KeyManager.activeAbility)
            {
                var target = null;

				if(KeyManager.activeAbility.energy > game.playingPlayerEnergy)
				{
					game.interface_.addMsg(slayOne.widgets.lang.get("game.msg.no_energy"), "red");
					soundManager.playSound(SOUND.NEGATIVE, 0.8);
				}

				else if(game.lastAbilityUses[pl_active_abilities[0] == KeyManager.activeAbility ? 0 : 1] + KeyManager.activeAbility.cooldown > game.ticksCounter)
				{
					game.interface_.addMsg(slayOne.widgets.lang.get("game.msg.no_cooldown"), "red");
					soundManager.playSound(SOUND.NEGATIVE, 0.8);
				}

				else if(KeyManager.activeAbility.type == "blink" && game.playingPlayer.carriesFlag())
				{
				 	game.interface_.addMsg(slayOne.widgets.lang.get("game.skills.teleport.disabled_in_ctf"), "red");
					soundManager.playSound(SOUND.NEGATIVE, 0.8);
				}

				else
				{
	                if(KeyManager.activeAbility.type == "place")
	                    target = game.getPotentialPlaceTarget(KeyManager.activeAbility);

	                else
	                    target = {
	                        x: x,
	                        y: y
	                    };

	            	network.send("ab$" + KeyManager.activeAbility.id + "$" + target.x + "$" + target.y);
	            }

                KeyManager.activeAbility = null;
            }

            else if(game.playingPlayer && game.playingPlayer.weapon)
            {
                if(game.playingPlayer.weapon.requiredStandTime && game.playingPlayer.standTime <= 0)
                {
                    if(game.playingPlayerClips[game.playingPlayer.weapon.id])
                    {
                        game.interface_.setMainKillMsg(slayOne.widgets.lang.get("game.msg.stand_required", { keyName: getKeyName(commandKeys[COMMAND.STAND]) }), "grey", "textInGrey");
                        soundManager.playSound(SOUND.NEGATIVE, 0.8);
                    }
                }

                else
				{
                    game.mouseDown();
				}
            }
        }

        else if(key == 3)
        {
            if(game.iAmSpec)
            {
                switchSpec(-1);
                return;
            }
        }

   });

	// when mouse is moved, store position
	document.documentElement.onmousemove = function(e)
	{
		// Calculate pageX/Y if missing and clientX/Y available
		if(e.pageX == null && e.clientX != null)
		{
			var doc = document.documentElement;
			var body = document.body;
			e.pageX = e.clientX + (doc && doc.scrollLeft || body && body.scrollLeft || 0) - (doc && doc.clientLeft || body && body.clientLeft || 0);
			e.pageY = e.clientY + (doc && doc.scrollTop || body && body.scrollTop || 0) - (doc && doc.clientTop || body && body.clientTop || 0);
		}

		if(typeof KeyManager !== 'undefined')
		{
			KeyManager.x = e.pageX;
			KeyManager.y = e.pageY;

			if(KeyManager.leftMouse && game && game.editingMode)
				game.editor.mouseMove();
		}
	};
}
