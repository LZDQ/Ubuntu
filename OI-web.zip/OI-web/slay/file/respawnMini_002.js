(function(){
    FunUI.traits.respawnMini = {
        _timeTillRespawn : null,
        _buttonRespawn : null,
        _counterLabel : null,
        __init__: function () {
            this._counterLabel = this.querySelector('.counter');
            this._buttonRespawn = this.querySelector('.F-Button.respawn');
            if (window.sendRespawn) {
                this._buttonRespawn.on('click', sendRespawn);
            }
            this._spreadButton = this.querySelector('.F-Button.spread');
            this._spreadButton.on('click', this.hide.bind(this, false));
        },
        show : function() {
            document.getElementById("menuButtonContainer").appendChild(this);
        },
        hide : function(force) {
            if (this.parentNode) {
                this.parentNode.removeChild(this);
            }

            if (!force) {
                F$('respawn').open();

                if (this._timeTillRespawn <= 0) {
                    F$('respawn').progress(0);
                }
            }
        },
        progress : function(timeTillRespawn) {
            this._timeTillRespawn = timeTillRespawn;
            if (!this.parentNode) {
                return;
            }

            if (timeTillRespawn > 0) {
                if (!this._buttonRespawn.disabled) {
                    this.addClass('waiting');
                    this.removeClass('ready');
                    this._buttonRespawn.disabled = true;
                }

                var respawnTimeStr = timeTillRespawn.toString();
                if(respawnTimeStr.indexOf(".") < 0) {
                    respawnTimeStr += ".0";
                }

                this._counterLabel.innerHTML = respawnTimeStr;
            } else if (timeTillRespawn == 0) {
                this.addClass('ready');
                this.removeClass('waiting');
                this._buttonRespawn.disabled = false;
            }
        }
    };
})();