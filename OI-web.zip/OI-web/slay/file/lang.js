(function( window, slayOne, document ){

var languageObject = {
	locale: null,
	supportedLocales: {
        'ar-SA': 'العربية',
        'de-DE': 'Deutsch',
        'en-US': 'English',
        'es-ES': 'español',
        'fr-FR': 'français',
        'id-ID': 'Bahasa Indonesia',
        'it-IT': 'italiano',
        'ja-JP': '日本語',
        'ko-KR': '한국어',
        // 'nl-NL': 'Nederlands',
        // 'no-NO': 'nynorsk',
        'pl-PL': 'polski',
        'pt-BR': 'português(Brazil)',
        // 'pt-PT': 'português(Portugal)',
        'ru-RU': 'русский',
        // 'sv-SE': 'svenska',
        'th-TH': 'ไทย',
        'tr-TR': 'Türkçe',
        'zh-TW': '中文(繁體)',
        'zh-CN': '中文(简体)',
	},
	defaultLocale: 'en-US',
	data: {},
	get: function(key, params){
		var result = this.data[this.locale][key];
		if (!result || result.length <= 0) {
			return "";
		}

		if (params) {
            result = result.replace(/\[\[([^\]]+)]]/g, function(pattern, key) {
                return params[key];
            });
		}

		return result;
	},
	initialize: function(callback) {
		var self = this;

		this.locale = this.getClosestLocale(this.getPreferredLocale() /*|| FacebookUtils.locale*/ || this.getSystemLocale());
		document.documentElement.setAttribute("lang", this.locale);
		// load locale and input to data
		ajax("locales/" + this.locale + ".json", function(data){
			self.data[self.locale] = JSON.parse(data);
			callback();
		});
	},
	getPreferredLocale: function(){
		var result = null;
		try {
			result = window.localStorage.getItem("langChosen");
		} catch(e) {
			result = null;
		}
		return result;
	},
	setPreferredLocale: function(val){
		try {
			window.localStorage.setItem("langChosen", val);
		} catch(e) {
			console.error(e);
		}
	},
	getSystemLocale: function(){
	    if (window.navigator.languages && window.navigator.languages.length != 0) {
	        return window.navigator.languages;
		}

		return window.navigator.language || window.navigator.browserLanguage || window.navigator.userLanguage;
	},
	getClosestLocale : function(locale) {
		if (!Array.isArray(locale)) {
			locale = [locale];
		}

		locale.map((lang) => {
			if (typeof lang != 'string') {
				return 'none';
			}
            return lang.replace("_", "-");
		});

		for (var lang of locale) {
            if (this.supportedLocales[lang]) {
                return lang;
            }
		}

        for (var i = 0; i < locale.length; i ++) {
            var lang = locale[i];

            for(var itrLang in this.supportedLocales) {
            	if (!this.supportedLocales.hasOwnProperty(itrLang))
            		continue;

                var strikeIndex = lang.indexOf("-");
                var main = strikeIndex >= 0 ? lang.substr(0, strikeIndex) : lang;

                if (itrLang.indexOf(main) == 0) {
                    return itrLang;
                }
            }
		}

		return this.defaultLocale;
	}
};

//export
if(!slayOne.widgets) {
    slayOne.widgets = {};
}

slayOne.widgets.lang = languageObject;

})(window, window.slayOne, window.document);//end main closure
