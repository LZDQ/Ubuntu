"use strict";

var pl_custombuild;

class CustomBuild {

	static show() {
		if(!playerData)
		{
			network.send('joinRandomGame$abc$' + MAP_TYPE.TOURNAMENT_UNRANKED);
			return;
		}

		pl_custombuild = this._copy(playerData.abilities);
		for(var i in pl_custombuild)
			pl_custombuild[i].id = i;

		var o = this.get();
		this.refresh();
		this.refreshCount();
		o.style.display = 'block';
	}

	static get(checkOnly) {
		var o = document.getElementById('customBuild');
		if(!o)
		{
			if(checkOnly)
				return;

			abilities.map((a) => {
				a.isPassive = a.type == 'passive';
				return a;
			});

			o = this._create();
		}
		return o;
	}

	static refresh() {
		for(var ab of pl_custombuild)
			if(ab.lvl)
				this.selectAb(ab.id, true);
	}

	static _drawOperate(box) {
		var preview = document.createElement('div');
		preview.className = 'preview';

		var previewTitle = document.createElement('p');
		previewTitle.className = 'title';
		previewTitle.innerText = 'abilities summary'
		preview.appendChild(previewTitle);

		var previewAb = document.createElement('div');
		previewAb.className = 'ab';
		preview.appendChild(previewAb);

		var reset = document.createElement('div');
		reset.className = 'F-Button large reset';
		reset.innerText = F_('game.btn.reset');
		reset.onclick = this.reset;

		box.appendChild(preview);

		var o = document.createElement('div');
		o.className = 'enter';

		var save = document.createElement('div');
		save.className = 'F-Button large';
		save.innerText = F_('profile.btn_desc_save.label');
		save.onclick = this.save;
		
		o.appendChild(reset);
		o.appendChild(save);

		box.appendChild(o);
	}

	static save() {
		var pre = CustomBuild._copy(pl_custombuild);
		pre.map((a) => {
			delete(a.id);
			return a;
		});

		var json = JSON.stringify(pre);
		if(json != JSON.stringify(playerData.abilities))
		{
			playerData.abilities = JSON.parse(json);
			network.send("abUpd$" + json);
		}
		
		Skin.refreshAbilitiesButton();
		CustomBuild.close();
	}

	static _copy(a) {
		return JSON.parse(JSON.stringify(a));
	}

	static _create() {
		var box = document.createElement('div');
		box.id = 'customBuild';
		box.className = 'F-Window';

		var h2 = document.createElement('div');
		h2.className = 'title';
		h2.innerText = 'BUILD';
		box.appendChild(h2);

		var inBox = document.createElement('div');
		inBox.className = 'content';

		var oCount = document.createElement('div');
		oCount.className = 'count';
		inBox.appendChild(oCount);

		var oAlert = document.createElement('div');
		oAlert.className = 'alert';
		inBox.appendChild(oAlert);

		this._drawOperate(inBox);

		this._drawAbAll(inBox);

		box.appendChild(inBox);

		var close = document.createElement('div');
		close.className = 'F-Button close';
		close.onclick = () => {
			this.close();
		};
		box.appendChild(close);

		document.body.appendChild(box);

		F$(box.id);

		return box;
	}

	static _drawAb(ab) {
		if (ab.zombieOnly) {
			return;
		}

		var btn = document.createElement('div');
		btn.className = 'checkbox';
		btn.onclick = () => {
			this.selectAb(ab.id);
		};

		var name = document.createElement('p');
		name.className = 'name';
		name.innerText = ab.name;

		var description = document.createElement('p');
		description.className = 'description';
		description.innerText = ab.description;

		var icon = Skin.tplCanvasAb(ab.id, 48);

		var row = document.createElement('div');
		row.className = 'ab-main ab_' + ab.id;
		row.appendChild(icon);
		row.appendChild(btn);
		row.appendChild(name);
		row.appendChild(description);

		var sub = this._drawAbSub(ab.id);
		if(sub)
			row.appendChild(sub);

		return row;
	}

	static _drawAbAll(box) {
		var abList = document.createElement('div');
		abList.className = 'ab-list';

		for (let isPassive of [false, true]) {

			if (isPassive) {
				var row= document.createElement('div');
				row.className = 'passive-text';
				row.innerText = 'Passive skill';
				abList.appendChild(row);
			}

			for (let ab of abilities) {

				if (ab.isPassive != isPassive) {
					continue;
				}

				var row = this._drawAb(ab);
				if (row) {
					abList.appendChild(row);
				}
			}
		}

		box.appendChild(abList);
	}

	static _drawAbSub(id) {
		var ab = abilities[id];

		if (!ab.isPassive && !ab.levelUpFields) {
			return;
		}

		var row = document.createElement('div');
		row.className = 'sub-tree';

		if (ab.isPassive) {

			var p = document.createElement('p');
			p.className = 'have-' + pl_custombuild[id].lvl;
			this._appendModBtn(p, id);
			this._appendMod(p, 10);
			row.appendChild(p);

		} else {

			for (var i = 0, j = ab.levelUpFields.length; i < j; i++) {
				var p = document.createElement('p');

				var lvl = 0;
				if (pl_custombuild[id].attributes.length > 0) {
					lvl = pl_custombuild[id].attributes[i];
				}
				p.className = 'have-' + lvl;
				p.innerText = ab.levelUpFieldsName[i];
				this._appendModBtn(p, id, i);
				this._appendMod(p, ab.levelUpMaxLvl[i]);
				row.appendChild(p);
			}
		}

		return row;
	}

	static _setSubTreeClass(id, sub, o) {
		var ab = abilities[id];

		if (!o) {
			var box = this.get();
			if (!box) {
				return;
			}
			if (ab.isPassive) {
				sub = 0;
			}

			o = box.querySelector('.ab_' + id + ' .sub-tree p:nth-of-type(' + (sub + 1) + ')');
		}

		var lvl = 0;
		var max = 10;
		var pl = pl_custombuild[id];

		if (ab.isPassive) {
			lvl = pl.lvl;
		} else {
			lvl = pl.attributes.length ? pl.attributes[sub] : 0;
			max = ab.levelUpMaxLvl[sub];
		}

		var className = 'have-' + lvl;
		if (lvl == 0) {
			className += ' min';
		} else if (lvl == max) {
			className += ' max';
		}
		o.className = className;
	}

	static _appendMod(box, j) {
		var div = document.createElement('div');
		for (var i = 0; i < j; i++) {
			var o = document.createElement('i');
			div.appendChild(o);
		}
		box.appendChild(div);
		return box;
	}

	static _appendModBtn(box, ab, sub) {
		var subBtn = document.createElement('div');
		subBtn.className = 'sub';
		subBtn.onclick = () => {
			this.click(ab, sub, false);
		};
		box.appendChild(subBtn);

		var addBtn = document.createElement('div');
		addBtn.className = 'add';
		addBtn.onclick = () => {
			this.click(ab, sub, true);
		};
		box.appendChild(addBtn);

		return box;
	}

	static click(id, sub, isAdd) {
		soundManager.playSound(SOUND.CLICK);

		if (isAdd && this.isMaxAb()) {
			this.alert();
			return;
		}

		var o = this.get();
		var add = isAdd ? 1 : -1;
		var isChange = false;
		var ab = abilities[id];
		var pl = pl_custombuild[id];

		if (ab.isPassive) {

			if ((isAdd && pl.lvl < 10) || (!isAdd && pl.lvl > 0)) {
				pl.lvl += add;
				o.querySelector('.ab_' + id + ' .sub-tree p').className = 'have-' + pl.lvl;
				if (pl.lvl < 1) {
					pl.lvl = 1;
					this.selectAb(id);
				}
			}

		} else if (ab.levelUpFieldsName.length) {

			var att = pl.attributes;
			if (!att.length) {
				att = ab.levelUpFields.map(() => {return 0;});
				pl.attributes = att;
			}

			var lvl = att[sub];
			if ((isAdd && lvl < ab.levelUpMaxLvl[sub]) || (!isAdd && lvl > 0)) {
				lvl += add;
			}
			att[sub] = lvl;
			o.querySelector('.ab_' + id + ' .sub-tree p:nth-of-type(' + (sub + 1) + ')').className = 'have-' + lvl;
		}

		this.refreshCount();
	}

	static calcAb() {
		var i = 0;
		pl_custombuild.map((a) => {
			i += a.lvl;
			if (a.attributes && a.attributes.length) {
				i += a.attributes.reduce((m, n) => {
					return m + n;
				});
			}
		});
		return i;
	}

	static calcActiveAb() {
		var i = 0;
		pl_custombuild.map((a) => {
			var ab = abilities[a.id];
			if (ab.isPassive) {
				return;
			}
			if (a.lvl) {
				i++;
			}
		});
		return i;
	}

	static refreshCount() {
		var main = document.getElementById('customBuild');

		var o;

		o = main.querySelector('.count');
		if (!o) {
			return;
		}
		o.innerText = 'Abilities points: ' + this.calcAb() + ' / 12';

		o = main.querySelector('.preview .ab');
		Skin.abilitiesThumbnail(o, pl_custombuild, 42);
	}

	static isMaxAb() {
		return this.calcAb() >= 12;
	}

	static reset() {
		pl_custombuild.map((a) => {
			a.lvl = 0;
			a.attributes = [];
			return a;
		});

		var o = CustomBuild.get(true);
		if (!o) {
			return;
		}

		var list = o.querySelectorAll('.ab-main')
		for (var btn of list) {
			btn.className = btn.className.replace(/ select/g, '');
		}

		CustomBuild.refreshCount();
	}

	static selectAb(i, showOnly) {
		var o = this.get(true);
		if (!o) {
			return;
		}

		if (!showOnly) {
			soundManager.playSound(SOUND.CLICK);
		}

		var pl = pl_custombuild[i];
		
		if(!pl)
		{
			pl_custombuild[i] = {
				lvl: 0,
				id: i
			}
			
			pl = pl_custombuild[i];
		}
		
		var isSelect = pl && pl.lvl > 0;
		var ab = abilities[i];

		if (!showOnly) {
			isSelect = !isSelect;
			if (isSelect) {
				if (this.isMaxAb()) {
					this.alert();
					return;
				}

				if (!ab.isPassive && this.calcActiveAb() >= 2) {
					this.alert('2active');
					return;
				}
			}
			pl.attributes = [];
			pl.lvl = isSelect? 1 : 0;
		}

		var div = o.querySelector('div.ab_' + i);
		var className = div.className;
		if (isSelect) {
			className += ' select';
		} else {
			className = className.replace(/ select/g, '')
		}
		div.className = className;

		if (isSelect && !showOnly) {

			className = 'have-0';
			if (isSelect && ab.isPassive) {
				className = 'have-1';
			}

			var list = div.querySelectorAll('.sub-tree p');
			for (var p of list) {
				p.className = className;
			}
		}

		this.refreshCount();
	}

	static alert(t) {
		var o = document.body.querySelector('#customBuild .alert');
		if (!o) {
			return;
		}
		if (!this.maxAlertVer) {
			this.maxAlertVer = 0;
		}
		this.maxAlertVer++;
		let ver = this.maxAlertVer;

		o.className = 'alert alertActive';

		if (t == '2active') {
			o.innerText = F_('abilities.warn.exceed');
		} else {
			o.innerText = 'You can spend a maximum of 12 skill points';
		}

		window.setTimeout(() => {

			if (ver != this.maxAlertVer) {
				return;
			}
			o.className = 'alert';

			window.setTimeout(() => {

				if (ver != this.maxAlertVer) {
					return;
				}
				o.innerText = '';

			}, 3000);
		}, 500);
	}

	static close() {
		var o = this.get(true);
		if (o) {
			o.style.display = 'none';
		}
	}
}
