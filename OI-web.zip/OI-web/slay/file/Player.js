Player.prototype = new Humanoid();
function Player(id, x, y, name, hp, armor, kills, deaths, weapon, x0, y0, hat, team, isInvisible, maxHP, hpRegeneration, clan_tag, authLevel, souls,
	energyRegeneration, invisEnergyRate, elo, isHumanZombie, isFakeCorpse, isBoss, db_id, worldElo, nameColor)
{
	this.id = parseInt(id);
    this.db_id = db_id;
    
	if(!name)
		name = 'Player';
	
	this.unsafeName = name.substr(0, 15);
	this.name = escapeHtml(this.unsafeName);
	this.authLevel = authLevel;
	
	nameColor = nameColor | 0;
	if(!NAME_COLOR[nameColor])
		nameColor = 50;
	
	if(nameColor > 200 && forcePlayerNameColor)
		nameColor = 200;
	
	this.nameColor = nameColor;
	this.nameColorCode = NAME_COLOR[nameColor].code;
	
	this.x = x;
	this.y = y;
	this.x0 = x0 ? x0 : x;
	this.y0 = y0 ? y0 : y;
	this.x00 = x0;
	this.y00 = y0;
	this.legFrame = 0;
	this.aimX = 0;
	this.aimY = 0;
	
	this.hp = parseFloat(hp);
	this.maxHP = parseFloat(maxHP);
	this.hpRegeneration = parseFloat(hpRegeneration);
	this.armor = parseFloat(armor);
	
	this.elo = elo ? parseInt(elo) : 0;
	this.kills = kills;
	this.deaths = deaths;
	this.weapon = weapon ? weapons[weapon] : weapons[0];
	this.team = parseInt(team);
	
	this.armorBar = imgCoords.armorBar;
	
	if(this.team == 1)
		this.armorBar = imgCoords.armorBarRed;
	
	else if(this.team == 2)
		this.armorBar = imgCoords.armorBarBlue;
	
	this.souls = souls | 0;
	this.soulLvl = getLvlFromSouls(this.souls);
	this.energyRegeneration = parseFloat(energyRegeneration);
	this.invisEnergyRate = parseFloat(invisEnergyRate);
	
	this.hat = hats[parseInt(hat)];
	if(!this.hat)
		this.hat = hats[0];
	this.originalHat = this.hat;
	this.removeAt = 0;
	this.bleeds = true;
	this.clan_tag = clan_tag ? clan_tag : "";
	this.reloadSound2 = null;
	this.lastKiller = null;
	this.noDraw = false;
	this.lastShieldActivated = -999999;
	this.lastShieldActivated2 = -999999;
	this.isHumanZombie = false;
	this.handsOffset = 0;
	this.startBlinkingGreen = -9999;
	this.nextPlayer = null;
	this.isPlayer = true;
	this.iac = "";
	
	this.init();
	
	this.isFakeCorpse = isFakeCorpse;
	this.isBoss = isBoss == 1;
	this.direction2 = Math.floor(Math.random() * 8);
	
	if(this.hp <= 0)
	{
		this.dieAt = game.ticksCounter;
		this.finallyRemoveAt = game.ticksCounter + 50;
	}
	
	game.addToObjectsToDraw(this);
	
	this.isInvisible = isInvisible == true;
	
	if(this == game.playingPlayer)
		game.playingPlayerAbilities = (playerData && playerData.authLevel >= 6) ? playerData.abilities : getDefaultAbilityObj(abilities);;

	if(isHumanZombie)
		this.turnZombie(true);
};

Player.prototype.init = function()
{
	this.z = 0;
	this.vz = 0;
	this.zNegative = 0;
	this.zNegative0 = 0;
	this.vzNegative = 0;
	this.z0 = 0;
	this.dieAt = 0;
	this.direction = 0;
	this.direction2 = 0;
	this.lastTickFire = -999;
	this.lastTimeFlameSoundStarted = -999;
	this.lastDirection2Update = -999;
	this.lastPosUpdate = -999;
	this.lastWeapon = null;
	this.standTime = 0;
	this.isInvisible = false;
	this.noInvisUntil = -9999;
	this.lastThrow = -9999;
	this.stepOffset = Math.floor(Math.random() * 5);
	this.smokeTimeOffset = Math.floor(Math.random() * 10);
    this.lastLifeSteal = -999;
    this.zombieSense = 0;
    this.isBoss = false;
    this.turnedBossAt = -99999;

	this.switchWeaponUntil = -999;
	this.bouncePoints = [];
	this.flameSound = null;
	this.flameDeath = false;
	this.flameDeathAndNowBouncing = false;
	this.path = [];
	this.laserHitUntil = -999;
	this.lastHit = -999;
	this.lockDirection2 = 0;
	this.lockDirection = 0;
	this.finallyRemoveAt = 0;
	this.hitUntil = -999;
	this.isReloading = false;
	this.startBlinkingGreen = -9999;
	this.noCorpseBounce = false;
	this.lastHumanToZombieTransformation = -999;
	this.lastDeathToZombieTransformation = -999;
	this.lastZombieToHumanTransformation = -999;
	this.unturnCorpseTill = -99999;
	this.turnCorpseTill = -99999;
	this.isFakeCorpse = false;

	this.lastSpawnTick = -99999;
	this.lightPillarsTop = [];
	this.lightPillarsBottom = [];

	this.hpGlideStart = -999;
	this.hpGlideEnd = -999;
	this.hpGlideAmount = 0;
	this.noDraw = false;
	this.lastShieldActivated = -999999;
	this.lastShieldActivated2 = -999999;
	this.lastShieldHit = -999999;
	this.lastEmoteStart = -99999;
	this.lastEmote = null;

	this.invincibleUntil = -9999;

	this.weaponCooldowns = [];
	this.weaponCooldowns2 = [];
	for(var i = 0; i < 20; i++)
		this.weaponCooldowns2[i] = (weapons[i] && weapons[i].cooldown2) ? weapons[i].cooldown2 : 0;
};

Player.prototype.respawn = function(x, y, turnZombie)
{
	if(this.isHumanZombie)
		this.createCorpse();

	if(turnZombie == "1")
		this.turnZombie();

	this.x = parseFloat(x);
	this.y = parseFloat(y);
	this.x0 = this.x;
	this.y0 = this.y;
	this.hp = this.maxHP;
	this.armor = 0;
	this.weapon = this.isHumanZombie ? weapons[12] : weapons[0];
	this.bouncePoints = [];

	this.init();

	if(turnZombie == "1")
		this.lastDeathToZombieTransformation = game.ticksCounter;

	if(game.playingPlayer == this)
	{
		game.resetPlayingPlayerStats();
		game.lastPickUp = Date.now();
	}

	if(turnZombie != "1")
		this.createSpawnEffect(game.playingPlayer == this);

	if(!this.isHumanZombie && game.ticksCounter >= 2)
		this.invincibleUntil = game.ticksCounter + CONST.SPAWN_INVINCIBILITY;

	if(game.playingPlayer == this)
	{
		uiManager.hideDeathScreen();
		slayOne.viewHelpers.hideAd();
	}
};

Player.prototype.turnBoss = function() {

	this.isBoss = true;
	this.turnedBossAt = game.ticksCounter;

	if (this.isHumanZombie) {

		this.weapon = weapons[14];
		soundManager.playSound(SOUND.ZOMBIE_TRANSFORM, this.x, this.y);

	} else {

		soundManager.playSound(SOUND.HUMAN_TRANSFORM, this.x, this.y);
	}

	this.hp = this.maxHP;
};

Player.prototype.getCured = function()
{
	if(this == game.playingPlayer)
		game.playingPlayerIsZombie = false;

	this.lastZombieToHumanTransformation = game.ticksCounter;

	this.isHumanZombie = false;
	this.weapon = weapons[0];
	this.team = 1;
	this.armor = 0;

	this.hat = this.originalHat;
	this.handsOffset = 0;
	if(this.isBoss)
    	this.isBoss = false;
    
	var el = document.getElementById("tr_" + this.id);
	if(el)
		document.getElementById("statsTable1").appendChild(el);

	if(this == game.playingPlayer)
	{
		game.resetPlayingPlayerStats();
		game.playingPlayerAbilities = (playerData && playerData.authLevel >= 6) ? playerData.abilities : getDefaultAbilityObj(abilities);;
		game.setActiveAbilities();
		game.playingPlayerEnergy = CONST.START_ENERGY;
	}
};

Player.prototype.turnZombie = function(noHpSet)
{
	if(this == game.playingPlayer)
		game.playingPlayerIsZombie = true;

	this.isHumanZombie = true;
	// this.maxHP = game.type.zombieBaseHP;
	if(!noHpSet)
		this.hp = this.maxHP;
	this.hpRegeneration = game.type.zombieHpRegeneration;
	this.energyRegeneration = game.type.zombieEnergyReg;
	this.weapon = weapons[12];
	this.armor = 0;
	this.team = 2;
	this.hat = {
		name: "Zombie",
		offset: 23,
		legs: 10
	};
	this.handsOffset = 256;

	if (this == game.playingPlayer) {
		game.playingPlayerEnergy = (this.soulLvl == 1) ? 100 : CONST.START_ENERGY;
	}

	var el = document.getElementById("tr_" + this.id);
	if(el)
		document.getElementById("statsTable2").appendChild(el);

	if(this == game.playingPlayer)
	{

		game.playingPlayerAbilities = getDefaultZombieAbilityObj((playerData && playerData.authLevel >= 6) ? playerData.abilities : getDefaultAbilityObj(abilities), abilities);

		game.setActiveAbilities();
	}
};

Player.prototype.turnHuman = function()
{
	if(this == game.playingPlayer)
		game.playingPlayerIsZombie = false;

	this.isHumanZombie = false;
	this.weapon = weapons[0];
	this.team = 1;
	this.resetCooldowns();

	this.hat = this.originalHat;
	this.handsOffset = 0;

	var el = document.getElementById("tr_" + this.id);
	if(el)
		document.getElementById("statsTable1").appendChild(el);

	if(this == game.playingPlayer)
	{
		game.playingPlayerAbilities = (playerData && playerData.authLevel >= 6) ? playerData.abilities : getDefaultAbilityObj(abilities);;
		game.setActiveAbilities();
	}
};

Player.prototype.resetCooldowns = function()
{
	// reset both cooldowns if they were cooldownin'
	if(this.weapon && this.weaponCooldowns[this.weapon.id] > 0 && this.weapon.cooldown)
		this.weaponCooldowns[this.weapon.id] = this.weapon.cooldown;

	if(this.weapon && this.weaponCooldowns2[this.weapon.id] > 0 && this.weapon.cooldown2)
		this.weaponCooldowns2[this.weapon.id] = this.weapon.cooldown2;

	this.stopReloadSound();
};

Player.prototype.stopReloadSound = function()
{
	if(this.reloadSound2 && this.reloadSound2.pause)
	{
		this.reloadSound2.pause();
		this.reloadSound2.currentTime = 0;
		this.reloadSound2 = null;
	}
};

Player.prototype.hpUpdate = function(hp, armor, splash)
{
	var newHP = parseFloat(hp);
	var newArmor = parseFloat(armor);
	var diff = parseInt(this.hp - newHP + (this.armor - newArmor));

	this.hp = newHP;
	this.armor = newArmor;

	if(game.playingPlayer == this)
		game.redScreen = Math.min(diff, 100) * 5;

	if(splash != "true" && diff > 9.9 && diff < 10.1 && this.lastShieldActivated <= game.ticksCounter && this.lastShieldActivated + abilities[16].duration >= game.ticksCounter)
	{
		this.lastShieldHit = game.ticksCounter;
		soundManager.playSound(SOUND.SHIELD_HIT, this.x, this.y);
		this.hitUntil = -999;
		this.lastHit = -999;
	}
};

Player.prototype.performLifesteal = function(amount)
{
	amount = Math.min(amount, 300);

	this.hp = Math.min(this.maxHP, this.hp + amount);

	this.lastLifeSteal = game.ticksCounter;

	if(this.x + 3 >= game.cameraX && this.y + 3 >= game.cameraY && this.x - 3 <= game.cameraX2 && this.y - 3 <= game.cameraY2 && !game.fastForward)
		for(var i = 0; i < amount; i += 5)
			new Sprite({
				x: this.x + Math.random() * 0.5 - 0.25,
				y: this.y + 0.5 + Math.random() * 0.5,
				img: imgCoords.healRed,
				scaleFunction: function(age){ return (this.ticksToLive - age) / this.ticksToLive * 2; },
				age: Math.random() * 10 + 35,
				xR: Math.random() * 0.1 - 0.05,
				xFunction: function(age){ return Math.pow(age, 0.7) * this.xR; },
				zFunction: function(age){ return 1.4 + age * 0.02; }
			});
};

Player.prototype.disableAbility = function(ab)
{
	if(ab.type == "invis")
	{
		this.isInvisible = false;
		if(this.x + 3 >= game.cameraX && this.y + 3 >= game.cameraY && this.x - 3 <= game.cameraX2 && this.y - 3 <= game.cameraY2)
		{
			createPoundSmoke(this.x, this.y + 0.5, 0.5, 9, 0.4);
			soundManager.playSound(SOUND.INVIS2, this.x, this.y);
		}
	}

	else if(ab.type == "playdead")
	{
		this.unturnCorpseTill = game.ticksCounter + ab.duration2;
		this.isFakeCorpse = false;
	}
};

Player.prototype.die = function(projectile, murderWeaponId, objX, objY, objAOE, killer, obj, startX, startY, vecX, vecY, vecH)
{
	this.dieAt = game.ticksCounter;
	this.finallyRemoveAt = game.ticksCounter + 100;
	this.lastKiller = killer;

	// drop flag stuff
	if(game.redFlag && game.redFlag.carriedBy == this)
	{
		game.addToObjectsToDraw(game.redFlag);
		game.redFlag.carriedBy = null;
		game.redFlag.isActive = true;

		if(game.getFieldPath(Math.floor(this.x), Math.floor(this.y)) >= 10)
		{
			game.redFlag.currentX = this.x;
			game.redFlag.currentY = this.y;
		}

		else
		{
			game.redFlag.currentX = game.redFlag.x;
			game.redFlag.currentY = game.redFlag.y;

			if(game.playingPlayer && game.playingPlayer.team == 1)
				game.interface_.setMainKillMsg(slayOne.widgets.lang.get("game.msg.flag.self_resetted"), "#36FF36", "textInGreen");

			else
				game.interface_.setMainKillMsg(slayOne.widgets.lang.get("game.msg.flag.enemy_resetted"), "#FF3232", "textInRed");

			soundManager.playSound(SOUND.FRAG1, undefined, undefined, 0.68);
		}
	}

	// flag stuff
	if(game.blueFlag && game.blueFlag.carriedBy == this)
	{
		game.addToObjectsToDraw(game.blueFlag);
		game.blueFlag.carriedBy = null;
		game.blueFlag.isActive = true;

		if(game.getFieldPath(Math.floor(this.x), Math.floor(this.y)) >= 10)
		{
			game.blueFlag.currentX = this.x;
			game.blueFlag.currentY = this.y;
		}

		else
		{
			game.blueFlag.currentX = game.blueFlag.x;
			game.blueFlag.currentY = game.blueFlag.y;

			if(game.playingPlayer && game.playingPlayer.team == 2)
				game.interface_.setMainKillMsg(slayOne.widgets.lang.get("game.msg.flag.self_resetted"), "#36FF36", "textInGreen");

			else
				game.interface_.setMainKillMsg(slayOne.widgets.lang.get("game.msg.flag.enemy_resetted"), "#FF3232", "textInRed");

			soundManager.playSound(SOUND.FRAG1, undefined, undefined, 0.68);
		}
	}

	if(game.playingPlayer && game.redFlag && game.redFlag.carriedBy == this)
	{
		if(this == game.playingPlayer)
		{

		}

		else if(this.team == game.playingPlayer.team)
		{
			game.interface_.setMainKillMsg(slayOne.widgets.lang.get("game.msg.flag.enemy_dropped", { playerName: this.name }), "#FF3232", "textInRed");
			soundManager.playSound(SOUND.FRAG1, undefined, undefined, 0.68);
		}

		else
		{
			game.interface_.setMainKillMsg(slayOne.widgets.lang.get("game.msg.flag.self_dropped", { playerName: this.name }), "#36FF36", "textInGreen");
			soundManager.playSound(SOUND.FRAG1, undefined, undefined, 0.68);
		}
	}
	
	if(game.targetLockedPlayer == this)
		game.targetLockedPlayer = null;
	
	if(game.playingPlayer == this)
		game.resetPlayingPlayerStats();
	
	if(murderWeaponId && weapons[murderWeaponId] && weapons[murderWeaponId].flameDeath)
		this.flameDeath = true;
	
	if(startX || startY || vecX || vecY || vecH)
	{
		this.bouncePoints = createBounce2(startX, startY, vecX, vecY, vecH, game);
		this.noCorpseBounce = true;
	}
	
	else
	{
		var vec = createBounce(this, projectile, objX, objY, objAOE, killer, obj, weapons[murderWeaponId] ? weapons[murderWeaponId].flameDeath : null, this.weapon);
		this.bouncePoints = createBounce2(this.x, this.y, vec.x, vec.y, vec.z, game);
	}
};

Player.prototype.isShootable = function()
{
    var wID = this.weapon.id;
    return this.z <= 0.6 && this.weaponCooldowns[wID] <= 0 && (this.weaponCooldowns2[wID] <= 0 || this.weaponCooldowns2[wID] >= this.weapon.cooldown2) && game.noShootUntil < game.ticksCounter;
};

Player.prototype.getTeamColor = function()
{
	return teamColors[this.team];
};

Player.prototype.carriesFlag = function()
{
	return (game.redFlag && game.redFlag.carriedBy == this) || (game.blueFlag && game.blueFlag.carriedBy == this);
};

Player.prototype.update = function()
{
	if(this.removeAt && this.removeAt <= game.ticksCounter)
		return false;

	if(this.dieAt)
	{
		// disable invisibility ~2 sec after death
		if(this.dieAt + 40 == game.ticksCounter && this.isInvisible)
			this.disableAbility(abilities[4]);

		if(this.dieAt + 20 == game.ticksCounter && game.playingPlayer == this && (!game.type.coopZombieMode || game.type.convertTime > game.ticksCounter || this.isHumanZombie))
			uiManager.showDeathScreen(this.lastKiller ? this.lastKiller.name : "");

		if(this.flameDeath)
		{
			var timeDead = game.ticksCounter - this.dieAt;

			var pos = Math.floor(timeDead / 5);

			if(pos > this.path.length - 2)
			{
				this.updateBounce();
				this.flameDeathAndNowBouncing = true;
			}

			else
			{
				this.x0 = this.x;
				this.y0 = this.y;

				this.x = this.path[pos].x + (this.path[pos + 1].x - this.path[pos].x) * ((timeDead / 5) % 1);
				this.y = this.path[pos].y + (this.path[pos + 1].y - this.path[pos].y) * ((timeDead / 5) % 1);

				this.direction = getDirectionFromAgle(this.x0, this.y0, this.x, this.y);
				this.direction2 = this.direction;
			}

			if(game.ticksCounter % 3 == 1 && this.x + 3 >= game.cameraX && this.y + 3 >= game.cameraY && this.x - 3 <= game.cameraX2 && this.y - 3 <= game.cameraY2 && !game.fastForward)
			{
				new Sprite({
					x: this.x + Math.random() * 0.6 - 0.3,
					y: this.y + Math.random() * 0.6 - 0.3,
					img: imgCoords["fire" + (Math.floor(Math.random() * 4) + 1)],
					scaleFunction: function(age){ return Math.max(0.75 - age / 20, 0) * this.r1; },
					alphaFunction: function(age){ return Math.max(0.75 - age / 20, 0); },
					r1: 3 + Math.random() * 1,
					zFunction: function(age){ return age * 0.1; },
				});

				new Sprite({
					x: this.x + Math.random() * 0.6 - 0.3,
					y: this.y + Math.random() * 0.6 - 0.3,
					img: imgCoords.dust1,
					scaleFunction: function(age){ return Math.max(0.75 - age / 70, 0) * this.r1; },
					alphaFunction: function(age){ return Math.max(0.40 - age / 90, 0); },
					r1: 3 + Math.random() * 1,
					zFunction: function(age){ return age * 0.1; },
				});

				// light
				new Sprite({
					x: this.x,
					y: this.y - 0.5,
					img: imgCoords.light_yellow,
					scaleFunction: function(age){ return Math.max(1 - age / 30, 0) * 4; },
					alphaFunction: function(age){ return Math.max(1 - age / 25, 0) * 0.16; }
				});
			}
		}

		else
			this.updateBounce();

		if(this.dieAt && game.playingPlayer == this)
		{
			var timeTillRespawn = Math.floor(((this.dieAt + CONST.PLAYER_RESPAWN_DELAY - game.ticksCounter) / 20) * 10) / 10;
			uiManager.countDownDeath(timeTillRespawn);
		}
	}

	else if(this.bouncePoints.length > 0)
		this.updateBounce();

	else if(this.weapon && this.switchWeaponUntil <= game.ticksCounter)
	{
		this.weaponCooldowns[this.weapon.id]--;

		if(this.isReloading)
		{
			this.weaponCooldowns2[this.weapon.id]--;

			if(this.weaponCooldowns2[this.weapon.id] < 0)
			{
				this.isReloading = false;
				this.stopReloadSound();
			}
		}
	}

	if(!this.dieAt)
	{
		this.z0 = this.z;

		if(this.z > 0)
		{
			this.z = Math.max(this.z + this.vz, 0);
			this.vz -= CONST.GRAVITY;

			if(this.z <= 0) // if we hit ground after jump
			{
				this.zNegative = -0.001;
				this.zNegative0 = 0;
				this.vzNegative = Math.max(this.vz * 0.9, -0.38);
			}
		}

		if(this.zNegative < 0 || this.zNegative0 < 0)
		{
			this.zNegative0 = this.zNegative;
			this.zNegative += this.vzNegative;
			this.vzNegative += 0.15;

			if(this.zNegative > 0)
				this.zNegative = 0;

			if(this.zNegative0 > 0)
				this.zNegative0 = 0;
		}

		this.spillBloodFromMeleeAttack();

		if(this.isHumanZombie && this == game.playingPlayer && game.ticksCounter % 20 == 13)
		{
			var bestDist = 999999;
			var bestPlayer = null;
			for(var i = 0; i < game.players.length; i++)
			{
				var p = game.players[i];

				if(!p.dieAt && !p.isHumanZombie)
				{
					var dist = Math.sqrt(Math.pow(p.x - this.x, 2) + Math.pow(p.y - this.y, 2));
					if(dist < bestDist && dist > 10)
					{
						bestDist = dist;
						bestPlayer = p;
					}
				}
			}

			this.nextPlayer = bestPlayer;
		}
	}

	// flamethrower sound update
	if(this.weapon == weapons[2] && this.lastTickFire + 7 > game.ticksCounter)
	{
		var volume = Math.min((this.lastTickFire + 7 - game.ticksCounter) / 5, 1) * 0.7;

		if(this.flameSound)
		{
			this.flameSound.volume = Math.max(volume * soundManager.getVolumeModifier(this.x, this.y), 0) * sound_volume;

			if(this.lastTimeFlameSoundStarted + 5300 < Date.now())
			{
				this.flameSound = soundManager.playSound(SOUND.FLAMETHROWER, this.x, this.y, volume);
				this.lastTimeFlameSoundStarted = Date.now();
			}
		}

		else
		{
			this.flameSound = soundManager.playSound(SOUND.FLAMETHROWER, this.x, this.y, volume);
			this.lastTimeFlameSoundStarted = Date.now();
		}
	}

	else if(this.flameSound)
	{
		this.flameSound.pause();
		this.flameSound.currentTime = 0;
		this.flameSound = null;
	}

	if(!this.dieAt && this.bouncePoints.length == 0 && this.lastPosUpdate < game.ticksCounter)
	{
		if(Math.sqrt(Math.pow(this.x - this.x0, 2) + Math.pow(this.y - this.y0, 2)) < 0.005)
		{
			this.x0 = this.x;
			this.y0 = this.y;
		}

		var x0 = this.x;
		var y0 = this.y;

		this.x += this.x - this.x0;
		this.y += this.y - this.y0;

		this.x0 = x0;
		this.y0 = y0;

		if(this.z <= 0 && (this.x != this.x0 || this.y != this.y0) && this.stepOffset == (game.ticksCounter % 5))
			soundManager.playSound(SOUND.STEP, this.x, this.y, 0.65);
	}

    // check if this player is seen
    if(game.type.coopZombieMode && this.isInvisible && 1 == game.ticksCounter % 20)
    {
    	for(var i = 0; i < game.players.length; i++)
    		if((game.players[i].team != this.team || this.team == 0) && game.players[i] != this && Math.sqrt(Math.pow(game.players[i].x - this.x, 2) + Math.pow(game.players[i].y - this.y, 2)) < 3)
    			this.noInvisUntil = game.ticksCounter + 40;

    	for(var i = 0; i < game.zombies.length; i++)
    		if(game.zombies[i].team != this.team && Math.sqrt(Math.pow(game.zombies[i].x - this.x, 2) + Math.pow(game.zombies[i].y - this.y, 2)) < 3)
    			this.noInvisUntil = game.ticksCounter + 40;
    }

	this.hp = Math.min(this.hp + this.hpRegeneration, this.maxHP);

	return true;
};

Player.prototype.setElo = function(count, x, y)
{
	var oldElo = this.elo;
	this.elo = parseInt(count);
	var diff = this.elo - oldElo;

	if(this == game.playingPlayer && diff > 0 && (x || y))
		game.floatingTexts.push(new FloatingText("+" + diff, x, y - 0.6, 1700, 1, "#B4B7B8", SCALE_FACTOR * 6));

	return diff;
};

Player.prototype.setKills = function(count)
{
	if(this == game.playingPlayer && this.isHumanZombie && count == (this.kills + 1))
		game.playingPlayerZombieKillStreak++;

	this.kills = parseInt(count);
};

Player.prototype.setDeaths = function(count)
{
	this.deaths = parseInt(count);

	if(this == game.playingPlayer && this.isHumanZombie)
		game.playingPlayerZombieKillStreak = 0;
};

Player.prototype.emote = function(emote)
{
	this.lastEmoteStart = game.ticksCounter;
	this.lastEmote = emote;
};

Player.prototype.setSouls = function(count, x, y)
{
	var diff = parseInt(count - this.souls);
	this.souls = parseInt(count);
	this.soulLvl = getLvlFromSouls(count);

	/*
	var el = document.getElementById("td_souls_" + this.id);

	if(el)
		el.innerHTML = this.souls;
	*/

	if(this == game.playingPlayer && diff > 0 && (x || y))
		game.floatingTexts.push(new FloatingText("+" + diff, x, y - 1.6, 1700, 1, "#B4B7B8", SCALE_FACTOR * 6, imgCoords.souls));

	if(this == game.playingPlayer && diff != 0)
		game.interface_.refreshSouls(this.souls);
};

Player.prototype.createAtributeEffect = function()
{
	this.lightPillarsTop = [];
	this.lightPillarsBottom = [];

	if(!(this.x + 5 >= game.cameraX && this.y + 5 >= game.cameraY && this.x - 5 <= game.cameraX2 && this.y - 5 <= game.cameraY2) || game.fastForward)
		return;

	for(var i = 0; i < Math.PI * 2; i += 0.4 + Math.random() * 0.15)
		(i <= Math.PI ? this.lightPillarsBottom : this.lightPillarsTop).push({
			x: Math.sin(i) * 0.45 + this.x,
			y: Math.cos(i) * 0.45 + this.y,
			w: 0.15 + Math.random() * 0.3,
			h: Math.random() * 1.5,
			vh: 0.05 + Math.random() * 0.1,
			vw: Math.random() * 0.01,
			age_offset: Math.random() * 8 - 4,
			img: imgCoords.pillar_of_light_yellow
		});

	for(var k = 0; k < 8; k++)
	{
		var randomAngle = Math.random() * Math.PI * 2;
		var rand = Math.random() * 0.7;

		new Sprite({
			x: this.x + Math.cos(randomAngle) * rand,
			y: this.y - SHOT_HEIGHT + Math.sin(randomAngle) * rand,
			z: Math.random(),
			img: imgCoords.particleWhite,
			scaleFunction: function(age){ return this.scale_; },
			scale_: Math.random() * 2 + 2,
			z_: Math.random() * 0.09,
			zFunction: function(age){ return age * this.z_; },
			age: 21
		});
	}

	// light
	new Sprite({
		x: this.x,
		y: this.y,
		img: imgCoords.light_white,
		scaleFunction: function(age){ return Math.max(0, 1 - (age / this.ticksToLive) * 0.6) * 5; },
		alphaFunction: function(age){ return Math.max((-1 * (1/ (((age * 0.9) - 125) / 500 + 0.31) + age / 4) + 16.9) * 3.7, 0) * 0.04; },
		age: 40,
	});

	soundManager.playSound(SOUND.ATT_UP, this.x, this.y, 0.85);

	this.lastSpawnTick = game.ticksCounter - 8;
};

Player.prototype.createLvlUpEffect = function()
{
	this.lightPillarsTop = [];
	this.lightPillarsBottom = [];

	if(!(this.x + 5 >= game.cameraX && this.y + 5 >= game.cameraY && this.x - 5 <= game.cameraX2 && this.y - 5 <= game.cameraY2) || game.fastForward)
		return;

	if(game.playingPlayer == this)
		game.floatingTexts.push(new FloatingText("+" + CONST.CRYSTALS_PER_SOULS_LVL, this.x, this.y - 1, 1700, 1, "#5cc3ef", SCALE_FACTOR * 6, imgCoords.crystals));

	for(var i = 0; i < Math.PI * 2; i += 0.25 + Math.random() * 0.1)
		(i <= Math.PI ? this.lightPillarsBottom : this.lightPillarsTop).push({
			x: Math.sin(i) * 0.6 + this.x,
			y: Math.cos(i) * 0.6 + this.y,
			w: 0.15 + Math.random() * 0.3,
			h: Math.random() * 1.5,
			vh: 0.05 + Math.random() * 0.1,
			vw: Math.random() * 0.01,
			age_offset: Math.random() * 8 - 4,
			img: imgCoords.pillar_of_light_blue
		});

	for(var k = 0; k < 12; k++)
	{
		var randomAngle = Math.random() * Math.PI * 2;
		var rand = Math.random() * 0.7;

		new Sprite({
			x: this.x + Math.cos(randomAngle) * rand,
			y: this.y - SHOT_HEIGHT + Math.sin(randomAngle) * rand,
			z: Math.random(),
			img: imgCoords.particleWhite,
			scaleFunction: function(age){ return this.scale_; },
			scale_: Math.random() * 2 + 2,
			z_: Math.random() * 0.09,
			zFunction: function(age){ return age * this.z_; },
			age: 26
		});
	}

	// light
	new Sprite({
		x: this.x,
		y: this.y,
		img: imgCoords.light_white,
		scaleFunction: function(age){ return Math.max(0, 1 - (age / this.ticksToLive) * 0.6) * 5; },
		alphaFunction: function(age){ return Math.max((-1 * (1/ (((age * 0.9) - 125) / 500 + 0.31) + age / 4) + 16.9) * 3.7, 0) * 0.04; },
		age: 44,
	});

	new Sprite({
		x: this.x,
		y: this.y,
		img: imgCoords.light_white,
		scaleFunction: function(age){ return Math.max(0, 1 - (age / this.ticksToLive) * 0.7) * 5; },
		alphaFunction: function(age){ return Math.max((-1 * (1/ (((age * 0.9) - 125) / 500 + 0.31) + age / 4) + 16.9) * 3.7, 0) * 0.1; },
		age: 60,
	});

	this.lastSpawnTick = game.ticksCounter;

	soundManager.playSound(SOUND.LVL_UP, this.x, this.y, this == game.playingPlayer ? 1 : 0.5);
};

Player.prototype.playFragSound = function(multiKillCount, volume)
{
	var fragSoundVolume = 0.68 * (volume ? volume : 1);

	if(multiKills[multiKillCount])
	{
		soundManager.playSound(SOUND[multiKills[multiKillCount].sound], undefined, undefined, 1.0);
		fragSoundVolume = 0.5;
	}

	soundManager.playSound(SOUND["FRAG" + Math.min(parseInt(multiKillCount), 5)], undefined, undefined, fragSoundVolume);
};

Player.prototype.refShieldHit = function(projectile, timesReflected)
{
	projectile.timesShieldReflected = timesReflected;
	soundManager.playSound(SOUND.SHIELD_HIT, this.x, this.y);
	soundManager.playSound(SOUND.REFLECT, this.x, this.y);
	soundManager.playSound(SOUND.REFLECT, this.x, this.y);
	this.lastShieldHit = game.ticksCounter;
	new PlasmaShield(projectile.x, projectile.y, projectile.x + projectile.vecX, projectile.y + projectile.vecY, 2);
	new PlasmaShield(projectile.x, projectile.y, projectile.x + projectile.vecX, projectile.y + projectile.vecY, 1.5);
	new PlasmaShield(projectile.x, projectile.y, projectile.x + projectile.vecX, projectile.y + projectile.vecY, 1.1);
};

Player.prototype.isAlliedWith = function(player)
{
	return this == player || (this.team == player.team && this.team >= 1);
};

Player.prototype.draw = function(exactTicks, x1, y1, x2, y2, percentageOfCurrentTickPassed)
{
	if(!(this.x + 3 >= x1 && this.y + 3 >= y1 && this.x - 3 <= x2 && this.y - 3 <= y2) || this.noDraw)
		return;

	if(this.laserHitUntil >= exactTicks || this.hitUntil >= exactTicks)
	{
		percentageOfCurrentTickPassed = 0;
		exactTicks = this.lastHit;
	}

	var scale = SCALE_FACTOR * 1.4;
	var frame = 0;

	if(this.ishumanZombie && this.soulLvl > 1)
		scale *= Math.pow(1.018, this.soulLvl - 1);

	var x = (this.x0 + percentageOfCurrentTickPassed * (this.x - this.x0) - game.cameraX) * FIELD_SIZE;
	var y = (this.y0 + percentageOfCurrentTickPassed * (this.y - this.y0) - game.cameraY) * FIELD_SIZE;
	var h = (this.z0 + percentageOfCurrentTickPassed * (this.z - this.z0)) * FIELD_SIZE;

	var x_ = x - 32 / 2 * scale;
	var y_ = y - (32 - 12) * scale;

	var x_recoiled = 0;
	var y_recoiled = 0;

	var weapon = null;
	var bounce = false;
	var blackness = 0;
	var whiteness = 0;
	var invisAlpha = 1;
	var isHumanZombie = this.isHumanZombie;
	var lastTickFire = this.lastTickFire;
	var hat = this.hat;
	var team = this.team;
	var zHead = (!this.dieAt && this.z <= 0) ? -((this.zNegative0 + percentageOfCurrentTickPassed * (this.zNegative - this.zNegative0)) * FIELD_SIZE * 0.25) : 0;
	var isInvisible = this.isInvisible;

	if(isInvisible)
	{
		if(this.noInvisUntil >= game.ticksCounter)
			invisAlpha = 0.6;

		else if(!game.playingPlayer || this.isAlliedWith(game.playingPlayer))
			invisAlpha = 0.3;

		else if(game.showEnemiesOnMinimapUntil >= game.ticksCounter)
			invisAlpha = 0.185;

		else if(game.playingPlayer && game.playingPlayer.zombieSense && Math.sqrt(Math.pow(this.x - game.playingPlayer.x, 2) + Math.pow(this.y - game.playingPlayer.y, 2)) < 10)
			invisAlpha = 0.4;

		else
			invisAlpha = 0.086;
	}

	// bushes
	if(game.playingPlayer && game.bushArray[Math.floor(this.x)] && game.bushArray[Math.floor(this.x)][Math.floor(this.y)])
	{
		if(!this.isAlliedWith(game.playingPlayer))
		{
			invisAlpha = 0.076;
			isInvisible = true;

			if(game.bushArray[Math.floor(game.playingPlayer.x)] && game.bushArray[Math.floor(game.playingPlayer.x)][Math.floor(game.playingPlayer.y)] && Math.sqrt(Math.pow(game.playingPlayer.x - this.x, 2) + Math.pow(game.playingPlayer.y - this.y, 2)) <= CONST.BUSH_VISION_RANGE)
			{
				invisAlpha = 0.55;
			}
		}

		else if(game.playingPlayer == this)
			invisAlpha = 0.56;
	}

	var weapon;

	if(this.flameDeath && !this.flameDeathAndNowBouncing)
	{
		var timeDead = exactTicks - this.dieAt;

		blackness = Math.min(timeDead / 50, 0.9);

		h = 0;

		if(timeDead < (this.path.length - 1) * 10)
			frame = parseInt((exactTicks * 0.6) % 8);
	}

	else if(this.dieAt || this.bouncePoints.length > 0)
	{
		if(this.x != this.x0)
			this.direction = (this.x > this.x0) ? 0 : 2;
		else if(this.direction != 2 && this.direction != 0)
			this.direction = 2;

		frame = (this.z >= this.z0 || this.z < 0.1) ? 1 : 0;
		bounce = true;
	}

	else
	{
		var shiftX = 0;
		var shiftY = 0;

		// shift
		if(this.z <= 0)
		{
			var shift = game.shiftArray[Math.floor(this.x)] ? game.shiftArray[Math.floor(this.x)][Math.floor(this.y)] : null;

			if(shift && shift[0])
				shiftX = shift[0];

			if(shift && shift[1])
				shiftY = shift[1];
		}

		if(Math.abs(this.x0 + shiftX - this.x) > 0.01 || Math.abs(this.y0 + shiftY - this.y) > 0.01)
		{
			this.direction = getDirectionFromAgle(this.x0, this.y0, this.x, this.y);
			var dist = Math.sqrt(Math.pow(this.x - this.x0, 2) + Math.pow(this.y - this.y0, 2));

			if(game.ticksCounter > 0)
			{
				if(this.z > 0)
					this.legFrame += exactTickDiff * 0.125;
				else
					this.legFrame += exactTickDiff * 0.6 * (dist / 0.202);
			}

			frame = Math.floor(this.legFrame) % 8;

			// running smoke effekt
			if(tickDiff > 0 && game.ticksCounter >= 0 && (game.ticksCounter + this.smokeTimeOffset) % 6 == 1 && !game.fastForward)
				new Sprite({
					x: this.x + Math.random() * 0.6 - 0.3,
					y: this.y + Math.random() * 0.6 - 0.3,
					img: imgCoords.dust1,
					scaleFunction: function(age){ return this.scale_ - age * 0.01; },
					scale_: Math.random() + 0.75,
					alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.23; },
					age: (1.7 + Math.random()) * 20,
					z_: Math.random() * 40 + 32,
					zFunction: function(age){ return age / this.z_; }
				});
		}
		else
		{
			this.direction = 0;
			frame = 3;
		}

		if(this == game.playingPlayer && game.ticksCounter >= 0 && !window.leavingGame && this.lastDeathToZombieTransformation + 40 < exactTicks &&
			this.lastHumanToZombieTransformation + 40 < exactTicks && !this.isFakeCorpse)
		{
			var newdirection2 = getDirectionFromAgle(x, y, KeyManager.x, KeyManager.y);
			
			if(newdirection2 != this.direction2)
			{
				this.direction2 = newdirection2;
				network.send("dirU$" + this.direction2);
			}
		}

		var switchTimer = (exactTicks + CONST.WPN_SWITCH_TICKS - this.switchWeaponUntil) / CONST.WPN_SWITCH_TICKS;
		weapon = this.weapon;
		var wpn_offset = 0;

		if(switchTimer < 0.17)
		{
			weapon = this.lastWeapon;
			wpn_offset = switchTimer * 70;
		}

		else if(switchTimer < 0.83)
			weapon = null;

		else if(switchTimer < 1)
			wpn_offset = -(-1 + switchTimer) * 70;

		if(isHumanZombie)
			weapon = null;

		if(lastTickFire >= exactTicks - 8)
		{
			x_recoiled = x - KeyManager.x;
			y_recoiled = y - KeyManager.y;

			var len = Math.sqrt(x_recoiled * x_recoiled + y_recoiled * y_recoiled);

			var len2 = 0.2 - Math.min(Math.max(exactTicks - lastTickFire - ((weapon && weapon.recoilTime) ? weapon.recoilTime : 3), 0) * 0.09, 0.2);

			x_recoiled *= (len2 * FIELD_SIZE) / len;
			y_recoiled *= (len2 * FIELD_SIZE) / len;

			if(this.weapon && this.weapon.recoil)
			{
				x_recoiled *= this.weapon.recoil;
				y_recoiled *= this.weapon.recoil;
			}
		}
	}

	var wpn_nr = (weapon && weapon.frames && lastTickFire + 4 > exactTicks) ? ((parseInt(exactTicks / weapon.cooldown) % weapon.frames) + weapon.frame) : (weapon ? weapon.frame : 0);

	if(this.flameDeathAndNowBouncing)
		blackness = 0.9;

	if(this.hitUntil >= exactTicks)
		whiteness = (Math.random() < 0.5) ? 0.95 : 0.1;

	var direction = this.direction;
	var direction2 = this.direction2;
	if(this.laserHitUntil >= exactTicks)
	{
		whiteness = 0.95;
		weapon = null;
		direction = this.lockDirection;
		direction2 = this.lockDirection2;
	}

	var vanishingAlpha = this.getVanishingAlpha(exactTicks);

	var nzOffset = 0;
	var standTime = this.standTime;
	var requiredStandTime = this.weapon.requiredStandTime;

	if(standTime && !this.dieAt)
	{
		nzOffset = Math.min((standTime + percentageOfCurrentTickPassed) / requiredStandTime, 1);
		frame = Math.floor(nzOffset * 2);
		direction = 8;
		nzOffset *= SCALE_FACTOR * 2;
	}

	// next player arrow
	if(this.nextPlayer && this == game.playingPlayer)
	{
		var a = getAngle(this.x, this.y, this.nextPlayer.x, this.nextPlayer.y);
		var dist = 1.0 + (Math.max(game.ticksCounter * 0.1, 0) % 1) * 0.3;

		c.fillStyle = "rgba(0, 0, 0, " + (0.4 + Math.sin(exactTicks * 0.3) * 0.2) + ")";
		c.beginPath();
		c.moveTo(x + Math.cos(a) * (dist + 0.4) * FIELD_SIZE, y + Math.sin(a) * (dist + 0.4) * FIELD_SIZE + 0.1 * FIELD_SIZE);
		c.lineTo(x + Math.cos(a - 0.15) * dist * FIELD_SIZE, y + Math.sin(a - 0.15) * dist * FIELD_SIZE + 0.1 * FIELD_SIZE);
		c.lineTo(x + Math.cos(a + 0.15) * dist * FIELD_SIZE, y + Math.sin(a + 0.15) * dist * FIELD_SIZE + 0.1 * FIELD_SIZE);
		c.lineTo(x + Math.cos(a) * (dist + 0.4) * FIELD_SIZE, y + Math.sin(a) * (dist + 0.4) * FIELD_SIZE + 0.1 * FIELD_SIZE);
		c.closePath();
		c.fill();

		c.fillStyle = "rgba(255, 255, 255, " + (0.4 + Math.sin(exactTicks * 0.3) * 0.2) + ")";
		c.beginPath();
		c.moveTo(x + Math.cos(a) * (dist + 0.4) * FIELD_SIZE, y + Math.sin(a) * (dist + 0.4) * FIELD_SIZE);
		c.lineTo(x + Math.cos(a - 0.15) * dist * FIELD_SIZE, y + Math.sin(a - 0.15) * dist * FIELD_SIZE);
		c.lineTo(x + Math.cos(a + 0.15) * dist * FIELD_SIZE, y + Math.sin(a + 0.15) * dist * FIELD_SIZE);
		c.lineTo(x + Math.cos(a) * (dist + 0.4) * FIELD_SIZE, y + Math.sin(a) * (dist + 0.4) * FIELD_SIZE);
		c.closePath();
		c.fill();
	}

	// shadow
	if(this.weapon == weapons[2] && lastTickFire + 2 >= exactTicks)
		c.globalAlpha = 0.4;
	c.globalAlpha *= vanishingAlpha * invisAlpha;
	c.drawImage(imgs.shadow, x_, y_, 32 * scale, 32 * scale);
	c.globalAlpha = 1.0;

	var age = exactTicks - this.lastSpawnTick;

	if((team == 1 || team == 2) && !this.isFakeCorpse)
	{
		var img = this.team == 1 ? imgCoords.light_red : imgCoords.light_blue;
		var lightAlpha = 1;
		if(isHumanZombie)
		{
			img = imgCoords.light_green;
			lightAlpha = 0.33;
		}
		var scale2 = SCALE_FACTOR * 3.5;
		c.globalAlpha = 0.30 * invisAlpha * lightAlpha;
		c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, x - scale2 * img.w / 2, y - h - scale2 * 12, img.w * scale2, img.h * scale2);
		c.globalAlpha = 1;
	}

	if(age < 25) // play spawn effect
		for(var i = 0; i < this.lightPillarsTop.length; i++)
			this.updateAndDrawPillar(this.lightPillarsTop[i], age);

	// flag
	var flag = team == 1 ? game.blueFlag : game.redFlag;
	var obj = team == 1 ? imgCoords.blueFlag : imgCoords.redFlag;
	if(flag && flag.carriedBy == this)
		c.drawImage(imgs.miscSheet, obj.x, obj.y, obj.w, obj.h, x - SCALE_FACTOR * obj.w / 2, y - h + nzOffset + zHead - (frame % 2) * SCALE_FACTOR / 2 - SCALE_FACTOR * 38, obj.w * SCALE_FACTOR, obj.h * SCALE_FACTOR);

	// reload bar 2
	var reloadPerc = 0;
	if(!wpn_offset && !x_recoiled && !y_recoiled && this.weapon && this.weaponCooldowns2[this.weapon.id] > 0 && this.weaponCooldowns2[this.weapon.id] < this.weapon.cooldown2 && this.bouncePoints.length == 0)
		reloadPerc = (this.weaponCooldowns2[this.weapon.id] - percentageOfCurrentTickPassed) / this.weapon.cooldown2;

	if(this.turnCorpseTill >= exactTicks)
	{
		var dir = this.direction2 % 2;
		frame = 7 - Math.max(Math.min(Math.floor((this.turnCorpseTill - exactTicks) * 7 / 20), 7), 0);
		c.drawImage(imgs.zombieDeath, frame * 32, 32 * dir, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
		return;
	}

	if(this.unturnCorpseTill >= exactTicks)
	{
		var dir = this.direction2 % 2;
		frame = Math.max(Math.min(Math.floor((this.unturnCorpseTill - exactTicks) * 7 / 20), 7), 0);
		c.drawImage(imgs.zombieDeath, frame * 32, 32 * dir, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
		return;
	}

	if(this.isFakeCorpse)
	{
		var dir = this.direction2 % 2;
		c.drawImage(imgs.zombieDeath, 7 * 32, 32 * dir, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
		return;
	}

	var normalDraw = true;
	if(this.lastDeathToZombieTransformation + 40 > exactTicks)
	{
        var turnFrame = Math.max(Math.min(Math.floor((exactTicks - this.lastDeathToZombieTransformation) * 10 / 40), 10), 0);
        var dir = this.direction2 % 2;

        c.globalAlpha = invisAlpha;
        c.drawImage(imgs.turnZombie, turnFrame * 32, dir * 32, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
        c.globalAlpha = 1;

        normalDraw = false;
        weapon = null;
        hat = this.originalHat;
        isHumanZombie = false;

        if(turnFrame <= 5)
        {
	        c.globalAlpha = (5 - turnFrame) / 5;
	        c.drawImage(imgs.legs, (legFrame + 3) * 32, 32 * 8 + hat.legs * 288, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
	        if(hat.hatOnly)
	        	c.drawImage(imgs.heads, 512 + legFrame * 32, 0, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
	        c.drawImage(imgs.heads, 512 + legFrame * 32, 32 * hat.offset, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
	        c.globalAlpha = 1;
	    }
	}

	else if(this.lastHumanToZombieTransformation + 40 > exactTicks)
	{
        var turnFrame = Math.max(Math.min(Math.floor((exactTicks - this.lastHumanToZombieTransformation) * 10 / 40), 10), 0);
        var turnDirection = (this.x0 > this.x) ? 0 : 1;

        c.globalAlpha = invisAlpha;
        c.drawImage(imgs.turnZombie, turnFrame * 32, (2 + turnDirection) * 32, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
        c.globalAlpha = 1;

        normalDraw = turnFrame <= 4;
        weapon = null;
        team = 1;
        hat = this.originalHat;
        isHumanZombie = false;
	}

	else if(this.lastZombieToHumanTransformation + 40 > exactTicks)
	{
        var turnFrame = Math.max(Math.min(Math.floor((exactTicks - this.lastZombieToHumanTransformation) * 5 / 40), 5), 0);

        c.globalAlpha = invisAlpha;
        c.drawImage(imgs.turnZombie, turnFrame * 32, 4 * 32, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
        c.globalAlpha = 1;

        normalDraw = turnFrame <= 0;
        weapon = null;
        team = 1;
        hat = this.originalHat;
        isHumanZombie = false;
	}

	else if(this.turnedBossAt + 40 > exactTicks)
	{
		var img_ = this.isHumanZombie ? imgs.zombieBoss : imgs.humanBoss;
		var transFrame = Math.max(Math.min(Math.floor((exactTicks - this.turnedBossAt) * 7 / 40), 7), 0);
		c.drawImage(img_, 45 * transFrame, 45 * 9, 45, 45, x - 45 / 2 * scale, y - (50 - 12) * scale - h + nzOffset - (frame % 2) * scale / 2 + zHead, 45 * scale, 45 * scale);
        normalDraw = false;
	}

	if(normalDraw)
	{
		// weapon
		if(this.lastThrow + 7 < exactTicks)
		{
			if(weapon)
			{
				c.globalAlpha = invisAlpha;

				c.drawImage(
					imgs.weaponsMinus,
					direction2 * 32 + (reloadPerc ? 256 : 0),
					wpn_nr * 32,
					32,
					32,
					x_ + x_recoiled + Math.sin(frame * (Math.PI / 2)) * scale / 3,
					y_ - h + zHead + nzOffset + wpn_offset + y_recoiled - (frame % 2) * scale / 2,
					32 * scale,
					32 * scale
				);
				c.drawImage(imgs.weaponsBodyMinus, direction2 * 32 + (reloadPerc ? 256 : 0), wpn_nr * 32, 32, 32, x_ , y_ - h + zHead - (frame % 2) * scale / 2, 32 * scale, 32 * scale);

				if(reloadPerc && (direction2 == 3 || direction2 == 4 || direction2 == 5))
				{
					var reloadFrame = Math.floor(exactTicks / 3) % 4;
					c.drawImage(imgs.hands, reloadFrame * 32 + 256, 32 * direction2, 32, 32, x_, y_ - h + nzOffset + zHead, 32 * scale, 32 * scale);
				}

				// muzzle flash
				if(weapon.muzzleFlash && (direction2 == 3 || direction2 == 4 || direction2 == 5) && lastTickFire >= Math.floor(exactTicks) - 4)
				{
					var mfi = imgCoords[weapon.muzzleFlash];
					var mff = -1;

					if(lastTickFire >= game.ticksCounter - 1 && weapon.muzzleFlashAnimationType != "row")
						mff = Math.floor(exactTicks * 0.5) % 2;

					if(lastTickFire >= game.ticksCounter - 4 && weapon.muzzleFlashAnimationType == "row")
						mff = Math.min(Math.floor((exactTicks - 1 - lastTickFire) * 1.0), 3);

					if(mff >= 0)
						c.drawImage(
							imgs.miscSheet,
							mfi.x + direction2 * 52,
							mfi.y + mff * 52,
							52,
							52,
							x_ - 10 * scale + x_recoiled + Math.sin(frame * (Math.PI / 2)) * scale / 2,
							y_ - 10 * scale - h + zHead + nzOffset + wpn_offset + y_recoiled - (frame % 2) * scale / 1.8,
							52 * scale,
							52 * scale
						);
				}

				c.globalAlpha = 1;
			}

			// hands (if no wpn)
			if(!weapon && !bounce && !isHumanZombie)
			{
				c.globalAlpha = invisAlpha;
				c.drawImage(imgs.hands, frame * 32, 32 * direction2 + this.handsOffset, 32, 32, x_, y_ - h + nzOffset + zHead, 32 * scale, 32 * scale);
				c.globalAlpha = 1;

				if(this.flameDeath)
				{
					c.globalAlpha = blackness * invisAlpha;
					c.drawImage(imgs.handsBlack, frame * 32, 32 * direction2 + this.handsOffset, 32, 32, x_, y_ - h + zHead, 32 * scale, 32 * scale);
					c.globalAlpha = 1;
				}

				if(whiteness > 0)
				{
					c.globalAlpha = whiteness;
					c.drawImage(imgs.handsWhite, frame * 32, 32 * direction2 + this.handsOffset, 32, 32, x_, y_ - h + nzOffset + zHead, 32 * scale, 32 * scale);
					c.globalAlpha = 1;
				}
			}
		}

	    if(bounce)
	    {
	    	if(this.isBoss)
	    	{
				var img_ = this.isHumanZombie ? imgs.zombieBoss : imgs.humanBoss;
				var xFrame = Math.floor(Math.min(Math.max((exactTicks - this.dieAt) * 0.25, 0), 6));
				c.globalAlpha = vanishingAlpha * invisAlpha;
				c.drawImage(img_, 45 * xFrame, 45 * 8, 45, 45, x - 45 / 2 * scale, y - (50 - 12) * scale - h + nzOffset - (frame % 2) * scale / 2 + zHead, 45 * scale, 45 * scale);
				c.globalAlpha = 1;
	    	}

	    	else if(isHumanZombie)
	    	{
		        var yFrame = this.direction;
		        if(yFrame >= 1)
		        	yFrame = 1;
		        var xFrame = Math.floor(Math.min(Math.max((exactTicks - this.dieAt) * 0.25, 0), 7));

		        c.globalAlpha = vanishingAlpha * invisAlpha;
		        c.drawImage(imgs.zombieDeath, xFrame * 32, 32 * yFrame, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
		        c.globalAlpha = 1;

		        if(this.flameDeath)
		        {
		            c.globalAlpha = blackness * vanishingAlpha * invisAlpha;
		            c.drawImage(imgs.zombieDeathBlack, xFrame * 32, 32 * yFrame, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
		            c.globalAlpha = 1;
		        }
	    	}

	    	else
	    	{
		        var legFrame = this.direction + frame;
		        var legs_offset = (hat.legs == 0 && team == 2) ? 4 : hat.legs;

		        c.globalAlpha = vanishingAlpha * invisAlpha;
		        c.drawImage(imgs.legs, (legFrame + 3) * 32, 32 * 8 + legs_offset * 288, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
		        if(hat.hatOnly)
		        	c.drawImage(imgs.heads, 512 + legFrame * 32, 0, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
		        c.drawImage(imgs.heads, 512 + legFrame * 32, 32 * hat.offset, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
		        c.globalAlpha = 1;

		        if(this.flameDeath)
		        {
		            c.globalAlpha = blackness * vanishingAlpha * invisAlpha;
		            c.drawImage(imgs.legsBlack, (legFrame + 3) * 32, 32 * 8 + legs_offset * 288, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
		            if(hat.hatOnly)
		            	c.drawImage(imgs.headsBlack, 512 + legFrame * 32, 0, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
		            c.drawImage(imgs.headsBlack, 512 + legFrame * 32, 32 * hat.offset, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
		            c.globalAlpha = 1;
		        }

		        if(whiteness > 0)
		        {
		            c.globalAlpha = whiteness;
		            c.drawImage(imgs.legsWhite, (legFrame + 3) * 32, 32 * 8 + legs_offset * 288, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
		            if(hat.hatOnly)
		            	c.drawImage(imgs.headsWhite, 512 + legFrame * 32, 0, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
		            c.drawImage(imgs.headsWhite, 512 + legFrame * 32, 32 * hat.offset, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
		            c.globalAlpha = 1;
		        }
			}
	    }

		else if(isHumanZombie && lastTickFire + 12 > game.ticksCounter && !this.flameDeath)
		{
			var attackAge = game.ticksCounter - lastTickFire;
			var frame2 = attackAge < 4 ? 0 : 256;

			// legs
			c.drawImage(imgs.legs, frame * 32, 32 * direction + hat.legs * 288, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);

			if(whiteness > 0)
			{
				c.globalAlpha = whiteness;
				c.drawImage(imgs.legsWhite, frame * 32, 32 * direction + hat.legs * 288, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
				c.globalAlpha = 1;
			}

			// head
			if(this.isBoss)
			{
				frame2 = Math.min(5 + attackAge * 1, 9);
				c.drawImage(imgs.zombieBoss, 45 * frame2, 45 * direction2, 45, 45, x - 45 / 2 * scale, y - (50 - 12) * scale - h + nzOffset - (frame % 2) * scale / 2 + zHead, 45 * scale, 45 * scale);
			}

			else
			{
				c.drawImage(imgs.heads, 32 * direction2 + frame2, (hat.offset + 1) * 32, 32, 32, x_, y_ - h + nzOffset, 32 * scale, 32 * scale);

				if(whiteness > 0)
				{
					c.globalAlpha = whiteness;
					c.drawImage(imgs.headsWhite, 32 * direction2 + frame2, (hat.offset + 1) * 32, 32, 32, x_, y_ - h + nzOffset, 32 * scale, 32 * scale);
					c.globalAlpha = 1;
				}
			}
		}

		else
		{
			// legs
			var legs_offset = (hat.legs == 0 && team == 2) ? 4 : hat.legs;
			c.globalAlpha = invisAlpha;
			c.drawImage(imgs.legs, frame * 32, 32 * direction + legs_offset * 288, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
			c.globalAlpha = 1;

			if(this.flameDeath)
			{
				c.globalAlpha = blackness * invisAlpha;
				c.drawImage(imgs.legsBlack, frame * 32, 32 * direction + legs_offset * 288, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
				c.globalAlpha = 1;
			}

			if(whiteness > 0)
			{
				c.globalAlpha = whiteness;
				c.drawImage(imgs.legsWhite, frame * 32, 32 * direction + legs_offset * 288, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
				c.globalAlpha = 1;
			}

			if(this.isBoss)
			{
				var img_ = this.isHumanZombie ? imgs.zombieBoss : imgs.humanBoss;
				c.globalAlpha = invisAlpha;
				c.drawImage(img_, 0, 45 * direction2, 45, 45, x - 45 / 2 * scale, y - (50 - 12) * scale - h + nzOffset - (frame % 2) * scale / 2 + zHead, 45 * scale, 45 * scale);
				c.globalAlpha = 1;
			}

			else
			{
				if(hat.hatOnly)
				{
					c.globalAlpha = invisAlpha;
					c.drawImage(imgs.heads, direction2 * 32 + (reloadPerc ? 256 : 0), 0, 32, 32, x_, y_ - h + nzOffset - (frame % 2) * scale / 2 + zHead, 32 * scale, 32 * scale);
					c.globalAlpha = 1;

					if(this.flameDeath)
					{
						c.globalAlpha = blackness * invisAlpha;
						c.drawImage(imgs.headsBlack, direction2 * 32 + (reloadPerc ? 256 : 0), 0, 32, 32, x_, y_ - h - (frame % 2) * scale / 2 + zHead, 32 * scale, 32 * scale);
						c.globalAlpha = 1;
					}

					if(whiteness > 0)
					{
						c.globalAlpha = whiteness;
						c.drawImage(imgs.headsWhite, direction2 * 32 + (reloadPerc ? 256 : 0), 0, 32, 32, x_, y_ - h + nzOffset - (frame % 2) * scale / 2 + zHead, 32 * scale, 32 * scale);
						c.globalAlpha = 1;
					}
				}

				// head
				c.globalAlpha = invisAlpha;
				c.drawImage(imgs.heads, direction2 * 32 + (reloadPerc ? 256 : 0), 32 * hat.offset, 32, 32, x_, y_ - h + nzOffset - (frame % 2) * scale / 2 + zHead, 32 * scale, 32 * scale);
				c.globalAlpha = 1;

				if(this.flameDeath)
				{
					c.globalAlpha = blackness * invisAlpha;
					c.drawImage(imgs.headsBlack, direction2 * 32 + (reloadPerc ? 256 : 0), 32 * hat.offset, 32, 32, x_, y_ - h - (frame % 2) * scale / 2 + zHead, 32 * scale, 32 * scale);
					c.globalAlpha = 1;
				}

				if(whiteness > 0)
				{
					c.globalAlpha = whiteness;
					c.drawImage(imgs.headsWhite, direction2 * 32 + (reloadPerc ? 256 : 0), 32 * hat.offset, 32, 32, x_, y_ - h + nzOffset - (frame % 2) * scale / 2 + zHead, 32 * scale, 32 * scale);
					c.globalAlpha = 1;
				}
			}
		}

		if(this.lastThrow + 7 >= exactTicks)
		{
			c.globalAlpha = invisAlpha;
			var throwHandsFrame = Math.max(Math.min(Math.floor((exactTicks - this.lastThrow + 1) * 0.5), 3), 0);
			c.drawImage(imgs.throwHands, throwHandsFrame * 32, 32 * direction2, 32, 32, x_, y_ - h + nzOffset + zHead, 32 * scale, 32 * scale);
			c.globalAlpha = 1;
		}

		// weapon
		else if(weapon)
		{
			c.globalAlpha = invisAlpha;

			if(reloadPerc && direction2 != 3 && direction2 != 4 && direction2 != 5)
			{
				var reloadFrame = Math.floor(exactTicks / 3) % 4;
				c.drawImage(imgs.hands, reloadFrame * 32 + 256, 32 * direction2, 32, 32, x_, y_ - h + nzOffset + zHead, 32 * scale, 32 * scale);
			}

			c.drawImage(imgs.weaponsPlus, direction2 * 32 + (reloadPerc ? 256 : 0), wpn_nr * 32, 32, 32, x_ + x_recoiled + Math.sin(frame * (Math.PI / 2)) * scale / 2, y_ - h + zHead + nzOffset + wpn_offset + y_recoiled - (frame % 2) * scale / 1.8, 32 * scale, 32 * scale);
			c.drawImage(imgs.weaponsBodyPlus, direction2 * 32 + (reloadPerc ? 256 : 0), wpn_nr * 32, 32, 32, x_ , y_ - h + zHead + nzOffset - (frame % 2) * scale / 2, 32 * scale, 32 * scale);

			// muzzle flash
			if(weapon.muzzleFlash && direction2 != 3 && direction2 != 4 && direction2 != 5 && lastTickFire >= Math.floor(exactTicks) - 4)
			{
				var mfi = imgCoords[weapon.muzzleFlash];
				var mff = -1;

				if(lastTickFire >= game.ticksCounter - 1 && weapon.muzzleFlashAnimationType != "row")
					mff = Math.floor(exactTicks * 0.5) % 2;

				if(lastTickFire >= game.ticksCounter - 4 && weapon.muzzleFlashAnimationType == "row")
					mff = Math.min(Math.floor((exactTicks - 1 - lastTickFire) * 1.0), 2);

				if(mff >= 0)
					c.drawImage(imgs.miscSheet, mfi.x + direction2 * 52, mfi.y + mff * 52, 52, 52, x_ - 10 * scale + x_recoiled + Math.sin(frame * (Math.PI / 2)) * scale / 2 , y_ - 10 * scale - h + zHead + nzOffset + wpn_offset + y_recoiled - (frame % 2) * scale / 1.8, 52 * scale, 52 * scale);
			}

			c.globalAlpha = 1;
		}

		// hands (if no wpn)
		if(!weapon && !bounce && isHumanZombie && !this.isBoss && lastTickFire + 12 <= game.ticksCounter)
		{
			c.globalAlpha = invisAlpha;
			c.drawImage(imgs.hands, frame * 32, 32 * direction2 + this.handsOffset, 32, 32, x_, y_ - h + nzOffset + zHead, 32 * scale, 32 * scale);
			c.globalAlpha = 1;

			if(this.flameDeath)
			{
				c.globalAlpha = blackness * invisAlpha;
				c.drawImage(imgs.handsBlack, frame * 32, 32 * direction2 + this.handsOffset, 32, 32, x_, y_ - h + zHead, 32 * scale, 32 * scale);
				c.globalAlpha = 1;
			}

			if(whiteness > 0)
			{
				c.globalAlpha = whiteness;
				c.drawImage(imgs.handsWhite, frame * 32, 32 * direction2 + this.handsOffset, 32, 32, x_, y_ - h + nzOffset + zHead, 32 * scale, 32 * scale);
				c.globalAlpha = 1;
			}
		}
	}

	// invincible
	if(this.invincibleUntil >= exactTicks)
	{
		var img_ = imgCoords["bubble" + ((Math.floor(exactTicks * 0.8) % 4) + 1)];
		c.globalAlpha = Math.max(Math.min(0.25, (this.invincibleUntil - exactTicks) * 0.02), 0) * (Math.random() * 0.2 + 0.9);
		c.drawImage(imgs.miscSheet, img_.x, img_.y, img_.w, img_.h, x - img_.w / 2 * scale, y - h - (img_.h / 2 + 6) * scale, img_.w * scale, img_.h * scale);
		c.globalAlpha = 1;
	}

	// lifesteal
	if(this.lastLifeSteal + 10 >= exactTicks)
	{
		var img_ = imgCoords.bubbleRed;
		c.globalAlpha = Math.max(this.lastLifeSteal + 10 - exactTicks, 0) * 0.04;
		c.drawImage(imgs.miscSheet, img_.x, img_.y, img_.w, img_.h, x - img_.w / 2 * scale, y - h - (img_.h / 2 + 6) * scale, img_.w * scale, img_.h * scale);
		c.globalAlpha = 1;
	}

	// green blinking (wenn soon becomign zombie)
	if(this.startBlinkingGreen < game.ticksCounter && this.startBlinkingGreen + 20 * 10 >= game.ticksCounter)
	{
		var img_ = imgCoords.bubbleGreen;
		c.globalAlpha = (0.7 + Math.sin(exactTicks) * 0.3) * 0.25;
		c.drawImage(imgs.miscSheet, img_.x, img_.y, img_.w, img_.h, x - img_.w / 2 * scale, y - h - (img_.h / 2 + 6) * scale, img_.w * scale, img_.h * scale);
		c.globalAlpha = 1;
	}

	// shield
	if(this.lastShieldActivated <= exactTicks && this.lastShieldActivated + abilities[16].duration >= exactTicks)
	{
		var age = Math.min(Math.max(exactTicks - this.lastShieldActivated, 0), 20) / 20;
		var alphaMod = 1;
		if(age < 0.2)
			alphaMod = age * 5;
		if(age > 0.8)
			alphaMod = (1 - age) * 5;

		if(this.lastShieldHit <= exactTicks && this.lastShieldHit + 10 >= exactTicks)
			alphaMod *= 0.6;

		var img_ = imgCoords.shield;
		var img2_ = imgCoords.shield2;
		c.globalAlpha = (Math.cos(exactTicks / 2) + 1 ) * 0.5 * alphaMod;
		c.drawImage(imgs.miscSheet, img_.x, img_.y, img_.w, img_.h, x - img_.w / 2 * scale, y - h - (img_.h / 2 + 6) * scale, img_.w * scale, img_.h * scale);
		c.globalAlpha = (Math.sin(exactTicks / 2) + 1) * 0.5 * alphaMod;
		c.drawImage(imgs.miscSheet, img2_.x, img2_.y, img2_.w, img2_.h, x - img2_.w / 2 * scale, y - h - (img2_.h / 2 + 6) * scale, img2_.w * scale, img2_.h * scale);
		c.globalAlpha = 1;

		if(this.lastShieldHit <= exactTicks && this.lastShieldHit + 10 >= exactTicks)
		{
			age = Math.min(Math.max(exactTicks - this.lastShieldHit, 0), 10) / 10;
			alphaMod = 1;
			if(age < 0.1)
				alphaMod = age * 10;
			if(age > 0.5)
				alphaMod = (1 - age) * 0.5;

			img2_ = imgCoords.shield3;

			c.globalAlpha = alphaMod;
			c.drawImage(imgs.miscSheet, img2_.x, img2_.y, img2_.w, img2_.h, x - img2_.w / 2 * scale, y - h - (img2_.h / 2 + 6) * scale, img2_.w * scale, img2_.h * scale);
			c.globalAlpha = 1;
		}
	}

	// shield2
	if(this.lastShieldActivated2 <= exactTicks && this.lastShieldActivated2 + abilities[16].duration >= exactTicks)
	{
		var age = Math.min(Math.max(exactTicks - this.lastShieldActivated2, 0), 20) / 20;
		var alphaMod = 1;
		if(age < 0.2)
			alphaMod = age * 5;
		if(age > 0.8)
			alphaMod = (1 - age) * 5;

		if(this.lastShieldHit <= exactTicks && this.lastShieldHit + 10 >= exactTicks)
			alphaMod *= 0.6;

		var img_ = imgCoords.refShield;
		var img2_ = imgCoords.refShield2;
		c.globalAlpha = (Math.cos(exactTicks / 2) + 1 ) * 0.5 * alphaMod;
		c.drawImage(imgs.miscSheet, img_.x, img_.y, img_.w, img_.h, x - img_.w / 2 * scale, y - h - (img_.h / 2 + 6) * scale, img_.w * scale, img_.h * scale);
		c.globalAlpha = (Math.sin(exactTicks / 2) + 1) * 0.5 * alphaMod;
		c.drawImage(imgs.miscSheet, img2_.x, img2_.y, img2_.w, img2_.h, x - img2_.w / 2 * scale, y - h - (img2_.h / 2 + 6) * scale, img2_.w * scale, img2_.h * scale);
		c.globalAlpha = 1;

		if(this.lastShieldHit <= exactTicks && this.lastShieldHit + 10 >= exactTicks)
		{
			age = Math.min(Math.max(exactTicks - this.lastShieldHit, 0), 10) / 10;
			alphaMod = 1;
			var scaleS = scale * 1.1;
			
			if(age < 0.1)
			{
				alphaMod = age * 10;
				scaleS = scale + scale * age * 1;
			}
			
			if(age > 0.5)
			{
				alphaMod = (1 - age) * 0.66;
			}

			img2_ = imgCoords.refShield3;

			c.globalAlpha = alphaMod;
			c.drawImage(imgs.miscSheet, img2_.x, img2_.y, img2_.w, img2_.h, x - img2_.w / 2 * scale, y - h - (img2_.h / 2 + 6) * scale, img2_.w * scale, img2_.h * scale);
			c.drawImage(imgs.miscSheet, img2_.x, img2_.y, img2_.w, img2_.h, x - img2_.w / 2 * scaleS, y - h - (img2_.h / 2 + 6) * scaleS, img2_.w * scaleS, img2_.h * scaleS);
			c.globalAlpha = 1;
		}
	}

	if(this.zombieSense && !this.isFakeCorpse && this.hp > 0)
	{
		var phase = (exactTicks % 16) / 15;
		var imgZ = imgCoords.zombieSenseCircle;
		var scaleZ = scale * (0.25 + phase * 1.5);

		c.globalAlpha = Math.max(0.8 - phase, 0.01);
		c.drawImage(imgs.miscSheet, imgZ.x, imgZ.y, imgZ.w, imgZ.h, x - imgZ.w / 2 * scaleZ, y - h - (imgZ.h / 2) * scaleZ - 14 * scale, imgZ.w * scaleZ, imgZ.h * scaleZ);
		c.globalAlpha = 1;
	}

	if(age < 25) // play spawn effect
		for(var i = 0; i < this.lightPillarsBottom.length; i++)
			this.updateAndDrawPillar(this.lightPillarsBottom[i], age);

	if(isInvisible && game.playingPlayer && !this.isAlliedWith(game.playingPlayer))
		return;

	var x = (this.x0 + percentageOfCurrentTickPassed * (this.x - this.x0) - game.cameraX) * FIELD_SIZE;
	var y = (this.y0 + percentageOfCurrentTickPassed * (this.y - this.y0) - game.cameraY) * FIELD_SIZE;

	if(this.dieAt)
		return;

	// hp
	var barScale = SCALE_FACTOR * 0.55;
	var barW = 42;
	var barH = game.playingPlayer == this ? 13: 9;
	var lvlSqSize = 0.45 * FIELD_SIZE;

	var x2 = x - (barW * barScale + lvlSqSize) / 2;
	var y2 = y - 1.85 * FIELD_SIZE - h;

	if(this.isBoss)
		y2 -= (this.isHumanZombie ? 1.0 : 0.5) * FIELD_SIZE;

	// lvl
	if(game.type.souls)
	{
		c.fillStyle = "rgba(22, 22, 22, 0.8)";
		c.fillRect(x2, y2, lvlSqSize, lvlSqSize);
		drawText(c, this.soulLvl.toString(), "white", 4 * SCALE_FACTOR, x2 + lvlSqSize / 2, y2 + lvlSqSize * 0.75, FIELD_SIZE, "center");

		x2 += lvlSqSize;
	}

	else
	{
		x2 += lvlSqSize * 0.5;
	}

	y2 += lvlSqSize - barH * barScale;
	c.fillStyle = "black";
	c.fillRect(x2, y2, barW * barScale, barH * barScale);

	// player name
	c.fillStyle = "rgba(22, 22, 22, 0.8)";
	
	if(this.team == 1)
		c.fillStyle = "rgba(140, 11, 11, 0.8)";
	
	else if(this.team == 2)
		c.fillStyle = "rgba(11, 11, 140, 0.8)";
	
	c.fillRect(x2, y2 - FIELD_SIZE * 0.27, barW * barScale, FIELD_SIZE * 0.26);
	
	/*
	if(this.team == 1 || this.team == 2)
	{
		c.lineWidth = SCALE_FACTOR * 0.5;
		
		if(this.team == 1)
			c.strokeStyle = "rgba(200, 11, 11, 1)";
		
		else if(this.team == 2)
			c.strokeStyle = "rgba(11, 11, 200, 1)";
		
		c.strokeRect(x2, y2 - FIELD_SIZE * 0.27, barW * barScale, FIELD_SIZE * 0.26);
	}
	*/
	
	var nameX = x;
	var nameAlign = 'center';
	if(game.type.souls)
	{
		nameX = x2 + FIELD_SIZE * 0.1;
		nameAlign = 'left';
	}
	drawText(
		c,
		this.unsafeName,
		this.nameColorCode,
		FIELD_SIZE * 0.22,
		nameX,
		y2 - FIELD_SIZE * 0.05,
		null,
		nameAlign,
		null,
		null,
		null,
		(barW - 4) * barScale
	);
	
	var hp = Math.min(this.hp - (this.hpGlideEnd >= exactTicks ? (this.hpGlideAmount * (this.hpGlideEnd - exactTicks) / (this.hpGlideEnd - this.hpGlideStart)) : 0), this.maxHP);

	var img = (!game.playingPlayer || this.isAlliedWith(game.playingPlayer)) ? imgCoords.hpBar1 : imgCoords.hpBar3;

	var w = (barW - 2) * barScale * (hp / this.maxHP);

	c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, x2 + 1 * barScale, y2 + 1 * barScale, w, barScale * 7);

	// hp seperator
	c.strokeStyle = "rgba(0, 0, 0, 1)";
	c.lineWidth = barScale;
	for(var i = CONST.HP_SEPERATOR_AMOUNT; i < this.maxHP; i += CONST.HP_SEPERATOR_AMOUNT)
	{
		c.beginPath();
		c.moveTo(x2 + 1 * barScale + (i / this.maxHP) * (barW - 2) * barScale, y2 + 6 * barScale);
		c.lineTo(x2 + 1 * barScale + (i / this.maxHP) * (barW - 2) * barScale, y2 + 8 * barScale);
		c.stroke();
	}

	// armor
	if(this.armor > 0)
	{
		var w2 = (barW - 2) * (this.armor / CONST.MAX_ARMOR);
		c.drawImage(imgs.miscSheet, this.armorBar.x, this.armorBar.y, w2 * 0.7, this.armorBar.h, x2 + 1 * barScale, y2 + 1 * barScale, w2 * barScale, 7 * barScale);

		// border
		c.strokeStyle = "#CFD2E0";
		c.lineWisth = barScale;
		c.strokeRect(x2 + 0.5 * barScale, y2 + 0.5 * barScale, (barW - 1) * barScale, 8 * barScale);
	}

	// energy
	if(game.playingPlayer == this)
	{
		var hoverAb = pl_active_abilities[this.hoverAbility];
		if(KeyManager.keys[commandKeys[COMMAND.ABILITY1]])
			hoverAb = pl_active_abilities[0];
		if(KeyManager.keys[commandKeys[COMMAND.ABILITY2]])
			hoverAb = pl_active_abilities[1];

		if(!hoverAb && KeyManager.activeAbility)
			hoverAb = KeyManager.activeAbility;

		if(hoverAb)
		{
			img = imgCoords.barBlue;
			w = (barW - 2) * (hoverAb.energy / 100) * barScale;
			c.globalAlpha = 0.6;
			c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, x2 + 1 * barScale, y2 + 9 * barScale, w, barScale * 3);
			c.globalAlpha = 1;
		}

		img = imgCoords.energyBar;
		w = (barW - 2) * (game.playingPlayerEnergy / 100) * barScale;
		c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, x2 + 1 * barScale, y2 + 9 * barScale, w, barScale * 3);
	}

	y2 += FIELD_SIZE * 0.05;
	x2 = x - FIELD_SIZE * 1.56 / 2;

	// weapon switch bar
	if(this == game.playingPlayer)
	{
		if(this.switchWeaponUntil > exactTicks)
		{
			y2 -= FIELD_SIZE * 0.75;
			c.fillStyle = "black";
			c.fillRect(x2 - FIELD_SIZE * 0.03, y2 - FIELD_SIZE * 0.03, FIELD_SIZE * 1.56, FIELD_SIZE * 0.30);
			w = 24 * (1 + ((exactTicks - this.switchWeaponUntil) / CONST.WPN_SWITCH_TICKS));

			if(w >= 0)
				c.drawImage(imgs.miscSheet, imgCoords.barGrey.x, imgCoords.barGrey.y, w, 4, x2, y2, SCALE_FACTOR * w, FIELD_SIZE * 0.24);

			drawText(c, slayOne.widgets.lang.get("game.msg.switching_weapon"), "rgba(255, 255, 255, 0.75)", SCALE_FACTOR * 3, x2 + FIELD_SIZE * 1.56 / 2, y2 + SCALE_FACTOR * 3, 500, "center");
		}
		
		// reload bar
		else if(this.weapon && this.weaponCooldowns[this.weapon.id] > 0 && this.weapon.cooldown > 7 && this.bouncePoints.length == 0)
		{
			y2 -= FIELD_SIZE * 0.75;
			c.fillStyle = "black";
			c.fillRect(x2 - FIELD_SIZE * 0.03, y2 - FIELD_SIZE * 0.03, FIELD_SIZE * 1.56, FIELD_SIZE * 0.30);
			w = 24 * ((this.weaponCooldowns[this.weapon.id] - percentageOfCurrentTickPassed) / this.weapon.cooldown);

			if(w >= 0)
				c.drawImage(imgs.miscSheet, imgCoords.barBlue.x, imgCoords.barBlue.y, w, 4, x2, y2, SCALE_FACTOR * w, FIELD_SIZE * 0.24);
		}

		// reload bar 2
		else if(this.weapon && this.weaponCooldowns2[this.weapon.id] > 0 && this.weaponCooldowns2[this.weapon.id] < this.weapon.cooldown2 && this.bouncePoints.length == 0)
		{
			y2 -= FIELD_SIZE * 0.75;
			c.fillStyle = "black";
			c.fillRect(x2 - FIELD_SIZE * 0.03, y2 - FIELD_SIZE * 0.03, FIELD_SIZE * 1.56, FIELD_SIZE * 0.30);
			w = 24 * ((this.weaponCooldowns2[this.weapon.id] - percentageOfCurrentTickPassed) / this.weapon.cooldown2);

			if(w >= 0)
				c.drawImage(imgs.miscSheet, imgCoords.barBlue.x, imgCoords.barBlue.y, w, 4, x2, y2, SCALE_FACTOR * w, FIELD_SIZE * 0.24);

			drawText(c, slayOne.widgets.lang.get("game.msg.reloading"), "rgba(255, 255, 255, 0.75)", SCALE_FACTOR * 3, x2 + FIELD_SIZE * 1.56 / 2, y2 + SCALE_FACTOR * 3, 500, "center");
		}

		else if(game.noShootUntil > exactTicks)
		{
			y2 -= FIELD_SIZE * 0.75;
			c.fillStyle = "white";
			c.fillRect(x2 - FIELD_SIZE * 0.03, y2 - FIELD_SIZE * 0.03, FIELD_SIZE * 1.56, FIELD_SIZE * 0.30);
			w = 24 * ((exactTicks - (game.noShootUntil - CONST.NO_SHOOT_AFTER_BLINK_TICKS)) / CONST.NO_SHOOT_AFTER_BLINK_TICKS);

			if(w >= 0)
				c.drawImage(imgs.miscSheet, imgCoords.barGrey.x, imgCoords.barGrey.y, w, 4, x2, y2, SCALE_FACTOR * w, FIELD_SIZE * 0.24);
		}
	}

	// emote
	if(this.lastEmoteStart + CONST.EMOTE_DURATION > game.ticksCounter && this.lastEmote)
	{
		var age = exactTicks - this.lastEmoteStart;

		if(age < 10)
			c.globalAlpha = age * 0.1;

		else if(age > CONST.EMOTE_DURATION - 10)
			c.globalAlpha = (CONST.EMOTE_DURATION - age) * 0.1;

		var scale = SCALE_FACTOR;
		var yE = y - FIELD_SIZE * 3.5;

		var imgE = imgCoords.emotesBubble;
		c.drawImage(imgs.miscSheet, imgE.x, imgE.y, imgE.w, imgE.h, x - imgE.w * 0.5 * scale, yE, scale * imgE.w, scale * imgE.h);

		imgE = imgCoords[this.lastEmote.imgString];
		var scale2 = scale * 10 / imgE.h;
		c.drawImage(imgs.miscSheet, imgE.x, imgE.y, imgE.w, imgE.h, x - imgE.w * 0.5 * scale2, yE + 2 * scale, scale2 * imgE.w, scale2 * imgE.h);

		c.globalAlpha = 1;
	}
	
	if(this == game.playingPlayer && this.weapon && this.weapon.hasLine && this.standTime >= this.weapon.requiredStandTime)
	{
		this.aimX = getMouseGamePlayX(KeyManager.x);
		this.aimY = getMouseGamePlayY(KeyManager.y);
		this.drawSniperLine(exactTicks);
	}
};

Player.prototype.drawSniperLine = function(exactTicks)
{
	if(game.replayMode)
		return;
	
	var startX = this.x;
	var startY = this.y;

	var vecX = this.aimX - startX;
	var vecY = this.aimY - startY;

	var len = Math.sqrt(vecX * vecX + vecY * vecY);
	vecX *= 0.1 / len;
	vecY *= 0.1 / len;

	var x = startX;
	var y = startY;

	var running = true;
	var counter = 0;
	while(running)
	{
		counter++;

		if(game.getFieldPath(Math.floor(x), Math.floor(y)) <= 5 || counter > 300)
			running = false;

		else
		{
			x += vecX;
			y += vecY;
		}
	}

	if(counter > 15)
	{
		var img = game.playingPlayer == this ? imgCoords.particleWhite : imgCoords.particleOrange;
		var size = SCALE_FACTOR * 1.5;
		
		if(game.playingPlayer != this && this.isInvisible)
			c.globalAlpha = 0.10;
		
		for(var i = 15 + exactTicks % 4; i < counter - 3; i+= 4)
			c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, (startX + vecX * i - game.cameraX) * FIELD_SIZE - size / 2, (startY + vecY * i - SHOT_HEIGHT - game.cameraY) * FIELD_SIZE - size / 2, size, size);
		
		if(game.playingPlayer != this && this.isInvisible)
			c.globalAlpha = 1;
	}
};
