function Network()
{
	this.socket = null;
	this.connected = false;
	this.forcedGameID = -1;
	this.connectedServerIndex = -1;
	
	// check for GET parameters
	var forcedServerIndex = -1;
	var arr = window.location.search.substr(1).split("&");
	for(var i = 0; i < arr.length; i++)
	{
		var vals = arr[i].split("=");
		
		if(vals[0] == "server")
			forcedServerIndex = vals[1];
		
		else if(vals[0] == "game")
			this.forcedGameID = vals[1];
	}
	
	for(var i = 0; i < SERVER_ADDRESSES.length; i++)
		if(forcedServerIndex == -1 || forcedServerIndex == i)
			try
			{
				var connection = new WebSocket(SERVER_ADDRESSES[i].adress);
				connection.serverIndex_ = i;
				connection.onopen = function(e)
				{
					if(network.connected)
					{
						e.target.close();
					}
					
					else
					{
						network.onopen(e.target, this.serverIndex_);
					}
				};
			}
			catch(e)
			{
				console.log("You browser seems to not support Websockets. Websockets, however, are required to run this game.");
			}
};

Network.prototype.onopen = function(socket, serverIndex)
{
	this.connected = true;
	this.socket = socket;
	this.connectedServerIndex = serverIndex;
	
	this.lastPing = 0;
	this.lastTimePingSent = 0;
	
	F$('bottomBar').show();
	F$('bottomBar').hideForFb();
	uiManager.refreshMenuButtons();
	
	var hkv = localStorage.getItem("hotkeyValue");
	if(hkv && hkv.length > 0)
		network.send("hotkeyInfo$" + hkv);
	
	// autologin
	var autologinStr = localStorage.getItem("autologin");
	if(autologinStr && autologinStr.length > 0)
		this.send("login$" + autologinStr);
	
	else if(this.forcedGameID != -1)
	{
		this.send("join-game$" + this.forcedGameID);
		this.forcedGameID = -1;
	}
	
	slayOne.views.homeScreen.render();
	
	this.socket.onmessage = function(data)
	{
		handleNetworkMsg(data.data);
	};
};

function handleNetworkMsg(msg)
{
	var arr = msg.split("$");
	
	if(arr[0] == "upd")
	{
		game.receiveUpdate(arr);
		replayFile.push(msg);
	}
	
	else if(arr[0] == "pro")
	{
		game.newProjectile(arr);
		replayFile.push(msg);
	}
	
	else if(arr[0] == "hp")
	{
    	game.hpUpdate(arr);
		replayFile.push(msg);
	}
	
	else if(arr[0] == "proD")
	{
		game.projectileDies(arr);
		replayFile.push(msg);
	}
	
	else if(arr[0] == "nP")
	{
		game.newPlayer(arr);
		replayFile.push(msg);
	}
	
	else if(arr[0] == "proM")
	{
		game.newProjectileMulti(arr);
		replayFile.push(msg);
	}
	
	else if(arr[0] == "hpO")
	{
		game.hpUpdateObject(arr);
		replayFile.push(msg);
	}
	
	else if(arr[0] == "nO")
	{
        game.newObject(arr);
		replayFile.push(msg);
    }
	
	else if(arr[0] == "beam1")
	{
		game.newBeam1(arr);
		replayFile.push(msg);
	}
	
	else if(arr[0] == "beam2")
	{
		game.newBeam2(arr);
		replayFile.push(msg);
	}
	
	else if(arr[0] == "pL")
	{
		game.playerLeaves(arr);
		replayFile.push(msg);
	}
	
	else if(arr[0] == "grn")
	{
		game.newGrenade(arr);
		replayFile.push(msg);
	}
	
	else if(arr[0] == "rl2")
	{
		game.reload2(arr);
		replayFile.push(msg);
	}
	
	else if(arr[0] == "rsp")
	{
		game.playerRespawns(arr);
		replayFile.push(msg);
	}
	
	else if(arr[0] == "ping")
	{
        network.lastPing = Date.now() - network.lastTimePingSent;
    }
	
	else if(arr[0] == "upg")
	{
        game.interface_.presentUpgChoice(arr);
    }
	
	else if(arr[0] == "emote")
	{
		game.emote(arr);
	}
	
	else if(arr[0] == "nZ")
	{
        if(game.map == map1)
            preStore.newZombies.push({value: arr, time: Date.now()});
        else
            game.newZombie(arr);
        
		replayFile.push(msg);
	}
	
	else if(arr[0] == "dbg")
	{
		try
		{
        	eval(msg.substring(4));
        }
        catch(e)
        {}
	}
	
	else if(arr[0] == "pid")
	{
        if(game.map == map1)
            preStore.pid = {value: arr[1], time: Date.now()};
        else
            game.setPlayingPlayerID(arr[1]);
	}
	
	else if(arr[0] == "tGf")
	{
        for(var i = 1; i < arr.length; i += 2)
        {
        	var p = game.getPlayerFromID(arr[i]);
        	
        	if(p)
        		p.iac = arr[i + 1];
        }
	}
	
	else if(arr[0] == "stats")
	{
        var result = {
            xpGained : parseInt(arr[1]),
            eloGained : parseInt(arr[2]),
            goldGained : parseInt(arr[3]),
            kills : parseInt(arr[4]),
            deaths : parseInt(arr[5]),
            xp : parseInt(arr[6]),
            elo : parseInt(arr[7]),
            gold : parseInt(arr[8]),
            souls : parseInt(arr[9]),
            show : parseInt(arr[10]),
            exit : typeof arr[11] == 'undefined' ? true : parseInt(arr[11]),
            chestId : parseInt(arr[12])
        };
		
        if(result.xp)
            uiManager.setXP(result.xp);
		
        if(result.goldGained)
        {
            playerData.gold = result.gold;
            F$('resourceBar').refresh();
        }
		
        if(result.exit)
            preExitGame();
        
        if(result.show)
            F$("result").show(result);
        
        else
        {
            if(result.exit)
            {
                exitGame();
                F$('result').hide();
            }
            else if(game.isTutorial())
                F$alert(F_('tutorial.alert.exit.content'), attemptExitGame, F_('tutorial.alert.exit.title'));
        }
	}
	
	else if(arr[0] == "logged")
	{
		slayOne.viewHelpers.hidePopup("account");
		
		var authLvl = AUTH_LEVEL.PLAYER;
	    if(arr[7] == "1")
	        authLvl = AUTH_LEVEL.MOD;
	    if(arr[8] == "1")
	        authLvl = AUTH_LEVEL.MOD2;
	    if(arr[9] == "1")
	        authLvl = AUTH_LEVEL.ADMIN;
		
		playerData = {
			authLevel: authLvl,
			name: arr[1],
			skin: hats[arr[2]],
			abilities: JSON.parse(arr[3]),
			gold: parseInt(arr[4]),
			gems: parseInt(arr[5]),
			xp: parseInt(arr[6]),
			lvl: getLvlFromXp(arr[6]),
			isMod: arr[7],
			isMod2: arr[8],
			isAdmin: arr[9],
			name_color_select: arr[10],
			skinsUnlocked: arr[11],
			clanTag: arr[12],
			clanRole: arr[13],
			chests: parseChests(arr[14]),
			dailyQuests: JSON.parse(arr[15]),
			db_id: arr[16],
			name_color: arr[17].split(",")
		};
		
		slayOne.viewHelpers.showFloatTip({
			tipType: 'success',
			content: slayOne.widgets.lang.get("msg.welcome", {
				playerName: playerData.name
			}),
			duration: 2000
		});
		
		slayOne.views.homeScreen.render();
		uiManager.refreshMenuButtons();
		F$('resourceBar').show();
		
		if(network.forcedGameID != -1)
		{
			network.send("join-game$" + network.forcedGameID);
			network.forcedGameID = -1;
		}
	}
	
	else if(arr[0] == "maplist4Cr")
	{
		var result = [];
		
		for(var i = 1; i < arr.length; i += 7)
			result.push({
				mapId: arr[i],
				mapName: arr[i + 1],
				mapW: arr[i + 2],
				mapH: arr[i + 3],
				mode: '', // Will be added by outside layer
				maxPlayers: arr[i + 4],
				thumbnail: arr[i + 5],
				mapDesc: arr[i + 6]
			});
		
		window.currentMaps = result;
		
		slayOne.views.roomCreateScreen.setNewMaps();
	}
	
	else if(arr[0] == "gL")
	{
		var result = [];
		
		for(var i = 1; i < arr.length; i += 9)
			result.push({
				roomId: arr[i],
				mapName: arr[i + 1],
				numPlayers: arr[i + 2],
				numPlayersMax: arr[i + 3],
				mode: arr[i + 4],
				mapW: arr[i + 5],
				mapH: arr[i + 6],
				tag: arr[i + 7],
				mapThumbnail: arr[i + 8]
			});
		
		slayOne.views.roomsListScreen.listInit_(result);
	}
	
	else if(arr[0] == "init")
	{
		hideLadderButton();
		game = new Game(JSON.parse(arr[1]));
		game.init(arr, msg);
		replayFile = [];
		replayFile.push(msg);
	}
	
	else if(arr[0] == "next-maps")
	{
        var mapVotes = {};
        for(var i = 1; i < arr.length; i += 5)
        {
            var id = arr[i];
            mapVotes[id] = {
                id: id,
                w: arr[i + 2],
                h: arr[i + 3],
                name: arr[i + 1],
                votes: parseInt(arr[i + 4])
            };
            game.setNextMaps(mapVotes);
        }
	}
	
	else if(arr[0] == "map-vote")
	{
        if(arr.length >= 3)
            game.voteNextMap(arr[1], arr[2]);
        else
            F$('rankInGame_mapList').voted = true;
	}
	
	else if(arr[0] == "cure")
	{
		game.cureTick = arr[1];
	}
	
	else if(arr[0] == "playerList")
	{
		uiManager.showPlayerList(arr);
	}
	
	else if(arr[0] == "plInfo")
	{
		uiManager.showPlayerInfoWithData(arr);
	}
	
	else if(arr[0] == "lvlUp")
	{
		uiManager.lvlUp(arr);
	}
	
    else if(arr[0] == "awardChest")
    {
        playerData.chests = parseChests(arr[1]);
        F$('resourceBar').refresh();
    }
	
    else if(arr[0] == "ban")
    {
		slayOne.viewHelpers.showFloatTip({
		    tipType: 'error',
		    content: "You are banned until " + (new Date(parseInt(arr[1]) + 60).toLocaleString()) + ". " + ((arr[3] && arr[3].length > 0) ? ("Reason: " + arr[3]) : ""),
		    duration: -1
		});
	
		if(arr[2] && arr[2].length > 0)
			localStorage.setItem("hotkeyValue", arr[2]);
	}
	
	else if(arr[0] == "svrMsg")
	{
		slayOne.viewHelpers.showFloatTip({
			tipType: arr[1],
			content: arr[3],
			duration: arr[2]
		});
	}
	
	else if(arr[0] == "regSuc")
	{
		slayOne.viewHelpers.showFloatTip({
			tipType: "success",
			content: "Registration complete.",
			duration: 2000
		});
		
		slayOne.viewHelpers.hidePopup("account");
	}
	
	else if(arr[0] == "openTreasureChestDone")
	{
        playerData.chests = parseChests(arr[1]);
        var gold = parseInt(arr[2]);
        var chestId = arr[3];
        playerData.gold += parseInt(gold);
		
        F$('resourceBar').refresh();
        F$("openChest").show(chestId, gold);
        soundManager.playSound(SOUND.OPEN_CHEST);
	}
	
	else if(arr[0] == "memberList" || arr[0] == "memberList2")
	{
		uiManager.memberList(arr);
	}
	
	else if(arr[0] == "clanInfo")
	{
		var clan = getClanObj(arr);
		F$('clanMain').show(clan);
		currentClan = clan;
		slayOne.functions.fff.showInfo();
		
		document.querySelector('.setting').style.display = (playerData.clanRole >= AUTH_LEVEL.ADMIN && playerData.clanTag == clan.tag) ? "" : "none";
	}
	
	else if(arr[0] == "clanInfo2")
	{
		var clan = getClanObj(arr);
		currentClan = clan;
		playerData.clanTag = clan.tag;
		playerData.clanRole = clan.clan_role;
		F$('clanMain').close();
		slayOne.functions.fff.showInfo();
		F$('clanMain').show();
		slayOne.views.homeScreen.render();
	}
	
	else if(arr[0] == "clanList")
	{
		var data = [];
		for(var i = 3; i < arr.length; i += 4)
			data.push({
				tag : arr[i],
				name : arr[i + 1],
				countMembers : parseInt(arr[i + 2]),
				elo : parseInt(arr[i + 3])
			});
		
		data.total = parseInt(arr[1]);
		data.page = parseInt(arr[2]);
		
		uiManager.showClanList(data);
	}
	
	else if(arr[0] == "lR")
	{
		game.ladderResult(arr);
	}
	
	else if(arr[0] == "ladderlist")
	{
		showLadderList(arr);
	}
	
	else if(arr[0] == "ladderlist2")
	{
		showLatestReplays(arr);
	}
	
	else if(arr[0] == "rep")
	{
		startReplay0(JSON.parse(msg.substring(4)));
	}
	
	else if(msg.substr(0, 4) == "chat" && game)
	{
		if(game && game.map != map1)
			game.interface_.chatMsg(msg.substr(5), "#8CD882");
		
		else if(msg.substr(0, 8) == "chat$-1$")
		{
			slayOne.viewHelpers.showFloatTip({
				tipType: "success",
				content: msg.substr(8),
				duration: 8000
			});
		}
		
		replayFile.push(msg);
	}
	
	else
	{
		console.log(arr);
	}
};

Network.prototype.send = function(data)
{
	if(this.connected && this.socket)
	{
		this.socket.send(data);
		return;
	}
	
	console.log("No connection.");
};