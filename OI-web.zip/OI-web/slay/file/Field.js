// represents a field in the grid or an exact position; p_mode = true => exact position, else Field
function Field(x, y, p_mode)
{
	this.x = x;
	this.y = y;
};

// get distance to other field, using field values
Field.prototype.distanceTo = function(otherField)
{
	return otherField ? Math.sqrt(Math.pow(this.x - otherField.x, 2) + Math.pow(this.y - otherField.y, 2)) : 999999;
};

Field.prototype.isSameGrid = function(otherField)
{
	return this.x == otherField.x && this.y == otherField.y;
};

// get vector from here to other Field
Field.prototype.vectorTo = function(otherField)
{
	return new Field(otherField.x - this.x, otherField.y - this.y);
};

// normalize the vector to a set length
Field.prototype.normalize = function(factor)
{
	var len = Math.sqrt(this.x * this.x + this.y * this.y);
	if(len == 0)
		len = 0.001;
	
	this.px *= factor / len;
	this.py *= factor / len;
	
	return this;
};

Field.prototype.getLen = function()
{
	return Math.sqrt(this.x * this.x + this.y * this.y);
}

// adds a vector to this one from x and y values
Field.prototype.add = function(otherField)
{
	return new Field(this.x + otherField.x, this.y + otherField.y);
};

Field.prototype.add3 = function(x, y)
{
	return new Field(this.x + x, this.y + y);
};

Field.prototype.mul = function(x, y)
{
	return new Field(this.x * x, this.y * y);
};

// returns a new field, created from adding a vector from this to otherfield with a fixed length
Field.prototype.addNormalizedVector = function(otherField, len)
{
	var x = otherField.x - this.x;
	var y = otherField.y - this.y;
	
	var len2 = Math.sqrt(x * x + y * y);
	if(len2 == 0)
		len2 = 0.001;
	
	x *= len / len2;
	y *= len / len2;
	
	return new Field(this.x + x, this.y + y);
};

// adds a vector to this field with a given angle and length and returns the resulting field; a different name might be cool
Field.prototype.add2 = function(angle, len)
{
	return this.add(new Field(Math.cos(angle), Math.sin(angle)).normalize(len));
};

// get angle from this point to another point
Field.prototype.getAngleTo = function(otherField)
{
	var returnValue = Math.atan((otherField.y - this.y) / (otherField.x - this.x));
	returnValue -= otherField.x - this.x < 0 ? Math.PI : 0;
	return returnValue;
};

Field.prototype.equals = function(otherField)
{
	return this.x == otherField.x && this.y == otherField.y;
};

Field.prototype.toString = function()
{
	return this.x + ":" + this.y;
};