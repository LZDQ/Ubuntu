(function(){
    var bottomBarModel = {
        data : new F$ArrayView(5)
    };

    FunUI.traits.bottomBar = {
        __init__: function() {

            this.querySelector('.ioGameLink').style.display = /*FacebookUtils.embeddedInCanvas ? "none" :*/ "";

            if (typeof FacebookUtils == 'object') {
                bottomBarModel.data.sourceView = FacebookUtils.fbArrayView;
            }
        },
        inviteFriend : function() {
            // FacebookUtils.inviteFriend();
        },
        show: function () {
            if (this.parentNode == null) {
                document.body.appendChild(this);
            }
        },
        hide: function() {
            if (this.parentNode) {
                this.parentNode.removeChild(this);
            }
        },
        showForFb : function() {
            this.show();
            this.removeClass('hide');
        },
        hideForFb : function() {
            this.addClass("hide");
        }
    };

    FunUI.traits.bottomBar_friend_list = {
        __init__ : function() {
            this.dataProvider = bottomBarModel.data;
        }
    };

    FunUI.traits.bottomBar_friend_list.itemRenderer = {
        __init__: function() {
            this.labelName = this.getSubComponent("name");
            this.pic = this.getSubComponent("pic");
            this.labelLevel = this.getSubComponent("level");
            this.on("click", this.showFriendInfo);
        },
        render: function (data, index) {
            this.labelName.innerHTML = data.name;
            this.labelLevel.innerHTML = data.level;
            this.pic.src = data.pic;
        },
        showFriendInfo : function() {
            // FacebookUtils.showFriendInfo(this.data.db_id);
        }
    };
})();