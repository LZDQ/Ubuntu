function Flare(x, y, z)
{
	this.x = x;
	this.y = y;
	this.z = z;
	
	this.vx = 0;
	this.vz = 0.015;
	
	this.tickOfBirth = game.ticksCounter;
	this.tickOfDeath = this.tickOfBirth + 40 + Math.random() * 40;
	
	game.effects.push(this);
	game.addToObjectsToDraw(this);
};

Flare.prototype.update = function(ticksCounter)
{
	this.vx += Math.random() * 0.004 - 0.002;
	this.vz += Math.random() * 0.004 - 0.002;
	
	return this.tickOfDeath > ticksCounter;
};

Flare.prototype.getYDrawingOffset = function()
{
	return this.y;
};

Flare.prototype.draw = function(exactTicks, x1, y1, x2, y2)
{
	if(!(this.x + 3 >= x1 && this.y + 3 >= y1 && this.x - 3 <= x2 && this.y - 3 <= y2))
		return;
	
	if(game.ticksCounter >= 0)
	{
		this.x += this.vx;
		this.z += this.vz;
	}
	
	var time2Live = Math.max(this.tickOfDeath - exactTicks, 0);
	var globalAlpha = Math.min(time2Live / 20, 1);
	
	var img = imgCoords.particleYellow;
	
	var drawX = g2rx(this.x) - (img.w / 2) * SCALE_FACTOR;
	var drawY = g2ry(this.y - this.z * 0.8) - (img.h / 2) * SCALE_FACTOR;
	
	c.globalAlpha = (Math.random() * 0.2 + 0.8) * globalAlpha;
	c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, drawX, drawY, img.w * SCALE_FACTOR, img.h * SCALE_FACTOR);
	
	var scale = SCALE_FACTOR * (Math.random() * 0.2 + 0.9);
	img = imgCoords.light_yellow;
	
	drawX = g2rx(this.x) - (img.w / 2) * scale;
	drawY = g2ry(this.y - this.z * 0.8) - (img.h / 2) * scale;
	
	c.globalAlpha = (Math.random() * 0.1 + 0.25) * globalAlpha;
	c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, drawX, drawY, img.w * scale, img.h * scale);
	c.globalAlpha = 1;
};