// parent class for zombies and players

function Humanoid()
{
	this.lastActualHit = -99999;
};

Humanoid.prototype.performHit = function(victim)
{
	this.victim = victim;
	this.targetX = victim.x;
	this.targetY = victim.y;

	if(this.x + 3 >= game.cameraX && this.y + 3 >= game.cameraY && this.x - 3 <= game.cameraX2 && this.y - 3 <= game.cameraY2)
	{
		soundManager.playSound(SOUND.ZOMBIE_BITE, victim.x, victim.y);
		this.lastActualHit = game.ticksCounter;
	}
};

Humanoid.prototype.getYDrawingOffset = function()
{
	return this.y;
};

Humanoid.prototype.blink = function(x, y)
{
	this.x = parseFloat(x);
	this.y = parseFloat(y);

	this.x0 = this.x;
	this.y0 = this.y;

	var vecX = this.x - this.x00;
	var vecY = this.y - this.y00;

	var dist = Math.sqrt(Math.pow(vecX, 2) + Math.pow(vecY, 2));
	var x = this.x00;
	var y = this.y00;

	vecX *= 1 / dist;
	vecY *= 1 / dist;

	if(!game.fastForward)
	{
		for(var i = 0; i < dist; i += 0.75)
		{
			x += vecX;
			y += vecY;

			new Sprite({
				x: x + Math.random() * 0.6 - 0.3,
				y: y + Math.random() * 0.6 - 0.3 - 0.5,
				img: imgCoords.dust1,
				scaleFunction: function(age){ return this.scale_ - age * 0.01; },
				scale_: Math.random() + 1.25,
				alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.25; },
				age: (1.7 + Math.random()) * 20
			});

			new Sprite({
				x: x + Math.random() * 0.6 - 0.3,
				y: y + Math.random() * 0.6 - 0.3 - 0.5,
				img: imgCoords.particleWhite,
				scaleFunction: function(age){ return this.scale_ - age * 0.01; },
				scale_: Math.random() + 1.55,
				alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.8; },
				age: Math.random() * 4 + 10
			});
		}

		soundManager.playSound(SOUND.BLINK, this.x00, this.y00);
		createBlinkEffect(this.x00, this.y00);
		createBlinkEffect(this.x, this.y);
	}

	this.laserHitUntil = game.ticksCounter + 3;
};

Humanoid.prototype.getVanishingAlpha = function(ticks)
{
	if(game.type.coopZombieMode)
		return 1;

	return this.dieAt ? Math.min(Math.max((this.finallyRemoveAt - ticks) / 40, 0), 1) : 1;
};

Humanoid.prototype.createCorpse = function()
{
	game.addCorpses(new Corpse(parseInt(this.id) + 50000, this.x, this.y, this.z, this.flameDeath, this.direction, this.bouncePoints, this.imgScale ? this.imgScale : 1));
};

Humanoid.prototype.updateBounce = function()
{
	if(this.bouncePoints.length > 0)
	{
		this.x0 = this.x;
		this.y0 = this.y;
		this.z0 = this.z;

		this.x = this.bouncePoints[0].x;
		this.y = this.bouncePoints[0].y;
		this.z = this.bouncePoints[0].h;

		if(this.bouncePoints[0].hitsGround)
		{
			var vecH = this.bouncePoints[0].vecH;

			if(this.x + 5 >= game.cameraX && this.y + 5 >= game.cameraY && this.x - 5 <= game.cameraX2 && this.y - 5 <= game.cameraY2)
			{
				var vanishingAlpha = this.getVanishingAlpha(game.ticksCounter);

				createPoundSmoke(this.x, this.y + 1.0, Math.min(vecH * 2.5, 1), parseInt(vecH * 40), 0.5 * vanishingAlpha);
				soundManager.playSound(SOUND.KICK, this.x, this.y, Math.min(vecH * 3, 1) * vanishingAlpha);
			}
		}

		if(this.bouncePoints[0].wallSmash && this.bouncePoints[1])
		{
			var p = this.bouncePoints[0];

			var len = Math.sqrt(Math.pow(this.bouncePoints[1].x - p.x, 2) + Math.pow(this.bouncePoints[1].y - p.y, 2));

			var startAngle = "";
			var finishAngle = "";

			var x = this.x;
			var y = this.y;

			if(p.wallSmash == "right")
			{
				startAngle = Math.PI * 0.5;
				finishAngle = Math.PI * 1.5;
				x += CONST.PLAYER_RADIUS;
			}

			else if(p.wallSmash == "left")
			{
				startAngle = Math.PI * -0.5;
				finishAngle = Math.PI * 0.5;
				x -= CONST.PLAYER_RADIUS;
			}

			else if(p.wallSmash == "top")
			{
				startAngle = Math.PI * 1.0;
				finishAngle = Math.PI * 2.0;
				y -= CONST.PLAYER_RADIUS;
			}

			else if(p.wallSmash == "bottom")
			{
				startAngle = Math.PI * 0;
				finishAngle = Math.PI * 1.0;
				y += CONST.PLAYER_RADIUS;
			}

			if(this.x + 5 >= game.cameraX && this.y + 5 >= game.cameraY && this.x - 5 <= game.cameraX2 && this.y - 5 <= game.cameraY2)
			{
				var vanishingAlpha = this.getVanishingAlpha ? this.getVanishingAlpha(game.ticksCounter) : 1;
				createPoundSmoke(x, y + 1.0 - p.h, Math.min(len * 1.5, 1), parseInt(len * 40), 0.5 * vanishingAlpha, startAngle, finishAngle);
				soundManager.playSound(SOUND.KICK, this.x, this.y, Math.min(len * 2.0, 1) * vanishingAlpha);
			}
		}

		this.bouncePoints.splice(0, 1);

		if(this.dieAt && this.bouncePoints.length == 0)
		{
			this.x = this.x0;
			this.y = this.y0;
			this.z = 0;
			this.z0 = 0;
		}
	}
};

Humanoid.prototype.updateField = function(field, value)
{
	if (field == "maxHP") {

		var rate = this.hp / this.maxHP;
		this.maxHP = parseFloat(value);
		this.hp = rate * this.maxHP;
		return;
	}

	this[field] = parseFloat(value);
};

Humanoid.prototype.updateAndDrawPillar = function(p, age)
{
	p.h += p.vh * exactTickDiff;
	p.w += p.vw * exactTickDiff;

	var x = (p.x - p.w / 2 - game.cameraX) * FIELD_SIZE;
	var y = (p.y - p.h - game.cameraY) * FIELD_SIZE;
	var this_age = age + p.age_offset;

	c.globalAlpha = ((this_age < 5) ? Math.max(this_age / 5, 0) : ((this_age < 10) ? 1 : Math.max(2.0 - this_age / 10, 0))) * 0.4;
	c.drawImage(imgs.miscSheet, p.img.x, p.img.y, p.img.w, p.img.h, x, y, p.w * FIELD_SIZE, p.h * FIELD_SIZE);
	c.globalAlpha = 1;
};

Humanoid.prototype.createSpawnEffect = function(ignorePosition)
{
	this.lightPillarsTop = [];
	this.lightPillarsBottom = [];

	if((!(this.x + 5 >= game.cameraX && this.y + 5 >= game.cameraY && this.x - 5 <= game.cameraX2 && this.y - 5 <= game.cameraY2) && !ignorePosition) || game.fastForward)
		return;

	for(var i = 0; i < Math.PI * 2; i += 0.3 + Math.random() * 0.15)
		(i <= Math.PI ? this.lightPillarsBottom : this.lightPillarsTop).push({
			x: Math.sin(i) * 0.45 + this.x,
			y: Math.cos(i) * 0.45 + this.y,
			w: 0.15 + Math.random() * 0.3,
			h: Math.random() * 1.5,
			vh: 0.05 + Math.random() * 0.1,
			vw: Math.random() * 0.01,
			age_offset: Math.random() * 8 - 4,
			img: imgCoords.pillar_of_light
		});

	for(var k = 0; k < 9; k++)
	{
		var randomAngle = Math.random() * Math.PI * 2;
		var rand = Math.random() * 0.7;

		new Sprite({
			x: this.x + Math.cos(randomAngle) * rand,
			y: this.y - SHOT_HEIGHT + Math.sin(randomAngle) * rand,
			z: Math.random(),
			img: imgCoords.particleWhite,
			scaleFunction: function(age){ return this.scale_; },
			scale_: Math.random() * 2 + 2,
			z_: Math.random() * 0.09,
			zFunction: function(age){ return age * this.z_; },
			age: 26
		});
	}

	for(var k = 0; k < 6; k++)
	{
		var randomAngle = Math.random() * Math.PI * 2;
		var rand = Math.random() * 0.7;

		new Sprite({
			x: this.x + Math.cos(randomAngle) * rand,
			y: this.y - SHOT_HEIGHT + Math.sin(randomAngle) * rand,
			z: Math.random(),
			img: imgCoords.particlePurple,
			scaleFunction: function(age){ return this.scale_; },
			scale_: Math.random() * 2 + 2,
			z_: Math.random() * 0.09,
			zFunction: function(age){ return age * this.z_; },
			age: 26
		});
	}

	// light
	new Sprite({
		x: this.x,
		y: this.y,
		img: imgCoords.light_white,
		scaleFunction: function(age){ return Math.max(0, 1 - (age / this.ticksToLive) * 0.6) * 5; },
		alphaFunction: function(age){ return Math.max((-1 * (1/ (((age * 0.9) - 125) / 500 + 0.31) + age / 4) + 16.9) * 3.7, 0) * 0.04; },
		age: 44
	});

	this.lastSpawnTick = game.ticksCounter;

	soundManager.playSound(SOUND.PLAYER_SPAWN, undefined, undefined, 0.95);
};

Humanoid.prototype.spillBloodFromMeleeAttack = function()
{
	if(this.lastTickFire + 12 > game.ticksCounter && this.x + 3 >= game.cameraX && this.y + 3 >= game.cameraY && this.x - 3 <= game.cameraX2 && this.y - 3 <= game.cameraY2)
	{
		var attackAge = game.ticksCounter - this.lastActualHit;

		if(attackAge >= 0 && attackAge <= 3 && this.victim && !this.victim.isObject)
		{
			var vecX = this.x - this.targetX;
			var vecY = this.y - this.targetY;

			var len = Math.sqrt(vecX * vecX + vecY * vecY);
			vecX *= 0.5 / len;
			vecY *= 0.5 / len;

			new Blood(this.targetX + vecX, this.targetY + vecY, -vecX, -vecY);
			new Blood(this.targetX + vecX, this.targetY + vecY, -vecX + Math.random() - 0.5, -vecY + Math.random() - 0.5, null, true);
			new Blood(this.targetX + vecX, this.targetY + vecY, -vecX, -vecY, imgCoords.particleWhite, true);
		}
	}
};
