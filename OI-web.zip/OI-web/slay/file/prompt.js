(function(window, slayOne, document){

function getPredefinedButtonConfig (buttonLabel) {
    switch(buttonLabel) {
        case 'ok': {
            return {
                btnName: 'ok',
                label: slayOne.widgets.lang.get("prompt.btn_ok.label"),
                theme: "TinyGreen",
            };
        }
        case 'cancel': {
            return {
                btnName: 'cancel',
                label: slayOne.widgets.lang.get("prompt.btn_cancel.label"),
                theme: "TinyRed",
            };
        }
    }
    return null;
}

/**
 * Prompt Window
 *
 * @param parentNode: dom element to append to
 * @param options:
 *                  title: string, optional
 *                  content: string
 *                  buttons: [ 'ok' | 'cancel' | { @see labelButton option, + btnName } ]
 *                  onClick: function(btnName)
 */
function promptWindow(options) {

    var domContainer = document.createElement('div');
    domContainer.className = "promptContainer";

    var titleOption = (options && options.title) ? options.title : "";
    if(titleOption && titleOption.length > 0) {
        var domTitle = document.createElement('div');
        domTitle.className = "promptTitle";
        domTitle.innerHTML = titleOption;
        domContainer.appendChild(domTitle);
    }

    var domContent = document.createElement('div');
    domContent.className = "promptContent";
    domContent.innerHTML = options.content;
    domContainer.appendChild(domContent);

    var domBtnContainer = document.createElement('div');
    domBtnContainer.className = "promptBtnContainer";
    options.buttons.forEach(function(btnOption){
        if(typeof(btnOption) == 'string') {
            btnOption = getPredefinedButtonConfig(btnOption);
        }
        if(!btnOption) {
            return;
        }
        var lastClick = btnOption.onClick;
        btnOption.onClick = function(){
            options.onClick && options.onClick(btnOption.btnName);
            lastClick && lastClick();
        };
        slayOne.widgets.labelButton(domBtnContainer, btnOption);
    });
    domContainer.appendChild(domBtnContainer);

    return domContainer;
}

//export
if(!slayOne.widgets) {
    slayOne.widgets = {};
}

slayOne.widgets.prompt = promptWindow;

})(window, window.slayOne, window.document);//end main closure