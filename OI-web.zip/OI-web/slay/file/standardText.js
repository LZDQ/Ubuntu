(function( slayOne, document ){

/**
 * Standard text
 *
 * @param parentNode: dom element to append to
 * @param options:
 *                  maxWidth: maximum width in pixels
 *                  textAlign: text align
 *                  skin: enum(dark|standard|light)
 *                  customClassName: string
 *                  customContainerClassName: string
 */
function standardText( parentNode, text, options ){

	var txt = document.createElement("span");

    var finalClassName = "standardText";
    if(options && options.customClassName) {
        finalClassName += " " + options.customClassName;
    }
    txt.className = finalClassName;

    var domLabel = document.createElement("span");
    domLabel.innerText = text;
    txt.appendChild(domLabel);
    
    if(options && options.maxWidth) {
        txt.style.maxWidth = options.maxWidth + "px";
    }

    if(options && options.textAlign) {
        txt.style.textAlign = options.textAlign;
    } else {
        txt.style.textAlign = "center";
    }

    if(options && options.letterSpacing) {
        txt.style.letterSpacing = options.letterSpacing + "px";
    }
    
    var field = slayOne.widgets.standardField(parentNode, txt, {
        skin: options.skin,
        customClassName: options.customContainerClassName
    });

    txt.setText = function(val){
        domLabel.innerText = val;
    };

    txt.setSkin = function(val){
        field.setSkin(val);
    };

    return txt;
}

//export
if(!slayOne.widgets) {
    slayOne.widgets = {};
}

slayOne.widgets.standardText = standardText;

})( window.slayOne, window.document);//end main closure