/**
 * View renders the "HotKey" UI
 *
 */
(function(window, slayOne, document){

var viewKey = "hotkeyScreen";

function showWindow(options){

    var domContent = document.createElement('div');
    domContent.className = "hotkeyView";

    var viewModel = {
    };

    var domHeader = document.createElement('div');
    domHeader.className = "screenTitle";
    domHeader.innerHTML = slayOne.widgets.lang.get("hotkey.title");
    domContent.appendChild(domHeader);

    var domKeysContainer = document.createElement('div');
    domKeysContainer.className = "hotkeysWrapper";

    var str = "";
    for(var attribute in commandNames) {

		var cmdKey = commandKeys[attribute];

		var name = window.commandNameLabels[attribute];
		var nameShow = '';
		if (typeof name === 'object' && name.hasOwnProperty('weapon')) {
			nameShow = slayOne.widgets.lang.get('config.keyname.weaponSwitch').replace(/\[\[weapon\]\]/, slayOne.widgets.lang.get('weapons.' + name.weapon + '.name'));
		} else {
			nameShow = slayOne.widgets.lang.get(name);
		}

		str += "<div class='hotkeySubDiv'>" + nameShow;
		str += " <button data-key='" + attribute + "' class='hotkey_button withClickSound' id='hotkey_" + attribute + "' onclick='changeHotkey1(" + attribute + ");'>";
		str += getKeyName(cmdKey) + "</button></div>";
    }

    domKeysContainer.innerHTML = str;

    domContent.appendChild(domKeysContainer);

    slayOne.viewHelpers.showPopup(viewKey, {
    	theme: 'light',
        content: domContent,
        onClose: options.onClose
    });
}

function hideWindow() {
    slayOne.viewHelpers.hidePopup(viewKey);
}

//export
slayOne.views[viewKey] = {
    showWindow: showWindow,
    hideWindow: hideWindow
};

})(window, window.slayOne, window.document);//end main closure
