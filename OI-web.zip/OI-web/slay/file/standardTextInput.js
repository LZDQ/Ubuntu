(function( slayOne, document ){

/**
 * Standard text input
 *
 * @param parentNode: dom element to append to
 * @param options:
 *                  size: applied to input element's "size" property
 *                  inputType: text | password
 *                  fontSize: font size
 *                  placeholder: applied to input elements "placeholder" property
 *                  skin: enum
 *                  onSubmit: callback(value)
 *                  iconClassName: icon class name
 */
function standardTextInput(parentNode, options){

	var inputText = document.createElement("input");
    inputText.className = "standardTextInput";

    var typeOption = (options && options.inputType) ? options.inputType : 'text';
    inputText.type = typeOption;

    if(options.cssId)
        inputText.id = options.cssId;
    
    if(options.size)
        inputText.size = options.size;
    
    if(options.fontSize)
    	inputText.style.fontSize = options.fontSize + "px";
    else
    	inputText.style.fontSize = "17px";
    
    if(options.placeholder)
        inputText.placeholder = options.placeholder;
    
    if(options && options.iconClassName)
    {
        var domIcon = document.createElement('div');
        domIcon.className = "standardTextInputIcon " + options.iconClassName;
        parentNode.appendChild(domIcon);
    }

    inputText.addEventListener("keypress", function(e) {
        if(e.which == 10 || e.which == 13)
            if(options.onSubmit)
            {
                window.soundManager.playSound(window.SOUND.CLICK);
                options.onSubmit(inputText.value);
            }
    });

    slayOne.widgets.standardField(parentNode, inputText, options);

    return inputText;
}

//export
if(!slayOne.widgets)
    slayOne.widgets = {};

slayOne.widgets.standardTextInput = standardTextInput;

})( window.slayOne, window.document);//end main closure