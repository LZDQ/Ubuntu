(function(){
    var properties = new F$ArrayView();
    var properties_next = new F$ArrayView();

    var itemRenderer = {
        _nameField : null,
        _valueField : null,
        __init__: function() {
            this._nameField = this.querySelector('.name');
            this._valueField = this.querySelector('.value');
        },
        render : function(data) {
            this._nameField.innerHTML = data.name;
            this._valueField.innerHTML = data.value;
        }
    };

    FunUI.traits.hatTooltip = {
        _titleField : null,
        __init__: function () {
            this._titleField = this.querySelector('h2');
        },
        render: function(data) {
            var hat = hats[data.id];
            var level = data.level;

            this._titleField.innerHTML = hat.name;

            var props = [];
            var props_next = [];

			var upgrade = hat.extra[level];
			if (upgrade) {

				var colorOK = '#bcbc77';
				var colorNotEnough = '#f48d8d';

				var skinCost = upgrade.upgradeSkinCost;
				if (skinCost) {
            	    var cost = {};
            	    cost.name = slayOne.widgets.lang.get('hatTooltip.skinCost');
            	    var clr = skinCost <= data.count ? colorOK : colorNotEnough;
            	    cost.value = '<span style="color: ' + clr + '">' + data.count + '/' + skinCost + '</span>';
            	    props_next.push(cost);
				}

            	var goldCost = upgrade.upgradeGoldCost;
            	if (goldCost) {
            	    var cost = {};
            	    cost.name = slayOne.widgets.lang.get('hatTooltip.goldCost');
            	    var clr = goldCost <= playerData.gold ? colorOK : colorNotEnough;
            	    cost.value = '<span style="color: ' + clr + '">' + goldCost + '</span>';
            	    props_next.push(cost);
            	}
			}

            for (var i = 0; i < abilities.length; i ++) {
                var aName = abilities[i].locales.name;
                if (hat[aName]) {
                    var prop = {};
                    var plus = hatQualityPlus[hat.quality];
                    prop.name = abilities[i].name;
                    prop.value = '+' + (hat[aName] + plus * (level - 1)).toFixed(1);
                    props.push(prop);

                    var prop_next = {};
                    prop_next.name = abilities[i].name;
                    prop_next.value = '+' + (hat[aName] + plus * level).toFixed(1);
                    props_next.push(prop_next);
                }
            }

            properties.source = props;
            properties_next.source = props_next;

            if (!hat.extra || !hat.extra[level + 1]) {
                this.addClass('noNext');
            } else {
                this.removeClass('noNext');
            }
        }
    };

    FunUI.traits.hatTooltip_list = {
        dataProvider: properties
    };
    FunUI.traits.hatTooltip_list_next = {
        dataProvider: properties_next
    };

    FunUI.traits.hatTooltip_list.itemRenderer = itemRenderer;
    FunUI.traits.hatTooltip_list_next.itemRenderer = itemRenderer;

})();