function Blood(x, y, vecX, vecY, img, noStain, zFunc, noStain2, additionalDrawingOffset)
{
	this.x = x;
	this.y = y;
	this.additionalDrawingOffset = additionalDrawingOffset ? additionalDrawingOffset : 0;
	this.z = 1;
	
	var len = Math.sqrt(vecX * vecX + vecY * vecY);
	vecX *= 0.2 / len;
	vecY *= 0.2 / len;
	
	this.vx = (Math.random() * 1 - 0.5) * 0.2 - vecX * 0.6;
	this.vy = (Math.random() * 1 - 0.5) * 0.2 - vecY * 0.6;
	
	this.scale = 1 + Math.random() * 1.5;
	this.spread = 0.25;
	
	this.tickOfBirth = game.ticksCounter;
	this.tickOfDeath = this.tickOfBirth + 67;
	this.hasBeenDrawn = noStain ? true : false;
	this.img = img ? img : imgCoords.particleRed;
	this.zFunc = zFunc;
	
	// try to find wall
	var len = Math.sqrt(vecX * vecX + vecY * vecY);
	vecX *= 0.2 / len;
	vecY *= 0.2 / len;
	
	var totalLen = 1.5 + Math.random() * 2;
	var running = true;
	while(running && !noStain2)
	{
		totalLen -= 0.2;
		
		x += vecX;
		y += vecY;
		
		var path = game.getFieldPath(Math.floor(x), Math.floor(y));
		
		if(path <= 5)
		{
			if(vecY < 0 && Math.floor(y) != Math.floor(y -= vecY) && Math.floor(x) == Math.floor(x -= vecX)) // create bloodstain on the wall
			{
				var img = imgCoords.particleRed;
				
				var w = 2 + Math.floor(Math.random() * 2);
				var h = 1;
				
				var x_ = (x + 12) * 16 - 1;
				var y_ = game.tilesCashes[Math.floor(y - 1)].height - 10 + Math.random() * 3;
				
				if(game.tilesCashes[Math.floor(y - 1)] && game.tilesCashes[Math.floor(y - 1)].getContext)
				{
					game.tilesCashes[Math.floor(y - 1)].getContext("2d").globalAlpha = 0.2;
					game.tilesCashes[Math.floor(y - 1)].getContext("2d").drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, Math.round(x_), Math.round(y_), w, h);
					game.tilesCashes[Math.floor(y - 1)].getContext("2d").globalAlpha = 1;
				}
			}
			
			running = false;
		}
		
		if(totalLen < 0)
		{
			if(path == 10) // create bloodstain on the ground
			{
				var img = imgCoords.particleRed;
				
				for(var j = 0; j < game.groundCanvas.length; j++)
				{
					game.groundCanvas[j].getContext("2d").globalAlpha = 0.2;
					game.groundCanvas[j].getContext("2d").drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, (x - game.groundMinX) * 16, (y - game.groundMinY) * 16, 2, 2);
					game.groundCanvas[j].getContext("2d").globalAlpha = 1;
				}
			}
			
			running = false;
		}
	}
	
	game.effects.push(this);
	game.addToObjectsToDraw(this);
};

Blood.prototype.update = function(ticksCounter)
{
	return this.tickOfDeath > ticksCounter && !this.hasBeenDrawn;
};

Blood.prototype.getYDrawingOffset = function()
{
	return this.y + this.additionalDrawingOffset;
};

Blood.prototype.draw = function(exactTicks, x1, y1, x2, y2)
{
	if(!(this.x + 3 >= x1 && this.y + 3 >= y1 && this.x - 3 <= x2 && this.y - 3 <= y2))
		return;
	
	var age = exactTicks - this.tickOfBirth - 3;
	
	var z = 0;
	var x = 0;
	var y = 0;
	
	if(age > Math.sqrt(1.2) / this.spread) // phase 2
	{
		if(this.hasBeenDrawn)
			return;
		
		x = (Math.sqrt(1.2) / this.spread) * this.vx + this.x;
		y = (Math.sqrt(1.2) / this.spread) * this.vy + this.y;
		
		for(var j = 0; j < game.groundCanvas.length; j++)
		{
			game.groundCanvas[j].getContext("2d").globalAlpha = 0.2;
			game.groundCanvas[j].getContext("2d").drawImage(imgs.miscSheet, this.img.x, this.img.y, this.img.w, this.img.h, (x - game.groundMinX) * 16, (y - game.groundMinY) * 16, 2, 2);
			game.groundCanvas[j].getContext("2d").globalAlpha = 1;
		}
		
		this.hasBeenDrawn = true;
	}
	
	else // phase 1
	{
		z = this.zFunc ? this.zFunc(age) : (-Math.pow(0.25 * age, 2) + 1.2);
		x = this.x + this.vx * age;
		y = this.y + this.vy * age;
		c.globalAlpha = 0.8;
	}
	
	var scale = SCALE_FACTOR * this.scale;
	
	var drawX = g2rx(x) - (this.img.w / 2) * scale;
	var drawY = g2ry(y - z * 0.5) - (this.img.h / 2) * scale;
	
	c.drawImage(imgs.miscSheet, this.img.x, this.img.y, this.img.w, this.img.h, drawX, drawY, this.img.w * scale, this.img.h * scale);
	c.globalAlpha = 1;
};






function Splash(x, y, img, scale, age, loop, yOffsetMod, animSpeed)
{
	this.x = x;
	this.y = y;
	this.yOffset = y + (yOffsetMod ? yOffsetMod : 0);
	
	this.scale = scale ? scale : 1;
	this.img = img;
	this.frameW = img.frameW ? img.frameW : img.w;
	this.countFrames = img.w / this.frameW;
	
	this.tickOfBirth = game.ticksCounter;
	this.tickOfDeath = this.tickOfBirth + (typeof age === "undefined" ? 40 : (age === 0 ? 999999999 : age));
	this.loop = loop ? true : false;
	this.frameOffset = this.loop ? Math.floor(Math.random() * 999) : 0;
	this.animSpeed = animSpeed ? animSpeed : 0.5;
	
	soundManager.playSound(SOUND.SPLASH, this.x, this.y);
	
	game.effects.push(this);
	game.addToObjectsToDraw(this);
};

Splash.prototype.update = function(ticksCounter)
{
	return this.tickOfDeath > ticksCounter;
};

Splash.prototype.getYDrawingOffset = function()
{
	return this.yOffset;
};

Splash.prototype.draw = function(exactTicks, x1, y1, x2, y2)
{
	if(!(this.x + 3 >= x1 && this.y + 3 >= y1 && this.x - 3 <= x2 && this.y - 3 <= y2))
		return;
	
	var age = exactTicks - this.tickOfBirth;
	
	var scale = SCALE_FACTOR * this.scale;
	
	var x_offset = Math.floor((age + this.frameOffset) * this.animSpeed);
	
	if(this.loop)
		x_offset = x_offset % this.countFrames;
	
	if(x_offset > this.countFrames - 1)
		return;
	
	var drawX = g2rx(this.x) - (this.frameW / 2) * scale;
	var drawY = g2ry(this.y) - (this.img.h / 2) * scale;
	
	c.globalAlpha = 0.9;
	c.drawImage(imgs.miscSheet, this.img.x + x_offset * this.frameW, this.img.y, this.frameW, this.img.h, drawX, drawY, this.frameW * scale, this.img.h * scale);
	c.globalAlpha = 1;
};









function Tile(x, y, type, game_)
{
	this.x = x;
	this.y = y;
	this.img = type.img;
	this.type = type;
	
	this.isTile = true;
	
	(game_ ? game_ : game).addToObjectsToDraw(this);
	(game_ ? game_ : game).noGridTiles.push(this);
};

Tile.prototype.getYDrawingOffset = function()
{
	return this.y;
};

Tile.prototype.draw = function(exactTicks, x1, y1, x2, y2)
{
	if(!(this.x + 3 >= x1 && this.y + 3 >= y1 && this.x - 3 <= x2 && this.y - 3 <= y2))
		return;
	
	var scale = SCALE_FACTOR;
	
	var drawX = g2rx(this.x) - (this.img.w / 2) * scale;
	var drawY = g2ry(this.y) - (this.img.h / 2) * scale;
	
	c.globalAlpha = 1;
	c.drawImage(imgs.tileSheet, this.img.x, this.img.y, this.img.w, this.img.h, drawX, drawY, this.img.w * scale, this.img.h * scale);
};