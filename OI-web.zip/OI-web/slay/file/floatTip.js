(function(window, slayOne, document){

/**
 * Float Tip
 *
 * @param parentNode: dom element to append to
 * @param options:
 *                  tipType: string enum, success | error
 *                  content: string
 *                  duration: number in miliseconds, -1 means never disappear; default 4000
 */
function floatTip(options) {

	var typeOption = (options && options.tipType) ? options.tipType : "success";
    
    var domContainer = document.createElement('div');
    domContainer.className = "floatTipContainer floatTipType" + capitalize(typeOption);

    var domIcon = document.createElement('div');
    domIcon.className = "floatTipIcon";
    domContainer.appendChild(domIcon);

    var domContent = document.createElement('div');
    domContent.className = "floatTipContent";
    domContent.innerHTML = options.content;
    domContainer.appendChild(domContent);

    domContainer.startShowAnimation = function(cbComplete){

    	addClassToDom(domContainer, "floatTipShowing");

    	domContainer.tipHideCallback = cbComplete;

    	var durationOption = (options && options.duration) ? options.duration : 5000;
    	if(durationOption <= 0) {
    		domContainer.hideTimeout = -1;
    		return;
    	}

    	domContainer.hideTimeout = setTimeout(function(){
    		domContainer.startHideAnimation(cbComplete);
    	}, durationOption);
    };

    domContainer.startHideAnimation = function(){
    	if(domContainer.hideTimeout > 0) {
    		clearTimeout(domContainer.hideTimeout);
    		domContainer.hideTimeout = -1;
    	}

    	removeClassFromDom(domContainer, "floatTipShowing");
    	addClassToDom(domContainer, "floatTipHiding");

    	setTimeout(function(){
    		domContainer.tipHideCallback && domContainer.tipHideCallback();
    	}, 500);
    };

    domContainer.setContent = function(val){
        domContent.innerHTML = val;
    };

    return domContainer;
}

//export
if(!slayOne.widgets) {
    slayOne.widgets = {};
}

slayOne.widgets.floatTip = floatTip;

})(window, window.slayOne, window.document);//end main closure