(function(){
    FunUI.traits.clanJoin = {
        _tagField : null,
        _nameField : null,
        _cancelButton : null,
        _currentTag: "",
        __init__: function()
        {
            this._tagField = this.querySelector(".clanTag");
            this._nameField = this.querySelector(".clanName");
            this._cancelButton = this.querySelector(".cancel");
			
            this.querySelector('.send').on('click', this.apply4Clan);
			
            this._cancelButton.on('click', this.close);
        },
        apply4Clan: function()
        {
            network.send("apply4Clan$" + this._currentTag + "$" + this.querySelector("#clanAppTextField textarea").innerHTML);
            this.close();
        },
        showClan: function(tag, name)
        {
        	this._currentTag = tag ? tag : currentClan.tag;;
            this._tagField.innerHTML = this._currentTag;
            this._nameField.innerHTML = name ? name : currentClan.name;
            this.open();
        }
    };
})();