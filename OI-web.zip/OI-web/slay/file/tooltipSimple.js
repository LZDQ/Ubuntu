FunUI.layouts["tooltipSimple"] = "<div id=\"tooltipSimple\" class=\"F-Tooltip\"> </div>";
