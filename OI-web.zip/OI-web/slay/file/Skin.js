"use strict";

class Skin {

	static show()
	{
		if(!playerData)
			return;
		
		if(!this.heroSelect)
			this.heroSelect = parseInt(playerData ? playerData.skin.id : 0);
		
		if(!this.heroClick)
			this.heroClick = this.heroSelect;
		
		this.filterAb = null;
		
		this.currentUpgradeHero = false;
		
		var o = this.get();
		this.tplHeroList();
		o.style.display = 'block';
	}

	static get()
	{
		var o = document.getElementById('skin');
		if(!o)
			o = this._create();
		return o;
	}

	static _createUpgrade()
	{
		var box = document.createElement('div');
		box.id = 'upgradeHero';
		box.className = 'F-Window';

		var h2 = document.createElement('div');
		h2.className = 'title';
		h2.innerText = 'BUY SLAYER';
		box.appendChild(h2);

		var inBox = document.createElement('div');
		inBox.className = 'content';

		box.appendChild(inBox);

		var close = document.createElement('div');
		close.className = 'F-Button close';
		close.onclick = this.closeUpgrade;
		box.appendChild(close);

		document.body.appendChild(box);

		F$(box.id);

		return box;
	}

	static closeUpgrade()
	{
		var o = document.getElementById('upgradeHero');
		if(o)
			o.style.display = 'none';
	}

	static _create()
	{
		var box = document.createElement('div');
		box.id = 'skin';
		box.className = 'F-Window';

		var h2 = document.createElement('div');
		h2.className = 'title';
		h2.innerText = F_('hero.list.title');
		box.appendChild(h2);

		var inBox = document.createElement('div');
		inBox.className = 'content';

		var filterBox = document.createElement('div');
		filterBox.className = 'filter';
		inBox.appendChild(filterBox);

		var viewBox = document.createElement('div');
		viewBox.className = 'view';
		inBox.appendChild(viewBox);

		var heroBox = document.createElement('div');
		heroBox.className = 'hero';
		inBox.appendChild(heroBox);

		box.appendChild(inBox);

		var close = document.createElement('div');
		close.className = 'F-Button close';
		close.onclick = () => {
			this.close();
		};
		box.appendChild(close);

		document.body.appendChild(box);

		F$(box.id);

		this.heroClick = parseInt(playerData ? playerData.skin.id : 0);

		return box;
	}

	static upgradeHero(heroId)
	{
		var o = document.getElementById('upgradeHero');
		if(!o)
			o = this._createUpgrade();
		
		this.currentUpgradeHero = heroId;
		this.refreshUpgrade();
		o.style.display = 'block';
	}

	static refreshUpgrade()
	{
		var heroId = this.currentUpgradeHero;

		var o = document.getElementById('upgradeHero');
		if(!o)
			return;

		var box = o.querySelector('.content');	
		box.innerHTML = '';
		box.style.textAlign = "center";
		
		// slayer avatar
		var canvas = document.createElement('canvas');
		canvas.className = 'hat';
		canvas.width = 100;
		canvas.height = 100;
		canvas.style.width = "200px";
		canvas.style.height = "200px";
		canvas.style.marginTop = "10px";
		box.appendChild(canvas);
		
		var ctx = canvas.getContext('2d');
		ctx.mozImageSmoothingEnabled = false;
		ctx.msImageSmoothingEnabled = false;
		ctx.imageSmoothingEnabled = false;
		drawHat(ctx, hats[heroId], 3.5, 2, 100, 100);
		
		var skinName = document.createElement("p");
		skinName.innerHTML = hats[heroId].name;
		skinName.style.fontSize = "30px";
		skinName.style.marginBottom = "60px";
		box.appendChild(skinName);
		
		if(!playerData.skinsUnlocked.split(";").contains(heroId))
		{
			if(!hats[heroId].gems && !hats[heroId].lvl) // can be bought for gold
			{
				var cost = goldCostBySkinQuality[hats[heroId].quality];
				this._appendButton(box, 'full', 'Buy for Gold x ' + cost, playerData.gold >= cost, () => {
					this._actionBuy('gold', heroId);
				});
			}
			
			if(hats[heroId].gems) // can be bought for gems
				this._appendButton(box, 'gem', 'Buy for Gem x ' + hats[heroId].gems, playerData.gems >= hats[heroId].gems, () => {
					this._actionBuy('gems', heroId);
				});
			
			if(hats[heroId].lvl)
			{
				var lvlUnlock = document.createElement("p");
				lvlUnlock.innerHTML = "Gets unlocked when you reach level " + hats[heroId].lvl;
				lvlUnlock.style.fontSize = "20px";
				lvlUnlock.style.color = "#dab700";
				box.appendChild(lvlUnlock);
			}
		}

		this.tplHeroList();
		this.tplHeroView(hats[heroId]);
	}

	static _actionBuy(action, heroId)
	{
		var o = document.getElementById('upgradeHero');
		if(!o)
			return;
		
		for(let btn of o.querySelectorAll('button'))
			btn.className = btn.className.replace(' disabled', '') + ' disabled';
		
		network.send('buyHero$' + action + '$' + heroId);
		
		playerData.skinsUnlocked += ";" + heroId;
		
		if(action == 'gold')
			playerData.gold -= goldCostBySkinQuality[hats[heroId].quality];
		
		else if(action == 'gems')
			playerData.gems -= hats[heroId].gems;
		
		F$('resourceBar').refresh();
		Skin.refreshUpgrade();
		
	    unlocks2Show.push({
	        type: "unlock",
	        item: hats[heroId]
	    });
	    showAchivement();
	    
		this.closeUpgrade();
	}

	static _appendText(box, className, text)
	{
		var p = document.createElement('p');
		p.className = className;
		p.innerText = text;
		box.appendChild(p);
	}

	static _appendButton(box, className, text, isEnable, onClick)
	{
		text = text.replace(/Gold/, '<i class="gold"></i>');
		text = text.replace(/Gem/, '<i class="gem"></i>');

		var button = document.createElement('button');
		button.className = className + (isEnable ? '' : ' disabled');
		button.innerHTML = text;
		if(isEnable)
			button.onclick = onClick;
		else
			button.disabled = true;
		
		var div = document.createElement('div');
		div.className = className;

		div.appendChild(button);
		box.appendChild(div);
	}

	static tplHeroList()
	{
		var o = document.getElementById('skin');
		if(!o)
			return;

		var list = o.querySelector('div.hero');
		list.innerHTML = '';
		
		var skinsArr = playerData.skinsUnlocked.split(";");
		
		for(let isHave of [true, false])
		{
			for(let hat of hats)
			{
				var iHaveSkin = skinsArr.contains(hat.id);
				
				if(iHaveSkin != isHave)
					continue;
				
				let o = document.createElement('div');
				let className = 'one-hero';
				if(!iHaveSkin)
					className += ' nohave';
				
				o.className = className;
				
				if(hat.id === this.heroSelect)
					o.className = o.className.replace(' selected', '') + ' selected';
				
				o.appendChild(this.tplCanvasHero(hat));
				
				let nameColor = hatQualityColor[hat.quality] ? (" style='color: " + hatQualityColor[hat.quality] + ";' ") : "";
				
				let name = document.createElement('div');
				name.className = 'info';
				name.innerHTML = '<br><span class="name" ' + nameColor + '>' + hat.name + '</span><br><span class="lvl">' + (iHaveSkin ? '' : F_('hero.buy.locked')) + '</span>';
				o.appendChild(name);

				o.onclick = () => {
					this.clickHeroSelect(this, hat, o);
				};

				list.appendChild(o);

				if(this.heroClick === hat.id)
					o.click();
			}
		}
	}

	static tplHeroView(hat)
	{
		var o = document.getElementById('skin');
		if(!o)
			return;
		
		var iHaveSkin = playerData.skinsUnlocked.split(";").contains(hat.id);
		
		var view = o.querySelector('div.view');
		view.innerHTML = '';
		
		view.appendChild(this.tplCanvasHero(hat));
		
		var name = document.createElement('div');
		name.className = 'info';
		var s = '<br /><span class="name">' + hat.name + '</span>';
		if(!iHaveSkin)
			s += '<br><span class="locked">' + F_('hero.buy.locked') + '</span>';
		
		name.innerHTML = s;
		view.appendChild(name);
		
		let bSelect = this.heroSelect === hat.id;
		
		if(hat.by)
		{
			var pAuthor = document.createElement('p');
			pAuthor.className = 'skin-author';
			pAuthor.innerText = F_('skin.author').replace(/\[\[name\]\]/, hat.by);
			view.appendChild(pAuthor);
		}
		
		var p = document.createElement('p');
		p.className = 'btn';
		
		if(['en-US', 'zh-CN', 'zh-TW'].indexOf(slayOne.widgets.lang.locale) == -1)
			p.className = 'btn btn-small';
		
		p.appendChild(this._tplHeroViewButton(
			view,
			'setHat',
			iHaveSkin,
			bSelect ? F_('hero.list.currentBtn') : F_('hero.list.selectBtn'),
			() => {
				bSelect ? this.close() : this.setHero(hat.id);
			}
		));
		
		if(!iHaveSkin)
		{
			p.appendChild(this._tplHeroViewButton(
				view,
				'upgrade',
				true,
				F_('hero.list.buyBtn'),
				() => {
					this.upgradeHero(hat.id);
				}
			));
		}
		view.appendChild(p);
	};

	static _tplHeroViewButton(view, key, isEnable, name, click)
	{
		var button = document.createElement('button');
		button.innerText = name;
		if(isEnable)
		{
			button.onclick = click;
			button.className = key;
		}
		else
		{
			button.disabled = true;
			button.className = key + ' disabled';
		}
		return button;
	};

	static setHero(id)
	{
		playerData.skin = hats[id];
		this.heroSelect = id;
		network.send('setHat$' + id);
		this.tplHeroList();
		this.refreshAbilitiesButton();
	};

	static resetCard(s)
	{
		playerData.skins_unlocked = s;
	}

	static tplCanvasHero(hat)
	{
		var canvas = document.createElement('canvas');
		canvas.className = 'hat';
		canvas.width = 100;
		canvas.height = 100;

		var ctx = canvas.getContext('2d');
		ctx.mozImageSmoothingEnabled = false;
		ctx.msImageSmoothingEnabled = false;
		ctx.imageSmoothingEnabled = false;

		drawHat(ctx, hat, 3.5, 2, 100, 100);

		return canvas;
	}

	static tplCanvasAb(i, size)
	{
		size = size|0;
		if(!size)
			size = 32;

		var canvas = document.createElement('canvas');

		canvas.width = size;
		canvas.height = size;

		var ctx = canvas.getContext("2d");

		ctx.mozImageSmoothingEnabled = false;
		ctx.msImageSmoothingEnabled = false;
		ctx.imageSmoothingEnabled = false;

		var a = abilities[i];

		var img = imgCoords[a.icon];
		var fac = size / Math.max(img.w, img.h);
		var w = img.w * fac;
		var h = img.h * fac;

		ctx.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, 0, 0, w, h);

		return canvas;
	}

	static getAbList(hatId)
	{
		var ab = hero[hatId];
		if(!ab)
			ab = hero[0];
		
		ab = ab.split(';');
		ab.shift();

		for(var id = 0, len = ab.length; id < len; id++)
		{
			let row = ab[id];

			let main = parseInt(row)|0;
			let sub = [];
			if(main && row.indexOf(',') > 0)
			{
				sub = row.split(',').map((a) => {
					return a|0;
				});
				sub.shift();
			}

			ab[id] = {
				id,
				lvl: main,
				attributes: sub,
			}
		}

		return ab;
	}
	
	static close()
	{
		var o = document.getElementById('skin');
		if(o)
			o.style.display = 'none';
		
		Skin.closeUpgrade();
	}

	static refreshAbilitiesButton(button)
	{
		if(!button)
		{
			button = document.getElementById('ability_button_main');
			if(!button)
				return;
		}

		Skin.abilitiesThumbnail(button, (playerData && playerData.authLevel >= 6) ? playerData.abilities : getDefaultAbilityObj(abilities));

		slayOne.widgets.hoverLight(button, {
			width: '180px',
			height: '118px',
			left: '-6px',
			top: '-6px'
		});

		slayOne.widgets.tooltip(button, {
			tip: playerData.authLevel >= 6 ? "Change abilities" : "Register to change abilities",
			align: "center"
		});

		slayOne.widgets.clickable(button);
	}

	static clickHeroSelect(obj, hat, o) {
		
		soundManager.playSound(SOUND.CLICK);

		obj.heroClick = hat.id;
		if (obj.prevSelect) {
			obj.prevSelect.className = obj.prevSelect.className.replace(' click', '');
		}
		o.className = o.className.replace(' click', '') + ' click';
		obj.prevSelect = o;
		obj.tplHeroView(hat);
	}

	static abilitiesThumbnail(box, pl, size) {

		if(!size)
			size = 32;

		box.innerHTML = '';
		for(var isPassive of [false, true])
		{
			for(var i = 0; i < abilities.length; i++)
			{
				var playerAbility = pl[i];

				if(!playerAbility || playerAbility.lvl === 0)
					continue;

				var ab = abilities[i];
				if((ab.type == 'passive') != isPassive)
					continue;

				var c_ = document.createElement('canvas');

				c_.width = size;
				if(!isPassive)
					c_.width *= 1.5;
				c_.height = c_.width;

				var ctx_ = c_.getContext("2d");

				ctx_.mozImageSmoothingEnabled = false;
				ctx_.msImageSmoothingEnabled = false;
				ctx_.imageSmoothingEnabled = false;

				// button background
				var img = imgCoords.button;
				ctx_.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, 0, 0, c_.width, c_.height);

				img = imgCoords[ab.icon];
				var fac = (c_.width * 0.75) / Math.max(img.w, img.h);
				var w = img.w * fac;
				var h = img.h * fac;
				ctx_.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, (c_.width - w) / 2, (c_.height - h) / 2, w, h);

				//once drawing is done, we attach to its parent
				box.appendChild(c_);
			}

			if(!isPassive)
				box.appendChild(document.createElement('br'));
		}
	}
}
