(function(slayOne, document){

/**
 * Standard field with 9-grid wrappers
 *
 * @param parentNode: dom element to append to
 * @param domContent: dom element to add as content
 * @param options
 *                  skin: enum(dark|standard|light|shadowed)
 *                  customClassName: string
 */
function standardField(parentNode, domContent, options){

    var domField = document.createElement("div");

    var finalClassName = "standardField";

    var skinOption = "standard";
    if(options && options.skin) {
    	skinOption = options.skin;
    }

    finalClassName += " standardFieldSkin" + capitalize(skinOption);

    if(options && options.customClassName) {
    	finalClassName += " " + options.customClassName;
    }

    domField.className = finalClassName;

    domField.appendChild(domContent);

    parentNode.appendChild(domField);

    domField.setSkin = function(val){
    	var finalClassName = "standardField standardFieldSkin" + capitalize(val);
    	if(options && options.customClassName) {
	    	finalClassName += " " + options.customClassName;
	    }
    	this.className = finalClassName;
    }.bind(domField);

    return domField;
}

//export
if(!slayOne.widgets) {
    slayOne.widgets = {};
}

slayOne.widgets.standardField = standardField;

})(window.slayOne, window.document);//end main closure