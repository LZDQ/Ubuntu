(function( slayOne, document ){

var themeSizes = {
    StandardGreen: { w: '160px', h: '60px' },
    LargeGreen: { w: '240px', h: '60px' },
    StandardYellow: { w: '160px', h: '60px' },
    LargeYellow: { w: '240px', h: '60px' },
    LargeBrown: { w: '286px', h: '68px' },
    LightGreen: { w: '278px', h: '48px' },
    LightDarkGreen: { w: '278px', h: '48px' },
    LightDisabled: { w: '278px', h: '48px' },
    LightFacebook: { w: '278px', h: '48px' },
    LightTwitch: { w: '278px', h: '48px' },
    TinyGreen: { w: '168px', h: '46px' },
    TinyRed: { w: '168px', h: '46px' },
    StandardTab: { w: '212px', h: '56px' },
    StandardTabActivated: { w: '212px', h: '56px' },
    SmallNormal: { w: '88px', h: '50px' },
    LargeNormal: { w: '206px', h: '54px' },
    LargeFBNormal: { w: '206px', h: '54px' },
    HugeNormal: { w: '246px', h: '54px' },
};

/**
 * Label button
 *
 * @param parentNode: dom element to append to
 * @param options:
 *                  label: button label
 *                  multiline: true | false
 *                  customClassName: string
 *                  noHoverLight: boolean, default false
 *                  theme:
 *                  - StandardGreen
 *                  - LargeGreen
 *                  - StandardYellow
 *                  - LargeYellow
 *                  - LargeBrown
 *                  - LightGreen
 *                  - LightDarkGreen
 *                  - LightDisabled
 *                  - LightFacebook
 *                  - LightTwitch
 *                  - StandardTab
 *                  - StandardTabActivated
 *                  - SmallNormal
 *                  - LargeNormal
 *                  - HugeNormal
 *                  - TinyGreen
 *                  - TinyRed
 *                  tip: tip content
 *                  tipAlign: tip alignment
 *                  onClick: func
 */
function labelButton( parentNode, options ){

	var btn = document.createElement("div");

    var btnTheme = (options && options.theme) ? options.theme : "StandardYellow";

    var finalClassName = "pixelated labelButton labelButton" + btnTheme;

    if(options && options.customClassName) {
        finalClassName += ' ' + options.customClassName;
    }

    var multiline = (options && options.multiline) ? options.multiline : false;
    if (multiline) {
        btn.innerHTML = '<div class="labelMultiline">' + options.label + '</div>';
    } else {
        btn.innerHTML = '<div class="label">' + options.label + '</div>';
    }

    btn.className = finalClassName;

    slayOne.widgets.clickable(btn);
    btn.onclick = options.onClick;

    if(!options || !options.noHoverLight) {
        btn.presentSubComponent("hover");
        // slayOne.widgets.hoverLight(btn, {
        //     width: themeSizes[btnTheme].w,
        //     height: themeSizes[btnTheme].h
        // });
    }

    if(options && options.tip && options.tip.length > 0) {
        btn.tipEffect = slayOne.widgets.tooltip(btn, {
            tip: options.tip,
            align: options.tipAlign
        });
    }

    parentNode.appendChild(btn);

    btn.setTheme = function(val){

        var finalClassName = "pixelated labelButton labelButton" + val;

        if(options && options.customClassName) {
            finalClassName += ' ' + options.customClassName;
        }

        btn.className = finalClassName;
        slayOne.widgets.clickable(btn);
    };

    return btn;
}

//export
if(!slayOne.widgets) {
    slayOne.widgets = {};
}

slayOne.widgets.labelButton = labelButton;

})( window.slayOne, window.document);//end main closure