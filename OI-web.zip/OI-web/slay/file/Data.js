// global constants
var CONST = {
	ITEM_RESPAWN_TIME: 20 * 45,
	PLAYER_RADIUS: 0.55,
	WPN_SWITCH_TICKS: 20,
	TRANSMUL: 100,
	MAX_ARMOR: 65,
	MOV_SPEED: 0.2035,
	MAX_JUMP_VEC_LEN: 0.21,
	ENERGY_REG_RATE: 0.05,
	GRAVITY: 0.066,
	MAX_HP_BASE: 86,
	MIN_MAP_SIZE: 8,
	MAX_MAP_SIZE: 128,
	SPAWN_INVINCIBILITY: 100,
	NO_SHOOT_AFTER_BLINK_TICKS: 40,
	XP_FLAG_RETURN: 30,
	START_ENERGY: 10,
	PERC_CRYSTALS_TRANSFER_ON_ZOMBIE_DEATH: 0.1,
	PERC_CRYSTALS_TRANSFER_ON_HUMAN_DEATH: 0.4,
	ZOMBIE_CRYSTAL_BASE: 25,
	ZOMBIE_BASE_DMG: 25,
	ZOMBIE_BASE_HP: 70,
	ZOMBIE_BASE_MOV_SPEED: 0.125,
	ZOMBIE_BASE_HP_REG: 0.035,
	CRYSTALS_PER_SOULS_LVL: 100,
	UPG_OPTIONS_PRESENTED: 5,
	HP_SEPERATOR_AMOUNT: 50,
	MAX_CRYSTALS: 1200,
	FLAME_DMG_PERIOD: 5,
	PLAYER_RESPAWN_DELAY: 150,
	CLAN_CREATION_GOLD_COST : 1000,
	GAME_CREATION_GOLD_COST : 100,
	EMOTE_DURATION: 100,
	BUSH_VISION_RANGE: 3,
	VETERAN_LVL: 200
};

var CREATION_FREE_MAPS = [
	1,
	76,
];

var TUTORIALS = {
	1 : {
		mapId: 1,//update mmshooter_maps set id=1 where name='Tutorial New';
		mapType : 0
	},
};

var AUTH_LEVEL = Object.freeze({
	NONE: 0,
	BOT: 2,
	GUEST: 4,
	PLAYER: 6,
	MOD: 8,
	MOD2: 9,
	ADMIN: 10
});

var MAP_TYPE = Object.freeze({
	DEATHMATCH: 0,
	TEAM_DEATHMATCH: 1,
	CTF: 2,
	TOURNAMENT: 3,
	TOURNAMENT_UNRANKED: 4,
	ZOMBIE_COOP: 5
});

var MAP_TYPE_SETTINGS = [];

MAP_TYPE_SETTINGS[MAP_TYPE.DEATHMATCH] = {
	id: MAP_TYPE.DEATHMATCH,
	zombies: true,
	souls: true,
	team: false,
	name: "Zombie Deathmatch",
	winningCondition: "souls",
	winningConditionLabel: "config.resource.soul.name",
	startMsg: "Don't team please. This is all vs all mode.",
	showTop3: true,
	ressourceIconName: "souls",
	langLabel: "config.mode.zdm.label",
	hidden: true,
	defaultBotCount: 4
};

MAP_TYPE_SETTINGS[MAP_TYPE.TEAM_DEATHMATCH] = {
	id: MAP_TYPE.TEAM_DEATHMATCH,
	zombies: true,
	spawnZombiesUntil: 20 * 60,
	extraSoulsOnKill: 30,
	souls: true,
	team: true,
	name: "Team Deathmatch",
	winningConditionLabel: "config.resource.soul.name",
	langLabel: "config.mode.tdm.label",
	icon: "mode_team.png",
	unlockLevel : 6,
	defaultBotCount: 4
};

MAP_TYPE_SETTINGS[MAP_TYPE.CTF] = {
	id: MAP_TYPE.CTF,
	zombies: false,
	team: true,
	name: "Capture The Flag",
	flag: true,
	langLabel: "config.mode.ctf.label",
	icon: "mode_flag.png",
	unlockLevel : 3,
	defaultBotCount: 4
};

MAP_TYPE_SETTINGS[MAP_TYPE.TOURNAMENT] = {
	id: MAP_TYPE.TOURNAMENT,
	zombies: false,
	team: false,
	name: "Ranked 1v1",
	lives: 5,
	winningConditionLabel: "config.resource.score.name",
	ingameElo: false,
	ressourceIconName: "star",
	startMsg: "1 versus 1. First player who dies 5 times loses the game.",
	langLabel: "config.mode.dm1.label",
	icon: "mode_ranked.png",
	inactive: true,
	hidden: true,
	queue: true,
	unlockLevel : 2,
	defaultBotCount: 0
};

MAP_TYPE_SETTINGS[MAP_TYPE.TOURNAMENT_UNRANKED] = {
	id: MAP_TYPE.TOURNAMENT_UNRANKED,
	zombies: false,
	team: false,
	customBuild: true,
	startMsg: "Don't team please. This is all vs all mode.",
	name: "Normal Deathmatch",
	winningCondition: "elo",
	winningConditionLabel: "config.resource.score.name",
	ingameElo: true,
	showTop3: true,
	ressourceIconName: "star",
	langLabel: "config.mode.dm2.label",
	defaultBotCount: 4
};

MAP_TYPE_SETTINGS[MAP_TYPE.ZOMBIE_COOP] = {
	id: MAP_TYPE.ZOMBIE_COOP,
	showTop3: true,
	showZombiesAndHumans: true,
	zombies: false,
	souls: true,
	team: false,
	coopZombieMode: true,
	convertTime: 20 * 20,
	preConvertTime: 10 * 20,
	convertPercentage: 0.2,
	name: "Zombie Coop",
	winningConditionLabel: "config.resource.soul.name",
	ressourceIconName: "souls",
	langLabel: "config.mode.zc.label",
	zombieBaseHP: 140,
	zombieHpRegeneration: 0.10,
	zombieMovSpeed: CONST.MOV_SPEED * 1.1,
	zombieLifesteal: 0.2,
	zombieEnergyReg: 0.06,
	humans_souls_per_sec: 2,
	zombies_souls_per_sec: 2,
	global_ammo_mod: 0.5,
	humanBossThreshold: 0.35,
	zombieBossThreshold: 0.5,
	zombieBossTime: 20 * 60 * 5,
	defaultBotCount: 18
};

// all fields in 7x7 range, ordered by dist to origin
var nbs = [
	{x: 0, y: 0},
	{x: 1, y: 0},
	{x: 0, y: 1},
	{x: 0, y: -1},
	{x: -1, y: 0},
	{x: 1, y: 1},
	{x: 1, y: -1},
	{x: -1, y: 1},
	{x: -1, y: -1},
	{x: 0, y: 2},
	{x: 2, y: 0},
	{x: 0, y: -2},
	{x: -2, y: 0},
	{x: 1, y: 2},
	{x: -1, y: -2},
	{x: -1, y: 2},
	{x: -2, y: 1},
	{x: -2, y: -1},
	{x: 1, y: -2},
	{x: 2, y: 1},
	{x: 2, y: -1},
	{x: -2, y: 2},
	{x: -2, y: -2},
	{x: 2, y: -2},
	{x: 2, y: 2},
	{x: -3, y: 0},
	{x: 0, y: 3},
	{x: 3, y: 0},
	{x: 0, y: -3},
	{x: 1, y: 3},
	{x: -3, y: -1},
	{x: 3, y: -1},
	{x: -3, y: 1},
	{x: 1, y: -3},
	{x: 3, y: 1},
	{x: -1, y: -3},
	{x: -1, y: 3},
	{x: 3, y: 2},
	{x: -3, y: 2},
	{x: 2, y: -3},
	{x: 2, y: 3},
	{x: 3, y: -2},
	{x: -2, y: 3},
	{x: -3, y: -2},
	{x: -2, y: -3},
	{x: -4, y: 0},
	{x: 4, y: 0},
	{x: 0, y: -4},
	{x: 0, y: 4},
	{x: -4, y: -1},
	{x: -1, y: -4},
	{x: -4, y: 1},
	{x: 1, y: -4},
	{x: 4, y: 1},
	{x: 1, y: 4},
	{x: 4, y: -1},
	{x: -1, y: 4},
	{x: -3, y: -3},
	{x: 3, y: -3},
	{x: -3, y: 3},
	{x: 3, y: 3},
	{x: -2, y: 4},
	{x: -2, y: -4},
	{x: 2, y: 4},
	{x: 4, y: -2},
	{x: -4, y: 2},
	{x: -4, y: -2},
	{x: 4, y: 2},
	{x: 2, y: -4},
	{x: 3, y: 4},
	{x: -4, y: -3},
	{x: -4, y: 3},
	{x: 5, y: 0},
	{x: -5, y: 0},
	{x: 0, y: 5},
	{x: 4, y: -3},
	{x: 0, y: -5},
	{x: -3, y: 4},
	{x: 4, y: 3},
	{x: -3, y: -4},
	{x: 3, y: -4},
	{x: -1, y: -5},
	{x: -1, y: 5},
	{x: 5, y: 1},
	{x: 5, y: -1},
	{x: 1, y: -5},
	{x: 1, y: 5},
	{x: -5, y: -1},
	{x: -5, y: 1},
	{x: -5, y: 2},
	{x: 5, y: -2},
	{x: -2, y: 5},
	{x: 2, y: -5},
	{x: -5, y: -2},
	{x: 5, y: 2},
	{x: 2, y: 5},
	{x: -2, y: -5},
	{x: 4, y: -4},
	{x: -4, y: -4},
	{x: -4, y: 4},
	{x: 4, y: 4},
	{x: -5, y: -3},
	{x: 5, y: -3},
	{x: -5, y: 3},
	{x: -3, y: -5},
	{x: -3, y: 5},
	{x: 3, y: 5},
	{x: 5, y: 3},
	{x: 3, y: -5},
	{x: 0, y: -6},
	{x: -6, y: 0},
	{x: 6, y: 0},
	{x: 0, y: 6},
	{x: -1, y: 6},
	{x: -6, y: 1},
	{x: 6, y: 1},
	{x: 6, y: -1},
	{x: 1, y: 6},
	{x: 1, y: -6},
	{x: -1, y: -6},
	{x: -6, y: -1},
	{x: 6, y: 2},
	{x: 2, y: -6},
	{x: 2, y: 6},
	{x: -6, y: -2},
	{x: -6, y: 2},
	{x: -2, y: 6},
	{x: -2, y: -6},
	{x: 6, y: -2},
	{x: -5, y: 4},
	{x: 5, y: 4},
	{x: -4, y: -5},
	{x: 4, y: 5},
	{x: -4, y: 5},
	{x: -5, y: -4},
	{x: 5, y: -4},
	{x: 4, y: -5},
	{x: 6, y: 3},
	{x: -6, y: 3},
	{x: -3, y: 6},
	{x: 3, y: 6},
	{x: 3, y: -6},
	{x: -3, y: -6},
	{x: 6, y: -3},
	{x: -6, y: -3},
	{x: -7, y: 0},
	{x: 7, y: 0},
	{x: 0, y: -7},
	{x: 0, y: 7},
	{x: -7, y: -1},
	{x: -1, y: -7},
	{x: 1, y: -7},
	{x: 7, y: 1},
	{x: 5, y: 5},
	{x: 5, y: -5},
	{x: 1, y: 7},
	{x: -1, y: 7},
	{x: -5, y: -5},
	{x: -7, y: 1},
	{x: -5, y: 5},
	{x: 7, y: -1},
	{x: -4, y: -6},
	{x: 4, y: 6},
	{x: 6, y: 4},
	{x: 4, y: -6},
	{x: -6, y: -4},
	{x: 6, y: -4},
	{x: -4, y: 6},
	{x: -6, y: 4},
	{x: -2, y: -7},
	{x: 7, y: -2},
	{x: -7, y: 2},
	{x: 7, y: 2},
	{x: 2, y: 7},
	{x: 2, y: -7},
	{x: -2, y: 7},
	{x: -7, y: -2},
	{x: 3, y: 7},
	{x: 7, y: 3},
	{x: -7, y: 3},
	{x: -3, y: 7},
	{x: -3, y: -7},
	{x: 3, y: -7},
	{x: 7, y: -3},
	{x: -7, y: -3},
	{x: -5, y: 6},
	{x: -6, y: 5},
	{x: 5, y: -6},
	{x: 6, y: 5},
	{x: -6, y: -5},
	{x: -5, y: -6},
	{x: 6, y: -5},
	{x: 5, y: 6},
	{x: 4, y: 7},
	{x: -7, y: 4},
	{x: 4, y: -7},
	{x: 7, y: -4},
	{x: -4, y: -7},
	{x: 7, y: 4},
	{x: -4, y: 7},
	{x: -7, y: -4},
	{x: 6, y: 6},
	{x: 6, y: -6},
	{x: -6, y: 6},
	{x: -6, y: -6},
	{x: 7, y: 5},
	{x: -5, y: -7},
	{x: 5, y: 7},
	{x: -7, y: 5},
	{x: 7, y: -5},
	{x: 5, y: -7},
	{x: -5, y: 7},
	{x: -7, y: -5},
	{x: -6, y: 7},
	{x: 6, y: 7},
	{x: 7, y: -6},
	{x: -7, y: 6},
	{x: 6, y: -7},
	{x: -6, y: -7},
	{x: 7, y: 6},
	{x: -7, y: -6},
	{x: -7, y: -7},
	{x: 7, y: -7},
	{x: -7, y: 7},
	{x: 7, y: 7}
];

var questTypes = {
	ExplosiveExpert: {
		icon: 'ExplosiveExpert',
		weapons: [1, 4, 6, 7, 10, 11],
	},
	Braaains: {
		icon: 'Braaains',
		weapons: [12],
	},
	LaserExpert: {
		icon: 'LaserExpert',
		weapons: [0, 5],
	},
	MinigunExpert: {
		icon: 'MinigunExpert',
		weapons: [3],
	},
	RocketExpert: {
		icon: 'RocketExpert',
		weapons: [4, 6, 7, 10],
	},
	FlameExpert: {
		icon: 'FlameExpert',
		weapons: [2],
	},
	RcExpert: {
		icon: 'RcExpert',
		weapons: [7],
	},
	ShotgunExpert: {
		icon: 'ShotgunExpert',
		weapons: [9],
	},
	SniperExpert: {
		icon: 'SniperExpert',
		weapons: [8],
	},
	CloseRange: {
		icon: 'CloseRange',
		weapons: [2, 9],
	},
	FastAndSlow: {
		icon: 'FastAndSlow',
		weapons: [3, 8],
	},
	GrenadeExpert: {
		icon: 'GrenadeExpert',
		weapons: [],
	},
};

var weapons = [

	{
		id: 0,
		name: "Laser Gun",
		cooldown: 17,
		dmg: 28,
		projectileSpeed: 0.75,
		lifetime: 60,
		collision: true,
		dieOnCollision: true,
		addHeight: true,
		description: "A basic laser gun.",
		soundName: "LASER",
		volume: 0.8,
		bouncePower: 0.15,
		bounceSpeed: 0.11,
		frame: 0,
		isLaser: true,
		light: "light_blue",
		particle: "particleBlue",
		_r: 58,
		_g: 58,
		_b: 230,
		selfImmuneTicks: 2,
		img: "weapon_laser",
		ammoImgSmall: "ammoLaserSmall",
		projectileImg: "laserBlue",
		muzzleFlash: "muzzleFlashLaserBlue",
		muzzleFlashAnimationType: "row",
		directions: 16,
		projectileScale: 0.85,
		zombieStunTime: 5
	},

	{
		id: 1,
		name: "Grenade Launcher",
		cooldown: 4,
		dmg: 60,
		projectileSpeed: 0.5,
		range: 9.5,
		aoe: 2.1,
		bounceBack: 0.15,
		aoeCursor: true,
		collision: false,
		dieOnCollision: false,
		description: "A powerful weapon that launches explosive grenades. Grenades can be shot over small obstacles like crates.",
		ammoImg: "ammoGL",
		ammoImgSmall: "ammoGrenadeSmall",
		soundName: "GREANDE_LAUNCH",
		projectileImg: "grenade",
		isGrenade: true,
		impactSound: "EXPLODE",
		impactSoundVolume: 1.0,
		ammoSize: 8,
		clipSize: 1,
		cooldown2: 55,
		ammoMsg: "Picked up some grenade rounds",
		reload2Sound: "RELOAD_GL",
		frame: 1,
		speedModifier: 1.03,
		img: "weapon_gl"
	},

	{
		id: 2,
		name: "Flamethrower",
		cooldown: 2,
		dmg: 4.0,
		dieOnCollision: true,
		projectileSpeed: 0.45,
		lifetime: 16,
		projectileSize: 1.0,
		collision: false,
		addHeight: true,
		description: "A short range weapon, that can kill an enemy very fast.",
		bouncePower: 0.15,
		bounceSpeed: 0.15,
		recoil: 0.2,
		flameDeath: true,
		ammoImg: "ammoFlame",
		ammoImgSmall: "ammoFlameSmall",
		ammoSize: 100,
		ammoMsg: "Picked up some gas",
		clipSize: 50,
		cooldown2: 60,
		reload2Sound: "RELOAD_FLAME",
		frame: 2,
		img: "weapon_flame",
		speedModifier: 1.13,
		selfImmuneTicks: 60,
		zombieStunTime: 1,
		noTeleport: true
	},

	{
		id: 3,
		name: "Minigun",
		cooldown: 2,
		dmg: 5.55,
		projectileSpeed: 3.0,
		lifetime: 20,
		collision: true,
		dieOnCollision: true,
		addHeight: true,
		description: "A strong, fast firing weapon.",
		bouncePower: 0.15,
		bounceSpeed: 0.19,
		soundName: "MG",
		volume: 0.7,
		recoil: 0.7,
		scattering: Math.PI * 0.03,
		recoilTime: 1,
		bounceBack: 0.05,
		bounceBackTarget: 0.05,
		normalProjectile: true,
		spawnBullets: true,
		frames: 2,
		ammoImg: "ammoMG",
		ammoImgSmall: "ammoMGSmall",
		ammoSize: 100,
		ammoMsg: "Picked up some minigun bullets",
		clipSize: 50,
		cooldown2: 60,
		reload2Sound: "RELOAD_MG",
		projectileImg: "projectile",
		directions: 16,
		projectileScale: 0.7,
		muzzleFlash: "muzzleFlashMG",
		frame: 3,
		img: "weapon_mg",
		zombieStunTime: 2
	},

	{
		id: 4,
		name: "Rocket Launcher",
		cooldown: 4,
		dmg: 60,
		projectileSpeed: 0.6,
		projectileSize: 0.25,
		lifetime: 130,
		aoe: 2.3,
		soundName: "ROCKET_LAUNCH",
		volume: 0.9,
		bounceStun: true,
		collision: true,
		dieOnCollision: true,
		bounceBackTarget: 0.33,
		description: "A powerful weapon that launches explosive rockets.",
		ammoImg: "ammoRL",
		ammoImgSmall: "ammoRocketSmall",
		ammoSize: 8,
		recoilTime: 6,
		clipSize: 1,
		cooldown2: 55,
		ammoMsg: "Picked up some rockets",
		reload2Sound: "RELOAD_RL",
		frame: 5,
		isRocket: true,
		img: "weapon_rl",
		projectileImg: "rocket",
		selfImmuneTicks: 3
	},

	{
		id: 5,
		name: "Laser Gun R",
		cooldown: 17,
		dmg: 28,
		projectileSpeed: 0.75,
		lifetime: 100,
		collision: true,
		dieOnCollision: true,
		reflection: true,
		addHeight: true,
		description: "A laser gun that gets reflected from walls and obstacles.",
		soundName: "LASER",
		volume: 0.8,
		bouncePower: 0.15,
		bounceSpeed: 0.11,
		frame: 6,
		isLaser: true,
		light: "light_green",
		particle: "particleGreen",
		ammoImg: "ammoLaser",
		ammoImgSmall: "ammoLaser2Small",
		ammoSize: 20,
		clipSize: 999999,
		cooldown2: 20,
		muzzleFlash: "muzzleFlashLaserGreen",
		muzzleFlashAnimationType: "row",
		ammoMsg: "Picked up a battery",
		reload2Sound: "LASER_RECHARGE",
		_r: 60,
		_g: 240,
		_b: 40,
		projectileImg: "laserGreen",
		directions: 16,
		projectileScale: 0.85,
		selfImmuneTicks: 1,
		img: "weapon_laser_r",
		zombieStunTime: 5
	},

	{
		id: 6,
		name: "Homing Launcher",
		cooldown: 4,
		dmg: 50,
		projectileSpeed: 0.36,
		turnRadius: 0.16,
		projectileSize: 0.2,
		lifetime: 250,
		aoe: 1.9,
		soundName: "ROCKET_LAUNCH",
		volume: 0.9,
		bounceStun: true,
		collision: true,
		dieOnCollision: true,
		bounceBackTarget: 0.25,
		description: "A powerful weapon that launches homing missiles.",
		ammoImg: "ammoHoming",
		ammoImgSmall: "ammoRocket2Small",
		ammoSize: 7,
		recoilTime: 6,
		clipSize: 1,
		cooldown2: 70,
		ammoMsg: "Picked up some homing missiles",
		reload2Sound: "RELOAD_RL_2",
		frame: 7,
		isHeatSeeking: true,
		isRocket: true,
		img: "weapon_homing",
		projectileImg: "homingRocket",
		speedModifier: 0.9,
		selfImmuneTicks: 3
	},

	{
		id: 7,
		name: "Remote Controlled Launcher",
		cooldown: 4,
		dmg: 58,
		projectileSpeed: 0.39,
		turnRadius: 0.20,
		projectileSize: 0.2,
		lifetime: 250,
		aoe: 1.9,
		soundName: "ROCKET_LAUNCH",
		volume: 0.9,
		bounceStun: true,
		collision: true,
		dieOnCollision: true,
		bounceBackTarget: 0.285,
		description: "A powerful weapon that launches homing missiles that follow your mouse cursor.",
		ammoImg: "ammoNapalm",
		ammoImgSmall: "ammoRocket3Small",
		ammoSize: 7,
		recoilTime: 6,
		clipSize: 1,
		cooldown2: 70,
		ammoMsg: "Picked up some homing missiles",
		reload2Sound: "RELOAD_RL_2",
		frame: 11,
		isHeatSeeking2: true,
		isRocket: true,
		img: "weapon_homing_2",
		projectileImg: "homingRocket2",
		speedModifier: 0.95,
		selfImmuneTicks: 3
	},
	/*
	{
		name: "Napalm Grenade Launcher",
		cooldown: 70,
		dmg: 20,
		projectileSpeed: 0.5,
		range: 8,
		aoe: 2.0,
		aoeCursor: true,
		collision: false,
		dieOnCollision: false,
		description: "A powerful weapon that launches napalm grenades. Grenades can be shot over small obstacles like crates.",
		ammoImg: "ammoNapalm",
		soundName: "GREANDE_LAUNCH",
		projectileImg: "napalmGrenade",
		impactSoundVolume: 0.7,
		bounceBack: 0.15,
		ammoSize: 8,
		clipSize: 999999,
		cooldown2: 60,
		createsFire: true,
		fireDuration: 20 * 8,
		fireDmg: 2,
		impactSound: "FLAME_EXPLODE",
		ammoMsg: "Picked up some napalm rounds",
		reload2Sound: "RELOAD_GL",
		frame: 8,
		img: "weapon_napalm",
		sootAlpha: 1
	},
	*/
	{
		id: 8,
		name: "Sniper Rifle",
		cooldown: 35,
		dmg: 65,
		projectileSpeed: 8.0,
		collision: true,
		dieOnCollision: true,
		addHeight: true,
		requiredStandTime: 20,
		description: "A sniper rifle with high range and damage. You need to aim first by pressing and holding F before you can shoot.",
		lifetime: 20,
		bouncePower: 0.15,
		bounceSpeed: 0.35,
		soundName: "SNIPER",
		volume: 0.9,
		recoil: 1.2,
		recoilTime: 7,
		normalProjectile: true,
		muzzleFlash: "muzzleFlashMG",
		spawnBullets: true,
		bounceBackTarget: 0.22,
		ammoImg: "ammoSniper",
		ammoImgSmall: "ammoSniperSmall",
		ammoSize: 10,
		ammoMsg: "Picked up some sniper rounds",
		clipSize: 5,
		cooldown2: 70,
		hasLine: true,
		reload2Sound: "RELOAD_MG",
		frame: 9,
		projectileImg: "projectile",
		directions: 16,
		projectileScale: 0.6,
		img: "weapon_sniper",
		isSniper: true,
		lastShotSound: "BING",
		speedModifier: 1.1,
		zombieStunTime: 10
	},

	{
		id: 9,
		name: "Shotgun",
		cooldown: 22,
		dmg: 7,
		dmgLossPerRange: 0.15,
		projectiles: 7,
		scattering: Math.PI * 0.09,
		projectileSpeed: 3.0,
		lifetime: 20,
		collision: true,
		dieOnCollision: true,
		addHeight: true,
		description: "The shotgun deals more damage, the closer you are to the target.",
		bouncePower: 0.25,
		bounceSpeed: 0.4,
		soundName: "SHOTGUN",
		volume: 0.8,
		recoil: 1.4,
		recoilTime: 5,
		bounceBack: 0.3,
		bounceBackTarget: 0.05,
		normalProjectile: true,
		muzzleFlash: "muzzleFlashMG",
		spawnBullets: true,
		ammoImg: "ammoShotgun",
		ammoImgSmall: "ammoShotgunSmall",
		ammoSize: 10,
		ammoMsg: "Picked up some shotgun shells",
		clipSize: 5,
		cooldown2: 55,
		reload2Sound: "SHOTGUN_RELOAD_LONG",
		frame: 10,
		projectileImg: "projectile",
		directions: 16,
		projectileScale: 0.55,
		img: "weapon_shotgun",
		speedModifier: 1.05,
		zombieStunTime: 10
	},

	{
		id: 10,
		name: "Rapid Rocket Launcher",
		cooldown: 15,
		dmg: 42,
		projectileSpeed: 0.6,
		projectileSize: 0.2,
		lifetime: 130,
		aoe: 1.45,
		soundName: "ROCKET_LAUNCH",
		volume: 0.75,
		bounceStun: true,
		collision: true,
		dieOnCollision: true,
		bounceBackTarget: 0.22,
		description: "A rocket launcher with a high fire rate.",
		ammoImgSmall: "ammoRocketSmall",
		ammoSize: 16,
		recoilTime: 6,
		clipSize: 8,
		cooldown2: 60,
		ammoMsg: "Picked up some rockets",
		reload2Sound: "RELOAD_RL",
		frame: 12,
		isRocket: true,
		img: "weapon_rapid_rl",
		projectileImg: "rocket",
		projectileScale: 0.8,
		speedModifier: 1.05,
		selfImmuneTicks: 3
	},

	{
		id: 11,
		name: "Rapid Grenade Launcher",
		cooldown: 18,
		dmg: 42,
		projectileSpeed: 0.5,
		range: 9.5,
		aoe: 1.5,
		bounceBack: 0.10,
		aoeCursor: true,
		collision: false,
		dieOnCollision: false,
		description: "A grenade launcher with high fire rate. Grenades can be shot over small obstacles like crates.",
		ammoImgSmall: "ammoGrenadeSmall",
		soundName: "GREANDE_LAUNCH",
		volume: 0.88,
		projectileImg: "grenade",
		projectileScale: 0.8,
		isGrenade: true,
		impactSound: "EXPLODE",
		impactSoundVolume: 0.8,
		ammoSize: 16,
		clipSize: 8,
		cooldown2: 60,
		ammoMsg: "Picked up some grenade rounds",
		reload2Sound: "RELOAD_GL",
		frame: 13,
		speedModifier: 1.05,
		img: "weapon_rapid_gl"
	},

	{
		id: 12,
		name: "Zombie Melee",
		cooldown: 16,
		dmg: 30.0,
		dieOnCollision: true,
		projectileSpeed: 0.30,
		lifetime: 0,
		projectileSize: 0.8,
		collision: true,
		addHeight: true,
		description: "Dangerous zombie melee claws.",
		bouncePower: 0.15,
		bounceSpeed: 0.11,
		recoil: 0,
		noWeapon: true,
		soundName: "ZOMBIE_ATT",
		impactSound: "ZOMBIE_BITE",
		impactSoundVolume: 0.8,
		ammoImgSmall: "blank",
		reload2Sound: "RELOAD_FLAME",
		img: "zombie_weapon",
		speedModifier: 1.0,
		zombieStunTime: 6,
		noTeleport: true,
		selfImmuneTicks: 3,
		slowTicks: 3,
		slowPerc: 0.5,
		corpseLifesteal: 20
	},

	{
		id: 13,
		name: "Zombie Ranged",
		cooldown: 20,
		dmg: 44.0,
		dieOnCollision: true,
		projectileSpeed: 0.45,
		lifetime: 40,
		projectileSize: 0.3,
		collision: true,
		addHeight: true,
		description: "Dangerous zombie poison.",
		bouncePower: 0.15,
		bounceSpeed: 0.11,
		recoil: 0,
		noWeapon: true,
		soundName: "ZOMBIE_ATT",
		impactSound: "ZOMBIE_BITE",
		impactSoundVolume: 0.8,
		ammoImgSmall: "blank",
		reload2Sound: "RELOAD_FLAME",
		img: "zombie_weapon",
		isZombieRangedWeapon: true,
		projectileScale: 1.15,
		speedModifier: 1.0,
		zombieStunTime: 6,
		selfImmuneTicks: 10,
		slowTicks: 10,
		slowPerc: 0.5
	},

	{
		id: 14,
		name: "Zombie Boss Melee",
		cooldown: 22,
		dmg: 110,
		dieOnCollision: true,
		projectileSpeed: 0.8,
		startAtOrigin: true,
		lifetime: 1,
		projectileSize: 1,
		collision: true,
		addHeight: true,
		description: "Dangerous zombie melee fists.",
		bouncePower: 0.15,
		bounceSpeed: 0.11,
		recoil: 0,
		noWeapon: true,
		soundName: "ZOMBIE_BOSS_HIT",
		impactSound: "ZOMBIE_BOSS_HIT",
		poundSmokeSize: 0.8,
		impactSoundVolume: 0.8,
		ammoImgSmall: "blank",
		reload2Sound: "RELOAD_FLAME",
		img: "zombie_weapon",
		speedModifier: 1.0,
		zombieStunTime: 6,
		noTeleport: true,
		selfImmuneTicks: 3,
		slowTicks: 3,
		slowPerc: 0.5
	},

	{
		id: 15,
		name: "Heal Beam",
		dmg: -5.0,
		selfHeal: 3.75,
		autoAimRange: 3.0,
		heals: true,
		isBeam: true,
		dieOnCollision: true,
		projectileSpeed: 10.5,
		soundName: "HEAL_WPN",
		friendly: true,
		beamRenderStartOffset: 1.2,
		lifetime: 5,
		cooldown: 5,
		projectileSize: 0.01,
		collision: true,
		addHeight: true,
		description: "A sweapon that heals you and your allies.",
		bouncePower: 0,
		recoil: 0.2,
		ammoImg: "ammoFlame",
		ammoImgSmall: "ammoHealSmall",
		ammoSize: 100,
		ammoMsg: "Picked up some energy",
		clipSize: 40,
		cooldown2: 60,
		reload2Sound: "RELOAD_FLAME",
		frame: 15,
		img: "weapon_heal",
		speedModifier: 1.15,
		selfImmuneTicks: 60,
		zombieStunTime: 1,
		noTeleport: true,
		disableByBot: true,
		beamColor1: "rgba(93, 194, 57, 0.7)",
		beamWidth1: 0.1,
		beamColor2: "rgba(126, 225, 92, 0.4)",
		beamWidth2: 0.21,
		beamColor3: "rgba(160, 242, 131, 0.15)",
		beamWidth3: 0.35,
		muzzleFlashParticle: "particleGreen"
	},

	{
		id: 16,
		name: "Energy Rifle",
		cooldown: 20,
		dmg: 20,
		canTriggerCombo: true,
		mode2Weapon: 17,
		projectileSpeed: 3.0,
		projectileSize: 0.2,
		muzzleFlashDisplayTime: 4,
		lifetime: 8,
		fadeOutAt: 4,
		collision: true,
		dieOnCollision: true,
		addHeight: true,
		description: "This weapon has two fire modes: a basic ray and an energy ball. If you hit the ball with the ray, you'll get a big explosion.",
		bouncePower: 0.2,
		bounceSpeed: 0.25,
		soundName: "ASMD1",
		volume: 0.55,
		recoil: 1.2,
		recoilTime: 5,
		bounceBack: 0.2,
		bounceBackTarget: 0.27,
		isLaser: true,
		light: "light_red",
		particle: "particleRed",
		_r: 230,
		_g: 58,
		_b: 58,
		projectileImg: "laserRed",
		ammoImg: "ammoMG",
		ammoImgSmall: "ammoASMDSmall",
		ammoSize: 28,
		ammoMsg: "Picked up some energy",
		clipSize: 14,
		cooldown2: 60,
		reload2Sound: "ASMD_RELOAD",
		directions: 16,
		muzzleFlash: "muzzleFlashMG",
		frame: 14,
		img: "weapon_asmd",
		zombieStunTime: 12,
		muzzleFlashParticle: "particleWhite",
		muzzleFlashLight2: "light_white",
		muzzleFlashLight: "light_red",
		hitLight1: "light_red",
		hitLight2: "light_white"
	},

	{
		id: 17,
		dummyFor: 16,
		name: "ASMD 2nd Mode",
		cooldown: 20,
		dmg: 45,
		comboDmg: 100,
		projectileSpeed: 0.35,
		projectileSize: 0.28,
		projectileScale: 1.45,
		bounceBack: 0.2,
		lifetime: 100,
		aoe: 1.4,
		comboAoe: 3.1,
		redExplosion: true,
		soundName: "ASMD_BALL_LAUNCH",
		impactSound: "ASMD_EXPLO_1",
		impactSoundCombo: "ASMD_EXPLO_2",
		volume: 0.9,
		bounceStun: true,
		collision: true,
		dieOnCollision: true,
		description: "A powerful weapon that launches explosive rockets.",
		ammoImg: "ammoRL",
		ammoImgSmall: "ammoASMDSmall",
		ammoSize: 40,
		recoilTime: 6,
		clipSize: 20,
		cooldown2: 60,
		ammoMsg: "Picked up some energy",
		reload2Sound: "ASMD_RELOAD",
		frame: 17,
		isRocket: true,
		img: "weapon_asmd",
		projectileImg: "fireballMedium",
		selfImmuneTicks: 30,
		noWeapon: true,
		directions: 1,
		noRocketEffects: true,
		glowLightImg: "light_red",
		flySound: "ASMD_FLY",
		projectileWiggle: true,
		spawnLight: "light_red"
	}

];

var weaponProto = {
	get name() {
		return F_ && F_("weapons." + this.id + ".name") || this.locales.name;
	},
	get description() {
		return F_ && F_("weapons." + this.id + ".description") || this.locales.description;
	},
	get ammoMsg() {
		return F_ && F_("weapons." + this.id + ".ammoMsg") || this.locales.ammoMsg;
	}
};

for(var i = 0; i < weapons.length; i++) {
	var src = weapons[i];
	src.id = i;

	if (typeof exports == 'undefined') {
		var dist = Object.create(weaponProto);
		dist.locales = {};
		for (var key in src) {
			if (['name', "description", "ammoMsg"].indexOf(key) >= 0) {
				dist.locales[key] = src[key];
			} else {
				dist[key] = src[key];
			}
		}

		weapons[i] = dist;
	}
}

var itemTypes = [

	{
		name: "Medikit",
		pickupMsg: "Picked up a medikit",
		hpRestored: 50,
		pickupSound: "HEAL",
		img: "medikit",
		scale: 0.55,
		shine: true
	},

	{
		name: "Armor",
		pickupMsg: "Picked up armor",
		armorRestored: CONST.MAX_ARMOR,
		pickupSound: "ARMOR",
		img: "armor",
		scale: 0.55,
		shine: true
	},

	{
		name: "Red Flag",
		pickupSound: "ARMOR",
		img: "redFlag",
		special: "redFlag",
		respawnPeriod: -1
	},

	{
		name: "Blue Flag",
		pickupSound: "ARMOR",
		img: "blueFlag",
		special: "blueFlag",
		respawnPeriod: -1
	}

];

var itemTypeProto = {
	get name() {
		return F_ && F_("itemTypes." + this.id + ".name") || this.locales.name;
	},
	get pickupMsg() {
		return F_ && F_("itemTypes." + this.id + ".pickupMsg") || this.locales.pickupMsg;
	}
};

for(var i = 0; i < itemTypes.length; i++)
{
	var src = itemTypes[i];
	src.id = i;
	
	if(typeof exports == 'undefined')
	{
		var dist = Object.create(itemTypeProto);
		dist.locales = {};
		for(var key in src)
		{
			if(['name', "pickupMsg"].indexOf(key) >= 0)
				dist.locales[key] = src[key];
			else
				dist[key] = src[key];
		}
		
		itemTypes[i] = dist;
	}
}

var objects = {

	healaura: {
		name: "Heal Aura",
		img: ["healWard", "healWard2"],
		animationType: "auto",
		hpPerTick: 0.3,
		aoe: 3.5,
		hp: 100,
		lifetime: 20 * 45,
		pathing: 5,
		turretsDontShootMe: true,
		showLifeTimeBar: true,
		barYOffset: 2.0
	},

	wall: {
		name: "Wall",
		img: ["block", "block2", "block3"],
		animationType: "dmg",
		lifetime: 20 * 180,
		noTeamLifetime: 20 * 90,
		hp: 80,
		pathing: 5,
		yOffset: 4,
		noBars: true,
		turretsDontShootMe: true,
		healthBarW: 16
	},

	autoturret: {
		name: "Auto Turret",
		lifetime: 20 * 120,
		hp: 115,
		aoe: 9,
		weapon: weapons[3],
		img: ["autoTurretBase"],
		animation: "autoturret",
		weaponCooldown: 2,
		pathing: 5,
		dmg: 2.25,
		spawnSound: "TURRET_INIT",
		volume: 0.5,
		initTicks: 40,
		rotateSpeed: 0.1,
		imgScale: 1.1
	},

	laserturret: {
		name: "Laser Turret",
		lifetime: 20 * 120,
		hp: 115,
		aoe: 9,
		bounce: 0.01,
		weapon: weapons[0],
		img: ["autoTurretBase"],
		animation: "laserturret",
		weaponCooldown: 19,
		pathing: 5,
		dmg: 28,
		spawnSound: "TURRET_INIT",
		volume: 0.5,
		initTicks: 40,
		rotateSpeed: 0.1,
		imgScale: 1.1
	},

	missileturret: {
		name: "Missile Turret",
		lifetime: 20 * 120,
		hp: 115,
		weapon: weapons[4],
		aoe: 8.5,
		radius: 2.3,
		img: ["autoTurretBase"],
		animation: "missileturret",
		weaponCooldown: 57,
		pathing: 5,
		dmg: 55,
		spawnSound: "TURRET_INIT",
		volume: 0.5,
		initTicks: 40,
		rotateSpeed: 0.09,
		imgScale: 1.1
	},

	grenadeturret: {
		name: "Grenade Turret",
		radius: 2.2,
		maxRangeBonus: 1.5,
		lifetime: 20 * 120,
		hp: 90,
		weapon: weapons[1],
		aoe: 7.5,
		img: ["autoTurretBase"],
		animation: "grenadeturret",
		weaponCooldown: 65,
		pathing: 5,
		dmg: 50,
		spawnSound: "TURRET_INIT",
		volume: 0.5,
		initTicks: 40,
		raytraceBlock: 4,
		rotateSpeed: 0.077,
		imgScale: 1.1
	},

	hegrenade: {
		name: "HE Grenade",
		lifetime: 1,
		img: ["grenade8", "grenade7", "grenade6", "grenade5", "grenade4", "grenade3", "grenade2", "grenade1"],
		pathing: 10,
		yOffset: 4,
		noBars: true,
		aoe: 2.75,
		dmg: 70,
		turretsDontShootMe: true
	},

	smokegrenade: {
		name: "Smoke Grenade",
		lifetime: 20 * 15,
		img: ["grenadeBlue8", "grenadeBlue7", "grenadeBlue6", "grenadeBlue5", "grenadeBlue4", "grenadeBlue3", "grenadeBlue2", "grenadeBlue1"],
		pathing: 10,
		yOffset: 4,
		noBars: true,
		aoe: 2.85,
		emitsSmoke: true,
		turretsDontShootMe: true
	},

	flashgrenade: {
		name: "Flash Grenade",
		lifetime: 4,
		img: ["grenadeYellow8", "grenadeYellow7", "grenadeYellow6", "grenadeYellow5", "grenadeYellow4", "grenadeYellow3", "grenadeYellow2", "grenadeYellow1"],
		pathing: 10,
		yOffset: 4,
		noBars: true,
		aoe: 2.85,
		flash: true,
		turretsDontShootMe: true
	},

	lasergrenade: {
		name: "Laser Grenade",
		lifetime: 4,
		img: ["grenadeYellow8", "grenadeYellow7", "grenadeYellow6", "grenadeYellow5", "grenadeYellow4", "grenadeYellow3", "grenadeYellow2", "grenadeYellow1"],
		pathing: 10,
		yOffset: 4,
		noBars: true,
		dmg: 24,
		countLasers: 5,
		turretsDontShootMe: true
	},

	poisongrenade: {
		name: "Acid Gas Grenade",
		lifetime: 200,
		img: ["grenadeBlue8", "grenadeBlue7", "grenadeBlue6", "grenadeBlue5", "grenadeBlue4", "grenadeBlue3", "grenadeBlue2", "grenadeBlue1"],
		pathing: 10,
		yOffset: 4,
		noBars: true,
		aoe: 3.5,
		emitsPoison: true,
		flameDPS: 25,
		turretsDontShootMe: true,
		noBounce: true
	}/*,

	remotemine: {
		name: "Remote Mine",
		radius: 2.2,
		lifetime: 20 * 180,
		hp: 50,
		img: ["mine2"],
		pathing: 10,
		dmg: 70,
		spawnSound: "TURRET_INIT",
		volume: 0.5,
		initTicks: 40,
		imgScale: 1,
		type: "remote",
		turretsDontShootMe: true
	}*/

};

var objectProto = {
	get name() {
		return F_ && F_("objects." + this.id + ".name") || this.locales.name;
	}
};

for(var id in objects)
{
	var src = objects[id];
	src.id = id;

	if(typeof exports == 'undefined')
	{
		var dist = Object.create(objectProto);
		dist.locales = {};
		for(var key in src)
		{
			if(['name'].indexOf(key) >= 0)
				dist.locales[key] = src[key];
			else
				dist[key] = src[key];
		}

		objects[id] = dist;
	}
}

var abilities = [

	{
		name: "Heal Aura",
		object: "healaura",
		cooldown: 0,
		energy: 45,
		range: 5,
		icon: "healWard",
		humanOnly: true,
		type: "place",
		description: "Create an aura that heals nearby players.",
		activeMsg: "Left click to place",
		levelUpFields: ["hpPerTick", "lifetime", "aoe"],
		levelUpFieldsName: ["Heal Rate", "Lifetime", "Radius"],
		displayScale: [20, 1 / 20, 1],
		levelUpValues: [0.15, 30 * 20, 0.9],
		levelUpCost: [100, 100, 100],
		levelUpMaxLvl: [3, 3, 3],
		cost: 100,
		maxLvl: 1,
		defaultLvl: 1,
		isFree: true
	},

	/*
	{
		name: "Auto Turret",
		object: "autoturret",
		cooldown: 0,
		energy: 60,
		range: 5,
		icon: "autoTurretIcon",
		type: "place",
		description: "Create a turret that shoots enemies.",
		activeMsg: "Left click to place",
		levelUpFields: ["dmg"],
		levelUpFieldsName: ["Damage"],
		levelUpValues: [0.45],
		levelUpCost: [100],
		levelUpMaxLvl: [3],
		cost: 100,
		maxLvl: 1,
		defaultLvl: 1,
		isFree: true
	},
	*/

	{
		name: "Laser Turret",
		object: "laserturret",
		cooldown: 0,
		energy: 55,
		range: 5,
		icon: "laserTurretIcon",
		humanOnly: true,
		type: "place",
		description: "Create a laser turret that shoots enemies.",
		activeMsg: "Left click to place",
		levelUpFields: ["aoe", "weaponCooldown", "maxCount"],
		levelUpFieldsName: ["Range", "Fire Rate", "Max Active"],
		levelUpValues: [1.5, -2, 1],
		displayScale: [1, 1 / 20, 1],
		levelUpCost: [100, 100, 100],
		levelUpMaxLvl: [3, 3, 3],
		levelUpMaxUpgLvl: [3, 3, 3],
		cost: 100,
		maxLvl: 1,
		defaultLvl: 1,
		tutorialLvl: 1,
		isFree: true,
		maxCount: 2
	},

	{
		name: "Wall",
		object: "wall",
		cooldown: 0,
		energy: 13,
		range: 5,
		icon: "block",
		humanOnly: true,
		type: "place",
		description: "Create a wall, that blocks pathing and projectiles. Grenades can be shot over it, though.",
		activeMsg: "Left click to place",
		levelUpFields: ["hp"],
		levelUpFieldsName: ["Health"],
		levelUpValues: [40],
		levelUpCost: [100],
		levelUpMaxLvl: [3],
		cost: 100,
		maxLvl: 1,
		isFree: true
	},

	{
		name: "Teleport",
		cooldown: 8 * 20,
		energy: 45,
		range: 4,
		type: "blink",
		icon: "blink",
		humanOnly: true,
		description: "Teleport over a short distance. After using teleport, you can not shoot for 2 sec.",
		activeMsg: "Left click to teleport",
		levelUpFields: ["range"],
		levelUpFieldsName: ["Range"],
		levelUpValues: [1.5],
		levelUpCost: [100],
		levelUpMaxLvl: [3],
		cost: 100,
		maxLvl: 1,
		gold: 1500
	},

	{
		name: "Invisibility",
		cooldown: 0,
		energy: 5,
		type: "invis",
		icon: "invis",
		humanOnly: true,
		description: "Makes you invisible.",
		invisEnergyRate: -0.21,
		isInstant: true,
		levelUpFields: ["invisEnergyRate"],
		levelUpFieldsName: ["Energy Cost"],
		levelUpValues: [0.016],
		displayScale: [20],
		levelUpCost: [100],
		levelUpMaxLvl: [3],
		cost: 100,
		maxLvl: 1,
		isFree: true
	},
	/*
	{
		name: "Smoke Grenade",
		object: "smokegrenade",
		cooldown: 0,
		energy: 25,
		range: 11,
		icon: "grenadeBlue1",
		type: "throw",
		description: "Throw a grenade that creates smoke and block sight.",
		activeMsg: "Left click to throw",
		levelUpFields: ["lifetime", "range"],
		levelUpFieldsName: ["Duration", "Range"],
		levelUpValues: [20 * 2, 1],
		displayScale: [1 / 20, 1],
		levelUpCost: [100, 100],
		levelUpMaxLvl: [3, 3],
		cost: 100,
		maxLvl: 1,
		isFree: true
	},
	*/
	{
		name: "Acid Grenade",
		object: "poisongrenade",
		cooldown: 0,
		energy: 30,
		range: 12,
		icon: "grenadeBlue1",
		humanOnly: true,
		type: "throw",
		description: "Throw an acid grenade, that causes damage to players and objects over time.",
		activeMsg: "Left click to throw",
		levelUpFields: ["range", "aoe", "flameDPS"],
		levelUpFieldsName: ["Range", "Radius", "Damage"],
		levelUpValues: [2, 0.5, 5],
		levelUpCost: [100, 100, 100],
		levelUpMaxLvl: [3, 3, 3],
		cost: 100,
		maxLvl: 1,
		isFree: true
	},

	{
		name: "HE Grenade",
		object: "hegrenade",
		energy: 20,
		range: 10,
		cooldown: 20,
		icon: "grenade1",
		humanOnly: true,
		type: "throw",
		description: "Throw a grenade that explodes and does damage.",
		activeMsg: "Left click to throw",
		levelUpFields: ["dmg", "range"],
		levelUpFieldsName: ["Damage", "Range"],
		levelUpValues: [10, 2],
		levelUpCost: [100, 100],
		levelUpMaxLvl: [3, 3],
		cost: 100,
		maxLvl: 1,
		isFree: true
	},

	/*
	{
		name: "Flash Grenade",
		object: "flashgrenade",
		cooldown: 0,
		energy: 30,
		range: 12,
		icon: "grenadeYellow1",
		type: "throw",
		description: "Throw a grenade that blinds nearby players.",
		activeMsg: "Left click to throw",
		levelUpFields: ["range"],
		levelUpFieldsName: ["Range"],
		levelUpValues: [2],
		levelUpCost: [100],
		levelUpMaxLvl: [3],
		cost: 100,
		maxLvl: 1,
		gold: 1200
	},
	*/

	{
		name: "Laser Grenade",
		object: "lasergrenade",
		cooldown: 6 * 20,
		energy: 35,
		range: 12,
		icon: "grenadeYellow1",
		humanOnly: true,
		type: "throw",
		description: "Throw a grenade that shoots lasers in all directions when detonating.",
		activeMsg: "Left click to throw",
		levelUpFields: ["countLasers"],
		levelUpFieldsName: ["Lasers"],
		levelUpValues: [2],
		levelUpCost: [100],
		levelUpMaxLvl: [3],
		cost: 100,
		maxLvl: 1,
		gold: 1800
	},

	{
		name: "Missile Turret",
		object: "missileturret",
		cooldown: 0,
		energy: 80,
		range: 5,
		icon: "missileTurretIcon",
		humanOnly: true,
		type: "place",
		description: "Create a turret that shoots enemies.",
		activeMsg: "Left click to place",
		levelUpFields: ["dmg", "radius", "maxCount"],
		levelUpFieldsName: ["Damage", "Radius", "Max Number"],
		levelUpValues: [14, 0.25, 1],
		levelUpCost: [100, 100, 100],
		levelUpMaxLvl: [3, 3, 3],
		cost: 100,
		maxLvl: 1,
		gold: 1200,
		maxCount: 2
	},

	{
		name: "Grenade Turret",
		object: "grenadeturret",
		cooldown: 0,
		energy: 75,
		range: 5,
		icon: "grenadeTurretIcon",
		humanOnly: true,
		type: "place",
		description: "Create a turret that shoots enemies.",
		activeMsg: "Left click to place",
		levelUpFields: ["dmg", "radius", "maxCount"],
		levelUpFieldsName: ["Damage", "Radius", "Max Number"],
		levelUpValues: [12, 0.22, 1],
		levelUpCost: [100, 100, 100],
		levelUpMaxLvl: [3, 3, 3],
		cost: 100,
		maxLvl: 1,
		gold: 1600,
		maxCount: 2
	},

	{
		name: "Scan",
		cooldown: 10 * 20,
		duration: 16 * 20,
		energy: 15,
		type: "scan",
		icon: "scan",
		humanOnly: true,
		description: "Show enemy players on the minimap for a while. Also increases the visibility of invisible players.",
		isInstant: true,
		levelUpFields: ["duration"],
		levelUpFieldsName: ["Duration"],
		levelUpValues: [6 * 20],
		displayScale: [1 / 20],
		levelUpCost: [100],
		levelUpMaxLvl: [3],
		cost: 100,
		maxLvl: 1,
		gold: 1200
	},

	{
		name: "Strength",
		type: "passive",
		field: "maxHP",
		mod: 7,
		zombieMod: 7,
		defaultLvl: 3,
		tutorialLvl: 6,
		icon: "strength",
		description: "Increases your max HP by 7",
		cost: 100,
		maxLvl: 10,
		isFree: true,
		causesFieldUpdate: true
	},

	{
		name: "Agility",
		type: "passive",
		field: "movementSpeed",
		mod: 0.0038,
		zombieMod: 0.0045,
		icon: "agility",
		description: "Increases your movement Speed",
		cost: 100,
		defaultLvl: 3,
		tutorialLvl: 3,
		maxLvl: 10,
		isFree: true
	},

	{
		name: "Regeneration",
		type: "passive",
		field: "hpRegeneration",
		mod: 0.0155,
		zombieMod: 0.03,
		icon: "regeneration",
		description: "Increases your HP regeneration rate",
		cost: 100,
		maxLvl: 10,
		gold: 1200,
		causesFieldUpdate: true
	},

	{
		name: "Intelligence",
		type: "passive",
		field: "energyRegeneration",
		mod: 0.01,
		zombieMod: 0.018,
		tutorialLvl: 10,
		icon: "intelligence",
		description: "Increases your energy regeneration rate",
		cost: 100,
		maxLvl: 10,
		gold: 1200,
		causesFieldUpdate: true
	},

	{
		name: "Lifesteal",
		type: "passive",
		field: "lifesteal",
		mod: 0.045,
		zombieMod: 0.1,
		icon: "lifesteal",
		description: "Makes you gain life when dealing damage",
		cost: 100,
		maxLvl: 10,
		gold: 1700
	},

	{
		name: "Shield",
		type: "shield",
		reduceDmgTo: 10,
		cooldown: 10 * 20,
		duration: 1 * 20,
		energy: 33,
		icon: "shieldIcon",
		humanOnly: true,
		description: "Reduces incoming damage to 10. Only lasts 1 sec.",
		isInstant: true,
		cost: 100,
		maxLvl: 1,
		gold: 2000
	},

	{
		name: "Play Dead",
		type: "playdead",
		cooldown: 10 * 20,
		duration: 20,
		duration2: 6,
		energy: 5,
		icon: "playDead",
		description: "Play dead.",
		isInstant: true,
		zombieOnly: true,
		maxLvl: 1,
		cost: 100,
		causesAbilityUpdate: true
	},

	{
		name: "Summon Zombie",
		type: "summon",
		energy: 40,
		range: 5,
		icon: "summonZombie",
		cooldown: 1,
		description: "Summon a zombie.",
		zombieOnly: true,
		maxLvl: 5,
		cost: 100,
		causesAbilityUpdate: true
	},

	{
		name: "Summon Stronger Zombie",
		type: "summon",
		energy: 50,
		range: 5,
		icon: "summonZombie2",
		cooldown: 1,
		description: "Summon a stronger zombie.",
		rangedZombie: true,
		zombieOnly: true,
		maxLvl: 5,
		cost: 100,
		causesAbilityUpdate: true
	},

	{
		name: "Zombie Sense",
		type: "passive",
		range: 5,
		field: "zombieSense",
		mod: 5,
		zombieMod: 5,
		icon: "zombieSenseIcon",
		description: "Show invisible players near you.",
		zombieOnly: true,
		maxLvl: 3,
		cost: 100,
		causesFieldUpdate: true
	},

	{
		name: "Summon Dark Zombie",
		type: "summon",
		energy: 80,
		range: 4,
		icon: "summonZombie3",
		cooldown: 1,
		description: "Summon a dark zombie.",
		zombieOnly: true,
		maxLvl: 5,
		cost: 100,
		special: "dark",
		requiredLvl: 8,
		causesAbilityUpdate: true
	},

	{
		name: "Damage",
		type: "passive",
		field: "dmg",
		mod: 0,
		zombieMod: 10,
		icon: "zombie_weapon",
		zombieOnly: true,
		description: "Increases your damage",
		cost: 100,
		maxLvl: 10
	},

	{
		name: "Summon Crawler",
		type: "summon",
		energy: 30,
		range: 4,
		icon: "crawler",
		cooldown: 1,
		description: "Summon a crawler.",
		zombieOnly: true,
		maxLvl: 5,
		cost: 100,
		special: "crawler",
		requiredLvl: 4,
		causesAbilityUpdate: true
	},
	
	{
		name: "Reflection Shield",
		type: "shield",
		reflects: true,
		cooldown: 10 * 20,
		duration: 1 * 20,
		energy: 33,
		icon: "refShieldIcon",
		humanOnly: true,
		description: "Reflects incoming projectiles.",
		isInstant: true,
		cost: 100,
		maxLvl: 1,
		gold: 2000
	}
	
	/*
	{
		name: "Remote Mine",
		object: "remotemine",
		cooldown: 0,
		energy: 30,
		range: 5,
		icon: "mine2",
		type: "place",
		description: "Place a mine that can be detonated remotely.",
		activeMsg: "Left click to place",
		levelUpFields: ["dmg", "radius"],
		levelUpFieldsName: ["Damage", "Radius"],
		levelUpValues: [7, 0.15],
		levelUpCost: [100, 100],
		levelUpMaxLvl: [3, 3],
		cost: 100,
		maxLvl: 1,
		gold: 1400
	}*/

];

var abilityProro = {
	get isAbility() {
		return true;
	},
	get name() {
		return F_ && F_("abilities." + this.id + ".name") || this.locales.name;
	},
	get description() {
		return F_ && F_("abilities." + this.id + ".desc") || this.locales.description;
	},
	get activeMsg() {
		return F_&& F_("abilities." + this.id + ".activeMsg") || this.locales.activeMsg;
	},
	get levelUpFieldsName() {
		if (!F_) {
			return this.locales.levelUpFieldsName;
		}
		var names = [];
		if(this.levelUpFields)
			for(var i = 0; i < this.levelUpFields.length; i ++)
				names[i] = F_("abilities." + this.id + ".levelUp." + this.levelUpFields[i]);

		return names;
	}
};

for(var i = 0; i < abilities.length; i++)
{
	var src = abilities[i];
	src.id = i;
	
	if(typeof exports !== 'undefined')
		src.isAbility = true;
	else
	{
		var dist = Object.create(abilityProro);
		dist.locales = {};
		for (var key in src) {
			if(['name', 'description', 'activeMsg', 'levelUpFieldsName'].indexOf(key) >= 0)
				dist.locales[key] = src[key];
			else
				dist[key] = src[key];
		}
		
		abilities[i] = dist;
	}
}

function getDefaultAbilityObj(abs)
{
	var obj = [];
	
	for(var i = 0; i < abs.length; i++)
	{
		var o = {lvl: abs[i].defaultLvl ? abs[i].defaultLvl : 0};
		obj.push(o);
		
		if(abs[i].levelUpFields)
		{
			o.attributes = [];
			for(var k = 0; k < abs[i].levelUpFields.length; k++)
				o.attributes.push(0);
		}
	}
	
	return obj;
};

function getTutorialAbilityObj(abs)
{
	var obj = [];

	for(var i = 0; i < abs.length; i++)
	{
		var o = {lvl: abs[i].tutorialLvl ? abs[i].tutorialLvl : 0};
		obj.push(o);

		if(abs[i].levelUpFields)
		{
			o.attributes = [];
			for(var k = 0; k < abs[i].levelUpFields.length; k++)
				o.attributes.push(0);
		}
	}

	return obj;
};

function getDefaultZombieAbilityObj(abs, config)
{
	var obj = [];

	for (var c of config) {

		var o = {
			lvl: c.humanOnly ? 0 : abs[c.id].lvl,
			attributes: null
		};

		if (c.levelUpFields) {
			o.attributes = (new Array(c.levelUpFields.length)).fill(0);
		}

		obj.push(o);
	}

	return obj;
};

// killing streaks
var killStreaks = {

	"5": {
		msg_start_self: "game.msg.streak5.self",
		msg_start_others: "game.msg.streak5.others",
		msg_ended_self: "game.msg.streak5.ended_self",
		msg_ended_others: "game.msg.streak5.ended_others",
		sound: "KILLING_SPREE",
		xp: 15
	},

	"10": {
		msg_start_self: "game.msg.streak10.self",
		msg_start_others: "game.msg.streak10.others",
		msg_ended_self: "game.msg.streak10.ended_self",
		msg_ended_others: "game.msg.streak10.ended_others",
		sound: "RAMPAGE",
		xp: 30
	},

	"15": {
		msg_start_self: "game.msg.streak15.self",
		msg_start_others: "game.msg.streak15.others",
		msg_ended_self: "game.msg.streak15.ended_self",
		msg_ended_others: "game.msg.streak15.ended_others",
		sound: "DOMINATING",
		xp: 50
	},

	"20": {
		msg_start_self: "game.msg.streak20.self",
		msg_start_others: "game.msg.streak20.others",
		msg_ended_self: "game.msg.streak20.ended_self",
		msg_ended_others: "game.msg.streak20.ended_others",
		sound: "UNSTOPPABLE",
		xp: 75
	},

	"25": {
		msg_start_self: "game.msg.streak25.self",
		msg_start_others: "game.msg.streak25.others",
		msg_ended_self: "game.msg.streak25.ended_self",
		msg_ended_others: "game.msg.streak25.ended_others",
		sound: "GODLIKE",
		xp: 120
	}

};

var multiKills = {

	"2": {
		name: "Double Kill",
		sound: "DOUBLE_KILL",
		xp: 12
	},

	"3": {
		name: "Multi Kill",
		sound: "MULTI_KILL",
		xp: 18
	},

	"4": {
		name: "Ultra Kill",
		sound: "ULTRA_KILL",
		xp: 25
	},

	"5": {
		name: "MONSTER Kill",
		sound: "MONSTER_KILL",
		xp: 35
	}

};

var emotes = [

	{
		name: "wink",
		command: "/wink",
		imgString: "emotesBlink"
	},

	{
		name: "cry",
		command: "/cry",
		imgString: "emotesCry"
	},

	{
		name: "angry",
		command: "/angry",
		imgString: "emotesDevil"
	},

	{
		name: "love",
		command: "/love",
		imgString: "emotesHeart"
	},

	{
		name: "dislike",
		command: "/dislike",
		imgString: "emotesDislike"
	},

	{
		name: "happy",
		command: "/happy",
		imgString: "emotesSmile"
	},

	{
		name: "evil",
		command: "/evil",
		imgString: "emotesGrin"
	},

	{
		name: "suprise",
		command: "/suprise",
		imgString: "emotesO"
	},

	{
		name: "like",
		command: "/like",
		imgString: "emotesLike"
	},

	{
		name: "smirk",
		command: "/smirk",
		imgString: "emotesSmirk"
	},

	{
		name: "pokerface",
		command: "/pokerface",
		imgString: "emotesPokerface"
	},

	{
		name: "hold",
		command: "/hold",
		imgString: "emotesHold"
	},

	{
		name: "go",
		command: "/go",
		imgString: "emotesGo"
	},

	{
		name: "fire",
		command: "/fire",
		imgString: "emotesFire"
	},

	{
		name: "back",
		command: "/back",
		imgString: "emotesBack"
	},

	{
		name: "safe",
		command: "/safe",
		imgString: "emotesOK"
	},

	{
		name: "come",
		command: "/come",
		imgString: "emotesFist"
	},

	{
		name: "giveup",
		command: "/giveup",
		imgString: "emotesFlagWhite"
	},

	{
		name: "flag",
		command: "/flag",
		imgString: "emotesFlagRed"
	},

	{
		name: "cry",
		command: "cry",
		imgString: "emotesCry"
	},

	{
		name: "sniper",
		command: "/sniper",
		imgString: "emotesSniper"
	},

	{
		name: "infected",
		command: "/infected",
		imgString: "emotesInfected"
	},

	{
		name: "fist",
		command: "/fist",
		imgString: "emotesPunch"
	},

	{
		name: "victory",
		command: "/victory",
		imgString: "emotesPeace"
	},

	{
		name: "cool",
		command: "/cool",
		imgString: "emotesCool"
	},

	{
		name: "hype",
		command: "/hype",
		imgString: "emotesHype"
	},

	{
		name: "gg",
		command: "/gg",
		imgString: "emotesGG"
	},

	{
		name: "troll",
		command: "/troll",
		imgString: "emotesTroll"
	},

	{
		name: "facepalm",
		command: "/facepalm",
		imgString: "emotesFacepalm"
	},

	{
		name: "comeon",
		command: "/comeon",
		imgString: "emotesElvis"
	}

];

var treasureChests = [
	
	{
		id: 0,
		waitTime: 1800,
		gold: [30, 42]
	},
	
	{
		id: 1,
		waitTime: 7200,
		gold: [120, 168]
	},
	
	{
		id: 2,
		waitTime: 28800,
		gold: [480, 672]
	},
	
	{
		id: 3,
		waitTime: 86400,
		gold: [1920, 2688]
	}
	
];

var NAME_COLOR = {

	50: {
		name: 'bot',
		code: '#d2d2d2',
	},

	100: {
		name: 'guest',
		code: '#fff',
	},

	200: {
		name: 'player',
		code: 'rgb(255, 255, 120)',
	},

	210: {
		name: 'veteran',
		code: '#ea9',
	},

	400: {
		name: 'steam',
		code: '#a4d007',
		isReward: true,
	},

	500: {
		name: 'community',
		code: '#cae',
		isReward: true,
	},

	800: {
		name: 'modder',
		code: '#e6a',
		isReward: true,
	},

	1000: {
		name: 'admin',
		code: '#6de',
	},
};

var hatQualityPlus = {
	Common: 0.4,
	Rare: 0.4,
	Epic: 0.8,
	Legendary: 1
};

var hatQualityColor = {
	"Rare": "#97b1ff",
	"Epic": "#d98bff",
	"Legendary": "#fd963a"
};

// skins
var hats = [

	{
		name: "Basic skin",
		offset: 0,
		legs: 0,
		noItem: true,
		isFree: true,
		quality: 'Common'
	},

	{
		name: "Hat",
		offset: 1,
		legs: 0,
		quality: 'Common'
	},

	{
		name: "Sun Glasses",
		offset: 3,
		legs: 0,
		gold: 100,
		quality: 'Common'
	},

	{
		name: "Soldier",
		offset: 5,
		legs: 1,
		quality: 'Common'
	},

	{
		name: "Soldier 2",
		offset: 9,
		legs: 1,
		lvl: 3,
		quality: 'Common'
	},

	{
		name: "Space",
		offset: 6,
		legs: 3,
		lvl: 8,
		quality: 'Common'
	},

	{
		name: "Skeleton",
		offset: 4,
		legs: 2,
		quality: 'Rare'
	},

	{
		name: "Grampa",
		offset: 7,
		legs: 0,
		quality: 'Common'
	},

	{
		name: "Mage",
		offset: 8,
		legs: 0,
		quality: 'Rare'
	},

	{
		name: "Zombie",
		offset: 10,
		legs: 0,
		gold: 500,
		quality: 'Rare'
	},

	{
		name: "Soldier 3",
		offset: 13,
		legs: 5,
		quality: 'Common'
	},

	{
		name: "Lundmar",
		offset: 14,
		legs: 0,
		quality: 'Rare'
	},

	{
		name: "Pleasure",
		offset: 16,
		legs: 6,
		quality: 'Rare'
	},

	{
		name: "Rabbit",
		offset: 12,
		legs: 8,
		quality: 'Epic'
	},

	{
		name: "Eye",
		offset: 18,
		legs: 7,
		lvl: 17,
		quality: 'Rare'
	},

	{
		name: "Gentleman",
		offset: 2,
		legs: 0,
		quality: 'Epic'
	},

	{
		name: "Dark",
		offset: 17,
		legs: 9,
		quality: 'Rare',
        gems: 2
	},

	{
		name: "Police",
		offset: 25,
		legs: 11,
		gold: 1500,
		hatOnly: true,
		quality: 'Epic'
	},

	{
		name: "Cowboy",
		offset: 27,
		legs: 12,
		lvl: 25,
		hatOnly: true,
		quality: 'Common'
	},

	{
		name: "Cowboy 2",
		offset: 29,
		legs: 13,
		hatOnly: true,
		quality: 'Common'
	},

	{
		name: "Snowcoat",
		offset: 30,
		legs: 14,
		hatOnly: true,
		quality: 'Common'
	},

	{
		name: "Snowcoat 2",
		offset: 31,
		legs: 15,
		gold: 1650,
		hatOnly: true,
		quality: 'Common'
	},

	{
		name: "Santa",
		offset: 32,
		legs: 16,
		lvl: 32,
		hatOnly: true,
		quality: 'Epic'
	},

	{
		name: "Girl 2",
		offset: 33,
		legs: 8,
		quality: 'Common'
	},

	{
		name: "Princess",
		offset: 34,
		legs: 17,
		quality: 'Epic',
        gems: 3
	},

	{
		name: "Girl 3",
		offset: 39,
		legs: 8,
		isFree: true,
		quality: 'Common'
	},

	{
		name: "Painter",
		offset: 19,
		legs: 9,
		lvl: 38,
		quality: 'Rare'
	},

	{
		name: "Rambo",
		offset: 40,
		legs: 9,
		quality: 'Epic'
	},

	{
		name: "Grim Reaper",
		offset: 41,
		legs: 18,
		lvl: 45,
		quality: 'Epic'
	},

	{
		name: "Phonecats",
		offset: 42,
		legs: 19,
		quality: 'Legendary'
	},

	{
		name: "Godenot",
		offset: 43,
		legs: 20,
		hatOnly: true,
		quality: 'Legendary'
	},

	{
		name: "Elf",
		offset: 44,
		legs: 14,
		hatOnly: true,
		quality: 'Epic'
	},

	{
		name: "Cat",
		offset: 45,
		legs: 21,
		quality: 'Epic'
	},

	{
		name: "Wolf",
		offset: 46,
		legs: 23,
		quality: 'Epic',
        gems: 3
	},

	{
		name: "Heaven Bul",
		offset: 47,
		legs: 9,
		quality: 'Epic'
	},

	{
		name: "iRaphael",
		offset: 48,
		legs: 7,
		lvl: 55,
		quality: 'Epic'
	},

	{
		name: "Dido D",
		offset: 49,
		legs: 22,
		quality: 'Rare'
	},

	{
		name: "Wu Kong",
		offset: 50,
		legs: 24,
		quality: 'Common'
	},

	{
		name: "Terror Bionic",
		offset: 51,
		legs: 25,
		quality: 'Rare',
        gems: 2
	},
	
	{
		name: "RobleisUTU",
		offset: 53,
		legs: 27,
		quality: 'Legendary'
	},

	{
		name: "Hippie",
		offset: 54,
		legs: 28,
		lvl: 60,
		quality: 'Rare'
	},

	{
		name: "cazum8",
		offset: 55,
		legs: 29,
		quality: 'Legendary'
	},

	{
		name: "Pozzitifon",
		offset: 56,
		legs: 30,
		quality: 'Rare'
	},
	
	{
		name: "EeOneGuy",
		offset: 58,
		legs: 32,
		lvl: 65,
		quality: 'Rare'
	},

	{
		name: "Girl 4",
		offset: 35,
		hatOnly: true,
		legs: 9,
		quality: 'Epic'
	},

	{
		name: "USA",
		offset: 64,
		hatOnly: false,
		legs: 34,
		quality: 'Common',
		isCountry: true
	},

	{
		name: "China",
		offset: 65,
		hatOnly: false,
		legs: 34,
		quality: 'Common',
		isCountry: true
	},

	{
		name: "Switzerland",
		offset: 66,
		hatOnly: false,
		legs: 34,
		quality: 'Common',
		isCountry: true
	},

	{
		name: "Vietnam",
		offset: 67,
		hatOnly: false,
		legs: 34,
		Intelligence: 2,
		Agility: 1,
		quality: 'Common',
		isCountry: true
	},

	{
		name: "Turkey",
		offset: 68,
		hatOnly: false,
		legs: 34,
		quality: 'Common',
		isCountry: true
	},

	{
		name: "Taiwan",
		offset: 69,
		hatOnly: false,
		legs: 34,
		quality: 'Common',
		isCountry: true
	},

	{
		name: "Denmark",
		offset: 70,
		hatOnly: false,
		legs: 34,
		quality: 'Common',
		isCountry: true
	},

	{
		name: "Indonesia",
		offset: 71,
		hatOnly: false,
		legs: 34,
		quality: 'Common',
		isCountry: true
	},

	{
		name: "Singapore",
		offset: 72,
		hatOnly: false,
		legs: 34,
		quality: 'Common',
		isCountry: true
	},

	{
		name: "Poland",
		offset: 73,
		hatOnly: false,
		legs: 34,
		quality: 'Common',
		isCountry: true
	},

	{
		name: "Canada",
		offset: 74,
		hatOnly: false,
		legs: 34,
		quality: 'Common',
		isCountry: true
	},

	{
		name: "Russia",
		offset: 75,
		hatOnly: false,
		legs: 34,
		quality: 'Common',
		isCountry: true
	},

	{
		name: "Philippines",
		offset: 76,
		hatOnly: false,
		legs: 34,
		quality: 'Common',
		isCountry: true
	},

	{
		name: "Ukraine",
		offset: 77,
		hatOnly: false,
		legs: 34,
		quality: 'Common',
		isCountry: true
	},

	{
		name: "Germany",
		offset: 78,
		hatOnly: false,
		legs: 34,
		quality: 'Common',
		isCountry: true
	},

	{
		name: "France",
		offset: 79,
		hatOnly: false,
		legs: 34,
		quality: 'Common',
		isCountry: true
	},

	{
		name: "UK",
		offset: 80,
		hatOnly: false,
		legs: 34,
		quality: 'Common',
		isCountry: true
	},

	{
		name: "Argentina",
		offset: 81,
		hatOnly: false,
		legs: 34,
		quality: 'Common',
		isCountry: true
	},

	{
		name: "Brazil",
		offset: 82,
		hatOnly: false,
		legs: 34,
		quality: 'Common',
		isCountry: true
	},

	{
		name: "Headphones",
		offset: 83,
		hatOnly: false,
		legs: 14,
		lvl: 71,
		quality: 'Rare'
	},

	{
		name: "Foxy",
		offset: 84,
		hatOnly: false,
		legs: 35,
		quality: 'Epic'
	},

	{
		name: "Blue Helmet",
		offset: 85,
		hatOnly: false,
		legs: 12,
		quality: 'Epic'
	},

	{
		name: "Lion",
		offset: 86,
		hatOnly: false,
		legs: 35,
		lvl: 85,
		quality: 'Legendary'
	},

	{
		name: "Dark5",
		offset: 87,
		hatOnly: false,
		legs: 1,
		quality: 'Rare'
	},

	{
		name: "Inuit",
		offset: 88,
		hatOnly: false,
		legs: 12,
		quality: 'Common',
        gems: 1
	},

	{
		name: "Bubblegum",
		offset: 89,
		hatOnly: false,
		legs: 6,
		quality: 'Epic'
	},

	{
		name: "Katydid",
		offset: 93,
		hatOnly: false,
		legs: 36,
		by: "Katydid",
		quality: 'Rare'
	},

	{
		name: "Witch",
		offset: 97,
		hatOnly: false,
		legs: 37,
		by: "Katydid",
		quality: 'Rare'
	},

	{
		name: "Hedgehog",
		offset: 98,
		hatOnly: false,
		legs: 7,
		by: "Bubbles",
		quality: 'Common'
	},

	{
		name: "Gem",
		offset: 99,
		hatOnly: false,
		legs: 38,
		lvl: 95,
		by: "Bubbles",
		quality: 'Epic',
        gems: 3
	},

	{
		name: "Sungod",
		offset: 100,
		hatOnly: false,
		legs: 39,
		by: "Bubbles",
		quality: 'Epic'
	},

	{
		name: "Tempest",
		offset: 101,
		hatOnly: false,
		legs: 40,
		by: "Demoness",
        quality: 'Epic'
	},

	{
		name: "Miku",
		offset: 102,
		hatOnly: false,
		legs: 41,
		by: "Iris Isotheis",
        quality: 'Epic'
	},

	{
		name: "Robot",
		offset: 103,
		hatOnly: false,
		legs: 1,
		lvl: 105,
        quality: 'Rare',
		by: "FLUFFY"
	},

	{
		name: "Demoness",
		offset: 104,
		hatOnly: false,
		legs: 6,
        quality: 'Rare',
		by: "Demoness"
	},

	{
		name: "Demon",
		offset: 105,
		hatOnly: false,
		legs: 42,
        quality: 'Rare',
		by: "Demoness"
	},

	{
		name: "Doggo",
		offset: 106,
		hatOnly: false,
		legs: 43,
        quality: 'Rare',
		by: "Katydid"
	},

	{
		name: "Mohawk",
		offset: 107,
		hatOnly: false,
		legs: 44,
        quality: 'Common',
		by: "Katydid"
	},

	{
		name: "Dragon",
		offset: 110,
		hatOnly: false,
		legs: 45,
		lvl: 115,
        Intelligence: 2,
        Strength: 1,
        quality: 'Epic',
		by: "Katydid"
	},

	{
		name: "Bob",
		offset: 112,
		hatOnly: false,
		legs: 7,
        quality: 'Common',
        by: "Roscoe"
	},

	{
		name: "Dwarf",
		offset: 113,
		hatOnly: false,
		legs: 7,
        quality: 'Epic',
        by: "Katydid",
        gems: 3
	},

	{
		name: "Sad Pepo",
		offset: 114,
		hatOnly: false,
		legs: 14,
        quality: 'Rare',
        by: "FabioJRTV"
	},

	{
		name: "Hunter",
		offset: 115,
		hatOnly: false,
		legs: 9,
		lvl: 125,
        quality: 'Rare',
        by: "SabertoothFang"
	},

	{
		name: "Egyptian",
		offset: 116,
		hatOnly: false,
		legs: 46,
        quality: 'Epic',
        by: "Coffee"
	},

	{
		name: "Cyber Ninja",
		offset: 117,
		hatOnly: false,
		legs: 47,
        quality: 'Rare',
        by: "DIIV"
	},

	{
		name: "Cyborg",
		offset: 118,
		hatOnly: false,
		legs: 0,
        quality: 'Rare',
        by: "TheAdam"
	},

	{
		name: "Gaping Maw",
		offset: 119,
		hatOnly: false,
		legs: 21,
        quality: 'Rare',
        by: "CoolKing"
	},

	{
		name: "Rainbow",
		offset: 120,
		hatOnly: false,
		legs: 47,
        quality: 'Legendary',
        by: "FabioJRTV"
	},

	{
		name: "Penguin",
		offset: 121,
		hatOnly: false,
		legs: 9,
		lvl: 101,
        quality: 'Rare',
        by: "Demoness",
        gems: 3
	},

	{
		name: "Freia",
		offset: 123,
		hatOnly: false,
		legs: 48,
        quality: 'Epic',
        by: "Coffee",
        gems: 3
	},

	{
		name: "King",
		offset: 124,
		hatOnly: false,
		legs: 50,
        quality: 'Legendary',
        by: "Demoness"
	},

	{
		name: "LAPA",
		offset: 125,
		hatOnly: false,
		legs: 0,
        quality: 'Epic',
        by: "Demoness"
	},

	{
		name: "Leprechaun",
		offset: 126,
		hatOnly: false,
		legs: 14,
        quality: 'Rare',
        by: "Demoness"
	},

	{
		name: "Gramma",
		offset: 127,
		hatOnly: false,
		legs: 8,
        quality: 'Epic',
        by: "Katydid"
	},

	{
		name: "Queen",
		offset: 128,
		hatOnly: false,
		legs: 49,
		lvl: 77,
        quality: 'Rare',
        by: "Demoness"
	},

	{
		name: "Astronaut",
		offset: 109,
		hatOnly: false,
		legs: 7,
        quality: 'Common',
        by: "Katydid"
	},

	{
		name: "Hannah",
		offset: 129,
		hatOnly: false,
		legs: 50,
        quality: 'Rare',
        by: "Demoness",
        gems: 2
	},

	{
		name: "Wendigo",
		offset: 130,
		hatOnly: false,
		legs: 21,
        quality: 'Rare',
        by: "D21"
	},

	{
		name: "Dark Crusader",
		offset: 131,
		hatOnly: false,
		legs: 47,
        quality: 'Rare',
        by: "Carnage"
	},

	{
		name: "Sunbeam ",
		offset: 132,
		hatOnly: false,
		legs: 7,
        quality: 'Epic',
        by: "D21"
	},
	
	{
		name: "Kitten Luly",
		offset: 134,
		hatOnly: false,
		legs: 6,
        quality: 'Rare',
        by: "Yuuki"
	},
	
	{
		name: "Goldfish",
		offset: 135,
		hatOnly: false,
		legs: 51,
        quality: 'Rare',
        by: "GiraffidaeW",
        gems: 2
	},
	
	{
		name: "Axolotl",
		offset: 137,
		hatOnly: false,
		legs: 53,
        quality: 'Epic',
        by: "GiraffidaeW"
	},
	
	{
		name: "Pig",
		offset: 138,
		hatOnly: false,
		legs: 53,
        quality: 'Epic',
        by: "GiraffidaeW"
	},
	
	{
		name: "Blind Master",
		offset: 139,
		hatOnly: false,
		legs: 0,
        quality: 'Rare',
        by: "Carnage"
	},
	
	{
		name: "Knight",
		offset: 142,
		hatOnly: false,
		legs: 55,
        quality: 'Legendary',
        by: "Katydid"
	},
	
	{
		name: "Vampire",
		offset: 143,
		hatOnly: false,
		legs: 9,
        quality: 'Rare',
        by: "CoolKing"
	},
	
	{
		name: "Slug",
		offset: 144,
		hatOnly: false,
		legs: 54,
        quality: 'Rare',
        by: "CoolKing"
	}
	
];

var goldCostBySkinQuality = {
	
	Common: 400,
	Rare: 2000,
	Epic: 6500,
	Legendary: 15000
	
};

var hatProto = {
	get isHat() {
		return true;
	},
	get name() {
		return F_ && F_("hats." + this.id + ".name") || this.locales.name;
	}
};

for(var i = 0; i < hats.length; i++)
{
	var src = hats[i];
	src.id = i;

	if (typeof exports !== 'undefined') {
		src.isHat = true;
	} else {
		var dist = Object.create(hatProto);
		dist.locales = {};
		for (var key in src) {
			if (['name'].indexOf(key) >= 0) {
				dist.locales[key] = src[key];
			} else {
				dist[key] = src[key];
			}
		}

		hats[i] = dist;
	}
}

var hatsByQuality = {
	Common: [],
	Rare: [],
	Epic: [],
	Legendary: []
};
for(var i = 0; i < hats.length; i++)
	hatsByQuality[hats[i].quality].push(hats[i]);

var tileTypes = [

	{
		"name": "Metal_Ground_1",
		"img": {"x": 0, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Crate",
		"img": {"x": 166, "y": 100, "w": 18, "h": 32},
		"pathing": 5,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall Top",
		"img": {"x": 0, "y": 44, "w": 16, "h": 53},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true,
		"isBorder": true
	},

	{
		"name": "Wall Top 2",
		"img": {"x": 16, "y": 44, "w": 16, "h": 53},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true,
		"isBorder": true
	},

	{
		"name": "Wall Top 3",
		"img": {"x": 32, "y": 44, "w": 16, "h": 53},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true,
		"isBorder": true
	},

	{
		"name": "Wall Top 4",
		"img": {"x": 48, "y": 44, "w": 16, "h": 53},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true,
		"isBorder": true
	},

	{
		"name": "Wall Left",
		"img": {"x": 0, "y": 97, "w": 24, "h": 56},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true,
		"isBorder": true
	},

	{
		"name": "Wall Left 2 ",
		"img": {"x": 24, "y": 97, "w": 24, "h": 56},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true,
		"isBorder": true
	},

	{
		"name": "Wall Left 3",
		"img": {"x": 48, "y": 97, "w": 24, "h": 56},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true,
		"isBorder": true
	},

	{
		"name": "Wall Left 4",
		"img": {"x": 72, "y": 97, "w": 24, "h": 56},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true,
		"isBorder": true
	},

	{
		"name": "Wall Right",
		"img": {"x": 0, "y": 152, "w": 24, "h": 56},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true,
		"isBorder": true
	},

	{
		"name": "Wall Right 2 ",
		"img": {"x": 24, "y": 152, "w": 24, "h": 56},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true,
		"isBorder": true
	},

	{
		"name": "Wall Right 3",
		"img": {"x": 48, "y": 152, "w": 24, "h": 56},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true,
		"isBorder": true
	},

	{
		"name": "Wall Right 4",
		"img": {"x": 72, "y": 152, "w": 24, "h": 56},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true,
		"isBorder": true
	},

	{
		"name": "Wall Bottom",
		"img": {"x": 0, "y": 204, "w": 16, "h": 42},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true,
		"isBorder": true
	},

	{
		"name": "Wall Bottom 2",
		"img": {"x": 16, "y": 204, "w": 16, "h": 42},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true,
		"isBorder": true
	},

	{
		"name": "Wall Bottom 3",
		"img": {"x": 32, "y": 204, "w": 16, "h": 42},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true,
		"isBorder": true
	},

	{
		"name": "Wall Bottom 4",
		"img": {"x": 48, "y": 204, "w": 16, "h": 42},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true,
		"isBorder": true
	},

	{
		"name": "Metal_Ground_2",
		"img": {"x": 16, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Metal_Ground_3",
		"img": {"x": 32, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Metal_Ground_4",
		"img": {"x": 48, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Metal_Ground_5",
		"img": {"x": 64, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Metal_Ground_6",
		"img": {"x": 80, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Wall Corner 1",
		"img": {"x": 64, "y": 43, "w": 24, "h": 54},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Corner 2",
		"img": {"x": 88, "y": 43, "w": 24, "h": 54},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Corner 3",
		"img": {"x": 176, "y": 43, "w": 24, "h": 54},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Corner 4",
		"img": {"x": 196, "y": 43, "w": 24, "h": 54},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Bottom High 1",
		"img": {"x": 112, "y": 43, "w": 16, "h": 54},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Bottom High 2",
		"img": {"x": 128, "y": 43, "w": 16, "h": 54},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Bottom High 3",
		"img": {"x": 144, "y": 43, "w": 16, "h": 54},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Bottom High 4",
		"img": {"x": 160, "y": 43, "w": 16, "h": 54},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Crate Placeholder",
		"img": {"x": 166, "y": 100, "w": 18, "h": 32},
		"pathing": 5,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Metal_Ground_7",
		"img": {"x": 96, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Metal_Ground_8",
		"img": {"x": 112, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Metal_Ground_9",
		"img": {"x": 128, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Metal_Ground_10",
		"img": {"x": 144, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Metal_Ground_11",
		"img": {"x": 160, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Metal_Ground_12",
		"img": {"x": 176, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Metal_Ground_13",
		"img": {"x": 192, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Metal_Ground_14",
		"img": {"x": 208, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Metal_Ground_15",
		"img": {"x": 224, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Metal_Ground_16",
		"img": {"x": 240, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Black Block",
		"img": {"x": 220, "y": 43, "w": 16, "h": 54},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lower Top 1",
		"img": {"x": 0, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"collection": [0, 1, 2, 3]
	},

	{
		"name": "Wall Lower Top 2",
		"img": {"x": 16, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lower Top 3",
		"img": {"x": 32, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lower Top 4",
		"img": {"x": 48, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lower Right Bottom",
		"img": {"x": 64, "y": 270, "w": 24, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall Lower Left Bottom",
		"img": {"x": 88, "y": 270, "w": 24, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall Lower Top 1",
		"img": {"x": 112, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"collection": [0, 1, 2, 3]
	},

	{
		"name": "Wall Lower Top 2",
		"img": {"x": 128, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lower Top 3",
		"img": {"x": 144, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lower Top 4",
		"img": {"x": 160, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lower Left Top",
		"img": {"x": 176, "y": 270, "w": 24, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall Lower Right Top",
		"img": {"x": 196, "y": 270, "w": 24, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall Lower Black",
		"img": {"x": 220, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall Lower Left 1",
		"img": {"x": 0, "y": 325, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"collection": [0, 1, 2, 3]
	},

	{
		"name": "Wall Lower Left 2",
		"img": {"x": 24, "y": 325, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lower Left 3",
		"img": {"x": 48, "y": 325, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lower Left 4",
		"img": {"x": 72, "y": 325, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lower Right 1",
		"img": {"x": 0, "y": 380, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"collection": [0, 1, 2, 3]
	},

	{
		"name": "Wall Lower Right 2",
		"img": {"x": 24, "y": 380, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lower Right 3",
		"img": {"x": 48, "y": 380, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lower Right 4",
		"img": {"x": 72, "y": 380, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Spawning Point",
		"img": {"x": 0, "y": 16, "w": 1, "h": 1},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Waypoint",
		"img": {"x": 0, "y": 16, "w": 1, "h": 1},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Torch North",
		"img": {"x": 117, "y": 98, "w": 7, "h": 34},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": false,
		"isTorch": true,
		"hideOnMinimap": true
	},

	{
		"name": "Torch Left",
		"img": {"x": 129, "y": 99, "w": 18, "h": 36},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": false,
		"isTorch": true,
		"flameOffsetX": -0.25,
		"flameOffsetY": -0.2,
		"hideOnMinimap": true
	},

	{
		"name": "Torch Right",
		"img": {"x": 135, "y": 99, "w": 18, "h": 36},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": false,
		"isTorch": true,
		"flameOffsetX": 0.25,
		"flameOffsetY": -0.2,
		"hideOnMinimap": true
	},

	{
		"name": "Low Crate",
		"img": {"x": 184, "y": 100, "w": 18, "h": 32},
		"pathing": 6,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Spikes",
		"img": {"x": 204, "y": 108, "w": 16, "h": 24},
		"pathing": 8,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Grass 1",
		"img": {"x": 256, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"collection": [0, 1, 2, 3]
	},

	{
		"name": "Grass 2",
		"img": {"x": 272, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Grass 3",
		"img": {"x": 288, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Grass 4",
		"img": {"x": 304, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Grass 5",
		"img": {"x": 320, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Grass 6",
		"img": {"x": 336, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Grass 7",
		"img": {"x": 352, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Grass 8",
		"img": {"x": 368, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Grass 9",
		"img": {"x": 384, "y": 0, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Grass 10",
		"img": {"x": 352, "y": 16, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Grass 11",
		"img": {"x": 368, "y": 16, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Grass 12",
		"img": {"x": 384, "y": 16, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Plate 1",
		"img": {"x": 224, "y": 16, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Plate 2",
		"img": {"x": 240, "y": 16, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Plate 3",
		"img": {"x": 256, "y": 16, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Wall 1x1",
		"img": {"x": 243, "y": 54, "w": 24, "h": 43},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall 1x1 2",
		"img": {"x": 267, "y": 54, "w": 24, "h": 43},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Water 1",
		"img": {"x": 384, "y": 32, "w": 16, "h": 16},
		"img2": {"x": 368, "y": 32, "w": 16, "h": 16},
		"w": 1,
		"h": 1,
		"ground": true,
		"pathing": 9
	},

	{
		"name": "Water Border Top",
		"img": {"x": 352, "y": 32, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Border Bottom",
		"img": {"x": 304, "y": 16, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Water Border Right",
		"img": {"x": 320, "y": 16, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Water Border Left",
		"img": {"x": 336, "y": 16, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Border Top",
		"img": {"x": 336, "y": 32, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Border Right",
		"img": {"x": 320, "y": 32, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Border Left",
		"img": {"x": 304, "y": 32, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Tree 2x2",
		"img": {"x": 363, "y": 48, "w": 36, "h": 45},
		"pathing": 0,
		"w": 2,
		"h": 2,
		"ground": false,
		"isNotFull": true
	},

	{
		"name": "Tree 2x2 2",
		"img": {"x": 327, "y": 48, "w": 36, "h": 45},
		"pathing": 0,
		"w": 2,
		"h": 2,
		"ground": false,
		"isNotFull": true
	},

	{
		"name": "Grass B 1",
		"img": {"x": 160, "y": 16, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"collection": [0, 1, 2, 3]
	},

	{
		"name": "Grass B 2",
		"img": {"x": 176, "y": 16, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Grass B 3",
		"img": {"x": 192, "y": 16, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Grass B 4",
		"img": {"x": 208, "y": 16, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Grass C 1",
		"img": {"x": 336, "y": 96, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"collection": [0, 1, 2, 3]
	},

	{
		"name": "Grass C 2",
		"img": {"x": 352, "y": 96, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Grass C 3",
		"img": {"x": 368, "y": 96, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Grass C 4",
		"img": {"x": 384, "y": 96, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Grass D 1",
		"img": {"x": 336, "y": 112, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"collection": [0, 1, 2, 3]
	},

	{
		"name": "Grass D 2",
		"img": {"x": 352, "y": 112, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Grass D 3",
		"img": {"x": 368, "y": 112, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Grass D 4",
		"img": {"x": 384, "y": 112, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Dirt 1",
		"img": {"x": 336, "y": 128, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"collection": [0, 1, 2, 3]
	},

	{
		"name": "Dirt 2",
		"img": {"x": 352, "y": 128, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "GDirt 3",
		"img": {"x": 368, "y": 128, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Dirt 4",
		"img": {"x": 384, "y": 128, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Moving Walkway Right",
		"img": {"x": 136, "y": 16, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"shiftX": 0.15,
		"editable": ["shiftX"],
		"editableCaption": ["speed"]
	},

	{
		"name": "Moving Walkway Left",
		"img": {"x": 124, "y": 140, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"shiftX": -0.15,
		"editable": ["shiftX"],
		"editableCaption": ["speed"]
	},

	{
		"name": "Moving Walkway Up",
		"img": {"x": 116, "y": 164, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"shiftY": -0.15,
		"editable": ["shiftY"],
		"editableCaption": ["speed"]
	},

	{
		"name": "Moving Walkway Down",
		"img": {"x": 132, "y": 164, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"shiftY": 0.15,
		"editable": ["shiftY"],
		"editableCaption": ["speed"]
	},

	{
		"name": "Teleporter",
		"img": {"x": 186, "y": 134, "w": 24, "h": 22},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"channel": 1,
		"editable": ["channel"],
		"editableCaption": ["channel"],
		"ground": true,
		"isTeleporter": true,
		"isNotFull": true
	},

	{
		"name": "Wall Inner Top Left",
		"img": {"x": 240, "y": 271, "w": 16, "h": 43},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall Inner Top Right",
		"img": {"x": 260, "y": 271, "w": 16, "h": 43},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall Inner Bot Left",
		"img": {"x": 280, "y": 271, "w": 16, "h": 43},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall Inner Bot Right",
		"img": {"x": 300, "y": 271, "w": 16, "h": 43},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Pillar N 1",
		"img": {"x": 106, "y": 218, "w": 18, "h": 49},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Pillar N 2",
		"img": {"x": 130, "y": 222, "w": 20, "h": 41},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Pillar N 3",
		"img": {"x": 213, "y": 148, "w": 18, "h": 32},
		"pathing": 5,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Pillar N 4",
		"img": {"x": 267, "y": 151, "w": 18, "h": 30},
		"pathing": 5,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Trunk 1",
		"img": {"x": 262, "y": 110, "w": 20, "h": 38},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Trunk 2",
		"img": {"x": 282, "y": 109, "w": 20, "h": 38},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Stone N 1 2x2",
		"img": {"x": 154, "y": 182, "w": 32, "h": 32},
		"pathing": 10,
		"w": 2,
		"h": 2,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Stone N 2 2x2",
		"img": {"x": 267, "y": 182, "w": 32, "h": 32},
		"pathing": 10,
		"w": 2,
		"h": 2,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Stone N 1",
		"img": {"x": 188, "y": 180, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Stone N 2",
		"img": {"x": 208, "y": 180, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Stone N 3",
		"img": {"x": 228, "y": 180, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Stone N 4",
		"img": {"x": 248, "y": 180, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Stone N 5",
		"img": {"x": 188, "y": 198, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Stone N 6",
		"img": {"x": 208, "y": 198, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Stone N 7",
		"img": {"x": 228, "y": 198, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Stone N 8",
		"img": {"x": 248, "y": 198, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Stone N 9",
		"img": {"x": 301, "y": 180, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Stone N 10",
		"img": {"x": 301, "y": 198, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Carpet Red Top Left",
		"img": {"x": 154, "y": 217, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Carpet Red Top",
		"img": {"x": 170, "y": 217, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Carpet Red Top Right",
		"img": {"x": 186, "y": 217, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Carpet Red Mid Left",
		"img": {"x": 154, "y": 233, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Carpet Red Mid",
		"img": {"x": 170, "y": 233, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Carpet Red Mid Left",
		"img": {"x": 186, "y": 233, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Carpet Red Bot Left",
		"img": {"x": 154, "y": 249, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Carpet Red Bot Mid",
		"img": {"x": 170, "y": 249, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Carpet Red Bot Right",
		"img": {"x": 186, "y": 249, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Carpet Blue Top Left",
		"img": {"x": 204, "y": 217, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Carpet Blue Top",
		"img": {"x": 220, "y": 217, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Carpet Blue Top Right",
		"img": {"x": 236, "y": 217, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Carpet Blue Mid Left",
		"img": {"x": 204, "y": 233, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Carpet Blue Mid",
		"img": {"x": 220, "y": 233, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Carpet Blue Mid Left",
		"img": {"x": 236, "y": 233, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Carpet Blue Bot Left",
		"img": {"x": 204, "y": 249, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Carpet Blue Bot Left",
		"img": {"x": 220, "y": 249, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Carpet Blue Bot Left",
		"img": {"x": 236, "y": 249, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Ground Stones",
		"img": {"x": 234, "y": 146, "w": 22, "h": 15},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Ground Stones 2",
		"img": {"x": 234, "y": 164, "w": 16, "h": 11},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Plant",
		"img": {"x": 252, "y": 165, "w": 14, "h": 13},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Plant 2",
		"img": {"x": 133, "y": 197, "w": 17, "h": 17},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Plant 3",
		"img": {"x": 86, "y": 236, "w": 17, "h": 14},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Plant 4",
		"img": {"x": 86, "y": 253, "w": 17, "h": 14},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Ground Stones 3",
		"img": {"x": 325, "y": 240, "w": 29, "h": 14},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Ground Stones 4",
		"img": {"x": 356, "y": 241, "w": 14, "h": 13},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Ground Stones 5",
		"img": {"x": 372, "y": 241, "w": 18, "h": 13},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Ground Stones 6",
		"img": {"x": 392, "y": 242, "w": 18, "h": 12},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Ground Stones 7",
		"img": {"x": 413, "y": 243, "w": 22, "h": 10},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Ground Stones 8",
		"img": {"x": 437, "y": 247, "w": 8, "h": 6},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Ground Stones 9",
		"img": {"x": 448, "y": 245, "w": 13, "h": 7},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Flag",
		"img": {"x": 252, "y": 221, "w": 15, "h": 30},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Flag 2",
		"img": {"x": 269, "y": 221, "w": 15, "h": 30},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Flag 3",
		"img": {"x": 285, "y": 221, "w": 15, "h": 30},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Flag 4",
		"img": {"x": 301, "y": 221, "w": 15, "h": 30},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Ground Stones 10",
		"img": {"x": 287, "y": 149, "w": 19, "h": 12},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Candles",
		"img": {"x": 289, "y": 165, "w": 14, "h": 12},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Candles",
		"img": {"x": 306, "y": 168, "w": 4, "h": 8},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Books",
		"img": {"x": 320, "y": 96, "w": 13, "h": 18},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Books 2",
		"img": {"x": 319, "y": 116, "w": 16, "h": 12},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Table",
		"img": {"x": 354, "y": 144, "w": 16, "h": 23},
		"pathing": 8,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Table 2",
		"img": {"x": 372, "y": 144, "w": 31, "h": 23},
		"pathing": 8,
		"w": 2,
		"h": 1,
		"ground": false
	},

	{
		"name": "Table 3",
		"img": {"x": 336, "y": 167, "w": 33, "h": 23},
		"pathing": 8,
		"w": 2,
		"h": 1,
		"ground": false
	},

	{
		"name": "Table 4",
		"img": {"x": 371, "y": 167, "w": 33, "h": 23},
		"pathing": 8,
		"w": 2,
		"h": 1,
		"ground": false
	},

	{
		"name": "Tree 2x2 3",
		"img": {"x": 340, "y": 190, "w": 34, "h": 45},
		"pathing": 0,
		"w": 2,
		"h": 2,
		"ground": false,
		"isNotFull": true
	},

	{
		"name": "Tree 2x2 4",
		"img": {"x": 378, "y": 190, "w": 34, "h": 45},
		"pathing": 0,
		"w": 2,
		"h": 2,
		"ground": false,
		"isNotFull": true
	},

	{
		"name": "Lab Floor 1",
		"img": {"x": 320, "y": 261, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Lab Floor 2",
		"img": {"x": 320, "y": 277, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Lab Floor 3",
		"img": {"x": 320, "y": 293, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Lab Floor 2x2",
		"img": {"x": 336, "y": 261, "w": 32, "h": 32},
		"pathing": 10,
		"w": 2,
		"h": 2,
		"ground": true
	},

	{
		"name": "Lab Floor Top Left",
		"img": {"x": 368, "y": 261, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Lab Floor Top",
		"img": {"x": 384, "y": 261, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Lab Floor Top Right",
		"img": {"x": 400, "y": 261, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Lab Floor Mid Left",
		"img": {"x": 368, "y": 277, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Lab Floor Mid",
		"img": {"x": 384, "y": 277, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Lab Floor Mid Right",
		"img": {"x": 400, "y": 277, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Lab Floor Bot Left",
		"img": {"x": 368, "y": 293, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Lab Floor Bot",
		"img": {"x": 384, "y": 293, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Lab Floor Bot Right",
		"img": {"x": 400, "y": 293, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true
	},

	{
		"name": "Lab Grass 1",
		"img": {"x": 416, "y": 261, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"collection": [0, 1, 2, 3, 4 ,5]
	},

	{
		"name": "Lab Grass 2",
		"img": {"x": 432, "y": 261, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Lab Gras 3",
		"img": {"x": 448, "y": 261, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Lab Grass 4",
		"img": {"x": 416, "y": 277, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Lab Grass 5",
		"img": {"x": 432, "y": 277, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Lab Grass 6",
		"img": {"x": 448, "y": 277, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Lab Grass 7",
		"img": {"x": 416, "y": 293, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"collection": [0, 1, 2, 3]
	},

	{
		"name": "Lab Grass 8",
		"img": {"x": 432, "y": 293, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Lab Grass 9",
		"img": {"x": 448, "y": 293, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Lab Grass 10",
		"img": {"x": 464, "y": 293, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Ground Stones Lab",
		"img": {"x": 417, "y": 188, "w": 22, "h": 16},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Lab Lamp",
		"img": {"x": 435, "y": 206, "w": 20, "h": 29},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Lab Lamp 2",
		"img": {"x": 441, "y": 154, "w": 14, "h": 25},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Tires",
		"img": {"x": 418, "y": 207, "w": 16, "h": 28},
		"pathing": 5,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Lab Obstacle 1",
		"img": {"x": 401, "y": 311, "w": 24, "h": 43},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Lab Obstacle 2",
		"img": {"x": 425, "y": 311, "w": 24, "h": 43},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Lab Obstacle 3",
		"img": {"x": 449, "y": 311, "w": 24, "h": 43},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall Lab Top 0",
		"img": {"x": 484, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"collection": [0, 1, 2, 3, 4]
	},

	{
		"name": "Wall Lab Top 1",
		"img": {"x": 500, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lab Top 2",
		"img": {"x": 516, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lab Top 3",
		"img": {"x": 532, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lab Top 4",
		"img": {"x": 548, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lab Right Bottom",
		"img": {"x": 564, "y": 270, "w": 24, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall Lab Left Bottom",
		"img": {"x": 588, "y": 270, "w": 24, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall Lab Bot 1",
		"img": {"x": 612, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"collection": [0, 1]
	},

	{
		"name": "Wall Lab Bot 2",
		"img": {"x": 628, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lab Left Top",
		"img": {"x": 676, "y": 270, "w": 24, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall Lab Right Top",
		"img": {"x": 696, "y": 270, "w": 24, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall Lab Black",
		"img": {"x": 720, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall Lab Left 1",
		"img": {"x": 500, "y": 325, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"collection": [0, 1, 2, 3]
	},

	{
		"name": "Wall Lab Left 2",
		"img": {"x": 524, "y": 325, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lab Left 3",
		"img": {"x": 548, "y": 325, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lab Left 4",
		"img": {"x": 572, "y": 325, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lab Right 1",
		"img": {"x": 500, "y": 380, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"collection": [0, 1, 2, 3]
	},

	{
		"name": "Wall Lab Right 2",
		"img": {"x": 524, "y": 380, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lab Right 3",
		"img": {"x": 548, "y": 380, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Lab Right 4",
		"img": {"x": 572, "y": 380, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Spiderweb",
		"img": {"x": 482, "y": 39, "w": 44, "h": 33},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Halloween Lamps 1",
		"img": {"x": 530, "y": 42, "w": 34, "h": 27},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Hallowen Lamps 2",
		"img": {"x": 575, "y": 39, "w": 34, "h": 27},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Hallowen Crate 1",
		"img": {"x": 482, "y": 74, "w": 16, "h": 33},
		"w": 1,
		"h": 1,
		"pathing": 5
	},

	{
		"name": "Hallowen Crate 1",
		"img": {"x": 502, "y": 74, "w": 16, "h": 33},
		"w": 1,
		"h": 1,
		"pathing": 5
	},

	{
		"name": "Hallowen Crate 1",
		"img": {"x": 502, "y": 74, "w": 16, "h": 33},
		"w": 1,
		"h": 1,
		"pathing": 5,
		"nowShow": true
	},

	{
		"name": "Hallowen Heap",
		"img": {"x": 541, "y": 71, "w": 38, "h": 33},
		"w": 2,
		"h": 1,
		"pathing": 5
	},

	{
		"name": "Hallowen Trunk",
		"img": {"x": 581, "y": 78, "w": 18, "h": 34},
		"w": 1,
		"h": 1,
		"pathing": 0
	},

	{
		"name": "Coffin",
		"img": {"x": 605, "y": 70, "w": 21, "h": 42},
		"w": 1,
		"h": 1,
		"pathing": 0
	},

	{
		"name": "Halloween Grass 1",
		"img": {"x": 462, "y": 116, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"collection": [0, 1, 2, 3, 4, 5, 6, 7, 8]
	},

	{
		"name": "Halloween Grass 2",
		"img": {"x": 478, "y": 116, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Halloween Grass 3",
		"img": {"x": 494, "y": 116, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Halloween Grass 4",
		"img": {"x": 462, "y": 132, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Halloween Grass 5",
		"img": {"x": 478, "y": 132, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Halloween Grass 6",
		"img": {"x": 494, "y": 132, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Halloween Grass 7",
		"img": {"x": 462, "y": 148, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Halloween Grass 8",
		"img": {"x": 478, "y": 148, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Halloween Grass 9",
		"img": {"x": 494, "y": 148, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Halloween Grass 10",
		"img": {"x": 510, "y": 116, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"collection": [0, 1, 2, 3]
	},

	{
		"name": "Halloween Grass 11",
		"img": {"x": 526, "y": 116, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Halloween Grass 12",
		"img": {"x": 542, "y": 116, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Halloween Grass 13",
		"img": {"x": 558, "y": 116, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Halloween Water",
		"img": {"x": 462, "y": 164, "w": 16, "h": 16},
		"img2": {"x": 478, "y": 164, "w": 16, "h": 16},
		"w": 1,
		"h": 1,
		"ground": true,
		"pathing": 9
	},

	{
		"name": "Halloween Water Border Top",
		"img": {"x": 558, "y": 148, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Halloween Border Bottom",
		"img": {"x": 510, "y": 132, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Halloween Water Border Right",
		"img": {"x": 526, "y": 132, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Halloween Water Border Left",
		"img": {"x": 542, "y": 132, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Halloween Border Top",
		"img": {"x": 542, "y": 148, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Halloween Border Right",
		"img": {"x": 526, "y": 148, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Halloween Border Left",
		"img": {"x": 510, "y": 148, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Dark Dirt 1",
		"img": {"x": 462, "y": 180, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"collection": [0, 1, 2, 3]
	},

	{
		"name": "Dark Dirt 2",
		"img": {"x": 478, "y": 180, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Dark Dirt 3",
		"img": {"x": 494, "y": 180, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Dark Dirt 4",
		"img": {"x": 510, "y": 180, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Invisible Blocker Low (only movement)",
		"img": {"x": 0, "y": 16, "w": 1, "h": 1},
		"pathing": 8,
		"w": 1,
		"h": 1
	},

	{
		"name": "Invisible Blocker Medium (projectiles)",
		"img": {"x": 0, "y": 16, "w": 1, "h": 1},
		"pathing": 5,
		"w": 1,
		"h": 1
	},

	{
		"name": "Invisible Blocker High (everything)",
		"img": {"x": 0, "y": 16, "w": 1, "h": 1},
		"pathing": 0,
		"w": 1,
		"h": 1
	},

	{
		"name": "Wall Winter Top 0",
		"img": {"x": 834, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"collection": [0, 1]
	},

	{
		"name": "Wall Winter Top 1",
		"img": {"x": 850, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Winter Right Bottom",
		"img": {"x": 914, "y": 270, "w": 24, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall Winter Left Bottom",
		"img": {"x": 938, "y": 270, "w": 24, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall Winter Bot 1",
		"img": {"x": 962, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"collection": [0, 1]
	},

	{
		"name": "Wall Winter Bot 2",
		"img": {"x": 978, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Winter Left Top",
		"img": {"x": 1026, "y": 270, "w": 24, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall Winter Right Top",
		"img": {"x": 1046, "y": 270, "w": 24, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall Winter Black",
		"img": {"x": 1070, "y": 270, "w": 16, "h": 44},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false
	},

	{
		"name": "Wall Winter Left 1",
		"img": {"x": 850, "y": 325, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"collection": [0, 1, 2, 3]
	},

	{
		"name": "Wall Winter Left 2",
		"img": {"x": 874, "y": 325, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Winter Left 3",
		"img": {"x": 898, "y": 325, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Winter Left 4",
		"img": {"x": 922, "y": 325, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Winter Right 1",
		"img": {"x": 850, "y": 380, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"collection": [0, 1, 2, 3]
	},

	{
		"name": "Wall Winter Right 2",
		"img": {"x": 874, "y": 380, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Winter Right 3",
		"img": {"x": 898, "y": 380, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Wall Winter Right 4",
		"img": {"x": 922, "y": 380, "w": 24, "h": 45},
		"pathing": 0,
		"w": 1,
		"h": 1,
		"ground": false,
		"noShow": true
	},

	{
		"name": "Christmas Lights 1",
		"img": {"x": 703, "y": 0, "w": 33, "h": 45},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Christmas Lights 2",
		"img": {"x": 744, "y": 0, "w": 33, "h": 45},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Christmas Lights 3",
		"img": {"x": 783, "y": 0, "w": 33, "h": 32},
		"pathing": 10,
		"noGrid": true,
		"isNotFull": true
	},

	{
		"name": "Ice 1",
		"img": {"x": 635, "y": 63, "w": 16, "h": 16},
		"pathing": 10,
		"ground": true,
		"w": 1,
		"h": 1,
		"isNotFull": false
	},

	{
		"name": "Spikes 2",
		"img": {"x": 651, "y": 61, "w": 16, "h": 23},
		"pathing": 8,
		"ground": false,
		"w": 1,
		"h": 1,
		"isNotFull": false
	},

	{
		"name": "Spikes 3",
		"img": {"x": 667, "y": 61, "w": 16, "h": 23},
		"pathing": 8,
		"ground": false,
		"w": 1,
		"h": 1,
		"isNotFull": false
	},

	{
		"name": "Tree Winter",
		"img": {"x": 688, "y": 52, "w": 19, "h": 39},
		"pathing": 0,
		"ground": false,
		"w": 1,
		"h": 1
	},

	{
		"name": "Winter Block 1",
		"img": {"x": 711, "y": 52, "w": 18, "h": 40},
		"pathing": 0,
		"ground": false,
		"w": 1,
		"h": 1
	},

	{
		"name": "Winter Block 2",
		"img": {"x": 736, "y": 53, "w": 18, "h": 40},
		"pathing": 0,
		"ground": false,
		"w": 1,
		"h": 1
	},

	{
		"name": "Gift",
		"img": {"x": 757, "y": 55, "w": 18, "h": 33},
		"pathing": 5,
		"ground": false,
		"w": 1,
		"h": 1
	},

	{
		"name": "Winter Crate 1",
		"img": {"x": 780, "y": 57, "w": 20, "h": 35},
		"pathing": 5,
		"ground": false,
		"w": 1,
		"h": 1
	},

	{
		"name": "Winter Crate 2",
		"img": {"x": 801, "y": 57, "w": 20, "h": 36},
		"pathing": 5,
		"ground": false,
		"w": 1,
		"h": 1,
		"noShow": true
	},

	{
		"name": "Winter Crate 1",
		"img": {"x": 780, "y": 57, "w": 20, "h": 35},
		"pathing": 5,
		"ground": false,
		"w": 1,
		"h": 1,
		"noShow": true
	},

	{
		"name": "Winter Crate 2",
		"img": {"x": 801, "y": 57, "w": 20, "h": 36},
		"pathing": 5,
		"ground": false,
		"w": 1,
		"h": 1
	},

	{
		"name": "Winter Block 3",
		"img": {"x": 631, "y": 129, "w": 23, "h": 55},
		"pathing": 0,
		"ground": false,
		"w": 1,
		"h": 1
	},

	{
		"name": "Winter Block 4",
		"img": {"x": 662, "y": 134, "w": 18, "h": 50},
		"pathing": 0,
		"ground": false,
		"w": 1,
		"h": 1
	},

	{
		"name": "Winter Block 5",
		"img": {"x": 683, "y": 141, "w": 24, "h": 43},
		"pathing": 0,
		"ground": false,
		"w": 1,
		"h": 1
	},

	{
		"name": "Winter Block 6",
		"img": {"x": 711, "y": 138, "w": 24, "h": 45},
		"pathing": 0,
		"ground": false,
		"w": 1,
		"h": 1
	},

	{
		"name": "Winter Block 7",
		"img": {"x": 739, "y": 139, "w": 24, "h": 45},
		"pathing": 0,
		"ground": false,
		"w": 1,
		"h": 1
	},

	{
		"name": "Winter Block 8",
		"img": {"x": 768, "y": 149, "w": 24, "h": 36},
		"pathing": 5,
		"ground": false,
		"w": 1,
		"h": 1
	},

	{
		"name": "Winter Statue",
		"img": {"x": 677, "y": 93, "w": 16, "h": 36},
		"pathing": 5,
		"ground": false,
		"w": 1,
		"h": 1
	},

	{
		"name": "Snow Stain 1",
		"img": {"x": 658, "y": 104, "w": 15, "h": 10},
		"pathing": 10,
		"ground": true,
		"noGrid": true,
	},

	{
		"name": "Snow Stain 2",
		"img": {"x": 635, "y": 81, "w": 16, "h": 16},
		"pathing": 10,
		"ground": true,
		"noGrid": true,
	},

	{
		"name": "Snow Stones",
		"img": {"x": 632, "y": 101, "w": 24, "h": 13},
		"pathing": 10,
		"ground": true,
		"noGrid": true,
	},

	{
		"name": "Snow Tree 2x2 1",
		"img": {"x": 614, "y": 0, "w": 38, "h": 58},
		"pathing": 0,
		"w": 2,
		"h": 2
	},

	{
		"name": "Snow Tree 2x2 2",
		"img": {"x": 653, "y": 0, "w": 36, "h": 59},
		"pathing": 0,
		"w": 2,
		"h": 2
	},

	{
		"name": "Snow Border Top",
		"img": {"x": 683, "y": 190, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Snow Border Left",
		"img": {"x": 683, "y": 206, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Snow Border Right",
		"img": {"x": 699, "y": 206, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Snow Border Bottom",
		"img": {"x": 715, "y": 206, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"isNotFull": true
	},

	{
		"name": "Snow 1",
		"img": {"x": 619, "y": 206, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"collection": [0, 1, 2, 3]
	},

	{
		"name": "Snow 2",
		"img": {"x": 635, "y": 206, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Snow 3",
		"img": {"x": 651, "y": 206, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Snow 4",
		"img": {"x": 667, "y": 206, "w": 16, "h": 16},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"ground": true,
		"noShow": true
	},

	{
		"name": "Barrel",
		"img": {"x": 97, "y": 97, "w": 16, "h": 28},
		"img2": {"x": 757, "y": 104, "w": 16, "h": 28},
		"img3": {"x": 777, "y": 105, "w": 16, "h": 28},
		"deathImg1": {"x": 828, "y": 5, "w": 38, "h": 34},
		"deathImg2": {"x": 880, "y": 13, "w": 32, "h": 26},
		"deathImg3": {"x": 922, "y": 23, "w": 32, "h": 15},
		"deathImg4": {"x": 959, "y": 24, "w": 35, "h": 14},
		"pathing": 5,
		"w": 1,
		"h": 1,
		"ground": false,
		"movable": true,
		"radius": 0.6,
		"hp": 100
	},

	{
		"name": "Hallowen Barrel",
		"img": {"x": 523, "y": 81, "w": 16, "h": 25},
		"img2": {"x": 757, "y": 104, "w": 16, "h": 25},
		"img3": {"x": 777, "y": 105, "w": 16, "h": 25},
		"deathImg1": {"x": 828, "y": 5, "w": 38, "h": 34},
		"deathImg2": {"x": 880, "y": 13, "w": 32, "h": 26},
		"deathImg3": {"x": 922, "y": 23, "w": 32, "h": 15},
		"deathImg4": {"x": 959, "y": 24, "w": 35, "h": 14},
		"w": 1,
		"h": 1,
		"pathing": 5,
		"movable": true,
		"radius": 0.6,
		"hp": 100
	},

	{
		"name": "Winter Barrel 1",
		"img": {"x": 823, "y": 65, "w": 16, "h": 29},
		"img2": {"x": 821, "y": 169, "w": 16, "h": 29},
		"img4": {"x": 842, "y": 170, "w": 16, "h": 29},
		"deathImg1": {"x": 1006, "y": 5, "w": 38, "h": 34},
		"deathImg2": {"x": 1058, "y": 13, "w": 32, "h": 26},
		"deathImg3": {"x": 1100, "y": 23, "w": 32, "h": 15},
		"deathImg4": {"x": 1131, "y": 24, "w": 35, "h": 14},
		"pathing": 5,
		"ground": false,
		"w": 1,
		"h": 1,
		"movable": true,
		"radius": 0.6,
		"hp": 100
	},

	{
		"name": "Winter Barrel 2",
		"img": {"x": 843, "y": 65, "w": 16, "h": 29},
		"img2": {"x": 821, "y": 169, "w": 16, "h": 29},
		"img4": {"x": 842, "y": 170, "w": 16, "h": 29},
		"deathImg1": {"x": 1006, "y": 5, "w": 38, "h": 34},
		"deathImg2": {"x": 1058, "y": 13, "w": 32, "h": 26},
		"deathImg3": {"x": 1100, "y": 23, "w": 32, "h": 15},
		"deathImg4": {"x": 1131, "y": 24, "w": 35, "h": 14},
		"pathing": 5,
		"ground": false,
		"w": 1,
		"h": 1,
		"movable": true,
		"radius": 0.6,
		"hp": 100
	},

	{
		"name": "Bush 1",
		"img": {"x": 864, "y": 48, "w": 16, "h": 40},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"blockVision": true,
		"collection": [0, 1, 2, 3]
	},

	{
		"name": "Bush 2",
		"img": {"x": 881, "y": 48, "w": 16, "h": 40},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"blockVision": true,
		"noShow": true
	},

	{
		"name": "Bush 3",
		"img": {"x": 898, "y": 48, "w": 16, "h": 40},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"blockVision": true,
		"noShow": true
	},

	{
		"name": "Bush 4",
		"img": {"x": 915, "y": 48, "w": 16, "h": 40},
		"pathing": 10,
		"w": 1,
		"h": 1,
		"blockVision": true,
		"noShow": true
	}

];

for(var i = 0; i < tileTypes.length; i++)
	tileTypes[i].id = i;

var playerLevelXp = [
	40,
	60,
	80,
	100,
	120,
	140,
	160,
	180,
	200,
	235,
	270,
	290,
	310,
	330,
	350,
	370,
	390,
	410,
	430,
	450,
	470,
	490,
	520,
	580,
	640,
	740,
	840,
	940,
	1140,
	1340,
	1540,
	1740,
	1940,
	2140,
	2300,
	2460,
	2620,
	2780,
	2940,
	3020,
	3100,
	3180,
	3260,
	3340,
	3420,
	3440,
	3460,
	3480,
	3500,
	3520,
];

var playerLevelXpTotal = [
	40,
	100,
	180,
	280,
	400,
	540,
	700,
	880,
	1080,
	1315,
	1585,
	1875,
	2185,
	2515,
	2865,
	3235,
	3625,
	4035,
	4465,
	4915,
	5385,
	5875,
	6395,
	6975,
	7615,
	8355,
	9195,
	10135,
	11275,
	12615,
	14155,
	15895,
	17835,
	19975,
	22275,
	24735,
	27355,
	30135,
	33075,
	36095,
	39195,
	42375,
	45635,
	48975,
	52395,
	55835,
	59295,
	62775,
	66275,
	69795,
];

function getTotalXPRequiredForLvl(lvl)
{
	var len = playerLevelXpTotal.length;
	var idx = lvl - 2;
	if(idx < 0)
		return 0;
	else if (idx < len)
		return playerLevelXpTotal[idx];
	else
		return playerLevelXpTotal[len - 1] + (idx - len + 1) * playerLevelXp[len - 1];
}

function getXPRequiredForLvl(lvl)
{
	var len = playerLevelXp.length;
	var idx = lvl - 2;
	if(idx < 0)
		return 0;
	else if (idx < len)
		return playerLevelXp[idx];
	else
		return playerLevelXp[len - 1];
}

function getLvlFromXp(xp)
{
	var len = playerLevelXpTotal.length;
	var xpTotal = playerLevelXpTotal[len - 1];
	var lvl = 1;

	if(xp <= xpTotal)
	{
		for(var i = 0; i < len; i++)
		{
			if(xp >= playerLevelXpTotal[i])
				lvl = i + 2;
			else
				break;
		}
	}
	else
		lvl = (len + 1) + Math.floor((xp - xpTotal) / playerLevelXp[len - 1]);

	return lvl;
}

function getCrystalsRequiredForLvl(lvl)
{
	// return lvl <= 1 ? 0 : Math.floor(Math.pow(lvl - 1, 1.56) * 10 + 4);
	return lvl <= 1 ? 0 : Math.floor(Math.pow(lvl - 1, 1.56) * 50 + 50);
};

function getLvlFromSouls(xp)
{
	var lvl = 1;

	while(getCrystalsRequiredForLvl(lvl + 1) <= xp)
		lvl++;

	return lvl;
};

function getFlagXPFromPlayerCount(playerCount)
{
	if(playerCount <= 1)
		return 0;

	if(playerCount == 2)
		return 10;

	if(playerCount == 3)
		return 15;

	if(playerCount == 4)
		return 20;

	if(playerCount == 5)
		return 25;

	return CONST.XP_FLAG_RETURN;
};

function createBounce(player, projectile, objX, objY, objAOE, killer, obj, flameDeath, weapon)
{
	var vecX = 0;
	var vecY = 0;
	var vecH = 0;
	var speed = 0;

	if(weapon && weapon.isBeam && killer)
	{
		var gunWeight = (weapon.bounceSpeed / (weapon.bounceSpeed + 0.25));

		var projVecX = player.x - killer.x;
		var projVecY = player.y - killer.y;

		var projVecLen = Math.sqrt(projVecX * projVecX + projVecY * projVecY);
		var plVecLen = Math.sqrt(Math.pow(player.x - player.x0, 2) + Math.pow(player.y - player.y0, 2));

		if(projVecLen == 0)
			projVecLen = 0.001;

		if(plVecLen == 0)
			plVecLen = 0.001;

		vecX = (projVecX / projVecLen) * gunWeight + ((player.x - player.x0) / plVecLen) * (1 - gunWeight);
		vecY = (projVecY / projVecLen) * gunWeight + ((player.y - player.y0) / plVecLen) * (1 - gunWeight);
		vecH = weapon.bouncePower;
		speed = weapon.bounceSpeed * 1.5;
	}

	if(flameDeath)
	{
		var projVecLen = 0;
		var plVecLen = Math.sqrt(Math.pow(player.x - player.x0, 2) + Math.pow(player.y - player.y0, 2));

		if(plVecLen == 0)
			plVecLen = 0.001;

		vecX = ((player.x - player.x0) / plVecLen);
		vecY = ((player.y - player.y0) / plVecLen);
		vecH = weapons[2].bouncePower;
		speed = weapons[2].bounceSpeed * 1.5;
	}

	else if(projectile && projectile.weapon.aoe)
	{
		vecX = player.x - projectile.x;
		vecY = player.y - projectile.y;

		if(vecX == 0 && vecY == 0)
			vecX = 0.01;

		vecH = Math.max((Math.min(Math.max(projectile.weapon.aoe - Math.sqrt(vecX * vecX + vecY * vecY), 1.0), 1.8) + 0.2) * 0.2, 0.001);
		speed = vecH * 2.5;
		if(typeof soundManager !== 'undefined' && soundManager && soundManager.playSound)
			soundManager.playSound(SOUND.PUNCH, player.x, player.y, 0.95);
	}

	else if(typeof objX != 'undefined' && typeof objY != 'undefined' && typeof objAOE != 'undefined' && (objX || objY || objAOE) && (objX != "0" || objY != "0" || objAOE != "0"))
	{
		vecX = player.x - objX;
		vecY = player.y - objY;

		if(vecX == 0 && vecY == 0)
			vecX = 0.01;

		vecH = Math.max((Math.min(Math.max(objAOE - Math.sqrt(vecX * vecX + vecY * vecY), 1.0), 1.8) + 0.2) * 0.2, 0.001);
		speed = vecH * 2.5;
		if(typeof soundManager !== 'undefined' && soundManager && soundManager.playSound)
			soundManager.playSound(SOUND.PUNCH, player.x, player.y, 0.95);
	}

	else if((!projectile && typeof killer == 'undefined') || (obj && obj.object && obj.object.noBounce))
	{
		vecX = Math.random() - 0.5;
		vecY = Math.random() - 0.5;
		vecH = 0.12;
		speed = 0.10;
		if(typeof soundManager !== 'undefined' && soundManager && soundManager.playSound)
			soundManager.playSound(SOUND.GUN_IMPACT, player.x, player.y, 0.55);
	}

	else if(projectile && !projectile.weapon.aoe)
	{
		var gunWeight = (projectile.weapon.bounceSpeed / (projectile.weapon.bounceSpeed + 0.25));

		var projVecLen = Math.sqrt(projectile.vecX * projectile.vecX + projectile.vecY * projectile.vecY);
		var plVecLen = Math.sqrt(Math.pow(player.x - player.x0, 2) + Math.pow(player.y - player.y0, 2));

		if(projVecLen == 0)
			projVecLen = 0.001;

		if(plVecLen == 0)
			plVecLen = 0.001;

		vecX = (projectile.vecX / projVecLen) * gunWeight + ((player.x - player.x0) / plVecLen) * (1 - gunWeight);
		vecY = (projectile.vecY / projVecLen) * gunWeight + ((player.y - player.y0) / plVecLen) * (1 - gunWeight);
		vecH = projectile.weapon.bouncePower;
		speed = projectile.weapon.bounceSpeed * 1.5;
	}

	else if(killer && killer.isZombie)
	{
		vecX = player.x - killer.x;
		vecY = player.y - killer.y;
		vecH = 0.15;
		speed = 0.11;
	}

	if(vecX == 0 && vecY == 0)
	{
		vecX = 0.01;
		vecY = 0.01;
		vecH = 0.01;
		speed = 0.02;
	}

	var len = Math.sqrt(vecX * vecX + vecY * vecY);

	vecX *= speed / len;
	vecY *= speed / len;

	return {
		x: vecX,
		y: vecY,
		z: vecH
	};
};

function createBounce2(x, y, vecX, vecY, vecH, game)
{
	var h = 0;

	var points = [];

	var running = true;
	while(running)
	{
		var wallSmash = false;

		var oldX = x;
		var oldY = y;

		x += vecX;
		y += vecY;

		var block = game.getHeight3(Math.floor(x), Math.floor(y));

		if(block > h)
		{
			x -= vecX * 2;
			wallSmash = vecX > 0 ? "right" : "left";
			block = game.getHeight3(Math.floor(x), Math.floor(y));

			if(block > h)
			{
				x += vecX * 2;
				y -= vecY * 2;
				wallSmash = vecY > 0 ? "bottom" : "top";
				block = game.getHeight3(Math.floor(x), Math.floor(y));

				if(block > h)
				{
					x -= vecX * 2;

					if(vecX > 0 && vecY > 0)
						wallSmash = "rightbottom";

					else if(vecX > 0 && vecY < 0)
						wallSmash = "righttop";

					else if(vecX < 0 && vecY > 0)
						wallSmash = "leftbottom";

					else if(vecX < 0 && vecY < 0)
						wallSmash = "lefttop";
				}
			}
		}

		vecX = x - oldX;
		vecY = y - oldY;

		if(wallSmash)
		{
			vecX *= 0.5;
			vecY *= 0.5;
		}

		var hitsGround = false;

		h += vecH;
		if(h < block)
		{
			h = block;
			vecH *= -0.6;
			vecX *= 0.75;
			vecY *= 0.75;

			if(vecH < 0.05)
				running = false;

			else
				hitsGround = true;
		}
		vecH -= 0.04;

		vecX *= 0.97;
		vecY *= 0.97;

		points.push({
			x: x,
			y: y,
			h: h,
			hitsGround: hitsGround,
			wallSmash: wallSmash,
			vecH: vecH
		});
	}

	return points;
};

function validateClanTag(str)
{
	if(!str)
		return false;
	
	if(str.length < 1 || str.length > 6)
		return false;
	
	for(var i = 0; i < str.length; i++)
		if(str.charAt(i).match(/[\w-+*]/g) != str.charAt(i))
			return false;
	
	return true;
};

function checkName(str)
{
	if(!str)
		return false;
	
	if(str.length < 3 || str.length > 15)
		return "3 - 15 chars.";
	
	if(str.charAt(0).match(/[\w]/g) != str.charAt(0))
		return "Only use letters, numbers, space and underscore. 1st / last char cant be space.";
	
	if(str.charAt(str.length - 1).match(/[\w]/g) != str.charAt(str.length - 1))
		return "Only use letters, numbers, space and underscore. 1st / last char cant be space.";
	
	for(var i = 1; i < str.length - 1; i++)
		if(str.charAt(i).match(/[\w ]/g) != str.charAt(i))
			return "Only use letters, numbers, space and underscore.";
	
	return "OK";
};

function validateClanName(str)
{
	if(!str)
		return false;
	
	if(str.length < 1 || str.length > 15)
		return false;
	
	if(str.charAt(0).match(/[\w]/g) != str.charAt(0))
		return false;
	
	if(str.charAt(str.length - 1).match(/[\w]/g) != str.charAt(str.length - 1))
		return false;
	
	for(var i = 1; i < str.length - 1; i++)
		if(str.charAt(i).match(/[\w ]/g) != str.charAt(i))
			return false;
	
	return true;
};

function validateClanText(str)
{
	return str && str.length < 500;
};

function validateLoginName(str)
{
	if(!str)
		return false;
	
	if(str.length < 3 || str.length > 20)
		return false;
	
	for(var i = 1; i < str.length - 1; i++)
		if(str.charAt(i).match(/[\w-]/g) != str.charAt(i))
			return false;
	
	return true;
};

function validatePW(str)
{
	if(!str)
		return false;
	
	if(str.length < 3 || str.length > 20)
		return false;
	
	return true;
};

function validateMail(str)
{
	return str.match(/^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/g) == str;
};

if(typeof exports !== 'undefined')
{
	exports.weapons = weapons;
	exports.itemTypes = itemTypes;
	exports.tileTypes = tileTypes;
	exports.constants = CONST;
	exports.creationFreeMaps = CREATION_FREE_MAPS;
	exports.authLevel = AUTH_LEVEL;
	exports.getTotalXPRequiredForLvl = getTotalXPRequiredForLvl;
	exports.getXPRequiredForLvl = getXPRequiredForLvl;
	exports.getLvlFromXp = getLvlFromXp;
	exports.getCrystalsRequiredForLvl = getCrystalsRequiredForLvl;
	exports.getLvlFromSouls = getLvlFromSouls;
	exports.hats = hats;
	exports.nameColor = NAME_COLOR;
	exports.hatsByQuality = hatsByQuality;
	exports.MAP_TYPE = MAP_TYPE;
	exports.MAP_TYPE_SETTINGS = MAP_TYPE_SETTINGS;
	exports.objects = objects;
	exports.abilities = abilities;
	exports.nbs = nbs;
	exports.killStreaks = killStreaks;
	exports.multiKills = multiKills;
	exports.getDefaultAbilityObj = getDefaultAbilityObj;
	exports.getTutorialAbilityObj = getTutorialAbilityObj;
	exports.getDefaultZombieAbilityObj = getDefaultZombieAbilityObj;
	exports.getFlagXPFromPlayerCount = getFlagXPFromPlayerCount;
	exports.createBounce = createBounce;
	exports.createBounce2 = createBounce2;
	exports.treasureChests = treasureChests;
	exports.questTypes = questTypes;
	exports.goldCostBySkinQuality = goldCostBySkinQuality;
	exports.validateClanTag = validateClanTag;
	exports.validateClanName = validateClanName;
	exports.validateClanText = validateClanText;
	exports.validateLoginName = validateLoginName;
	exports.validatePW = validatePW;
	exports.validateMail = validateMail;
	exports.checkName = checkName;
}
