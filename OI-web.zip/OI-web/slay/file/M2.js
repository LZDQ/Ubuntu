function drawMiniMap(view, size, percentageOfCurrentTickPassed) {

	var c = view._canvas.getContext("2d");

	var game = view._game;

	var w = minimapSizeFactor * (game.map.x > game.map.y ? size : (game.map.x / game.map.y * size));
	var h = minimapSizeFactor * (game.map.y > game.map.x ? size : (game.map.y / game.map.x * size));
	view._canvas.width = w;
	view._canvas.height = h;

	c.mozImageSmoothingEnabled = false;
	c.msImageSmoothingEnabled = false;
	c.imageSmoothingEnabled = false;

	var scale = w / game.map.x;
	var scaleTop3 = SCALE_FACTOR_BASE * 0.8;

	c.globalAlpha = 0.8;
	c.drawImage(view._baseCanvas, 0, 0, w, h);

	drawMiniMapScreenBorder(c, size, w / game.map.x);

	// players / zombies
	var players = game.players;

	c.globalAlpha = 1 - 0.7 * (Math.cos(timestamp / 100) / (Math.PI) + 0.5);
	for (var p of players) {

		var rank = -1;
		if (game.type.zombies)
			for (var k = 0; k < game.interface_.top3.length; k++)
				if (game.interface_.top3[k].name == p.name)
					rank = game.interface_.top3[k].rank;

		if(p.dieAt)
			continue;

		if(!game.playingPlayer || p == game.playingPlayer || rank > 0 || (p.team == game.playingPlayer.team && p.team != 0)
			|| game.showEnemiesOnMinimapUntil >= game.ticksCounter || (game.playingPlayer.isHumanZombie && p.isBoss))
		{
			var x_ = p.x0 + percentageOfCurrentTickPassed * (p.x - p.x0);
			var y_ = p.y0 + percentageOfCurrentTickPassed * (p.y - p.y0);
			var x2_ = w * x_ / game.map.x;
			var y2_ = h * y_ / game.map.y;
			var crownImg = imgCoords.crownYellow;
			var crosshairImg = imgCoords.crosshairRed;

			if(p != game.playingPlayer && game[scf1 + scf2] > game.ticksCounter + 1000)
				return;

			if (p.isZombie) {
				c.fillStyle = "#FFFA7D";
				img = imgCoords.light_yellow;
			}
			else if (p == game.playingPlayer) {
				c.fillStyle = "#00FF06";
				img = imgCoords.light_green;
				crownImg = imgCoords.crownGreen;
				crosshairImg = imgCoords.crosshairGreen;
			}
			else if((game.playingPlayer && p.team == game.playingPlayer.team && p.team != 0) || (!game.playingPlayer && !p.isHumanZombie))
			{
				c.fillStyle = "#FFFFFF";
				img = imgCoords.light_white;
				crownImg = imgCoords.crownWhite;
				crosshairImg = imgCoords.crosshairWhite;
			}
			else
			{
				c.fillStyle = "#FF0000";
				img = imgCoords.light_red;
				crownImg = imgCoords.crownRed;
				crosshairImg = imgCoords.crosshairRed;
			}

			if (p.weapon && p.weapon.isSniper && game.showEnemiesOnMinimapUntil >= game.ticksCounter) {
				c.drawImage(imgs.miscSheet, crosshairImg.x, crosshairImg.y, crosshairImg.w, crosshairImg.h, x2_ - scale * 3, y2_ - scale * 3, scale * 6, scale * 6);
			}
			else if (rank == 1) {
				c.drawImage(imgs.miscSheet, crownImg.x, crownImg.y, crownImg.w, crownImg.h, x2_ - scale * 2.5, y2_ - scale * 2.5, scale * 5, scale * 5);
			}
			else if (rank > 0) {
				drawText(c, rank, c.fillStyle, scaleTop3 * 2.5, x2_, y2_ + scaleTop3 * 2, 20 * scaleTop3, "center", c.globalAlpha);
			}
			else {
				c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, x2_ - scale * 4, y2_ - scale * 4, scale * 8, scale * 8);
				c.fillRect(x2_ - scale, y2_ - scale, scale * 2, scale * 2);
			}

		}
	}
	c.globalAlpha = 1;

	// ctf
	if (game.type.flag) {
		for (var j = 0; j < 2; j++) {
			var img = j == 0 ? imgCoords.redFlag : imgCoords.blueFlag;
			var flag = j == 0 ? game.redFlag : game.blueFlag;

			if (flag) {
				var x_ = flag.currentX;
				var y_ = flag.currentY;

				if (flag.carriedBy) {
					var p = flag.carriedBy;
					x_ = p.x0 + percentageOfCurrentTickPassed * (p.x - p.x0);
					y_ = p.y0 + percentageOfCurrentTickPassed * (p.y - p.y0);
				}

				var x2_ = w * x_ / game.map.x;
				var y2_ = h * y_ / game.map.y;

				c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, x2_ - 3 * scale, y2_ - 5 * scale, scale * 6, scale * 8);
			}
		}
	}
}

function drawMiniMapScreenBorder(c, size, rate) {

	var X = game.cameraX;
	var Y = game.cameraY;
	var W = game.cameraX2 - game.cameraX;
	var H = game.cameraY2 - game.cameraY;

	X = ((X * rate)|0) + 0.5;
	Y = ((Y * rate)|0) + 0.5;
	W = ((W * rate)|0);
	H = ((H * rate)|0) + 2;

	c.strokeStyle = "#FFF";
	c.strokeRect(X, Y, W, H);
}
