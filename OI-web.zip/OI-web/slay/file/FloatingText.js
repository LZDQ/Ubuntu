function FloatingText(text, x, y, lifetime, speed, color, size, img)
{
	this.text = text;
	this.color = color ? color : "red";
	this.size = size ? size : FIELD_SIZE * 0.3;
	this.img = img;
	
	this.x = x;
	this.y = y;
	
	this.timeOfBirth = Date.now();
	this.lifetime = lifetime ? lifetime : 2000;
	this.speed = speed ? speed : 2;
};

FloatingText.prototype.update = function()
{
	return (this.timeOfBirth + this.lifetime) >= Date.now(); 
};

FloatingText.prototype.draw = function()
{
	var now = Date.now();
	
	var x = (this.x - game.cameraX) * FIELD_SIZE;
	var y = (this.y - game.cameraY - (now - this.timeOfBirth) * this.speed / 1000) * FIELD_SIZE;
	
	
	if(this.img)
		x += this.img.w / 2;
	
	var time2Live = Math.max(this.timeOfBirth + this.lifetime - now, 0.001);
	var alpha = time2Live > 500 ? 1 : (time2Live / 500);
	
	if(this.timeOfBirth + 200 > now)
		alpha = (now - this.timeOfBirth) / 200;
	
	drawText(c, this.text, this.color, this.size, x, y, 250, "center", alpha);
	
	if(this.img)
	{
		var scale = SCALE_FACTOR * 0.9;
		c.globalAlpha = alpha;
		c.drawImage(imgs.miscSheet, this.img.x, this.img.y, this.img.w, this.img.h, x - c.measureText(this.text).width / 2 - (this.img.w + 2) * scale, y - this.img.h * scale * 0.8, this.img.w * scale, this.img.h * scale);
		c.globalAlpha = 1;
	}
};