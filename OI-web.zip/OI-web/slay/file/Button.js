function Button(x, y, w, h, key)
{
	this.x = x;
	this.y = y;
	this.w = w;
	this.h = h;
	this.key = key;
	this.isPressedOld = false;
	this.isPressed = false;
};

Button.prototype.getX = function()
{
	var x = this.x;
	
	while(x < 0)
		x += WIDTH / FIELD_SIZE_BASE;
	
	return x;
};

Button.prototype.getY = function()
{
	var y = this.y;
	
	while(y < 0)
		y += HEIGHT / FIELD_SIZE_BASE;
	
	return y;
};

Button.prototype.draw = function()
{
	c.lineWidth = SCALE_FACTOR_BASE;
	c.strokeStyle = "rgba(255, 255, 255, 0.8)";
	c.strokeRect(this.getX() * FIELD_SIZE_BASE, this.getY() * FIELD_SIZE_BASE, this.w * FIELD_SIZE_BASE, this.h * FIELD_SIZE_BASE);
};

Button.prototype.contains = function(x, y)
{
	var x_ = this.getX() * FIELD_SIZE_BASE;
	var y_ = this.getY() * FIELD_SIZE_BASE;
	
	return x >= x_ && x <= (x_ + this.w * FIELD_SIZE_BASE) && y >= y_ && y <= (y_ + this.h * FIELD_SIZE_BASE);
};

Button.prototype.keyDown = function()
{
	KeyManager.keyDown(this.key);
};

Button.prototype.keyUp = function()
{
	KeyManager.keyUp(this.key);
};