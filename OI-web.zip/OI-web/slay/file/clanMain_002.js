(function(){
    var clans = new F$ArrayView();
    var appliedClans = {};
	
    FunUI.traits.clanMain = {
        _searchInput: null,
        _tabPage: null,
        _createIndex : 1,
        _mineIndex : 2,
        appliedClans: appliedClans,
        __init__: function()
        {
            this._searchInput = this.querySelector('.searchInput');
            this._searchInput.on(FunUI.events.INPUT_SUBMIT, this.loadClanList);
            this._tabPage = this.querySelector('.F-TabPage.content');
            this.querySelector('.F-Button.search').on('click', this.loadClanList);
            network.send("getClanAppsOfPlayer");
        },
        show: function(tag)
        {
            this.open();
            
            if(playerData.clanTag || tag)
            {
                this.showMine();
                network.send("myClanInfo" + (tag ? ("$" + tag) : ""));
            }
            else
                this.showCreate();
            
			this._tabPage.selectedIndex = (playerData.clanTag || tag) ? this._mineIndex : this._createIndex;
        },
        showMine : function()
        {
            this._tabPage.excludePage(this._createIndex);
            this._tabPage.includePage(this._mineIndex);
            this._tabPage.selectedIndex = this._mineIndex;
        },
        showCreate : function()
        {
            this._tabPage.excludePage(this._mineIndex);
            this._tabPage.includePage(this._createIndex);
            this._tabPage.selectedIndex = this._createIndex;
        },
        onLoadClanApps: function(message)
        {
            for(var i = 1; i < message.length; i++)
                this.appliedClans[message[i]] = true;
        },
        loadClanList: function()
        {
            network.send("clanList$" + this._searchInput.text + "$" + 0 + "$20");
        }
    };

    FunUI.traits.clanMain_create = {
        _nameInput: null,
        _tagInput: null,
        _descInput: null,
        __init__: function () {
            this._nameInput = this.querySelector('.F-TextInput.name');
            this._tagInput = this.querySelector('.F-TextInput.tag');
            this._descInput = this.querySelector('.F-TextInput.description');
			
            this.querySelector('.goldNumber').innerText = CONST.CLAN_CREATION_GOLD_COST;
            this.querySelector('.F-Button.create').on('click', this.create);
        },
        create: function () {
            F$confirm(F_('clanMain.create.confirm.content', {
                gold: CONST.CLAN_CREATION_GOLD_COST,
                clanName: this._tagInput.text
            }), this._create);
        },
        _create: function () {
            if(playerData.gold < CONST.CLAN_CREATION_GOLD_COST)
            {
                slayOne.viewHelpers.showFloatTip({
                    tipType: 'error',
                    content: F_('clanMain.create.error.insufficient')
                });
                return;
            }
            
            network.send("createClan$" + this._tagInput.text + "$" + this._nameInput.text + "$" + this._descInput.text);
        },
        onClanInfo : function(data) {
            F$('clanMain').showMine();
            setTimeout(F$('clanMain_mine').showInfo, 0, data);
        },
        onCreate: function () {
            playerData.gold -= CONST.CLAN_CREATION_GOLD_COST;
            F$('resourceBar').refresh();
        }
    };

    var infoPanel = {
        _showClan: function()
        {
        	var elements = document.getElementsByClassName('clanTag');
        	for(var i = 0; i < elements.length; i++)
        		elements[i].innerText = currentClan.tag;
        	
        	elements = document.getElementsByClassName('clanName');
        	for(var i = 0; i < elements.length; i++)
        		elements[i].innerText = currentClan.name;
        	
        	elements = document.getElementsByClassName('elo');
        	for(var i = 0; i < elements.length; i++)
        		elements[i].innerText = currentClan.elo;
        	
        	elements = document.getElementsByClassName('membersCount');
        	for(var i = 0; i < elements.length; i++)
        		elements[i].innerText = currentClan.countMembers;
        	
        	elements = document.getElementsByClassName('membersCount');
        	for(var i = 0; i < elements.length; i++)
        		elements[i].innerText = currentClan.countMembers;
        	
        	elements = document.getElementsByClassName('clanDescription');
        	for(var i = 0; i < elements.length; i++)
        		elements[i].innerText = currentClan.description;
        },
    };

    FunUI.traits.clanMain_info = Object.assign({
        _joinButton: null,
        _anchor: false,
        __init__: function()
        {
            this.querySelector('.back').on('click', this.goBack);
            this.querySelector('.btnMembers').on('click', this.showMembers);
            this._joinButton = this.querySelector('.join');
            this._joinButton.on('click', this.showJoin);
        },
        showMembers: function()
        {
            F$('myClan').showClan();
        },
        showClan: function(anchor)
        {
            F$('clanMain_browseViewStack').selectSubView(1);
            this._showClan();
            this._joinButton.style.visibility = (playerData.clanTag || appliedClans[currentClan.id]) ? "hidden" : "visible";
            this._anchor = anchor;
        },
        showJoin: function() {
            F$('clanJoin').showClan();
        },
        goBack: function() {
            F$('clanMain_browseViewStack').selectSubView(0);
            if (this._anchor) {
                F$("clanMain").loadClanList();
                this._anchor = false;
            }
        }
    }, infoPanel);
	
    FunUI.traits.clanMain_list = {
        dataProvider: clans
    };
	
    FunUI.traits.clanMain_list.itemRenderer = {
        _titleField : null,
        _membersNumberField: null,
        _joinButton: null,
        __init__: function() {
            this.querySelector(".info").on('click', this.requestClanInfo);
            this._joinButton = this.querySelector('.join');
            this._joinButton.on('click', this.showJoin);

            this._titleField = this.querySelector("h4");
            this._membersNumberField = this.querySelector(".membersNumber");
        },
        render: function() {
            this._tagField.innerText = currentClan.tag;
            this._titleField.tooltipData = "[" + currentClan.tag + "] " + currentClan.name;
            this._membersNumberField.innerText = currentClan.countMembers;
            this._joinButton.style.visibility = playerData.clanTag ? "hidden" : "visible";
        },
        requestClanInfo: function()
        {
        	F$('clanMain').show(currentClan.tag);
        },
        showClanInfo: function()
        {
            document.getElementById('clanMain_info').showClan();
        },
        showJoin: function() {
            F$('clanJoin').showClan();
        }
    };

    FunUI.traits.clanMain_myInfo = Object.assign({
            showClan: function()
            {
                this._showClan();
                var el = document.getElementById('clanHint');
                if(el)
                    el.style.display = (!currentClan || !currentClan.appsCount) ? "none" : "block";
            },
        },
        infoPanel
    );

    FunUI.traits.clanMain_mine = {
        _viewStack: null,
        _nameInput: null,
        _tagLabel: null,
        _descInput: null,
        __init__: function() {
            this._viewStack = this.querySelector('.F-ViewStack');
            this.querySelector('.setting').on('click', this.showEdit);
            this.querySelector('.back').on('click', this.back);
            this.querySelector('.F-Button.members').on('click', this.showMembers);
			
            this.querySelector('.leave').on('click', this.leave);
			
            this._nameInput = this.querySelector('.clanForm .F-TextInput.name');
            this._tagLabel = this.querySelector('.clanForm .tag');
            this._descInput = this.querySelector('.clanForm .F-TextInput.description');
            
            this.querySelector('.F-Button.save').on('click', this.update);
            this.querySelector("#joinButton").on('click', this.showJoin);
        },
        back: function()
        {
            this.showInfo();
        },
        showMembers: function()
        {
            F$('clanMain').close();
            F$('myClan').showClan();
        },
        showInfo: function()
        {
            F$('clanMain_myInfo').showClan();
            if(document.getElementById("clanSettingsButton"))
            	document.getElementById("clanSettingsButton").style.visibility = (playerData.clanTag && playerData.clanRole >= AUTH_LEVEL.ADMIN) ? "visible" : "hidden";
            if(document.getElementById("leaveButton"))
            	document.getElementById("leaveButton").style.display = (playerData.clanTag == currentClan.tag) ? "" : "none";
            if(document.getElementById("joinButton"))
            	document.getElementById("joinButton").style.display = (playerData.clanTag || appliedClans[currentClan.id]) ? "none" : "";
        	if(this._viewStack)
            	this._viewStack.selectSubView(0);
        },
        showEdit: function()
        {
            this._viewStack.selectSubView(1);
            this.querySelector('.clanForm .F-TextInput.name').text = currentClan.name;
            this._tagLabel.innerText = "[" + currentClan.tag + "]";
            // this._descInput.text = escapeHtml(currentClan.description);
            this._descInput.innerHTML = "<textarea id='clanDescTextArea'>" + escapeHtml(currentClan.description) + "</textarea>";
        },
        update: function()
        {
            network.send("update-clan$" + this._nameInput.text + "$" + document.getElementById("clanDescTextArea").value);
            this.onUpdate();
        },
        onUpdate: function()
        {
            currentClan.name = this._nameInput.text;
            currentClan.description = document.getElementById("clanDescTextArea").value;
            this.showInfo();
        },
        leave: function()
        {
            F$confirm(
                F_("clanMain.leave.confirm.content"),
                this.doLeave
            );
        },
        showJoin: function() {
            F$('clanJoin').showClan();
        },
        doLeave: function()
        {
        	network.send("leaveClan");
            currentClan = null;
            playerData.clanTag = "";
            playerData.clanRole = 0;
            F$('clanMain').show();
            slayOne.views.homeScreen.render();
        }
    };
    
    slayOne.functions.fff = FunUI.traits.clanMain_mine;
})();