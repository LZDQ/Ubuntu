(function(){

    FunUI.traits.respawn = {
        _gameLink : null,
        _linkInput : null,
        _forceHide : false,
        _killerNameLabel : null,
        _buttonRespawn : null,
        _counterLabel : null,
        _timeTillRespawn : null,
        __init__: function () {
            this._linkInput = this.querySelector('.inviteLink');
            this._killerNameLabel = this.querySelector('.killer>.name');
            this._buttonRespawn = this.querySelector('.F-Button.respawn');
            if (typeof sendRespawn == 'function') {
                this._buttonRespawn.on('click', sendRespawn);
            }
            this._counterLabel = this.querySelector('.counter');
            this.querySelector('.F-Button.link').on('click', this.copyLink);
            this.querySelector('.F-Button.help').on('click', window.showTutorialWindow_);
            this.on(FunUI.events.REMOVE_POP_UP, this.showMini);
        },
        show : function(killerName) {
            this._forceHide = false;
            this._gameLink = getCurrentGameLink();

            this._linkInput.value = this._gameLink;

            if (!killerName) {
                killerName = "zombie";
            }

            this._killerNameLabel.innerHTML = killerName;
            this.open();
        },
        copyLink : function() {
            copyInput(this._linkInput);
        },
        "<Observer event='click' selector='.F-Button.socialMedia.fb' />" : function() {
            shareToFacebook(this._gameLink);
        },
        "<Observer event='click' selector='.F-Button.socialMedia.tw' />" : function() {
            shareToTwiter(this._gameLink);
        },
        progress : function(timeTillRespawn) {
            this._timeTillRespawn = timeTillRespawn;
            if (!this.parentNode) {
                if (F$('respawnMini').parentNode) {
                    F$('respawnMini').progress(timeTillRespawn);
                }
                return;
            }

            if (timeTillRespawn > 0) {
                if (!this._buttonRespawn.disabled) {
                    this.addClass('waiting');
                    this.removeClass('ready');
                    this._buttonRespawn.disabled = true;
                }

                var respawnTimeStr = timeTillRespawn.toString();
                if(respawnTimeStr.indexOf(".") < 0) {
                    respawnTimeStr += ".0";
                }

                this._counterLabel.innerHTML = respawnTimeStr;
            } else if (timeTillRespawn == 0) {
                this.addClass('ready');
                this.removeClass('waiting');
                this._buttonRespawn.disabled = false;
            }
        },
        showMini : function() {
            if (!this._forceHide) {
                F$('respawnMini').show();
                if (this._timeTillRespawn <= 0) {
                    F$('respawnMini').progress(0);
                }
            }
        },
        hide : function(force) {
            this._forceHide = force;
            this.close();
    	}
    };
})();