(function( window, slayOne, document ){

var iconButtonSizes = {
    standard: {w: '62px', h: '66px'},
    small: {w: '44px', h: '48px'},
};

/**
 * Icon button
 *
 * @param parentNode: dom element to append to
 * @param options:
 *                  cssId: string
 *                  theme: standard | small
 *                  customClassName: string
 *                  iconClassName: string
 *                  onClick: func
 *                  tip: tip content
 */
function iconButton(parentNode, options){

	var btn = document.createElement("div");

    var themeOption = (options && options.theme) ? options.theme : "standard";

    if(options && options.cssId) {
        btn.id = options.cssId;    
    }
    var finalClassName = "pixelated iconButton";
    if(options && options.customClassName) {
        finalClassName += ' ' + options.customClassName;
    }
    btn.className = finalClassName;

    var domBackground = document.createElement("div");
    domBackground.className = "iconButtonBackground" + capitalize(themeOption);
    btn.appendChild(domBackground);

    var domContent = document.createElement("div");
    domContent.className = "iconButtonIcon iconButtonIcon" + capitalize(themeOption) + " " + options.iconClassName;
    btn.appendChild(domContent);

    slayOne.widgets.clickable(btn);
    btn.onclick = function(){
        options.onClick();
    };

    parentNode.appendChild(btn);

    slayOne.widgets.hoverLight(btn, {
        width: iconButtonSizes[themeOption].w,
        height: iconButtonSizes[themeOption].h
    });

    var isTipEnabled = (options.tip && options.tip.length > 0);
    if(isTipEnabled) {
        btn.tipEffect = slayOne.widgets.tooltip(btn, {
            tip:options.tip
        });
    }

    

    return btn;
}

//export
if(!slayOne.widgets) {
    slayOne.widgets = {};
}

slayOne.widgets.iconButton = iconButton;

})( window, window.slayOne, window.document);//end main closure