(function(){
    var rewards = new F$ArrayView();

    FunUI.traits.levelUp = {
        _badge : null,
        _rewardTitle : null,
        __init__ : function () {
            this._badge = this.querySelector('.badge');
            this._rewardTitle = this.querySelector('.rewardArea legend');
        },
        show : function(model) {
            FunUI.managers.PopUpManager.addPopUp(this, true, FunUI.managers.PopUpManager.LAYER_TOP);
            this._badge.innerHTML = model.level;
            this._rewardTitle.innerHTML = F_('levelUp.reward.title', {level: model.level});
            rewards.source = model.rewards.slice(0, 9);
            soundManager.playSound(SOUND.LVLUP);
        },
        "<Observer event='click' selector='.F-Button.ok' /> hide" : function() {
            FunUI.managers.PopUpManager.removePopUp(this);
            document.removeEventListener("click", this.tryHide, true);
        },
        "<Observer event='click' selector='.F-Button.share' />": function() {
            shareToFacebook(window.location.href);
        }
    };

    FunUI.traits.levelUp_rewardList = {
        dataProvider : rewards
    };

    FunUI.traits.levelUp_rewardList.itemRenderer = {
        _iconUnlock : null,
        _title : null,
        _canvas : null,
        _c : null,
        _img : null,
        __init__ : function() {
            this._iconUnlock = this.querySelector('.icon_unlock');
            this._title = this.querySelector('h3');

            this._canvas = this.querySelector('canvas');
            this._c = this._canvas.getContext('2d');
            this._c.mozImageSmoothingEnabled = false;
            this._c.msImageSmoothingEnabled = false;
            this._c.imageSmoothingEnabled = false;

            this._img = this.querySelector('img');
        },
        render : function(data, index) {
            this._c.fillStyle = "rgba(0, 0, 0, 0)";

            if (data.type == 'gold') {

                this._title.innerHTML = F_('levelUp.title.gold', {gold: 'x' + data.value});
                this._canvas.style.display = "none";
                this._img.src = "imgs/icons/icon_gold02.png";
                this._img.style.display = "";
                this._iconUnlock.style.display = "none";

            } else if (data.type == 'chest') {

                this._title.innerHTML = F_('levelUp.title.chest', {
                    name : getChestName(data.id),
                    count: 'x' + data.value
                });
                this._canvas.style.display = "none";
                this._img.src = "imgs/chest/chest_" + data.id + ".png";
                this._img.style.display = "";
                this._iconUnlock.style.display = "none";

            } else if (data.type == 'mode') {

                var mode = MAP_TYPE_SETTINGS[data.value];
                this._title.innerHTML = F_(mode.langLabel);
                this._canvas.style.display = "none";
                this._img.src = "imgs/icons/" + mode.icon;
                this._img.style.display = "";
                this._iconUnlock.style.display = "";

            } else if (data.type == 'gem') {

                this._title.innerHTML = F_('levelUp.title.gem', {gem: 'x' + data.value});
                this._canvas.style.display = "none";
                this._img.src = "imgs/icons/gem.png";
                this._img.style.display = "";
                this._iconUnlock.style.display = "none";

            } else if (data.type == 'hat') {

                var hat = hats[data.value];
                this._title.innerHTML = hat.name;
                this._img.style.display = "none";
                this._canvas.style.display = "";
                this._iconUnlock.style.display = "";
                if (!window.imgs) {
                    return;
                }

                drawHat(this._c, hat, 3.5, 2, this._canvas.width, this._canvas.height);
            }
        }
    };
})();