if (!navigator.userAgent.match(/(BingPreview|Bot)\//)) {
	(function () {
		try {
			eval('"use strict"; class foo {}');
		} catch (e) {
			window.location.href = '/not-support-browser.html';
		}
	})();
}

var isDesktop = typeof require !== 'undefined';
var isSteam = navigator.userAgent.indexOf('Slay.one Steam') > -1;
var SteamInfo = {
	init: false,
	user: null,
	ticket: null,
};

if (isSteam) {
	document.title = 'Slay.one';
}

const ipcRenderer = (window.isDesktop && !isSteam) ? require('electron').ipcRenderer : false;
