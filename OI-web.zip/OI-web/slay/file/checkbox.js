(function(window, slayOne, document){

/**
 * Check box
 *
 * @param parentNode: dom element to append to
 * @param options:
 *                  label: string
 *                  labelClassName: string
 *                  customClassName: string
 *                  selected: true | false
 *                  onChange: callback(currentValue)
 *                  tip: string
 *                  tipAlign: string
 *                  tipMultiline: boolean
 *                  tipWidth: css property string
 */
function checkbox(parentNode, options) {

    var domContainer = document.createElement("div");
    var finalClassName = "checkboxWrapper";
    if(options && options.customClassName)
        finalClassName += " " + options.customClassName;
    
    domContainer.className = finalClassName;
	
    if(options && options.cssId)
        domContainer.id = options.cssId;
	
    var initSelected = false;
    if(options && options.selected)
        initSelected = options.selected;

    var widgetModel = {
        selected: initSelected,
        onChange: null
    };

    if(options && options.onChange)
        widgetModel.onChange = options.onChange;

    var domWidget = document.createElement("div");
    domWidget.className = "checkboxIconWrapper";

    var domWidgetSelected = document.createElement("div");
    domWidgetSelected.className = "checkboxIconSelected";
    domWidgetSelected.style.display = initSelected ? "block" : "none";
    domWidget.appendChild(domWidgetSelected);

    domContainer.appendChild(domWidget);

    var domLabel = document.createElement("div");
    var labelClassName = "checkboxLabel";
    if(options && options.labelClassName) {
        labelClassName += ' ' + options.labelClassName;
    }
    domLabel.className = labelClassName;
    domLabel.innerHTML = options.label;
    domContainer.appendChild(domLabel);

    domContainer.toggleSelected = function(){
        domContainer.setSelected(!domContainer.getSelected());
    };

    domContainer.setSelected = function(val){
        if(widgetModel.selected == val) {
            return;
        }
        widgetModel.selected = val;
        domWidgetSelected.style.display = val ? "block" : "none";
        widgetModel.onChange && widgetModel.onChange(widgetModel.selected);
    };

    domContainer.getSelected = function(){
        return widgetModel.selected;
    };

    domContainer.addEventListener("click", function(){
        domContainer.toggleSelected();
    });

    slayOne.widgets.clickable(domContainer);

    if(options && options.tip) {
        var tipAlignOption = (options && options.tipAlign) ? options.tipAlign : "center";
        if(options && options.tipMultiline) {
            var tipWidthOption = (options && options.tipWidth) ? options.tipWidth : "200px";
            slayOne.widgets.tooltip(domContainer, {
                tip: options.tip,
                align: tipAlignOption,
                multiline: true,
                width: tipWidthOption
            });
        } else {
            slayOne.widgets.tooltip(domContainer, {
                tip: options.tip,
                align: tipAlignOption
            });
        }
    }

    parentNode.appendChild(domContainer);

    return domContainer;
}

//export
if(!slayOne.widgets) {
    slayOne.widgets = {};
}

slayOne.widgets.checkbox = checkbox;

})(window, window.slayOne, window.document);//end main closure