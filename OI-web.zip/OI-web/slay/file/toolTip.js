(function(window, slayOne, document){

/**
 * Tooltip
 *
 * @param parentNode: dom element to append to
 * @param options:
 *                  tip: tip content
 *                  multiline: true | false, default false
 *                  align: left | center | right, default left
 *                  verticalAlign: top | bottom, default bottom
 *                  (multiline:true) width: css str, default 200px
 */
function tooltip(parentNode, options) {
    
    var domTip = parentNode.querySelector(".standardTooltipContainer");
    if(!domTip) {
        domTip = document.createElement("div");

        var finalClassName = "standardTooltipContainer";

        var verticalAlignOption = (options && options.verticalAlign) ? options.verticalAlign : "bottom";

        if(verticalAlignOption == "top") {
            finalClassName += " standardTooltipContainerOnTop";
        }

        domTip.className = finalClassName;
        domTip.style.display = "none";
        parentNode.appendChild(domTip);
        parentNode.addEventListener("mouseover", function(){
            domTip.style.display = "block";    
        });
        parentNode.addEventListener("mouseout", function(){
            domTip.style.display = "none";
        });
    }

    var tooltipClassName = 'standardTooltip';

    var isMultiline = (options && options.multiline) ? options.multiline : false;
    if(isMultiline) {
        tooltipClassName = "standardTooltipMultiline";
        var tipWidth = (options && options.width) ? options.width : '200px';
        domTip.style.width = tipWidth;
        domTip.innerHTML = '<div class="' + tooltipClassName + '"><span>' + options.tip + '</span></div>';
    } else {
        domTip.innerHTML = '<div class="' + tooltipClassName + '"><span>' + options.tip + '</span></div>';
    }

    var alignment = "left";
    if(options && options.align) {
        alignment = options.align;
    }
    switch(alignment) {
        case "left": {
            domTip.style.left = '2px';
            domTip.style.right = 'auto';
            domTip.style.display = 'none';
            domTip.querySelector("." + tooltipClassName).style.left = '0';
            break;
        }
        case "center": {
            domTip.style.left = '50%';
            domTip.style.right = 'auto';
            domTip.style.display = 'none';
            domTip.querySelector("." + tooltipClassName).style.left = '-50%';
            break;
        }
        case "right": {
            domTip.style.right = '2px';
            domTip.style.left = 'auto';
            domTip.style.display = 'none';
            domTip.querySelector("." + tooltipClassName).style.right = "0";
            break;
        }
    }

    domTip.hide = function(){
        domTip.style.display = "none";
    };

    domTip.show = function(){
        domTip.style.display = "block";
    };

    parentNode.tipEffect = domTip;

    return domTip;
    
}

//export
if(!slayOne.widgets) {
    slayOne.widgets = {};
}

slayOne.widgets.tooltip = tooltip;

})(window, window.slayOne, window.document);//end main closure