function Interface(map)
{
	this.messages = []; // active chat messages are stores here

	document.getElementById('chatloginner').innerHTML = ""; // clear chatlog

	this.hoverWeapon = -1;
	this.hoverAbility = -1;
	this.buttons = [];
	this.top3 = [];
	this.chatlog = [];
	
	this.ladderEndAt = -1;
	this.ladderEndMsg = "You lose!";
	this.ladderMsgArr = ["Player1", "Player2", 3, 0];
	this.currentUpgChoices = [];
	this.oldUpgChoices = [];
	this.showOldUpgChoicesUntil = -9999;
	this.currentUpgChoicesStart = -9999;
	this.currentUpgChoicesEnd = -9999;
	this.selectedChoiceUntil = -9999;
	this.upgNotificationStart = -9999;
	this.upgNotificationHovered = false;
	this.cureButtonHovered = false;
	this.abilityPoints = 0;
	this.soulLvl = 1;
	this.soulsGot = 0;
	this.soulsNeeded = 0;
	this.hoverChoice = null;
	this.buttonIsHovered = false;
	this.lastChoiceIndex = -1;
	this.skipButtonHover = false;
	this.unskipButtonHover = false;
	this.upgradeChoicesAvailable = false;
	this.tutorialMessagesActive = [];
	this.lastTutorialMessagesStateChange = [];
	if(map && map.tutorialMessages)
		for(var i = 0; i < map.tutorialMessages.length; i++)
		{
			this.tutorialMessagesActive.push(false);
			this.lastTutorialMessagesStateChange.push(-99999);
		}

	if(isMobile)
	{
		this.buttons.push(new Button(1, -1.8, 1.5, 1.5, KEY.LEFT));
		this.buttons.push(new Button(2.6, -1.8, 1.5, 1.5, KEY.DOWN));
		this.buttons.push(new Button(4.2, -1.8, 1.5, 1.5, KEY.RIGHT));
		this.buttons.push(new Button(2.6, -3.4, 1.5, 1.5, KEY.UP));
	}

	// replay stuff
	this.replayLength = 0;
	this.replayLengthStr = "";
	this.replayTimer = 0;
	this.provisionalReplayPos = -1;
	this.fastForwardTo = -1;
	this.replayPlusHover = false;
	this.replayMinusHover = false;

	this.recordGIF = false;
	this.gifButtonIsHovered = false;
	this.gifProcessing = false;
};

Interface.prototype.analyzeReplay = function(r)
{
	var counter = 0;

	for(var i = 0; i < r.length; i++)
	{
		var splitMsg = r[i].split("$");
		if(splitMsg[0] == "upd")
			counter++;
	}

	this.replayLength = counter;
	this.replayLengthStr = ticks2TimeStr(this.replayLength);
};

Interface.prototype.setMainKillMsg = function(msg, color, cssAnimName, two, img)
{
	if(game.fastForward)
		return;

	var el = document.getElementById("mainKillMsg" + (two ? "2" : ""));

	var str = "";
	for(var i = 0; i < msg.length; i++)
		str += "<span class='noSelect' oncontextmenu='return false;'>" + msg.substr(i, 1) + "</span>";

	el.innerHTML = str;
	el.style.color = color;

	if(img)
	{
		el.innerHTML = "<span> &nbsp;</span>" + el.innerHTML;

		var scale = SCALE_FACTOR * 0.7;
		var canvas = document.createElement("canvas");
		canvas.className = "noSelect";
		canvas.width = Math.floor(scale * img.w);
		canvas.height = Math.floor(scale * img.h);
		canvas.getContext("2d").mozImageSmoothingEnabled = false;
        canvas.getContext("2d").msImageSmoothingEnabled = false;
		canvas.getContext("2d").imageSmoothingEnabled = false;
		canvas.getContext("2d").drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, 0, 0, canvas.width, canvas.height);
		el.insertBefore(canvas, el.firstChild);
	}

	var els = el.childNodes;
	for(var i = 0; i < els.length; i++)
	{
		els[i].style.animationName = cssAnimName;
		els[i].style.animationDelay = (i * 0.015) + "s";
		els[i].style.animationDuration = "5s";
	}
};

Interface.prototype.getFormattedPlayerName = function(player)
{
	if (!player) {
        return null;
    }
	var clan_tag = "";
	if (player.clan_tag && player.clan_tag.length > 0) {
		clan_tag = "[<span style='color: " + player.nameColorCode + ";'>" + player.clan_tag + "</span>] ";
	}

	var player_name = clan_tag + "<span style='color: " + player.nameColorCode + ";'>" + player.name + "</span>";

	return "<span style='background: " + player.getTeamColor() + ";'>" + player_name + "</span>";
};

Interface.prototype.addKillMsg = function(p1, p2, projectile, murderWeaponID, obj, splash)
{
	if(game.fastForward)
		return;

	var el = document.getElementById('killsDisplayDiv');
	var now = Date.now();

	var div = document.createElement("div");

	p1 = this.getFormattedPlayerName(p1);
	p2 = this.getFormattedPlayerName(p2);

	var canvas = document.createElement("canvas");
	var img = (projectile && projectile.weapon) ? imgCoords[projectile.weapon.img] : imgCoords.grenade1;
	var wpn = typeof murderWeaponID !== "undefined" ? weapons[murderWeaponID] : null;

	if(wpn)
		img = imgCoords[wpn.img];

	if(obj)
		img = imgCoords[obj.ability.icon];

	if(splash == "true")
		img = imgCoords.splashSingle;

	var scale = ((projectile && projectile.weapon) || wpn) ? (SCALE_FACTOR_BASE * 0.3) : (SCALE_FACTOR_BASE * 0.6);
	canvas.width = Math.floor(scale * img.w);
	canvas.height = Math.floor(scale * img.h);
	canvas.getContext("2d").mozImageSmoothingEnabled = false;
    canvas.getContext("2d").msImageSmoothingEnabled = false;
	canvas.getContext("2d").imageSmoothingEnabled = false;
	canvas.getContext("2d").drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, 0, 0, canvas.width, canvas.height);

	if(p1 == p2)
		div.innerHTML = slayOne.widgets.lang.get("game.msg.killed_self_broadcast", { playerName: p1 });
	else
		div.innerHTML = p1 + " <img src='" + canvas.toDataURL() + "' /> " + p2;

	div.className = "chatMsg noSelect killMsg";
	div.setAttribute("data-time", now);

	el.appendChild(div);
};

Interface.prototype.chatMsg = function(msg, color)
{
	if(game.fastForward)
		return;
	
	var el = document.getElementById('chatDisplayDiv');
	var el2 = document.getElementById('chatloginner');
	var now = Date.now();

	var playerID = msg.split("$")[0];
	var formattedPlayerName = null;

	if(playerID == -1)
		formattedPlayerName = "<span style='text-decoration: underline; color: red;'>Server</span>";
	else
	{
		var pl = game.getPlayerFromID(playerID);
		if(pl && pl.name && playerIsBeeingIgnored(pl.name))
			return;
		
		formattedPlayerName = this.getFormattedPlayerName(pl);
	}
	
	if(formattedPlayerName)
	{
		msg = formattedPlayerName + ": " + escapeHtml(msg.split("$").slice(1).join("$"));

		var div = document.createElement("div");
		var div2 = document.createElement("div");
		div.innerHTML = msg;
		div2.innerHTML = msg;
		div.className = "chatMsg noSelect";
		div2.className = "noSelect";
		div.setAttribute("data-time", now);

		el.appendChild(div);
		el2.appendChild(div2);

		soundManager.playSound(SOUND.CHAT1, undefined, undefined, 0.5);
	}
};

Interface.prototype.addMsg = function(msg, color)
{
	if(game.fastForward)
		return;

	var el = document.getElementById('chatDisplayDiv');
	var now = Date.now();

	var div = document.createElement("div");
	div.innerHTML = "<span style='color: " + color + ";'>" + msg + "</span>";
	div.className = "chatMsg noSelect";
	div.setAttribute("data-time", now);

	el.appendChild(div);
};

Interface.prototype.click = function()
{
	var now = Date.now();

	if(this.hoverWeapon >= 0 && game && !weaponsUnclickable)
	{
		game.switchWeapon(this.hoverWeapon);
		return true;
	}

	if(this.cureButtonHovered)
	{
		game.cureTick = 0;
		network.send("cure");
		return true;
	}

	if(this.hoverAbility >= 0 && game && !weaponsUnclickable)
	{
		this.initAbility(pl_active_abilities[this.hoverAbility], this.hoverAbility);
		return true;
	}

	if(this.hoverChoice && game && game.playingPlayer)
	{
		if(this.showOldUpgChoicesUntil < now)
		{
			this.currentUpgChoicesEnd = now + 200;
			network.send("upg$" + this.hoverChoice.index + "$" + this.hoverChoice.sub);
			this.lastChoiceIndex = this.hoverChoice.i;
			this.selectedChoiceUntil = now + 500;
			this.upgradeChoicesAvailable = false;
			this.abilityPoints -= this.hoverChoice.cost;
			soundManager.playSound(SOUND.BEEBEEP);
			game.playingPlayer.createAtributeEffect();
		}
		return true;
	}

	if(this.upgNotificationStart > 0 && this.upgNotificationHovered)
	{
		this.shopUpgrades();
		return true;
	}

	if(this.skipButtonHover)
	{
		this.hideUpgrades();
		return true;
	}

	if(this.unskipButtonHover)
	{
		this.shopUpgrades();
		return true;
	}

	if(this.provisionalReplayPos >= 0)
	{
		soundManager.playSound(SOUND.CLICK);
		this.replayJumpTo();
		return true;
	}

	if(this.gifButtonIsHovered)
	{
		soundManager.playSound(SOUND.CLICK);

		if(this.recordGIF)
			this.endGIF();

		else
			this.startGIF();

		return true;
	}

	if(this.replayPlusHover)
	{
		window.soundManager.playSound(SOUND.CLICK);
		changeReplaySpeed(1);
		return true;
	}

	if(this.replayMinusHover)
	{
		window.soundManager.playSound(SOUND.CLICK);
		changeReplaySpeed(-1);
		return true;
	}
};

Interface.prototype.shopUpgrades = function()
{
	this.currentUpgChoicesStart = Date.now();
	this.currentUpgChoicesEnd = this.currentUpgChoicesStart + 9999999;
	this.upgNotificationStart = -9999;
	soundManager.playSound(SOUND.BEEBEEP);
};

Interface.prototype.hideUpgrades = function()
{
	this.currentUpgChoicesEnd = Date.now() + 200;
	soundManager.playSound(SOUND.BEEBEEP);
	this.hoverChoice = null;
};

Interface.prototype.initAbility = function(ab, i)
{
	if(KeyManager.activeAbility == ab)
	{
		KeyManager.activeAbility = null;
		soundManager.playSound(SOUND.SWITCH);
	}
	
	else
	{
		var error = false;

		if(ab.energy > game.playingPlayerEnergy)
		{
			error = true;
			this.addMsg(slayOne.widgets.lang.get("game.msg.no_energy"), "red");
			soundManager.playSound(SOUND.NEGATIVE, 0.8);
		}

		else if(game.lastAbilityUses[i] + ab.cooldown > game.ticksCounter)
		{
			error = true;
			this.addMsg(slayOne.widgets.lang.get("game.msg.no_cooldown"), "red");
			soundManager.playSound(SOUND.NEGATIVE, 0.8);
		}

		else if(ab.type == "blink" && game.playingPlayer.carriesFlag())
		{
			error = true;
		 	this.addMsg(slayOne.widgets.lang.get("game.skills.teleport.disabled_in_ctf"), "red");
			soundManager.playSound(SOUND.NEGATIVE, 0.8);
		}

		if(ab.isInstant)
		{
			if(!error)
			{
				network.send("ab$" + ab.id);
				KeyManager.activeAbility = null;
			}
		}

		else
		{
			if(!error)
				soundManager.playSound(SOUND.SWITCH);
			KeyManager.activeAbility = ab;
		}
	}
};

Interface.prototype.killAllMsgs = function()
{
	var el = document.getElementById('chatDisplayDiv');
	while(el.childNodes.length > 0)
		el.removeChild(el.childNodes[0]);

	el = document.getElementById('killsDisplayDiv');
	while(el.childNodes.length > 0)
		el.removeChild(el.childNodes[0]);
};

Interface.prototype.refreshTop3 = function()
{
    var sort = game.type.winningCondition;
    
    if(!sort)
    	return;
    
	var playersByScore = game.players.sort(game.playerSortHandler);
	
	this.top3 = [];
	this.playingPlayerStats = null;
	var playingPlayerIsInTop3 = false;
    var myRank = 0;
    
	for(var i = 0; i < Math.min(3, playersByScore.length); i++)
	{
		this.top3[i] = {
			rank: i + 1,
			id : playersByScore[i].id,
			team: playersByScore[i].team,
			name: playersByScore[i].name,
			clan: playersByScore[i].clan_tag,
			souls: playersByScore[i][sort]
		};

		if(game.playingPlayer == playersByScore[i]) {
            playingPlayerIsInTop3 = true;
            myRank = i + 1;
		}
	}
	
	if(game && game.playingPlayer && !playingPlayerIsInTop3)
		for(i = 0; i < playersByScore.length; i++)
			if(playersByScore[i] == game.playingPlayer) {
				myRank = i + 1;
                this.top3.push({
					rank: myRank,
                    id: game.playingPlayer.id,
                    team: game.playingPlayer.team,
                    clan: game.playingPlayer.clan_tag,
                    name: game.playingPlayer.name,
                    souls: game.playingPlayer[sort]
                });
                break;
			}
	
    return myRank;
};

Interface.prototype.presentUpgChoice = function(splitMsg)
{
	var now = Date.now();

	if(this.currentUpgChoicesEnd + 500 > now)
	{
		this.oldUpgChoices = this.currentUpgChoices;
		this.showOldUpgChoicesUntil = now + 500;
		this.currentUpgChoicesStart = now - 1000;
		this.currentUpgChoicesEnd = now + 9999999;
		this.upgNotificationStart = -9999;
	}

	else
		this.upgNotificationStart = now;

	this.currentUpgChoices = [];
	this.abilityPoints = splitMsg[1];

	this.refreshSouls(parseInt(splitMsg[2]));
	if (game.playingPlayer) {
		game.playingPlayer.souls = parseInt(parseInt(splitMsg[2]));
		game.playingPlayer.soulLvl = getLvlFromSouls(parseInt(splitMsg[2]));
	}

	var k = 0;
	for(var i = 3; i < splitMsg.length; i += 3)
	{
		var upg = abilities[splitMsg[i]];

		var maxLvl = (splitMsg[i + 1] != "-1") ? 5 : 10;

		if(splitMsg[i + 1] == "-1" && upg.maxLvl)
			maxLvl = upg.maxLvl;

		else if(splitMsg[i + 1] != "-1" && upg.levelUpMaxUpgLvl && upg.levelUpMaxUpgLvl[splitMsg[i + 1]])
			maxLvl = upg.levelUpMaxUpgLvl[splitMsg[i + 1]];

		this.currentUpgChoices.push({
			img: imgCoords[upg.icon],
			text: upg.name + (splitMsg[i + 1] != "-1" ? (" - " + upg.levelUpFieldsName[splitMsg[i + 1]]) : ""),
			cost: splitMsg[i + 1] != "-1" ? upg.levelUpCost[splitMsg[i + 1]] : upg.cost,
			index: splitMsg[i],
			sub: splitMsg[i + 1],
			lvl: parseInt(splitMsg[i + 2]),
			maxLvl: maxLvl,
			i: k
		});

		k++;
	}

	if(this.currentUpgChoices.length == 0)
		this.upgNotificationStart = -9999;

	this.upgradeChoicesAvailable = this.currentUpgChoices.length > 0;
};

Interface.prototype.refreshSouls = function(souls)
{
	this.soulLvl = getLvlFromSouls(souls);
	var lowBorder = getCrystalsRequiredForLvl(this.soulLvl);
	var highBorder = getCrystalsRequiredForLvl(this.soulLvl + 1);
	this.soulsGot = souls - lowBorder;
	this.soulsNeeded = highBorder - lowBorder;
};

Interface.prototype.draw = function(exactTicks)
{
	var now = Date.now();

	// kill old chat messages
	var el = document.getElementById('chatDisplayDiv');
	var els = el.childNodes;
	for(var i = 0; i < els.length; i++)
		if(els[i].getAttribute("data-time") < now - 10000 || i < els.length - 10)
			el.removeChild(els[i]);

	el = document.getElementById('killsDisplayDiv');
	var els = el.childNodes;
	for(var i = 0; i < els.length; i++)
		if(els[i].getAttribute("data-time") < now - 10000 || i < els.length - 10)
			el.removeChild(els[i]);

	var scale = SCALE_FACTOR_BASE * 0.8;
	var scaleA = scale * 0.5;
	var scaleM = scale * 0.40;

	// tutorial messages
	if(game.map.tutorialMessages && game.playingPlayer)
		for(var i = 0; i < game.map.tutorialMessages.length; i++)
		{
			var msg = game.map.tutorialMessages[i];

			// check if in range
			if(tickDiff > 0)
			{
				var inRange = Math.sqrt(Math.pow(game.playingPlayer.x - msg.x, 2) + Math.pow(game.playingPlayer.y - msg.y, 2)) <= 3.5;

				if(this.tutorialMessagesActive[i] != inRange)
					this.lastTutorialMessagesStateChange[i] = game.ticksCounter;

				this.tutorialMessagesActive[i] = inRange;
			}

			// draw
			if(this.tutorialMessagesActive[i] || (this.lastTutorialMessagesStateChange[i] + 10) >= game.ticksCounter)
			{
				var msg_alpha = 1;

				if((this.lastTutorialMessagesStateChange[i] + 20) >= game.ticksCounter)
				{
					msg_alpha = Math.min(Math.max((game.ticksCounter - this.lastTutorialMessagesStateChange[i]) / 10, 0.05), 0.95);

					if(!this.tutorialMessagesActive[i])
						msg_alpha = 1 - msg_alpha;
				}

				var x = g2rx(msg.x);
				var y = g2ry(msg.y - 3);
				var textW = SCALE_FACTOR_BASE * 78;
				c.globalAlpha = msg_alpha;

				var img = imgCoords.speech;
				c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, x - 90 * SCALE_FACTOR_BASE * 0.5, y - 10 * SCALE_FACTOR_BASE, 90 * SCALE_FACTOR_BASE, img.h * SCALE_FACTOR_BASE);

				// img
				if(msg.img && imgCoords[msg.img])
				{
					img = imgCoords[msg.img];
					var scaleImg = Math.min(16 / img.w, 16 / img.h) * SCALE_FACTOR_BASE;
					c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, x - 76 * SCALE_FACTOR_BASE * 0.5, y + SCALE_FACTOR_BASE * 6 - img.h * 0.5 * scaleImg, img.w * scaleImg, img.h * scaleImg);
					textW -= (img.w) * scaleImg + SCALE_FACTOR_BASE * 4;
					x = x + (-textW + SCALE_FACTOR_BASE * 78) * 0.5;
				}

				c.globalAlpha = 1;
				drawText(c, F_(msg.msg), "white", SCALE_FACTOR_BASE * 3.5, x, y, textW, "center", msg_alpha, "rgba(0, 0, 0, 0.0)", SCALE_FACTOR_BASE * 5, null, null, null, "Verdana, Geneva, Arial, Helvetica, sans-serif");
				gaEventOnce('tutorial-step-' + msg.msg);
			}
		}

	var buttonAlpha = weaponsUnclickable ? 0.7 : 1.0;

	var wpns = (game && game.playingPlayerIsZombie) ? [weapons[12]] : weapons;

	// weapon menue
	if(game && game.playingPlayer && (game.playingPlayer.weapon || game.playingPlayerIsZombie) && !game.playingPlayer.dieAt)
	{
		var button_img = imgCoords.weaponFrame2;

		var x1 = WIDTH - (button_img.w + 1) * scaleM;
		var y1 = HEIGHT - (button_img.h + 1) * scaleM;

		this.hoverWeapon = -1;

		var img2 = imgCoords.weaponFrameCurrent;

		for(var i = 0; i < wpns.length; i++)
		{
			var wpn = wpns[wpns.length - i - 1];

			var totalAmmo = game.playingPlayerClips[wpn.id] + game.playingPlayerAmmo[wpn.id];

			if(((totalAmmo > 0 || game.playingPlayer.weapon == wpn) && !wpn.noWeapon) || (wpn == weapons[12] && game.playingPlayerIsZombie))
			{
				button_img = (totalAmmo > 0 || wpn == weapons[12]) ? imgCoords.weaponFrame2Green : imgCoords.weaponFrame2;
				var sheet = (totalAmmo > 0 || wpn == weapons[12]) ? imgs.miscSheet : imgs.miscSheetGrey;

				c.globalAlpha = buttonAlpha;

				// button
				c.drawImage(sheet, button_img.x, button_img.y, button_img.w, button_img.h, x1, y1, button_img.w * scaleM, button_img.h * scaleM);

				// current frame
				if(game.playingPlayer.weapon == wpn || wpn == weapons[12])
					c.drawImage(imgs.miscSheet, img2.x, img2.y, img2.w, img2.h, x1 - 3 * scaleM, y1 - 3 * scaleM, img2.w * scaleM, img2.h * scaleM);

				// wpn img
				var wpn_img = imgCoords[wpn.img];
				c.drawImage(sheet, wpn_img.x, wpn_img.y, wpn_img.w, wpn_img.h, x1 + button_img.w * scaleM * 0.4 - wpn_img.w * 0.5 * scaleM * 1.3, y1 + (button_img.h - 3) * scaleM - wpn_img.h * scaleM * 1.3, wpn_img.w * scaleM * 1.3, wpn_img.h * scaleM * 1.3);

				// ammo img
				var ammo_img = imgCoords[wpn.ammoImgSmall];
				c.drawImage(sheet, ammo_img.x, ammo_img.y, ammo_img.w, ammo_img.h, x1 + button_img.w * scaleM * 0.25 - ammo_img.w * scaleM * 1.2, y1 + button_img.h * scaleM * 0.2 - ammo_img.h * 0.5 * scaleM * 1.2, ammo_img.w * scaleM * 1.2, ammo_img.h * scaleM * 1.2);

				// ammo
				var ammo = wpn.ammoSize ? (game.playingPlayerClips[wpn.id] + " (" + game.playingPlayerAmmo[wpn.id] + ")") : "INF";
				drawText(c, ammo, totalAmmo > 0 ? "#4FAC43" : "rgba(255, 255, 255, " + (buttonAlpha * 0.7) + ")", scaleM * 7.5, x1 + button_img.w * scaleM * 0.35, y1 + button_img.h * 0.55);

				// key
				if(wpn.id <= 9)
				{
					var key = commandKeys[COMMAND["WPN" + (wpn.id + 1)]];
					var color = KeyManager.keys[key] ? "rgba(100, 170, 110, " + (buttonAlpha * 0.8) + ")" : "rgba(255, 255, 255, " + (buttonAlpha * 0.8) + ")";
					drawText(c, "[" + keyNames[key] + "]", color, scaleM * 6, x1 + button_img.w * scaleM * 0.8, y1 + button_img.h * scaleM * 0.8, "right");
				}

				c.globalAlpha = 1;

				// hover
				if(!weaponsUnclickable && KeyManager.x >= x1 && KeyManager.y >= y1 && KeyManager.y <= y1 + button_img.h * scaleM)
				{
					this.hoverWeapon = wpn.id;

					c.fillStyle = "rgba(0, 0, 0, 0.8)";
					c.fillRect(WIDTH - 100 * scale, HEIGHT - 80 * scale, 60 * scale, 50 * scale);

					drawText(c, wpn.name, "white", scale * 4, WIDTH - 95 * scale, HEIGHT - 74 * scale, scale * 200, "left", 1, null, null, scale * 50);
					drawText(c, wpn.description, "#D4D4D4", scale * 3, WIDTH - 95 * scale, HEIGHT - 64 * scale, scale * 50, "left", 1, null, scale * 3.5);

					// hover frame
					c.globalAlpha = 0.5;
					c.drawImage(imgs.miscSheet, img2.x, img2.y, img2.w, img2.h, x1 - 3 * scaleM, y1 - 3 * scaleM, img2.w * scaleM, img2.h * scaleM);
					c.globalAlpha = 1;
				}

				y1 -= (button_img.h + 2) * scaleM;
			}
		}
	}

	var now = Date.now();

	// replay speed display
	if(window.lastReplaySpeedChange + 2000 > now)
	{
		var alpha_ = Math.min((window.lastReplaySpeedChange + 2000 - now) / 750, 1);
		drawText(c, "Speed x" + window.replayOption.display, "#FFD155", FIELD_SIZE_BASE * 0.35, WIDTH - SCALE_FACTOR_BASE * 7, HEIGHT - SCALE_FACTOR_BASE * 10, 500, "right", alpha_);
	}

	// ability msg
	if(game.playingPlayer && KeyManager.activeAbility && KeyManager.activeAbility.activeMsg)
		drawText(c, KeyManager.activeAbility.activeMsg, "#C0EDBA", FIELD_SIZE_BASE * 0.4, WIDTH * 0.5, HEIGHT * 0.1, WIDTH - 20, "center", 0.8, "rgba(255, 255, 255, 0.3)", FIELD_SIZE_BASE * 0.45);

	// abilities
	this.hoverAbility = -1;
	if(game && game.playingPlayer && !game.playingPlayer.dieAt)
		for(var i = 0; i < pl_active_abilities.length; i++)
			if(pl_active_abilities[i])
			{
				c.globalAlpha = buttonAlpha;
				var a = pl_active_abilities[i];

				// button
				var button_img = game.playingPlayerEnergy >= a.energy ? imgCoords.abilityFrameGreen : imgCoords.abilityFrame;
				var x1 = WIDTH - scaleA * (button_img.w + 1) * (pl_active_abilities.length - i) - (imgCoords.weaponFrame.w + 6) * scaleM;
				var y1 = HEIGHT - (button_img.h + 1) * scaleA;
				var sheet = (a.energy <= game.playingPlayerEnergy && game.lastAbilityUses[i] + a.cooldown <= game.ticksCounter) ? imgs.miscSheet : imgs.miscSheetGrey;
				c.drawImage(sheet, button_img.x, button_img.y, button_img.w, button_img.h, x1, y1, button_img.w * scaleA, button_img.h * scaleA);

				var img = imgCoords[a.icon];
				var imgScale = ((button_img.w - 6) * scaleA) / Math.max(img.w, img.h);
				var x = x1 + (button_img.w * scaleA - img.w * imgScale) / 2;
				var y = y1 + (button_img.h * scaleA - img.h * imgScale) * 0.2;
				c.drawImage(sheet, img.x, img.y, img.w, img.h, x, y, img.w * imgScale, img.h * imgScale);

				// key
				var key = commandKeys[COMMAND["ABILITY" + (i + 1)]];
				var color = KeyManager.keys[key] ? "rgba(100, 170, 110, " + (buttonAlpha * 0.8) + ")" : "rgba(255, 255, 255, " + (buttonAlpha * 0.7) + ")";
				drawText(c, getKeyName(key), color, scale * 3.5, x1 + button_img.w * scaleA * 0.5, y1 + scaleA * 38, button_img.w, "center");

				// hover
				if(!weaponsUnclickable && KeyManager.x > x1 && KeyManager.x < (x1 + button_img.w * scaleA) && KeyManager.y > (HEIGHT - (button_img.h + 1) * scaleA))
				{
					this.hoverAbility = i;

					c.globalAlpha = 0.3;
					c.drawImage(imgs.miscSheetWhite, button_img.x, button_img.y, button_img.w, button_img.h, x1, y1, button_img.w * scaleA, button_img.h * scaleA);
					c.globalAlpha = 1;

					c.fillStyle = "rgba(0, 0, 0, 0.8)";
					c.fillRect(WIDTH - 100 * scale, HEIGHT - 65 * scale, scale * 65, scale * 35);

					drawText(c, a.name, "white", scale * 4, WIDTH - scale * 96, HEIGHT - 58 * scale);
					drawText(c, slayOne.widgets.lang.get("game.skills.misc.energy_cost", { energy: a.energy }), "#DD52CE", scale * 3, WIDTH - scale * 96, HEIGHT - 52 * scale, scale * 90, "left");
					drawText(c, a.description, "#D4D4D4", scale * 3, WIDTH - scale * 96, HEIGHT - 45 * scale, scale * 55, "left", 1, null, scale * 3.5);
				}

				// cooldown
				var cd = game.lastAbilityUses[pl_active_abilities[0] == a ? 0 : 1] + a.cooldown - game.ticksCounter;
				if(cd > 0)
					drawText(c, Math.floor(cd / 20).toString(), "red", scale * 9, x1 + button_img.w * scaleA * 0.5, y1 + scaleA * 25, button_img.w, "center", 1, "rgba(0, 0, 0, 0.65)", button_img.h);
			}

	// invincible counter
	if(game.playingPlayer && game.playingPlayer.invincibleUntil > game.ticksCounter && game.ticksCounter > 0)
		drawText(
			c,
			slayOne.widgets.lang.get("game.msg.invincible", { seconds: Math.ceil((game.playingPlayer.invincibleUntil - game.ticksCounter) / 20) }),
			"#dbe0be",
			FIELD_SIZE_BASE * 0.2,
			WIDTH * 0.5,
			HEIGHT * 0.85,
			WIDTH - 20,
			"center",
			0.8,
			"rgba(255, 255, 255, 0.2)",
			FIELD_SIZE_BASE * 0.3
		);

	var yText = 7.5 * scale;

	// team souls
	if(game && game.type.team && game.type.souls)
	{
		// souls img
		var scaleTS = scale * 0.9;
		var soulsImg = imgCoords.souls;
		c.drawImage(imgs.miscSheet, soulsImg.x, soulsImg.y, soulsImg.w, soulsImg.h, WIDTH * 0.5 - soulsImg.w * 0.5 * scaleTS, 1 * scaleTS, soulsImg.w * scaleTS, soulsImg.h * scaleTS);

		drawText(c, game.scoreTeam1, "#A13232", scale * 6, WIDTH * 0.5 - (soulsImg.w * 0.5 + 3) * scaleTS, yText + 2 * scale, scale * 70, "right", 1, "rgba(0, 0, 0, 0.3)", scale * 7);
		drawText(c, game.scoreTeam2, "#1B698E", scale * 6, WIDTH * 0.5 + (soulsImg.w * 0.5 + 3) * scaleTS, yText + 2 * scale, scale * 70, "left", 1, "rgba(0, 0, 0, 0.3)", scale * 7);

		yText += 11 * scale;
	}

	// game timer
	if(game.roundTime > 0 && (game.map.special != "tutorial1" || game.ticksCounter >= (game.roundTime - 20 * 60)))
	{
		var str = "";

		var ongoing;
		if(game.ticksCounter < 0)
		{
            str = Math.floor(-game.ticksCounter / 20);
            ongoing = false;
		}
		else
		{
            str = ticks2TimeStr(game.roundTime - game.ticksCounter);
            ongoing = true;
		}

		F$('rankInGame').refreshTime(ongoing, str);

		drawText(c, str, "rgba(255, 255, 255, 0.7)", scale * 5.5, WIDTH / 2, yText, WIDTH * 0.9, "center");

		yText += 6 * scale;
	}

	if (game.fps) {
		var fpsFontSize = scale * 4.5;
		drawText(c, 'FPS: ' + game.fps, fpsColor(game.fps), fpsFontSize, 10, 100, WIDTH * 2, 'left');
		if (game.fpsAvg) {
			drawText(c, ' (' + game.fpsAvg + ')', fpsColor(game.fpsAvg), fpsFontSize, 10 + fpsFontSize * 4.5, 100, WIDTH * 2, 'left');
		}
	}

	if (game.type.coopZombieMode) {
		var alive = 0;
		for (var p of game.players) {
			if (p && !p.isHumanZombie) {
				alive++;
			}
		}
		drawText(c, 'Alive: ' + alive + ' / ' + game.players.length, pingColor(alive > 3 ? 1 : 999), fpsFontSize, 10, 130, WIDTH * 2, 'left');
	}

    var scanMsg = function (text, color) {
		drawText(
			c,
            text,
            color,
			FIELD_SIZE_BASE * 0.3,
			WIDTH * 0.5,
			yText + 2 * scale,
			WIDTH - 20,
			"center"
		);
    };

	// scan msg
    if(game.playingPlayer && !game.playingPlayer.dieAt && game.showEnemiesOnMinimapUntil >= game.ticksCounter)
		scanMsg(
			slayOne.widgets.lang.get("game.skills.scan.countdown", { seconds: Math.floor((game.showEnemiesOnMinimapUntil - game.ticksCounter) / 20) }),
			"rgba(0, 255, 6, 0.7)"
		);
	
    else if(game && game.type.flag)
		scanMsg(
			slayOne.widgets.lang.get(game.getFlagText()),
			"rgba(255, 246, 173, " + (0.55 + Math.sin(exactTicks * 0.4) * 0.15) + ")"
		);
	
    else if(game && game.type.coopZombieMode)
		scanMsg(
			game.getZombieCoopText(),
			"rgba(255, 246, 173, " + (0.55 + Math.sin(exactTicks * 0.4) * 0.15) + ")"
		);
	
	if(game.ticksCounter < 0)
		drawText(c, game.victoryMsg, "rgba(255, 255, 255, 0.7)", scale * 7.0, WIDTH / 2, 17 * SCALE_FACTOR_BASE, WIDTH * 0.9, "center");

	if(game.ticksCounter < 0)
	    F$('rankInGame').setVictoryMessage(game.victoryMsg);
	else
        F$('rankInGame').setVictoryMessage("");

	scale *= 0.7;

	// upgrades
	this.hoverChoice = null;
	this.upgNotificationHovered = false;
	this.skipButtonHover = false;
	this.unskipButtonHover = false;
	var upgChoices = this.showOldUpgChoicesUntil >= now ? this.oldUpgChoices : this.currentUpgChoices;
	if(game && game.playingPlayer && game.type.souls && game.ticksCounter > 0)
	{
		var img = imgCoords.newStatsFrame;
		var img2 = imgCoords.soulsBar;
		var img3 = imgCoords.hpBar1;
		var img4 = imgCoords.energyBar;

		y = HEIGHT - (img.h + 1) * scale;
		x = 1 * scale;

		c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, x, y, img.w * scale, img.h * scale);
		drawText(c, this.soulLvl, "#e1f063", scale * 8, x + 16 * scale, y + 14 * scale, 24 * scale, "right", 1, null, null, 10 * scale); // soul lvl
		drawText(c, game.playingPlayer.unsafeName, "#b9cc8d", scale * 8, x + 20 * scale, y + 14 * scale, 100 * scale, "left", 1, null, null, scale * 42); // player name
		drawText(c, game.playingPlayer.souls, "#b4b7b8", scale * 7, x + 18 * scale, y + 29 * scale, 100 * scale, "left", 1, null, null, 16 * scale); // souls total
		drawText(c, this.abilityPoints, "#5cc3ef", scale * 7, x + 46 * scale, y + 29 * scale, 100 * scale, "left", 1, null, null, 16 * scale); // ability points / crystals
		c.drawImage(imgs.miscSheet, img2.x, img2.y, img2.w, img2.h, x + 69 * scale, y + 5 * scale, 73 * scale * (this.soulsGot / this.soulsNeeded), 10 * scale); // souls bar
		drawText(c, this.soulsGot + " / " + this.soulsNeeded, "#d0e661", scale * 8, x + 106 * scale, y + 14 * scale, 84 * scale, "center"); // souls got / needed
		c.drawImage(imgs.miscSheet, img3.x, img3.y, img3.w, img3.h, x + 69 * scale, y + 20 * scale, 73 * scale * (game.playingPlayer.hp / game.playingPlayer.maxHP), 5 * scale); // hp bar
		drawText(c, Math.ceil(game.playingPlayer.hp) + " / " + Math.ceil(game.playingPlayer.maxHP), "white", scale * 6, x + 106 * scale, y + 25 * scale, 84 * scale, "center", 1, null, null, null, "black"); // hp text
		c.drawImage(imgs.miscSheet, img4.x, img4.y, img4.w, img4.h, x + 69 * scale, y + 28 * scale, 73 * scale * (game.playingPlayerEnergy / 100), 2 * scale); // energy bar

		img = imgCoords.newUpgFrame;
		img2 = imgCoords.newUpgFrameWhite;
		img3 = imgCoords.newUpgFrameYellow;
		y -= (img.h + 1) * scale;

		if(game.playingPlayer.dieAt)
			return;

		if(this.upgNotificationStart > 0)
		{
			var nr = ((game.ticksCounter / 3) % 3) + 1;
			img = imgCoords["newUps" + Math.floor(nr)];

			var age = now - this.upgNotificationStart;
			var h = Math.min(img.h, age / 400 * img.h);

			c.globalAlpha = 1 - (nr % 1);
			c.drawImage(imgs.miscSheet, img.x, img.y, img.w, h, x, y, img.w * scale, h * scale);

			img = imgCoords["newUps" + ((Math.floor(nr) % 3) + 1)];

			c.globalAlpha = nr % 1;
			c.drawImage(imgs.miscSheet, img.x, img.y, img.w, h, x, y, img.w * scale, h * scale);
			c.globalAlpha = 1;

			drawText(c, F_("game.msg.choose_upgrade"), "#4BA6FA", scale * 8, x + 5 * scale, y + 10 * scale, 200 * scale, "left", 1, null, null, scale * 100);
			drawText(c, F_("game.msg.upgrade_shortcut", {key: keyNames[commandKeys[COMMAND.PICK_UPGRADE]]}), "#4BA6FA", scale * 6, x + 6 * scale, y + 21 * scale, 200 * scale, "left", 1, null, null, scale * 100);

			// hover
			if(KeyManager.x <= img.w * scale && KeyManager.y >= y)
			{
				this.upgNotificationHovered = true;

				nr = ((game.ticksCounter / 5) % 4) + 1;
				img = imgCoords["newUpsFrame" + Math.floor(nr)];

				c.globalAlpha = 1 - (nr % 1);
				c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, x - 1 * scale, y - 2 * scale, img.w * scale, img.h * scale);

				img = imgCoords["newUpsFrame" + ((Math.floor(nr) % 4) + 1)];

				c.globalAlpha = nr % 1;
				c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, x - 1 * scale, y - 2 * scale, img.w * scale, img.h * scale);
				c.globalAlpha = 1;
			}
		}

		else if(upgChoices.length > 0)
		{
			if(this.currentUpgChoicesStart + 350 > now)
				x -= scale * img.w * (this.currentUpgChoicesStart + 350 - now) / 350;

			if(this.currentUpgChoicesEnd < now)
				x -= scale * img.w * (now - this.currentUpgChoicesEnd) / 350;

			for(var i = 0; upgChoices && i < upgChoices.length; i++)
			{
				var choice = upgChoices[i];

				var img5 = choice.img;
				var abImgScale = scale * 16 / Math.max(img5.w, img5.h);

				c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, x, y, img.w * scale, img.h * scale);
				c.drawImage(imgs.miscSheet, img5.x, img5.y, img5.w, img5.h, x + img.h * scale / 2 - img5.w * abImgScale / 2 - scale * 1, y + img.h * scale / 2 - img5.h * abImgScale / 2, img5.w * abImgScale, img5.h * abImgScale); // upg img
				drawText(c, choice.cost, "#5cc3ef", scale * 7.5, x + 108 * scale, y + 18 * scale); // cost
				drawText(c, choice.text, "#FFFDC0", scale * 6.5, x + 24 * scale, y + 22 * scale, 150 * scale, "left", 1, null, null, scale * 70); // name

				// lvl
				for(var k = 0; k < choice.maxLvl; k++)
				{
					c.fillStyle = k < choice.lvl ? "#65E054" : "rgba(0, 0, 0, 0.8)";
					c.fillRect(x + 24 * scale + k * 11 * scale, y + 4 * scale, 10 * scale, 2 * scale);
				}

				// selected choice
				if(this.lastChoiceIndex == i && this.selectedChoiceUntil > now)
				{
					if(game.ticksCounter % 2 == 1)
					{
						c.globalAlpha = 0.75;
						c.drawImage(imgs.miscSheet, img3.x, img3.y, img3.w, img3.h, x, y, img3.w * scale, img3.h * scale);
						c.globalAlpha = 1;
					}
				}

				// hover
				else if(KeyManager.x <= x + img.w * scale && KeyManager.y >= y && KeyManager.y <= y + img.h * scale)
				{
					this.hoverChoice = choice;
					c.globalAlpha = 0.4;
					c.drawImage(imgs.miscSheetWhite, img.x, img.y, img.w, img.h, x, y, img.w * scale, img.h * scale);
					c.globalAlpha = 1;
				}

				y -= (img.h + 1) * scale;
			}

			// hide / skip buton
			img2 = imgCoords.upgSkip;
			x += 5 * scale;
			y += (img.h + 1) * scale - img2.h * scale;
			c.drawImage(imgs.miscSheet, img2.x, img2.y, img2.w, img2.h, x, y, img2.w * scale, img2.h * scale);
			drawText(c, F_("game.msg.hideskip_shortcut", {key: keyNames[commandKeys[COMMAND.PICK_UPGRADE]]}), "#304420", scale * 6.5, x + 17 * scale, y + 12 * scale, scale * 100, "left", 1, null, null, scale * 62, "#688551"); // cost

			if((KeyManager.x <= x + img2.w * scale && KeyManager.y >= y && KeyManager.y <= y + img2.h * scale) || KeyManager.keys[commandKeys[COMMAND.PICK_UPGRADE]])
			{
				c.globalAlpha = 0.3;
				c.drawImage(imgs.miscSheetWhite, img2.x, img2.y, img2.w, img2.h, x, y, img2.w * scale, img2.h * scale);
				c.globalAlpha = 1;
				this.skipButtonHover = true;
			}

			// show ups again button
			if(this.currentUpgChoicesEnd + 200 < now && this.upgradeChoicesAvailable)
			{
				img2 = imgCoords.upgUnskip;
				x = 5 * scale;
				y = HEIGHT - (imgCoords.newStatsFrame.h + 1) * scale - img2.h * scale;

				c.drawImage(imgs.miscSheet, img2.x, img2.y, img2.w, img2.h, x, y, img2.w * scale, img2.h * scale);
				drawText(c, F_("game.msg.show_upgrades_shortcut", {key: keyNames[commandKeys[COMMAND.PICK_UPGRADE]]}), "#304420", scale * 6.5, x + 17 * scale, y + 12 * scale, scale * 200, "left", 1, null, null, scale * 64, "#688551"); // cost
				if((KeyManager.x <= x + img2.w * scale && KeyManager.y >= y && KeyManager.y <= y + img2.h * scale) || KeyManager.keys[commandKeys[COMMAND.PICK_UPGRADE]])
				{
					c.globalAlpha = 0.3;
					c.drawImage(imgs.miscSheetWhite, img2.x, img2.y, img2.w, img2.h, x, y, img2.w * scale, img2.h * scale);
					c.globalAlpha = 1;
					this.unskipButtonHover = true;
				}
			}
		}
	}

	if(window.tickDiff > 0 && this.recordGIF)
	{
		canvasGIF.width = canvasGIF.width;
		canvasGIF.getContext("2d").drawImage(canvas, 0, 0, canvas.width, canvas.height, 0, 0, canvasGIF.width, canvasGIF.height);

		var img = imgCoords.main_logo;
		canvasGIF.getContext("2d").drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, 2, canvasGIF.height - 2 - img.h, img.w, img.h);

		this.gif.addFrame(canvasGIF.getContext("2d"), {delay: 50, copy: true});
	}

	// cure button
	this.cureButtonHovered = false;
	if(game.cureTick && (!game.playingPlayer.isHumanZombie || game.cureTick < game.ticksCounter))
		game.cureTick = 0;

	if(game.cureTick)
	{
		var img = imgCoords.cureButton;
		var scaleC = 3.2 * 0.65;
		c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, scaleC * 100, 3 * scaleC, img.w * scaleC, img.h * scaleC);
		
		var text = slayOne.widgets.lang.get("game.buttons.cure");
		text += ' ( ' + Math.floor((game.cureTick - game.ticksCounter) / 20) + ' )';
		drawText(c, text, "white", scale * 8, scaleC * (100 + 0.5 * img.w), 24 * scaleC, scale * 200, "center");
		
		// hover
		if(KeyManager.x >= scaleC * 100 && KeyManager.x <= (img.w + 100) * scaleC && KeyManager.y <= img.h * scaleC)
		{
			this.cureButtonHovered = true;
			c.globalAlpha = 0.5;
			c.drawImage(imgs.miscSheetWhite, img.x, img.y, img.w, img.h, scaleC * 100, 3 * scaleC, img.w * scaleC, img.h * scaleC);
			c.globalAlpha = 1.0;
		}
	}

	// replay timeline
	this.replayPlusHover = false;
	this.replayMinusHover = false;
	if(game.replayMode && this.replayLength)
	{
		scale = SCALE_FACTOR_BASE * 0.8;

		var img = imgCoords.replayBar;
		var img2 = imgCoords.replayPos;

		var percDone = this.replayTimer / this.replayLength;
		var str = " " + ticks2TimeStr(this.replayTimer) + " / " + this.replayLengthStr;

		if(game.fastForward && this.fastForwardTo > 0)
			str += " (" + ticks2TimeStr(this.fastForwardTo) + ")";

		else
		{
			this.provisionalReplayPos = -1;
			var provisionalReplayPerc = -1;
			if(KeyManager.x <= (90 * scale) && KeyManager.y >= (HEIGHT - (img.h + 2) * scale))
			{
				provisionalReplayPerc = Math.min(Math.max((KeyManager.x / scale - 5) / 78, 0), 1);
				this.provisionalReplayPos = Math.floor(provisionalReplayPerc * this.replayLength);
				str += " (" + ticks2TimeStr(this.provisionalReplayPos) + ")";
			}
		}

		drawText(c, str, "white", scale * 6.0, 4 * scale, HEIGHT - (img.h + 6) * scale, scale * 200, "left", 1, "rgba(0, 0, 0, 0.5)", scale * 10);

		c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, scale * 2, HEIGHT - (img.h + 2) * scale, img.w * scale, img.h * scale);

		c.drawImage(imgs.miscSheet, img2.x, img2.y, img2.w, img2.h, scale * (5 + percDone * 78), HEIGHT - (img2.h + 2) * scale, img2.w * scale, img2.h * scale);

		if(game.fastForward && this.fastForwardTo > 0)
		{
			c.globalAlpha = 0.5;
			c.drawImage(imgs.miscSheet, img2.x, img2.y, img2.w, img2.h, scale * (5 + (this.fastForwardTo / this.replayLength) * 78), HEIGHT - (img2.h + 2) * scale, img2.w * scale, img2.h * scale);
			c.globalAlpha = 1;
		}

		else if(provisionalReplayPerc >= 0)
		{
			c.globalAlpha = 0.5;
			c.drawImage(imgs.miscSheet, img2.x, img2.y, img2.w, img2.h, scale * (5 + provisionalReplayPerc * 78), HEIGHT - (img2.h + 2) * scale, img2.w * scale, img2.h * scale);
			c.globalAlpha = 1;
		}

		img = imgCoords.replayPlusMinus;
		c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, scale * 90, HEIGHT - (img.h + 2) * scale, img.w * scale, img.h * scale);

		if(KeyManager.x >= (scale * 90) && KeyManager.x <= ((90 + img.w) * scale) && KeyManager.y >= (HEIGHT - (img.h + 2) * scale) && KeyManager.y <= (HEIGHT - (img.h + 2 - 9) * scale))
		{
			this.replayPlusHover = true;
			img2 = imgCoords.replayWhite;
			c.globalAlpha = 0.2;
			c.drawImage(imgs.miscSheet, img2.x, img2.y, img2.w, img2.h, scale * 90, HEIGHT - (img.h + 2) * scale, img2.w * scale, img2.h * scale);
			c.globalAlpha = 1;
		}

		if(KeyManager.x >= (scale * 90) && KeyManager.x <= ((90 + img.w) * scale) && KeyManager.y >= (HEIGHT - (img.h + 2 - 9) * scale))
		{
			this.replayMinusHover = true;
			img2 = imgCoords.replayWhite;
			c.globalAlpha = 0.2;
			c.drawImage(imgs.miscSheet, img2.x, img2.y, img2.w, img2.h, scale * 90, HEIGHT - (img.h + 2 - 9) * scale, img2.w * scale, img2.h * scale);
			c.globalAlpha = 1;
		}

		// record gif UI
		this.gifButtonIsHovered = false;
		if(!game.fastForward)
		{
			if(this.gifProcessing)
				drawText(c, " gif is being processed ...", "white", scale * 6.0, 4 * scale, HEIGHT - 38 * scale, scale * 200, "left", 1, "rgba(0, 0, 0, 0.5)", scale * 10);

			else
			{
				img = this.recordGIF ? imgCoords.stopGif : imgCoords.startGif;
				c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, scale * 2, HEIGHT - (34 + img.h) * scale, img.w * scale, img.h * scale);

				if(KeyManager.x <= ((img.w + 2) * scale) && KeyManager.y >= (HEIGHT - (img.h + 34) * scale) && KeyManager.y <= (HEIGHT - 34 * scale))
				{
					this.gifButtonIsHovered = true;
					img = imgCoords.whiteGif;
					c.globalAlpha = 0.2;
					c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, scale * 2, HEIGHT - (34 + img.h) * scale, img.w * scale, img.h * scale);
					c.globalAlpha = 1;
				}

				if(this.recordGIF)
					drawText(c, " recording ...", "white", scale * 6.0, (4 + img.w) * scale, HEIGHT - 38 * scale, scale * 200, "left", 1, "rgba(0, 0, 0, 0.5)", scale * 10);
			}
		}
	}
	
	// ladder result animation
	if(this.ladderEndAt > 0)
	{
		var age = (Date.now() - this.ladderEndAt) / 1000;
		var age2 = Math.min(age * 20.8, 500) ;
		
		var grad = c.createLinearGradient(0, HEIGHT * 0.2, 0, HEIGHT * 0.8);
		grad.addColorStop(0, "rgba(0, 0, 0, 0)");
		grad.addColorStop(0.4, "rgba(0, 0, 0, 0.5)");
		grad.addColorStop(0.6, "rgba(0, 0, 0, 0.5)");
		grad.addColorStop(1, "rgba(0, 0, 0, 0)");
		c.fillStyle = grad;
		c.fillRect(0, HEIGHT * 0.5 - SCALE_FACTOR_BASE * 15 * age2, WIDTH, SCALE_FACTOR_BASE * 30 * age2);
		
		var color = "rgba(100, 255, 100, " + Math.min(1, age * 2) + ")";
		if(this.ladderEndMsg == "You lose!")
			var color = "rgba(255, 100, 100, " + Math.min(1, age * 2) + ")";
		if(this.ladderEndMsg == "Draw!")
			var color = "rgba(255, 255, 100, " + Math.min(1, age * 2) + ")";
		
		var colorPoints = "rgba(100, 255, 100, " + (0.6 * Math.min(1, age * 2)) + ")";
		if(this.ladderEndMsg == "You lose!")
			var colorPoints = "rgba(255, 100, 100, " + (0.6 * Math.min(1, age * 2)) + ")";
		if(this.ladderEndMsg == "Draw!")
			var colorPoints = "rgba(255, 255, 100, " + (0.6 * Math.min(1, age * 2)) + ")";
		
		drawText(c, this.ladderEndMsg, color, SCALE_FACTOR_BASE * 11.0, WIDTH * 0.5, HEIGHT * 0.5 - SCALE_FACTOR_BASE * 3, WIDTH, "center");
		drawText(c, this.ladderMsgArr[0], "rgba(255, 255, 255, " + Math.min(1, age * 2) + ")", SCALE_FACTOR_BASE * 7.0, WIDTH * 0.5 - SCALE_FACTOR_BASE * 14, HEIGHT * 0.5 + SCALE_FACTOR_BASE * 9.6, WIDTH, "right");
		drawText(c, this.ladderMsgArr[2], "rgba(255, 255, 100, " + Math.min(1, age * 2) + ")", SCALE_FACTOR_BASE * 8.0, WIDTH * 0.5 - SCALE_FACTOR_BASE * 1.9, HEIGHT * 0.5 + SCALE_FACTOR_BASE * 10, WIDTH, "right");
		drawText(c, ":", "rgba(255, 255, 255, " + Math.min(1, age * 2) + ")", SCALE_FACTOR_BASE * 7.0, WIDTH * 0.5, HEIGHT * 0.5 + SCALE_FACTOR_BASE * 9.6, WIDTH, "center");
		drawText(c, this.ladderMsgArr[1], "rgba(255, 255, 255, " + Math.min(1, age * 2) + ")", SCALE_FACTOR_BASE * 7.0, WIDTH * 0.5 + SCALE_FACTOR_BASE * 14, HEIGHT * 0.5 + SCALE_FACTOR_BASE * 9.6, WIDTH);
		drawText(c, this.ladderMsgArr[3], "rgba(255, 255, 100, " + Math.min(1, age * 2) + ")", SCALE_FACTOR_BASE * 8.0, WIDTH * 0.5 + SCALE_FACTOR_BASE * 2.9, HEIGHT * 0.5 + SCALE_FACTOR_BASE * 10, WIDTH);
		
		if(this.ladderMsgArr[4])
			drawText(c, this.ladderMsgArr[4], colorPoints, SCALE_FACTOR_BASE * 3.5, WIDTH * 0.5, HEIGHT * 0.5 + SCALE_FACTOR_BASE * 18, WIDTH, "center");
		
		var scale = SCALE_FACTOR_BASE;
		var lightScale = SCALE_FACTOR_BASE * 0.4;
		c.fillStyle = "white";
		var img = (this.ladderEndMsg == "You lose!") ? imgCoords.light_red : imgCoords.light_green;
		for(var x = WIDTH * 0.5; x > 0; x -= scale * 7)
		{
			c.globalAlpha = Math.max(1 - 5 * Math.abs(1 - (age - 0.4) - x / (WIDTH * 0.5)), 0);
			var yScale = Math.pow(Math.max(1 - 5 * Math.abs(1 - (age - 0.4) - x / (WIDTH * 0.5)), 0), 2) * scale * 2;
			
			c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, x - img.w * 0.5 * lightScale, HEIGHT * 0.5 - img.w * 0.5 * lightScale, img.w * lightScale, img.h * lightScale);
			c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, WIDTH - x - img.w * 0.5 * lightScale, HEIGHT * 0.5 - img.w * 0.5 * lightScale, img.w * lightScale, img.h * lightScale);
			
			c.fillRect(x - scale, HEIGHT * 0.5 - yScale, scale * 2, yScale * 2);
			c.fillRect(WIDTH - x - scale, HEIGHT * 0.5 - yScale, scale * 2, yScale * 2);
		}
		
		c.globalAlpha = 1;
	}
	
	if(game.type.lives && game.ticksCounter < 139 && this.ladderEndAt <= 0)
	{
		var arr = ["5", "4", "3", "2", "1", "Go!"];
		var str = arr[Math.floor(game.ticksCounter / 20)];
		var alpha = 0;
		
		if(str)
		{
			c.fillStyle = "rgba(0, 0, 0, 0.5)";
			c.fillRect(0, HEIGHT * 0.5 - SCALE_FACTOR_BASE * 20, WIDTH, SCALE_FACTOR_BASE * 40 + SCALE_FACTOR_BASE);
			
			var age = (game.ticksCounter / 20) % 1;
			alpha = 1;
			var color = "rgba(100, 255, 100, " + (1 - age * 0.3) + ")";
			drawText(c, str, color, SCALE_FACTOR_BASE * (11.0 + age * 4), WIDTH * 0.5, HEIGHT * 0.5 - SCALE_FACTOR_BASE * 2, WIDTH, "center");
		}
		
		else
		{
			var age = 1 - (game.ticksCounter % 20) / 20;
			alpha = Math.max(age * 0.5, 0);
			c.fillStyle = "rgba(0, 0, 0, " + Math.max(age * 0.5, 0) + ")";
			c.fillRect(0, HEIGHT * 0.5 - SCALE_FACTOR_BASE * 20, WIDTH, SCALE_FACTOR_BASE * 40 + SCALE_FACTOR_BASE);
		}
		
		if(game.players.length >= 2)
		{
			drawText(c, game.players[0].name, "rgba(255, 255, 255, " + alpha + ")", SCALE_FACTOR_BASE * 7.0, WIDTH * 0.5 - SCALE_FACTOR_BASE * 8, HEIGHT * 0.5 + SCALE_FACTOR_BASE * 9.6, WIDTH, "right");
			drawText(c, "vs", "rgba(255, 255, 100, " + alpha + ")", SCALE_FACTOR_BASE * 7.0, WIDTH * 0.5, HEIGHT * 0.5 + SCALE_FACTOR_BASE * 9.6, WIDTH, "center");
			drawText(c, game.players[1].name, "rgba(255, 255, 255, " + alpha + ")", SCALE_FACTOR_BASE * 7.0, WIDTH * 0.5 + SCALE_FACTOR_BASE * 8, HEIGHT * 0.5 + SCALE_FACTOR_BASE * 9.6, WIDTH);
			drawText(c, "First player who dies 5 times, loses.", "rgba(180, 180, 180, " + alpha + ")", SCALE_FACTOR_BASE * 3.0, WIDTH * 0.5, HEIGHT * 0.5 + SCALE_FACTOR_BASE * 17, WIDTH, "center");
		}
	}
	
	// mobile buttons
	if(isMobile)
		for(var i = 0; i < this.buttons.length; i++)
			this.buttons[i].draw();
};

Interface.prototype.startGIF = function()
{
	var relation = 700 / WIDTH;

	canvasGIF.width = WIDTH * relation;
	canvasGIF.height = HEIGHT * relation;

	canvasGIF.getContext("2d").mozImageSmoothingEnabled = false;
    canvasGIF.getContext("2d").msImageSmoothingEnabled = false;
	canvasGIF.getContext("2d").imageSmoothingEnabled = false;

	this.gif = new GIF({
		workers: 3,
		quality: 10,
		width: canvasGIF.width,
		height: canvasGIF.height,
		debug: true
	});

	this.recordGIF = true;
};

Interface.prototype.endGIF = function()
{
	this.recordGIF = false;
	this.gifProcessing = true;

	this.gif.on('finished', function(blob) {
		var d = new Date();
		saveAs(blob, "slay-one-gif-" + d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate() + ".gif");
		game.interface_.gif = null;
		game.interface_.gifProcessing = false;
	});

	this.gif.render();
};

Interface.prototype.replayJumpTo = function()
{
	if(this.provisionalReplayPos == this.replayTimer)
		return;

	if(this.provisionalReplayPos < this.replayTimer)
		startReplay();

	game.interface_.fastForwardTo = this.provisionalReplayPos;
	game.fastForward = true;
	window.oldReplayOptionsIndex = window.replayOptionsIndex;
	window.replayOptionsIndex = window.replayOptions.length - 1;
	window.replayOption = window.replayOptions[window.replayOptionsIndex];
};
