(function (window, slayOne, document) {
	
	var viewKey = "homeScreen";
	
	//cached DOM references
	var domMain = document.getElementById("homeUI");
	var domMainContent = document.getElementById("homeUIContent");
	var domAbilities = null;
	
	function renderButtonChangeSkins_(parentNode)
	{
		//button to click when user wants to change skins on their little dude
		var button = document.createElement("button");

		button.onclick = function () {
			if(playerData.authLevel >= 6)
				Skin.show();
		};

		button.id = "button_change_skins";
		button.className = "hatButton standardWell pixelated";
		button.style.position = "relative";

		// canvas used for animation in the button
		var canvas = document.createElement("canvas");

		// make it the same size as its parent
		canvas.style.width = '100%';
		canvas.style.height = '100%';

		button.appendChild(canvas);
		parentNode.appendChild(button);

		slayOne.widgets.hoverLight(button, {
			width: '120px',
			height: '118px',
			left: '-6px',
			top: '-6px'
		});

		slayOne.widgets.tooltip(button, {
			tip: playerData.authLevel >= 6 ? "Change skin" : "Register to change your skin",
			align: "center"
		});

		slayOne.widgets.clickable(button);

		// export global reference, to be checked in the main requestAnimationFrame loop, so that the animated little dude is updated in the same frame as the game in the background
		window.uiManager.canvasChangeSkinsButton = canvas;

		return button;
	}
	
	function renderButtonAbilities_(parentNode)
	{
		// importing global data and modules
		var imgs = window.imgs;
		var imgCoords = window.imgCoords;
		var abilities = window.abilities;
		var button = document.createElement("button");
		domAbilities = button;
		
		button.onclick = function() {
			if(playerData.authLevel >= 6)
				CustomBuild.show();
		};

		button.id = "ability_button_main";
		button.className = "standardWell pixelated";
		button.style.position = "relative";

		button.refreshView = Skin.refreshAbilitiesButton;

		button.refreshView(button);

		// done building, so add
		parentNode.appendChild(button);
	}

	var cachedSocialButtons = null;

	/**
	 * save doms so that they will not be initialized again, which causes some errors
	 */
	function collectSocialButtons() {
		cachedSocialButtons.container.removeChild(cachedSocialButtons.disc);
		cachedSocialButtons.container.removeChild(cachedSocialButtons.fb);
		cachedSocialButtons.container.removeChild(cachedSocialButtons.wiki);
		cachedSocialButtons.container.removeChild(cachedSocialButtons.rd);
		cachedSocialButtons.container.removeChild(cachedSocialButtons.fbw);
		cachedSocialButtons.container = null;
	}

	function renderSocialButton_(buttonClassName, openURL, tipLabel) {
		var domButton = document.createElement("div");
		domButton.className = "socialMediaBtn " + buttonClassName;
		domButton.onclick = function () {
			window.open(openURL, "_blank");
		};
		slayOne.widgets.hoverLight(domButton, {
			width: "46px",
			height: "50px"
		});
		
		if(tipLabel && tipLabel.length > 0)
			slayOne.widgets.tooltip(domButton, {
				tip: tipLabel,
				align: "center"
			});
		
		slayOne.widgets.clickable(domButton);
		return domButton;
	}

	/**
	 * Method renders all social media buttons, must be called AFTER @parentNode has already been appended to the DOM
	 *
	 * @param parentNode: dom element to append to
	 * @private
	 */
	function renderSocialMedia_(parentNode)
	{
		var domContainer = document.createElement("div");
		//the button positioning is a bit tough to control, so we put them in this extra container to make slight adjustment through CSS
		domContainer.className = "socialMediaContainer";

		var domYouTube;
		var domFacebookPage;
		var domTwitter;
		var domReddit;
		var domDisc;
		var domWiki;
		var domFacebookWidget;

		if(cachedSocialButtons)
		{
			domYouTube = cachedSocialButtons.yt;
			domFacebookPage = cachedSocialButtons.fb;
			domTwitter = cachedSocialButtons.twttr;
			domReddit = cachedSocialButtons.rd;
			domDisc = cachedSocialButtons.disc;
			domWiki = cachedSocialButtons.wiki;
			domFacebookWidget = cachedSocialButtons.fbw;
		}
		else
		{
			cachedSocialButtons = {};

			cachedSocialButtons.yt = domYouTube = renderSocialButton_("socialMediaYt", "https://www.youtube.com/channel/UCvfm6BNJ8tLJy2lZkaZTAFg?sub_confirmation=1", "Youtube");
			cachedSocialButtons.fb = domFacebookPage = renderSocialButton_("socialMediaFb", "https://www.facebook.com/slay.one.game/", "Facebook");
			cachedSocialButtons.twttr = domTwitter = renderSocialButton_("socialMediaTw", "https://twitter.com/slayoneofficial", "Twitter");
			cachedSocialButtons.rd = domReddit = renderSocialButton_("socialMediaRd", "https://www.reddit.com/r/slayone", "Reddit");
			cachedSocialButtons.disc = domDisc = renderSocialButton_("socialMediaDisc", "https://discordapp.com/invite/DTvcu44", "Discord");
			cachedSocialButtons.wiki = domWiki = renderSocialButton_("socialMediaWiki", "https://slayone.gamepedia.com/Slay.one_Wiki", "Wiki");
			
			domFacebookWidget = document.createElement("div");
			//adding facebook's special tag for its like/share button, which will be parsed by the "parse" method below
			domFacebookWidget.innerHTML = '<div class="fb-like" data-href="https://www.facebook.com/slay.one.game/" data-layout="button" data-action="like" data-size="small" data-show-faces="false" data-share="true"></div>';
			cachedSocialButtons.fbw = domFacebookWidget;
		}

		cachedSocialButtons.container = domContainer;
		domContainer.appendChild(domFacebookPage);
		domContainer.appendChild(domWiki);
		domContainer.appendChild(domReddit);
		domContainer.appendChild(domDisc);
		domContainer.appendChild(domFacebookWidget);

		//since we're added the facebook button dynamically, we call this method to parse the facebook-specific tag above
		if(!domFacebookWidget.widgetInited && window.FB)
			domFacebookWidget.widgetInited = true;
			try {
				window.FB.XFBML.parse(domFacebookWidget);
			} catch (e) {
			}

		parentNode.appendChild(domContainer);

	}

	function showNeedsLoginWindow()
	{
		slayOne.views.needsLoginScreen.render();
	}

	var levelBar;
	function renderLevelInfo_(parentNode)
	{
		levelBar = document.createElement("div");
		levelBar.className = "levelInfo";
		parentNode.appendChild(levelBar);
		refreshExp();
	}

	function refreshExp()
	{
		playerData.lvl = getLvlFromXp(playerData.xp);

		var xp1 = playerData.xp - getTotalXPRequiredForLvl(playerData.lvl);
		var xp2 = getXPRequiredForLvl(playerData.lvl + 1);
		var perc = Math.floor(xp1 * 100 / xp2);

		levelBar.innerHTML = '<div class="levelHeader">Level ' + playerData.lvl + '</div><div class="levelProgressBar"><div class="progressIndicator" style="width: ' + perc + '%;"></div></div>' +
			'<div class="standardTooltip">EXP: ' + xp1 + ' / ' + xp2 + '<br /><br />' + F_('home.tooltip.exp') + '</div>';
	}
	
	function renderWelcomeMessage_(parentNode)
	{
		var domWelcomeMsg = document.createElement('div');
		domWelcomeMsg.className = "homeWelcomeMsgWrapper";
		var str = "";
		str += '<div class="msgHead">' + slayOne.widgets.lang.get("home.welcome.prefix") + '</div>';
		domWelcomeMsg.innerHTML = str;
		parentNode.appendChild(domWelcomeMsg);

		var domWelcomeBody = document.createElement('div');
		domWelcomeBody.className = "msgBody";
		domWelcomeMsg.appendChild(domWelcomeBody);

		refreshWelcomeMessage(domWelcomeBody);
	}
	
	function refreshWelcomeMessage(parentNode)
	{
		var domMsgBody = parentNode ? parentNode : document.querySelector(".homeWelcomeMsgWrapper .msgBody");
		if(!domMsgBody)
			return;
		
		domMsgBody.innerHTML = "";
		generatePlayerProfileBody(domMsgBody);
	}
	
	function generatePlayerProfileBody(parentNode)
	{
		var domPlayerContent = document.createElement('div');
		var str = "";
		if(playerData.clanTag && playerData.clanTag.length > 0)
			str += "[<span class='pseudoLink withClickSound' onclick='uiManager.requestMyClanInfo();' style='color: white;'>" + playerData.clanTag + "</span>] ";
		str += "<span class='nick pseudoLink withClickSound' onclick='uiManager.showPlayerInfoById(\"" + playerData.db_id + "\");' style='color: " + NameColor.getColor() + ";'>";
		str += escapeHtml(playerData.name) + "</span>";
		domPlayerContent.innerHTML = str;
		parentNode.appendChild(domPlayerContent);
	}

	function renderNickNameTextInput_(parentNode)
	{
		slayOne.widgets.standardTextInput(parentNode, {
			size: 10,
			placeholder: slayOne.widgets.lang.get("home.input.nickname.placeholder"),
			cssId: "inputNickname",
			skin: "shadowed"
		});
	}

	function renderBottomButtons_(parentNode)
	{
		var prevNode = parentNode.querySelector("#homeBottomButtons");
		if(prevNode != null)
			parentNode.removeChild(prevNode);

		var domContainer = document.createElement("div");
		domContainer.id = "homeBottomButtons";

		var divPlay = document.createElement("div");
		divPlay.className = "homeBottomButton";
		var buttonPlay = slayOne.widgets.labelButton(divPlay, {
			label: slayOne.widgets.lang.get("home.buttons.play.label"),
			theme: "StandardYellow",
			tip: slayOne.widgets.lang.get('home.buttons.play.tooltip'),
			onClick: function () {
				gaEventOnce('player-click-play-button');
				var inputNickname = document.getElementById("inputNickname");
				var nickname = "";
				if(inputNickname)
				{
					nickname = trim(inputNickname.value).replace(/ /g, '_');
					inputNickname.value = nickname;
				}

				F$('newGame').show(nickname);
			}
		});
		domContainer.appendChild(divPlay);

		if(playerData.authLevel >= AUTH_LEVEL.PLAYER)
		{
			domContainer.addClass("loggedIn");
			var divListRooms = document.createElement("div");
			divListRooms.className = "homeBottomButton buttonLobby";
			var buttonListRooms = slayOne.widgets.labelButton(divListRooms, {
				label: slayOne.widgets.lang.get('home.buttons.lobby.label'),
				theme: "StandardGreen",
				tip: slayOne.widgets.lang.get('home.buttons.lobby.tooltip'),
				tipAlign: "center",
				onClick: function () {
					uiManager.showLobby();
				}
			});
			domContainer.appendChild(divListRooms);

			var divLogOut = document.createElement("div");
			divLogOut.className = "homeBottomButton";
			
			/*
			if(FacebookUtils.embeddedInCanvas)
				slayOne.widgets.labelButton(divLogOut, {
					label: slayOne.widgets.lang.get('home.buttons.guide.label'),
					tip: slayOne.widgets.lang.get('top.buttons.faq_small.tooltip'),
					tipAlign: "right",
					theme: "StandardGreen",
					onClick: showTutorialWindow_
				});
			else
			*/
				slayOne.widgets.labelButton(divLogOut, {
					label: slayOne.widgets.lang.get('home.buttons.logout.label'),
					tip: slayOne.widgets.lang.get('home.buttons.logout.tooltip'),
					tipAlign: "right",
					theme: "StandardGreen",
					onClick: logout
				});

			domContainer.appendChild(divLogOut);
		}
		else
		{
			domContainer.removeClass("loggedIn");
			var divLogin = document.createElement("div");
			divLogin.className = "homeBottomButton";
			var buttonLogin = slayOne.widgets.labelButton(divLogin, {
				label: slayOne.widgets.lang.get('home.buttons.login.label'),
				tip: slayOne.widgets.lang.get('home.buttons.login.tooltip'),
				tipAlign: "center",
				theme: "StandardGreen",
				onClick: function () {
					hideWindow();
					window.uiManager.showAccountWindow(0);
				}
			});
			domContainer.appendChild(divLogin);

			var divSignup = document.createElement("div");
			divSignup.className = "homeBottomButton";
			var buttonSignup = slayOne.widgets.labelButton(divSignup, {
				label: slayOne.widgets.lang.get('home.buttons.signup.label'),
				tip: slayOne.widgets.lang.get('home.buttons.signup.tooltip'),
				tipAlign: "right",
				theme: "StandardGreen",
				onClick: function () {
					hideWindow();
					window.uiManager.showAccountWindow(1);
				}
			});
			domContainer.appendChild(divSignup);
		}

		parentNode.appendChild(domContainer);
	}

	function hideWindow(forever)
	{
		window.hideHomeWindowForever = !!forever;
		window.showHomeWindow = false;
		domMain.style.display = "none";
	}

	function showWindow()
	{
		window.showHomeWindow = !window.hideHomeWindowForever;
	}

	function refreshAbilitiesPanel()
	{
		domAbilities.refreshView();
	}
	
	function render()
	{
		if(domMainContent.innerHTML && domMainContent.innerHTML.length > 0)
			collectSocialButtons();
		
		domMainContent.innerHTML = "";

		var aRows = [
			//first row
			[{renderMethod: renderButtonChangeSkins_}, {renderMethod: renderButtonAbilities_}, {renderMethod: renderSocialMedia_}],
			//second row
			[{renderMethod: (playerData.authLevel >= AUTH_LEVEL.PLAYER) ? renderWelcomeMessage_ : renderNickNameTextInput_}, {renderMethod: renderLevelInfo_}]
		];

		//render layout rows
		for (var i = 0; i < aRows.length; i++) {

			var
			aCells = aRows[i],
				domTable = document.createElement("div"),
				domRow = document.createElement("div");

			if(i == 0)
				domTable.className = "mainLayoutTable";
			else
				domTable.className = "profile";
			
			domRow.style.display = "table-row";
			
			//render layout cells
			for(var j = 0; j < aCells.length; j++)
			{
				var layoutCell = aCells[j];
				var domCell = document.createElement("div");
				//binding here allows these private methods access to the "this" scope
				var renderMethod = layoutCell.renderMethod ? layoutCell.renderMethod.bind(this) : null;

				domCell.className = "mainLayoutCell";
				
				renderMethod(domCell);

				domRow.appendChild(domCell);
			}
			
			domTable.appendChild(domRow);
			domMainContent.appendChild(domTable);
		}
		
		renderBottomButtons_(domMain);
		
		showWindow();

	}

	setInterval(function () {

		if(window.showHomeWindow && !window.isPlayingGame)
		{
			if(domMain.style.display == "none" || !domMain.style.display)
				domMain.style.display = "block";
		}
		else
		{
			if(domMain.style.display == "block")
				domMain.style.display = "none";
		}
	}, 50);

	//export
	slayOne.views[viewKey] = {
		render: render,
		showWindow: showWindow,
		hideWindow: hideWindow,
		refreshAbilitiesPanel: refreshAbilitiesPanel,
		refreshWelcomeMessage: refreshWelcomeMessage,
		refreshExp : refreshExp
	};

})(window, window.slayOne, window.document);//end main closure
