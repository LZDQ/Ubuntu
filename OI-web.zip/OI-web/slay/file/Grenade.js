function Grenade(startX, startY, targetX, targetY, speed, aoe, id, weapon, owner)
{
	this.x = parseFloat(startX);
	this.y = parseFloat(startY);
	this.x0 = this.x;
	this.y0 = this.y;
	
	this.vecX = parseFloat(targetX) - this.x;
	this.vecY = parseFloat(targetY) - this.y;
	
	this.dist = Math.sqrt(this.vecX * this.vecX + this.vecY * this.vecY);
	this.originalDist = this.dist;
	
	this.lastBlock = 10;
	
	soundManager.playSound(SOUND.GRENADE_LAUNCH, this.x, this.y);
	
	this.tickOfStart = game.ticksCounter;
	this.aoe = parseFloat(aoe);
	this.id = parseInt(id);
	this.dieAt = 0;
	this.weapon = weapon;
	this.duration = parseInt(this.dist / this.weapon.projectileSpeed);
	
	this.vecX *= this.weapon.projectileSpeed / this.dist;
	this.vecY *= this.weapon.projectileSpeed / this.dist;
	
	this.parabelScheitel = Math.pow(this.dist / 2, 2) * 0.08;
	
	game.addToObjectsToDraw(this);
	
	var x = this.x;
	var y = this.y;
	
	if(!game.fastForward)
	{
		for(var i = 0; i < 4; i++)
			new Sprite({
				x: x + Math.random() * 0.3 - 0.15,
				y: y - SHOT_HEIGHT + Math.random() * 0.3 - 0.15,
				img: imgCoords.dust1,
				scaleFunction: function(age){ return this.scale_ - age * 0.01; },
				scale_: Math.random() + 1.1,
				alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.35; },
				age: (2.7 + Math.random()) * 20,
				x_: this.vecX * 2.25,
				y_: this.vecY * 2.25,
				i_: i / 5,
				zFunction: function(age){ return (-1 / (Math.pow((age / 5) + 1, 3)) + 1) * 1.5 * this.i_; },
				xFunction: function(age){ return (-1 / (Math.pow((age / 5) + 1, 3)) + 1) * 2 * this.i_ * this.x_; },
				yFunction: function(age){ return (-1 / (Math.pow((age / 5) + 1, 3)) + 1) * 2 * this.i_ * this.y_; }
			});
		
		for(var i = 1; i < 3; i++)
			new Sprite({
				x: x + Math.random() * 0.3 - 0.15,
				y: y - SHOT_HEIGHT + Math.random() * 0.3 - 0.15,
				img: imgCoords.dust1,
				scaleFunction: function(age){ return this.scale_ - age * 0.01; },
				scale_: Math.random() + 1.1,
				alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.35; },
				age: (2.7 + Math.random()) * 20,
				x_: -this.vecY * 2.25,
				y_: this.vecX * 2.25,
				i_: i / 5,
				xFunction: function(age){ return (-1 / (Math.pow((age / 5) + 1, 3)) + 1) * 2 * this.i_ * this.x_; },
				yFunction: function(age){ return (-1 / (Math.pow((age / 5) + 1, 3)) + 1) * 2 * this.i_ * this.y_; }
			});
		
		for(var i = 1; i < 3; i++)
			new Sprite({
				x: x + Math.random() * 0.3 - 0.15,
				y: y - SHOT_HEIGHT + Math.random() * 0.3 - 0.15,
				img: imgCoords.dust1,
				scaleFunction: function(age){ return this.scale_ - age * 0.01; },
				scale_: Math.random() + 1.1,
				alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.35; },
				age: (2.7 + Math.random()) * 20,
				x_: this.vecY * 2.25,
				y_: -this.vecX * 2.25,
				i_: i / 5,
				xFunction: function(age){ return (-1 / (Math.pow((age / 5) + 1, 3)) + 1) * 2 * this.i_ * this.x_; },
				yFunction: function(age){ return (-1 / (Math.pow((age / 5) + 1, 3)) + 1) * 2 * this.i_ * this.y_; }
			});
		
		new Sprite({
			x: x,
			y: y - SHOT_HEIGHT,
			img: imgCoords.light_yellow,
			scaleFunction: function(age){ return 5; },
			age: 7
		});
	}
};

Grenade.prototype.update = function()
{
	if(this.dieAt && this.dieAt + 10 <= game.ticksCounter)
		return false;
	
	if(this.dieAt)
		return true;
	
	this.x0 = this.x;
	this.y0 = this.y;
	
	this.x += this.vecX;
	this.y += this.vecY;
	
	this.dist -= this.weapon.projectileSpeed;
	
	var block = game.getFieldPath(Math.floor(this.x), Math.floor(this.y));
	var maxAllowedBlock = this.dist < 1.2 ? 9 : 5;
	
	if(block < maxAllowedBlock)
	{
		soundManager.playSound(SOUND.GRENADE_BOUNCE, this.x, this.y, 1.0);
		
		this.x -= this.vecX * 2;
		block = game.getFieldPath(Math.floor(this.x), Math.floor(this.y));
		
		if(block < maxAllowedBlock)
		{
			this.x += this.vecX * 2;
			this.y -= this.vecY * 2;
			block = game.getFieldPath(Math.floor(this.x), Math.floor(this.y));
			
			if(block < maxAllowedBlock)
				this.x -= this.vecX * 2;
		}
	}
	
	if(this.lastBlock == 5 && block == 5 && this.dist < 1.2)
	{
		this.explode();
		return false;
	}
	
	this.lastBlock = block;
	
	this.vecX = this.x - this.x0;
	this.vecY = this.y - this.y0;
	
	if(this.dist <= 0) // explode
	{
		if(game.getFieldPath(Math.floor(this.x), Math.floor(this.y)) != 9)
			this.explode();
		
		else if(this.x + 3 >= game.cameraX && this.y + 3 >= game.cameraY && this.x - 3 <= game.cameraX2 && this.y - 3 <= game.cameraY2)
			new Splash(this.x, this.y, imgCoords.splash);
		
		return false;
	}
	
	return true;
};

Grenade.prototype.blink = function(x, y, oldX, oldY)
{
	soundManager.playSound(SOUND.BLINK, this.x, this.y, 0.65);
	createBlinkEffectSmall(parseFloat(oldX) - 0.2 + Math.random() * 0.4, parseFloat(oldY) - 0.2 + Math.random() * 0.4);
	
	this.x = parseFloat(x);
	this.y = parseFloat(y);
	
	this.x0 = this.x;
	this.y0 = this.y;
	
	soundManager.playSound(SOUND.BLINK, this.x, this.y, 0.65);
	createBlinkEffectSmall(this.x - 0.25 + Math.random() * 0.5, this.y - 0.25 + Math.random() * 0.5);
};

Grenade.prototype.explode = function()
{
	if(this.x + 10 >= game.cameraX && this.y + 10 >= game.cameraY && this.x - 10 <= game.cameraX2 && this.y - 10 <= game.cameraY2)
	{
		createExplosion(this.x, this.y, this.aoe, this.weapon.sootAlpha);
		soundManager.playSound(SOUND[this.weapon.impactSound], this.x, this.y, this.weapon.impactSoundVolume);
		game.corpseBounce(this.x, this.y, this.aoe);
	}
	
	this.dieAt = game.ticksCounter;
};

Grenade.prototype.getYDrawingOffset = function()
{
	return this.y;
};

Grenade.prototype.draw = function(exactTicks, x1, y1, x2, y2, percentageOfCurrentTickPassed)
{
	if(!(this.x + 3 >= x1 && this.y + 3 >= y1 && this.x - 3 <= x2 && this.y - 3 <= y2) || this.dieAt)
		return;
	
	var perc = (exactTicks - this.tickOfStart) / this.duration;
	
	var x = this.x0 + percentageOfCurrentTickPassed * (this.x - this.x0);
	var y = this.y0 + percentageOfCurrentTickPassed * (this.y - this.y0);
	
	var direction = getDirectionFromAgle(this.x0, this.y0, this.x, this.y);
	
	var passedDist = perc * this.originalDist;
	
	var h = -0.08 * Math.pow(passedDist - this.originalDist / 2, 2) + this.parabelScheitel + ((1 - passedDist / this.originalDist) * SHOT_HEIGHT * 1.5);
	
	// shadow
	c.globalAlpha = 0.3;
	c.drawImage(imgs.shadow, (x - game.cameraX) * FIELD_SIZE - 16 * SCALE_FACTOR / 2, (y - game.cameraY) * FIELD_SIZE - 16 * SCALE_FACTOR / 2, 32 * SCALE_FACTOR / 2, 32 * SCALE_FACTOR / 2);
	c.globalAlpha = 1;
	
	// grenade
	var xSource = Math.min(Math.floor(perc * 3), 2) * 10;
	var img = imgCoords[this.weapon.projectileImg];
	var scale = this.weapon.projectileScale ? (this.weapon.projectileScale * SCALE_FACTOR) : SCALE_FACTOR;
	c.drawImage(imgs.miscSheet, img.x + xSource, img.y + 10 * direction, 10, 10, (x - game.cameraX) * FIELD_SIZE - 5 * scale, (y - h * 0.9 - game.cameraY) * FIELD_SIZE - 5 * scale, 10 * scale, 10 * scale);
};