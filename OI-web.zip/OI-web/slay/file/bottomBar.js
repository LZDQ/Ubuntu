FunUI.layouts["bottomBar"] = 
	'<div id="bottomBar" class="hide">' + 
		'<a class="withClickSound" href="javascript: toggleImprint();">_(home.footer.imprint.label)</a> ' + 
		'<a class="withClickSound" href="javascript: toggleAGB();">_(home.footer.terms.label)</a> ' + 
		'<a class="withClickSound" href="javascript: toggleDSE()">_(home.footer.privacy.label)</a> ' + 
		'<a class="ioGameLink withClickSound" href="http://iogames.space/" target="_blank">.IO Games</a>' + 
	'</div>';
