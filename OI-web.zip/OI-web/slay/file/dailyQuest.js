(function(){
    var quests = new F$ArrayView();
    var updateHintInterval = null;

    FunUI.traits.dailyQuest = {
        open: function () {
            quests.source = playerData.dailyQuests.quests;
            FunUI.managers.PopUpManager.addPopUp(this, this.modal);
            if (updateHintInterval) {
                clearInterval(updateHintInterval);
            }
            updateHintInterval = setInterval(this.updateHint, 1000);
            this.updateHint();
        },
        close: function () {
            FunUI.managers.PopUpManager.removePopUp(this);
            if (updateHintInterval) {
                clearInterval(updateHintInterval);
                updateHintInterval = null;
            }
        },
        tryCompleteQuests: function () {
            for (var i = 0; i < playerData.dailyQuests.quests.length; i++) {
                if (playerData.dailyQuests.quests[i]) {
                    if (!playerData.dailyQuests.quests[i].completed && !playerData.dailyQuests.quests[i].completeRequestSent) {
                        if (playerData.dailyQuests.quests[i].count >= playerData.dailyQuests.quests[i].total) {
                            network.send('completeDailyQuest$' + i);
                            playerData.dailyQuests.quests[i].completeRequestSent = true;
                            break;
                        }
                    }
                }
            }
        },
        refresh: function () {
            quests.source = playerData.dailyQuests.quests;
            quests.invalidate();
        },
        updateHint: function () {
            var allDone = true;
            for (var i = 0; i < playerData.dailyQuests.quests.length; i++) {
                if (playerData.dailyQuests.quests[i]) {
                    if (!playerData.dailyQuests.quests[i].completed) {
                        allDone = false;
                        break;
                    }
                }
            }
            var hint = this.querySelector('.hint');
            if (allDone) {
                var countdown = playerData.dailyQuests.refreshCountdown -
                    parseInt((Date.now() - playerData.dailyQuests.refreshCountdownStart) / 1000);
                var hours = parseInt(countdown / 3600);
                var minutes = Math.ceil((countdown - hours * 3600) / 60);
                hint.innerText = slayOne.widgets.lang.get('dailyQuest.allDone')
                    .replace('[[x]]', hours).replace('[[y]]', minutes);
            } else {
                hint.innerText = slayOne.widgets.lang.get('dailyQuest.unavailing');
            }
        }
    };
    FunUI.traits.dailyQuest_list = {
        dataProvider: quests
    };
    FunUI.traits.dailyQuest_list.itemRenderer = {
        _quest : null,
        _empty : null,
        _nameField : null,
        _figure : null,
        _weapon : null,
        _descField : null,
        _countField : null,
        _chest : null,
        _rewardCount: null,
        _futureField : null,
        _rankButton : null,
        _completed : null,
        __init__: function() {
            this._quest = this.querySelector('.quest');
            this._empty = this.querySelector('.empty');
            this._nameField = this.querySelector('.name');
            this._figure = this.querySelector('.figure');
            this._weapon = this.querySelector('.weapon');
            this._descField = this.querySelector('.desc');
            this._countField = this.querySelector('.count');
            this._chest = this.querySelector('.chest');
            this._rewardCount = this.querySelector('.rewardCount');
            this._futureField = this.querySelector('.future');
            this._rankButton = this.querySelector('.rank');
            this._completed = this.querySelector('.completed');
        },
        show: function () {
            FunUI.managers.PopUpManager.addPopUp(this, false, FunUI.utils.LAYER_TOP);
        },
        render: function (data) {

			Skin.close();

            if (data == null) {
                var hours = parseInt(playerData.dailyQuests.refreshCountdown / 3600);
                var minutes = Math.ceil((playerData.dailyQuests.refreshCountdown - hours * 3600) / 60);
                minutes = minutes >= 10 ? '' + minutes : '0' + minutes;
                this._futureField.innerHTML = F_("dailyQuest.countdown", {seconds: hours + ":" + minutes});
                this._empty.style.display = 'block';
                this._quest.style.display = 'none';
                return;
            }

            this._nameField.innerHTML = slayOne.widgets.lang.get('dailyQuest.' + data.type + '.title');
            this._weapon.src = "imgs/dailyQuest/" + data.type + ".png";
            this._descField.innerHTML = slayOne.widgets.lang.get('dailyQuest.' + data.type + '.desc').replace('[[x]]', data.total);
            this._countField.innerHTML = data.count + '/' + data.total;
            this._chest.src = "imgs/chest/chest_1" + ".png";
            this._rewardCount.innerText = 'x' + data.rewardCount;
            this._empty.style.display = 'none';
            this._quest.style.display = 'block';

            this._completed.src = "imgs/dailyQuest/completed.png";
            if (data.completed) {
                this._completed.style.display = 'block';
            } else {
                this._completed.style.display = 'none';
            }
        },
    };
})();