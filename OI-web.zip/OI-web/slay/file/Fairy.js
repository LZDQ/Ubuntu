function Fairy(x, y)
{
	this.x = x;
	this.y = y;
	this.x0 = x;
	this.y0 = y;
	this.z = 0.2 + Math.random() * 0.6;
	
	this.vx = Math.random() * 0.005 - 0.0025;
	this.vy = Math.random() * 0.005 - 0.0025;
	
	this.tickOfDeath = game.ticksCounter + 450 + Math.floor(Math.random() * 120);
};

Fairy.prototype.update = function(ticksCounter)
{
	this.vx += Math.random() * 0.0005 - 0.00025;
	this.vy += Math.random() * 0.0005 - 0.00025;
	
	return this.tickOfDeath > ticksCounter;
};

Fairy.prototype.draw = function(exactTicks, x1, y1)
{
	if(game.ticksCounter >= 0)
	{
		this.x += this.vx;
		this.y += this.vy;
	}
	
	var fac = 1 / (1 - this.z);
	
	var x = x1 + (this.x - x1) * fac;
	var y = y1 + (this.y - y1) * fac;
	
	if(!(x + 3 >= game.cameraX && y + 3 >= game.cameraY && x - 3 <= game.cameraX2 && y - 3 <= game.cameraY2))
		return;
	
	var time2Live = Math.max(this.tickOfDeath - exactTicks, 0);
	var globalAlpha = Math.min(time2Live / 20, 1);
	
	var scale = SCALE_FACTOR * this.z * 3;
	var img = imgCoords.particleWhite;
	
	var drawX = g2rx(x) - (img.w / 2) * scale;
	var drawY = g2ry(y - this.z * 0) - (img.h / 2) * scale;
	
	c.globalAlpha = 0.2 * globalAlpha;
	c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, drawX, drawY, img.w * scale, img.h * scale);
	
	scale = SCALE_FACTOR * this.z * 3;
	img = imgCoords.light_light_yellow;
	
	drawX = g2rx(x) - (img.w / 2) * scale;
	drawY = g2ry(y - this.z * 0) - (img.h / 2) * scale;
	
	c.globalAlpha = (Math.random() * 0.05 + 0.1) * globalAlpha;
	c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, drawX, drawY, img.w * scale, img.h * scale);
	c.globalAlpha = 1;
};