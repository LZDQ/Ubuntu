FunUI.layouts["tooltipMap"] =
	'<div id="tooltipMap" class="F-Tooltip">' +
		'<h2>Courtuard</h2>' +
		'<div class="summary">' +
//			'<img width="100">' +
			'<div class="size">2*2</div>' +
		'</div>' +
	'</div>';
