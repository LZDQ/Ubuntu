(function(){
    var size = 150;
    var top3Players = new F$ArrayView();

    FunUI.traits.miniMap = {
        _canvas: null,
        _baseCanvas: null,
        _game: null,
        _gameChanged: null,
        _scoreButton : null,
        __init__: function()
        {
            this._canvas = this.querySelector('canvas');
            this._scoreButton = this.querySelector('.F-Button.score');
            this._scoreButton.on("click", this.toggleFullRank);
        },
        show: function(game)
        {
            document.body.appendChild(this);
            this._game = game;
            this.drawBaseCanvas();
            
            if(game.type.showTop3 && game.type.winningCondition)
                F$('miniMap_list').style.display = "";
            else
                F$('miniMap_list').style.display = "none";
        },
        hide: function()
        {
            if(this.parentNode == document.body)
                document.body.removeChild(this);
        },
        drawBaseCanvas: function()
        {
            if(!this._baseCanvas)
                this._baseCanvas = document.createElement('canvas');
            
            var game = this._game;
            this._baseCanvas.width = game.map.x;
            this._baseCanvas.height = game.map.y;
            var ctx = this._baseCanvas.getContext("2d");

            if(tileTypes[game.map.defaultTiles].avgColor)
            {
                ctx.fillStyle = tileTypes[game.map.defaultTiles].avgColor;
                ctx.fillRect(0, 0, this._baseCanvas.width, this._baseCanvas.height);
            }

            for(var i = 0; i < game.groundTiles.length; i++)
            {
                var tile = game.groundTiles[i];
                var type = tile.type;

                if(type.avgColor)
                {
                    ctx.fillStyle = type.avgColor;
                    ctx.fillRect(tile.x, tile.y, type.w ? type.w : 1, type.h ? type.h : 1);
                }
            }

            ctx.fillStyle = "black";
            ctx.globalAlpha = 0.5;
            ctx.fillRect(0, 0, this._baseCanvas.width, this._baseCanvas.height);

            ctx.globalAlpha = 1;
            for(var i = 0; i < game.tiles.length; i++)
                if(!game.tiles[i].ground)
                {
                    var tile = game.tiles[i];
                    var type = tile.type;

                    if(type.avgColor)
                    {
                        ctx.fillStyle = type.avgColor;
                        ctx.fillRect(tile.x, tile.y, type.w ? type.w : 1, type.h ? type.h : 1);
                    }

                }
        },
        render: function(percentageOfCurrentTickPassed) {
            if(!this._canvas)
                return;
            
			drawMiniMap(this, size, percentageOfCurrentTickPassed);

            if(this._game.type.showTop3 && game.type.winningCondition)
                top3Players.source = game.interface_.top3;

            this._scoreButton.disabled = (this._game.ticksCounter < 0);
        },
        toggleFullRank: function() {
            var rankView = F$('rankInGame');
            if(!rankView.parentNode)
                rankView.show();
            else
                rankView.hide();
        }
    };

    FunUI.traits.miniMap_list = {
        dataProvider : top3Players
    };

    FunUI.traits.miniMap_list.itemRenderer = {
        _rankField : null,
        _nameField : null,
        _scoreField : null,
        __init__ : function() {
            this._rankField = this.querySelector('.rank');
            this._nameField = this.querySelector('.name');
            this._scoreField = this.querySelector('.score');
        },
        render: function(data)
        {
            var itsme = game && game.playingPlayer && game.playingPlayer.id == data.id;

            this._rankField.innerHTML = data.rank;

            var clan = '';
            if(data.clan)
                clan = "[" + data .clan + "] ";
            
            this._nameField.innerHTML = clan + escapeHtml(data.name);

            var souls = data.souls;
            if(souls >= 1000)
                souls = Math.floor(souls / 1000) + "k";

            this._scoreField.innerHTML = souls;

            if(itsme)
                this.addClass('me');
            else
                this.removeClass('me');

            if(data.team == 1)
            {
                this.addClass("redTeam");
                this.removeClass("blueTeam");
            }
            else if(data.team == 2)
            {
                this.addClass("blueTeam");
                this.removeClass("redTeam");
            }
            else
            {
                this.removeClass("blueTeam");
                this.removeClass("redTeam");
            }
        }
    };
})();