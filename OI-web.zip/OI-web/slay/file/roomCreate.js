/**
 * View renders the "CreateRoom" UI
 *
 */
(function(window, slayOne, document){

function renderGameModeSwitcher_(parentNode)
{
    var domContainer = document.createElement('div');
    domContainer.className = "gameModeSwitcherDdlWrapper";
	
    var gameModeFilterOptions = [];
	for(var i = 0; i < MAP_TYPE_SETTINGS.length; i++)
		if(!MAP_TYPE_SETTINGS[i].hidden)
			gameModeFilterOptions.push({
				label: slayOne.widgets.lang.get(MAP_TYPE_SETTINGS[i].langLabel),
            	value : MAP_TYPE_SETTINGS[i].id
			});
	
    var initIndex = 0;
	
    for(var i = 0; i < gameModeFilterOptions.length; i++)
        if(gameModeFilterOptions[i].value == window.filterMapType)
        {
            initIndex = i;
            break;
        }
	
    slayOne.widgets.dropdownMenu(domContainer, {
        customClassName: "gameModeSwitcherDdl",
        customButtonClassName: "gameModeSwitcherBtn",
        customButtonWidth: "262px",
        customButtonHeight: "44px",
        cssId: "gameModeSwitch",
        selectOptions: gameModeFilterOptions,
        initIndex: initIndex,
        mainButtonTip: slayOne.widgets.lang.get("lobby.views.create.mode_filter.tooltip"),
        onSwitch: function(gameModeOption)
        {
        	window.filterMapType = gameModeOption.value;
            listClear_();
            localStorage.setItem("defaultCreateMode", window.filterMapType);
    		getNumBots();
            refreshList_();
        }
    });
	
    parentNode.appendChild(domContainer);
}

function renderMapsList_(parentNode)
{
    // List wrapper
    var domList = document.createElement('div');
    domList.className = "mapListWrapper";

    // Loading indicator while loading the list
    var domLoading = document.createElement('div');
    domLoading.className = "mapListLoading";
    domLoading.id = "mapListLoading";
    var domLoadingIndicator = slayOne.widgets.loadingIndicator(domLoading, {
        width: '100%',
        height: '100%'
    });
    domLoadingIndicator.id = "domLoadingIndicator";
    domList.appendChild(domLoading);

    // List body - scrollable
    var domTableBody = document.createElement('div');
    domTableBody.className = "mapListBody";
    domTableBody.id = "domTableMapListBody";
    domList.appendChild(domTableBody);

    parentNode.appendChild(domList);
}

function renderParamFields_(parentNode)
{
    renderBotsInput_(parentNode);
    renderRoundTimeInput_(parentNode);
}

function renderBotsInput_ (parentNode)
{
    var domContent = document.createElement('div');
    domContent.className = "roomCreateParamInput";

    var domLabel = document.createElement('span');
    domLabel.className = "fieldLabel";
    domLabel.innerText = slayOne.widgets.lang.get("lobby.views.create.bots_num.prefix");
    domContent.appendChild(domLabel);

    var staticNum = document.createElement('div');
    staticNum.className = "staticNum";
    staticNum.innerText = 18;
    staticNum.style.display = 'none';
    domContent.appendChild(staticNum);

    var tiNumBots = slayOne.widgets.standardTextInput(domContent, {
        size: 10,
        placeholder: "",
        cssId: "inputNumBots",
        skin: "standard",
        customClassName: "botNumTextInput"
    });
    
    tiNumBots.type = "number";
    tiNumBots.min = 0;
    tiNumBots.max = 8;

    slayOne.widgets.tooltip(domContent, {
        tip: slayOne.widgets.lang.get("lobby.views.create.bots_num.tooltip"),
        align: "left",
        multiline: true,
        width: "450px",
        verticalAlign: "top"
    });
	
	parentNode.appendChild(domContent);
	
    getNumBots();
}

function getRoundTime()
{
	return (window.filterMapType == MAP_TYPE.ZOMBIE_COOP) ? '10' : '15';
}

function getNumBots()
{
	var input = document.getElementById("inputNumBots");
	var staticNum = input.parentNode.parentNode.querySelector('div.staticNum');

    if(window.filterMapType == MAP_TYPE.ZOMBIE_COOP)
    {
		input.parentNode.style.display = 'none';
		staticNum.style.display = '';
        input.value = '18';
    }
    else
    {
		input.parentNode.style.display = '';
		staticNum.style.display = 'none';
        input.value = '4';
    }
}

function renderRoundTimeInput_(parentNode)
{
    var domContent = document.createElement('div');
    domContent.className = "roomCreateParamInput";

    var domLabel = document.createElement('span');
    domLabel.className = "fieldLabel";
    domLabel.innerText = slayOne.widgets.lang.get("lobby.views.create.round_time.prefix");
    domContent.appendChild(domLabel);

    var tiRoundTime = slayOne.widgets.standardTextInput(domContent, {
        size: 10,
        placeholder: "",
        cssId: "inputRoundTime",
        skin: "standard",
        customClassName: "roundTimeTextInput"
    });
    
    tiRoundTime.type = "number";
    tiRoundTime.min = 10;

    slayOne.widgets.tooltip(domContent, {
        tip: slayOne.widgets.lang.get("lobby.views.create.round_time.tooltip"),
        align: "left"
    });

    tiRoundTime.value = getRoundTime();

    parentNode.appendChild(domContent);
}

function renderPrivateGameCheckbox_(parentNode)
{
    var domCheckBox = slayOne.widgets.checkbox(parentNode, {
        selected: false,
        label: slayOne.widgets.lang.get("lobby.views.create.private_game.checkbox"),
        customClassName: "roomCreatePrivateCheckbox",
        cssId: "checkBoxbPrivateGame",
        onChange: function (selected) {
        },
    });

    slayOne.widgets.tooltip(domCheckBox, {
        tip: slayOne.widgets.lang.get("lobby.views.create.private_game.tooltip"),
        align: "left"
    });
}

function isFreeMap()
{
    var mapId = window.selectedMapId;
    
    for(var i = 0; i < CREATION_FREE_MAPS.length; i++)
        if(mapId == CREATION_FREE_MAPS[i])
            return true;
    
    return false;
}

function renderStartButton_ (parentNode)
{
    var button = document.createElement('div');
    button.className = 'F-Button gold';
    button.innerHTML = '<div class="label"> <span>' + slayOne.widgets.lang.get("lobby.views.create.start_btn.label") + '</span><div class="icon x16 gold" id="roomCreationPrice1"></div>' + 
    	'<span class="goldNumber" id="roomCreationPrice2">' + CONST.GAME_CREATION_GOLD_COST + '</span> </div><div class="hover"></div>';

    button.on('click', function(){
        createGame();
    });

    parentNode.appendChild(button);
}

function listInit_()
{
	window.currentMapNodes = [];
    var numColumns = 3;
    var mapRow = null;
    for(var i = 0; i < window.currentMaps.length; i++)
    {
        if(i % numColumns == 0)
        {
            mapRow = document.createElement('div');
            mapRow.className = 'mapListRow';
        }

        var mapCell = document.createElement('div');
        mapCell.className = 'mapListCell';
        var addedNode = listCreateOne_(mapCell, window.currentMaps[i]);
        window.currentMapNodes.push(addedNode);
        mapRow.appendChild(mapCell);

        if(i % numColumns == numColumns - 1)
        {
            document.getElementById("domTableMapListBody").appendChild(mapRow);
            mapRow = null;
        }
    }

    if(mapRow != null)
        document.getElementById("domTableMapListBody").appendChild(mapRow);
    
    // Select the first
    if(window.currentMaps.length > 0)
        selectMap_(window.currentMaps[0].mapId, true);
}

function listClear_()
{
    document.getElementById("domTableMapListBody").innerHTML = '';
    window.currentMapNodes = [];
}

/**
* Create one map cell
*/
function listCreateOne_(parentNode, mapData)
{
    var domMap = document.createElement('div');
    domMap.className = "mapNode";
    
    var mapHTML = '';
    mapHTML += '<div class="mapTitle">' + mapData.mapName + '</div>';
    mapHTML += '<div class="mapThumbail">';
    mapHTML += '<img src="' +  mapData.thumbnail + '" onerror="holdPlaceMapThumbnail(event); " onload="holdPlaceMapThumbnail(event);">';
    mapHTML += '<div class="mapSize">' + mapData.mapW + 'x' + mapData.mapH + '</div>';
    mapHTML += '</div>';
    mapHTML += '<div class="mapCapacity">' + slayOne.widgets.lang.get("lobby.views.create.list.row.tooltip.player.header") + ': <span>' + mapData.maxPlayers + '</span></div>';
    mapHTML += '<div class="mapMode">' + slayOne.widgets.lang.get(MAP_TYPE_SETTINGS[mapData.mode].langLabel) + '</div>';

    domMap.innerHTML = mapHTML;

    var domHighlight = document.createElement('div');
    domHighlight.className = "mapNodeHighlight";
    domHighlight.style.display = "none";
    domMap.appendChild(domHighlight);

    domMap.setSelected = function(val){
        if(val) {
            domHighlight.style.display = "block";
            addClassToDom(domMap, "selectedNode");
        } else {
            domHighlight.style.display = "none";
            removeClassFromDom(domMap, "selectedNode");
        }
    };

    domMap.dataset.slayOneMapId = mapData.mapId.toString();

    // Add map tooltip
    if(mapData.mapDesc && mapData.mapDesc.length > 0) {

        var escapedDesc = escapeHtml(mapData.mapDesc);
        if(escapedDesc.length > 0) {
            var domRoomTip = document.createElement('div');
            domRoomTip.className = "mapListTip";
            domRoomTip.style.display = "none";

            var roomTipHTML = '<div class="mapTipWrapper">';
            roomTipHTML += '<div class="mapMetaDetail">' + escapedDesc + '</div>';
            roomTipHTML += '</div>';

            domRoomTip.innerHTML = roomTipHTML;
            domMap.appendChild(domRoomTip);

            domMap.addEventListener("mouseover", function(){
                domRoomTip.style.display = "flex";
            });

            domMap.addEventListener("mouseout", function(){
                domRoomTip.style.display = "none";
            });
        }

    }

    slayOne.widgets.hoverLight(domMap, {
        width: '166px',
        height: '198px'
    });

    domMap.addEventListener("click", function(evt){
        selectMap_(mapData.mapId);
    });

    slayOne.widgets.clickable(domMap);

    parentNode.appendChild(domMap);

    return domMap;
}

function refreshList_()
{
    listClear_();
    
    document.getElementById("domTableMapListBody").style.display = 'none';
    document.getElementById("domLoadingIndicator").startAnimation();
    document.getElementById("mapListLoading").style.display = 'block';
    
    window.network.send("req-map-list-4-create$" + window.filterMapType);
}

function setNewMaps()
{
    document.getElementById("domTableMapListBody").style.display = 'block';
    document.getElementById("mapListLoading").style.display = 'none';
    document.getElementById("domLoadingIndicator").stopAnimation();

    window.currentMaps.forEach(function(mapData){
        mapData.mode = window.filterMapType;
    });

    listInit_();
}

function selectMap_(mapId, force)
{
    if(!force && mapId == window.selectedMapId)
        return;

    if(window.selectedMapId != null)
    {
        var oldMapNode = getMapNodeById_(window.selectedMapId);
        if(oldMapNode)
            oldMapNode.setSelected(false);
    }

    window.selectedMapId = mapId;

    var isFree = isFreeMap();
    document.getElementById("roomCreationPrice1").style.display = isFree ? 'none' : '';
    document.getElementById("roomCreationPrice2").style.display = isFree ? 'none' : '';

    var newMapNode = getMapNodeById_(mapId);
    if(newMapNode)
        newMapNode.setSelected(true);
}

function getMapNodeById_(mapId)
{
    for(var i = 0; i < window.currentMapNodes.length; i++)
        if(window.currentMapNodes[i].dataset.slayOneMapId == mapId.toString())
            return window.currentMapNodes[i];
    return null;
}

function createGame()
{
    var isFree = isFreeMap();
    if(isFree)
    {
        createGame_();
        return;
    }
	
    if(playerData.gold < CONST.GAME_CREATION_GOLD_COST)
    {
        slayOne.viewHelpers.showFloatTip({
            tipType: 'error',
            content: slayOne.widgets.lang.get("room.create.error.insufficient")
        });
		
        return;
    }
	
    F$confirm(F_('room.create.confirm', {
        gold: CONST.GAME_CREATION_GOLD_COST
    }), createGame_.bind());
}

function createGame_()
{
    var respCb = function()
    {
        slayOne.viewHelpers.hidePopup("lobby");
        
        if(!isFreeMap())
            playerData.gold -= CONST.GAME_CREATION_GOLD_COST;
        
        F$('resourceBar').refresh();
    };
    
    network.send("create-game$" + window.selectedMapId + "$" + document.getElementById("inputRoundTime").value + "$" + document.getElementById("inputNumBots").value + "$" +
    	window.filterMapType + "$" + (document.getElementById("checkBoxbPrivateGame").getSelected() ? 1 : 0));
    
    slayOne.viewHelpers.hidePopup("lobby");
}

function render(parentNode)
{
    var domContent = document.createElement('div');
    parentNode.appendChild(domContent);
    domContent.className = "roomTabView roomCreateView";

    // Keep in sync with the mode chosen in HomeUI
    var storedCreateMode = localStorage.getItem("defaultCreateMode");
    if(storedCreateMode && storedCreateMode.length > 0)
        window.filterMapType = storedCreateMode;

    var aRows = [
        [ { renderMethod: renderGameModeSwitcher_ }, { renderMethod: renderPrivateGameCheckbox_ } ],
        [ { renderMethod: renderMapsList_ } ],
        [ { renderMethod: renderParamFields_ }, { renderMethod: renderStartButton_ } ],
    ];

    for(var i = 0; i < aRows.length; i++)
    {
        var aCells = aRows[i];
        var domTable = document.createElement("div");
        var domRow = document.createElement("div");
        domTable.appendChild(domRow);
        domContent.appendChild(domTable);
        domTable.className = "mainLayoutTable";
        domRow.style.display = "table-row";
        domTable.style.marginBottom = (i == 0) ? "15px" : "8px";

        for(var j = 0; j < aCells.length; j++)
        {
            var layoutCell = aCells[j];
            var domCell = document.createElement("div");
            domRow.appendChild(domCell);
            var renderMethod = layoutCell.renderMethod ? layoutCell.renderMethod.bind(this): null;
            domCell.className  = "mainLayoutCell roomCreateLayoutCell";
            renderMethod(domCell);
        }
    }
	
    domContent.onShow = function(initData){
        refreshList_();
    };
	
    return domContent;
}

// export
slayOne.views.roomCreateScreen = {
    render: render,
    setNewMaps: setNewMaps
};

})(window, window.slayOne, window.document);
