FunUI.layouts["clanJoin"] =
	'<div id="clanJoin" class="F-Window light" data-modal="true">' +
		'<h2 class="title">_(clanJoin.title)</h2>' +
		'<div class="content">' +
			'<h3>' +
				'<span class="quote">[</span>' +
				'<span class="clanTag">BBB</span>' +
				'<span class="quote">]</span> ' +
				'<span class="clanName">CLAN NAME</span>' +
			'</h3>' +
			'<div class="F-TextInput desc" data-multiline="true" id="clanAppTextField">I&#x2019;d like to join your clan</div>' +
			'<div class="buttonBar">' +
				'<div class="F-Button tiny cancel">_(clanJoin.button.cancel)</div>' +
				'<div class="F-Button tiny send">_(clanJoin.button.send)</div>' +
			'</div>' +
		'</div>' +
	'</div>';