FunUI.layouts["clanMain"] =
	'<div class="F-Window" id="clanMain" data-modal="true">' +
		'<h2 class="title">_(clanMain.title)</h2>' +
		'<ul class="F-TabPage content">' +
			'<li id="clanMain_browse" class="F-TabSubPage browse">' +
				'<h3 class="title">_(clanMain.browse.title)</h3>' +
				'<ul id="clanMain_browseViewStack" class="F-ViewStack content">' +
					'<li class="subView">' +
						'<div class="searchBar">' +
							'<div class="F-TextInput searchInput" data-placeholder="_(clanMain.browse.search.placeholder)"></div>' +
							'<div class="F-Button search" data-tooltip-data="_(clanMain.tooltip.search)"></div>' +
						'</div>' +
						'<ul id="clanMain_list" class="F-List">' +
							'<li class="F-ItemRenderer">' +
								'<h4>' +
									'<span class="quote">[</span>' +
									'<span class="clanTag">BBB</span>' +
									'<span class="quote">]</span> ' +
									'<span class="clanName">CLAN NAME</span>' +
								'</h4>' +
								'<div class="members">' +
									'<h5 class="membersTitle">_(clanMain.label.members)</h5>' +
									'<span class="membersNumber"></span>' +
								'</div>' +
								'<div class="F-Button small join">_(clanMain.browse.join)</div>' +
								'<div class="F-Button info" data-tooltip-data="_(clanMain.tooltip.profile)"></div>' +
							'</li>' +
						'</ul>' +
					'</li>' +
					'<li id="clanMain_info" class="subView">' +
						'<div class="clanInfo">' +
							'<div class="baseInfo">' +
								'<h4>' +
									'<span class="quote">[</span>' +
									'<span class="clanTag">BBB</span>' +
									'<span class="quote">]</span> ' +
									'<span class="clanName">CLAN NAME</span>' +
								'</h4>' +
								'<table>' +
									'<tr>' +
										'<th>_(clanMain.label.score)</th>' +
										'<td class="elo">1,000,220</td>' +
										'<th>_(clanMain.label.members)</th>' +
										'<td class="members membersCount">150</td>' +
									'</tr>' +
								'</table>' +
							'</div>' +
							'<pre class="description clanDescription">...</pre>' +
						'</div>' +
						'<div class="F-Button back" data-tooltip-data="_(clanMain.tooltip.back)"></div>' +
						'<div class="buttonBar">' +
							'<div class="F-Button tiny join">_(clanMain.browse.info.button.join)</div>' +
							'<div class="space"></div>' +
							'<div class="F-Button tiny dark btnMembers"> _(clanMain.browse.info.button.members) </div>' +
						'</div>' +
					'</li>' +
				'</ul>' +
			'</li>' +
			'<li id="clanMain_create" class="F-TabSubPage">' +
				'<h3 class="title">_(clanMain.create.title)</h3>' +
				'<div class="content clanForm">' +
					'<div class="F-TextInput name" id="createClanName" data-placeholder="_(clanMain.create.placeholder.name)" data-max-length="12"></div>' +
					'<div class="F-TextInput tag" id="createClanTag" data-placeholder="_(clanMain.create.placeholder.tag)" data-max-length="6"></div>' +
					'<div class="F-TextInput description clanDescription" id="createClanDesc" data-placeholder="_(clanMain.create.placeholder.description)" data-multiline="true"></div>' +
					'<div class="F-Button gold create">' +
						'<div class="label">' +
							'<span>_(clanMain.create.button.label)</span>' +
							'<div class="icon x16 gold"></div>' +
							'<span class="goldNumber">1,000</span>' +
						'</div>' +
					'</div>' +
				'</div>' +
			'</li>' +
			'<li id="clanMain_mine" class="F-TabSubPage active">' +
				'<h3 class="title">_(clanMain.mine.title)</h3>' +
				'<ul class="F-ViewStack content">' +
					'<li id\"clanMain_myInfo" class="subView">' +
						'<div class="clanInfo">' +
							'<div class="baseInfo">' +
								'<h4>' +
									'<span class="quote">[</span>' +
									'<span class="clanTag">BBB</span>' +
									'<span class="quote">]</span> ' +
									'<span class="clanName">CLAN NAME</span>' +
								'</h4>' +
								'<table>' +
									'<tr>' +
										'<th>_(clanMain.label.score)</th>' +
										'<td class="elo">1,000,220</td>' +
										'<th>_(clanMain.label.members)</th>' +
										'<td class="members membersCount">150</td>' +
									'</tr>' +
								'</table>' +
							'</div>' +
							'<pre class="description clanDescription">...</pre>' +
						'</div>' +
						'<div class="buttonBar">' +
							'<div class="F-Button tiny join" id="joinButton">_(clanMain.browse.info.button.join)</div>' +
							'<div class="F-Button tiny red leave" id="leaveButton">_(clanMain.mine.operations.leave)</div>' +
							'<div class="F-Button tiny members">' +
								'_(clanMain.mine.operations.members)' +
								'<div id="clanHint" class="hint"></div>' +
							'</div>' +
						'</div>' +
					'</li>' +
					'<div id="clanSettingsButton" class="F-Button setting" data-tooltip-data="_(clanMain.tooltip.setting)"></div>' +
					'<li class="subView clanForm">' +
						'<div class="F-Button back" data-tooltip-data="_(clanMain.tooltip.back)"></div>' +
						'<div class="tag" data-placeholder="_(clanMain.create.placeholder.tag)"></div>' +
						'<div class="F-TextInput name" data-placeholder="_(clanMain.create.placeholder.name)" data-max-length="6"></div>' +
						'<div class="F-TextInput description clanDescription" data-placeholder="_(clanMain.create.placeholder.description)" data-multiline="true"></div>' +
						'<div class="F-Button huge save">_(clanMain.mine.setting.save)</div>' +
					'</li>' +
				'</ul>' +
			'</li>' +
		'</ul>' +
		'<div class="F-Button close"></div>' +
	'</div>';
