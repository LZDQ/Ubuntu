(function(){
    FunUI.traits.newGame = {
        _nickName : null,
        show: function(nickName)
        {
            this._nickName = nickName || "";
            this.open();
            this.renderLock();
        },
        renderLock: function()
        {
            this.querySelector('.custom').disabled = !playerData.db_id;

            var buttons = this.querySelectorAll(".row.fourth .F-Button");
            for(var i = 0; i < buttons.length; i ++)
            {
                var button = buttons[i];
                var setting = MAP_TYPE_SETTINGS[button.gameMode];

                if(setting.unlockLevel > playerData.lvl)
                {
                    button.disabled = true;
                    button.tooltipData = F_("config.mode.tooltip.lock", {
                        mode : F_(setting.langLabel),
                        level : setting.unlockLevel
                    });
                }
                else
                {
                    button.disabled = false;
                    button.tooltipData = null;
                }
            }
        },
        "<Observer event='click' selector='.row.fourth .F-Button' />": function(event)
        {
            var button = event.currentTarget;
            var gameMode = button.gameMode;
            
            if(MAP_TYPE_SETTINGS[gameMode] && MAP_TYPE_SETTINGS[gameMode].queue)
            {
                this.close();
                network.send('enterQueue$' + gameMode);
				document.getElementById("ladderDiv").style.display = "";
				searchingLadder = true;
				return;
			}
            
            if(MAP_TYPE_SETTINGS[gameMode] && MAP_TYPE_SETTINGS[gameMode].customBuild)
            {
                this.close();
                network.send('joinRandomGame$' + this._nickName + '$' + MAP_TYPE.TOURNAMENT_UNRANKED);
				return;
			}
			
            window.joinGamePurpose = null;
            network.send(sendToServer = "joinRandomGame$" + this._nickName + "$" + gameMode);
            gaEventOnce('player-want-to-join-random-game');
            this.close();
        },
        "<Observer event='click' selector='.row.second .item' />": function(event)
        {
            var target = event.currentTarget;
            var modes = ["ranked", "ffa", "zombie", "team"];
            
            for(var i = 0; i < modes.length; i++)
                if(target.hasClass(modes[i]))
                {
                    for(var j = 0; j < modes.length; j++)
                        if(modes[i] != modes[j])
                            this.removeClass(modes[j]);
                    
                    this.addClass(modes[i]);
                    break;
                }
        },
        "<Observer event='click' selector='.tutorial' />": function()
        {
            if(!isTutored(1))
                gaEventOnce('player-click-tutorial-button');
            
            startTutorial();
            this.close();
        },
        "<Observer event='click' selector='.custom' />": function()
        {
        	if(playerData.db_id)
        	{
            	uiManager.showLobby();
            	this.close();
            }
        }
    };
})();