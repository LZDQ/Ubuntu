(function(){
    FunUI.traits.changeNick = {
        __init__: function () {
            var input = this.querySelector('input');
            input.maxLength = 15;
            input.value = currentProfile.displayName;
        },
        "<Observer event='keypress' selector='input' />": function(e) {
            if(e.keyCode == 13)
                this.submit();
        },
        open: function() {
			var dateLimit = this.querySelector('.dateLimit');
			var day = this.changeLimitDays();
			var hours = ((day % 1) * 24) | 0;
			var minutes = (day < 1 && hours == 0) ? (((((day % 1) * 24) % 1) * 60) | 0) : -1;
			
			if(day)
			{
				dateLimit.innerText = "You can change your name after " + ((day >= 1) ? ((day | 0) + " days and ") : "") + ((hours >= 1 || day >= 1) ? (hours + " hours.") : (minutes + " minutes."));
				dateLimit.style.display = 'block';
			}
			else
				dateLimit.style.display = 'none';
            this.show(null, null, this.submit);
        },
		changeLimitDays: function() {
			return Math.max(6 - ((now() - currentProfile.tsNick) / 86400), 0);
		},
        submit: function()
        {
			if(this.changeLimitDays())
				return;
			
			var nick = this.querySelector('input').value;
			
            var val = checkName(nick);
			if(val != "OK")
			{
				slayOne.viewHelpers.showFloatTip({
					tipType: "error",
					content: val,
					duration: 6000
				});
				return;
			}
			
            network.send("changeNick$" + nick);
			
			playerData.name = nick;
            currentProfile.displayName = nick;
			currentProfile.tsNick = (Date.now() / 1000) | 0;
            var o;
            if(o = Z$('#homeUIContent .nick'))
                o.innerText = nick;
            if(o = Z$('#playerProfileScreen .playerNick'))
                o.innerText = nick;
            this.hide();
        }
    };
})();