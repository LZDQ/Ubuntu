(function(){
    FunUI.traits.tooltipMap = {
        _titleField: null,
        _img: null,
        _imgForLoad: null,
        _sizeField: null,
        __init__: function()
        {
            this._titleField = this.querySelector('h2');
            this._img = this.querySelector('img');
            this._imgForLoad = new Image();
            this._imgForLoad.on("load", this.setImage);
            this._sizeField = this.querySelector('.size');
        },
        render: function(data)
        {
            // this._img.src = "imgs/main_ui/map_placeholder.png";
            this._titleField.innerHTML = data.name;
            this._sizeField.innerHTML = data.w + "x" + data.h;
            // this._img.src = getMapThumbnail(data.id, data.version);
        },
        setImage: function()
        {
            if(this._imgForLoad.naturalWidth == 1 && this._imgForLoad.naturalHeight == 1)
                return;
            
            this._img.src = this._imgForLoad.src;
        }
    };
})();