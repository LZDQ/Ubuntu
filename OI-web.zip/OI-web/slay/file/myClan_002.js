(function(){
    var members = new F$ArrayView(10);
    var requests = new F$ArrayView(10);

    var invalidateRequests = requests.invalidate.bind(requests);
    var invalidateMembers = members.invalidate.bind(members);

    FunUI.traits.myClan = {
        _membersSearchInput : null,
        _requestsSearchInput : null,
        _requestsPage : null,
        _membersPage : null,
        __init__: function()
        {
            this._requestsSearchInput = this.querySelector('.requestsPage .searchInput');
            this._requestsSearchInput.on(FunUI.events.INPUT_SUBMIT, invalidateRequests);
            this._membersSearchInput = this.querySelector('.membersPage .searchInput');
            this._membersSearchInput.on(FunUI.events.INPUT_SUBMIT, invalidateMembers);

            this.querySelector('.requestsPage .F-Button.search').on('click', invalidateRequests);
            this.querySelector('.membersPage .F-Button.search').on('click', invalidateMembers);

            this.on(FunUI.events.ADD_POP_UP, this.onAddPopUp);
            this.on(FunUI.events.REMOVE_POP_UP, this.onRemovePopUp);

            requests.filter = this.requestsFilerFunction;
            members.filter = this.membersFilerFunction;

            this._requestsPage = this.querySelector('.requestsPage');
            this._membersPage = this.querySelector('.membersPage');
        },
        membersFilerFunction: function(data) {
            return data.name.indexOf(this._membersSearchInput.text) >= 0;
        },
        requestsFilerFunction: function(data) {
            return data.name.indexOf(this._requestsSearchInput.text) >= 0;
        },
        showClan: function()
        {
            this.open();
        },
        onAddPopUp: function()
        {
        	network.send("getMemberList$" + currentClan.tag);
            this.querySelector('.F-TabPage.content').selectedIndex = 0;
            requests.source = [];
            members.source = [];
			
            this.title = currentClan.tag;
            this._requestsPage.disabled = currentClan.tag != playerData.clanTag || playerData.clanRole < AUTH_LEVEL.MOD;
        },
        onRemovePopUp: function()
        {
            F$('clanMain').open();
        }
    };

    FunUI.traits.myClan_memberList = {
        dataProvider : members,
    };

    FunUI.traits.myClan_memberList.itemRenderer = {
        _nameLabel : null,
        _roleLabel : null,
        __init__ : function() {
        },
        render: function(data)
        {
            this._nameLabel.innerHTML = data.name;
            this._roleLabel.innerHTML = data.role;
        },
    };

    FunUI.traits.myClan_requestList = {
        dataProvider : requests
    };

    FunUI.traits.myClan_requestList.itemRenderer = {
        _nameLabel : null,
        __init__ : function() {
            this._nameLabel = this.querySelector('.name');
            this.querySelector(".info").on('click', this.getPlayerInfo);
        },
        render: function(data) {
            this._nameLabel.innerHTML = data.name;
        },
        getPlayerInfo: function() {
            showPlayerInfo(this.data.id);
        }
    };
})();