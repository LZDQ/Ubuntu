(function(){
    var chests = new F$ArrayView();
    var quests = new F$ArrayView();
    var cdInterval;
    var countingHandlers = [];

    FunUI.traits.resourceBar = {
        _goldField : null,
        __init__: function()
        {
            this._goldField = this.querySelector('.resource.gold .value');
            this._gemField = this.querySelector('.resource.gem .value');
            
            this.refresh();
        },
        refresh: function()
        {
            if(this._goldField)
                this._goldField.innerHTML = playerData.gold;
            
            if(this._gemField)
            {
                this._gemField.innerHTML = playerData.gems;
                
				var gemDisplay = 'none';
				if(!playerData.gems && !isSteam && playerData && !playerData.steam_bind)
					gemDisplay = 'inline-block';
				
				this.querySelector('.F-Button.buy-gem').style.display = gemDisplay;
            }
           
            chests.source = treasureChests;
        },
        show: function()
        {
            document.body.appendChild(this);

            if(!cdInterval)
                cdInterval = setInterval(this.countdown, 100);
            
            this.refresh();
        },
        hide: function()
        {
            if(this.parentNode)
            {
                clearInterval(cdInterval);
                cdInterval = 0;
                this.parentNode.removeChild(this);
            }
        },
        countdown: function()
        {
            for(var i = 0; i < countingHandlers.length; i ++)
                countingHandlers[i]();
        },
        "<Observer event='click' selector='.F-Button.buy-gem' />": function()
        {
			F$('steamGem').show();
        }
    };

    FunUI.traits.resourceBar_chestsList = {
        dataProvider: chests
    };

    FunUI.traits.resourceBar_chestsList.itemRenderer = {
        _amountField: null,
        _countdownLabel: null,
        _buttonSpeedUp: null,
        _timeout: null,
        __init__: function()
        {
            this._amountField = this.querySelector('.amount');
            this._countdownLabel = this.querySelector('.countdown>.label');
        },
        render: function(data)
        {
            this.className = this.className.replace(/chest_\d+/g, "");
            this.addClass("chest_" + data.id);

            var myChest = playerData.chests[data.id];
            var count = myChest ? myChest.count : 0;
            this._amountField.innerHTML = count;
            setTimeout(this.countdown, 0);
        },
        countdown: function()
        {
            var myChest = playerData.chests[this.data.id];
            var count = myChest ? myChest.count : 0;
            if(count == 0)
            {
                this.removeClass("openable");
                return;
            }

            var countdownIndex = countingHandlers.indexOf(this.countdown);
            var openTime = myChest.openTime * 1000;
            if(openTime >= serverTime())
            {
                this._countdownLabel.innerHTML = formatCountdown(openTime);
                
                if(countdownIndex < 0)
                    countingHandlers.push(this.countdown);
                
                this.removeClass("openable");
            }
            else
            {
                if(countdownIndex >= 0)
                    countingHandlers.splice(countdownIndex, 1);
                
                this.addClass("openable");
            }
        },
        "<Observer event='click' selector='.F-Button.open' />": function()
        {
            network.send("openTreasureChest$" + this.data.id);
        }
    };
	
    FunUI.traits.resourceBar_dailyQuestSidebar = {
        dataProvider : quests,
        refresh: function()
        {
            quests.source = playerData.dailyQuests.quests;
            quests.invalidate();
        },
    };

    FunUI.traits.resourceBar_dailyQuestSidebar.itemRenderer = {
        _quest: null,
        _icon: null,
        _amount: null,
        _haveQuest: null,
        _completed: null,
        __init__: function()
        {
            this._quest = this.querySelector('.questTitle');
            this._icon = this.querySelector('.icon');
            this._amount = this.querySelector('.amount');
            this._haveQuest = this.querySelector('.haveQuest');
            this._completed = this.querySelector('.completed');

            this.on('click', function()
            {
                F$("dailyQuest").open();
            });
        },
        render: function(data)
        {
            this._quest.innerText = slayOne.widgets.lang.get('dailyQuestSidebar.quest');
            if(data == null)
            {
                this._haveQuest.style.display = 'none';
                return;
            }
            
            this._icon.src = "imgs/dailyQuest/" + data.type + ".png";
            this._haveQuest.style.display = 'block';
            this._amount.innerText = data.count + '/' + data.total;
            this._completed.src = "imgs/dailyQuest/completed.png";
            
            if(data.completed)
            {
                this._amount.style.display = 'none';
                this._completed.style.display = 'block';
            }
            else
            {
                this._amount.style.display = 'block';
                this._completed.style.display = 'none';
            }
        }
    };
})();