function PlasmaShield(x, y, toX, toY, radius)
{
	this.x = x;
	this.y = y;
	this.radius = radius ? radius : 0.5;
	
	var vecX = toX - x;
	var vecY = toY - y;
	
	this.angle = getAngle(x, y, toX, toY) + Math.random() * 0.2 - 0.1;
	
	var len = Math.sqrt(vecX * vecX + vecY * vecY);
	
	this.x -= vecX * (this.radius - 0.1) / len;
	this.y -= vecY * (this.radius - 0.1) / len;
	
	this.tickOfBirth = game.ticksCounter;
	this.tickOfDeath = game.ticksCounter + 10;
	
	game.effects.push(this);
	game.addToObjectsToDraw(this);
};

PlasmaShield.prototype.update = function()
{
	return this.tickOfDeath > game.ticksCounter;
};

PlasmaShield.prototype.getYDrawingOffset = function()
{
	return this.y;
};

PlasmaShield.prototype.draw = function(exactTicks, x1, y1, x2, y2)
{
	if(!(this.x + 3 >= x1 && this.y + 3 >= y1 && this.x - 3 <= x2 && this.y - 3 <= y2))
		return;
	
	var age = (exactTicks - this.tickOfBirth) * 50;
	var randomYOffsetPixels = ((age * 0.05) % 4 - 2) * SCALE_FACTOR * 0.5;
	
	c.scale(1, 0.8);
	c.strokeStyle = "rgba(200, 200, 255, " + ((1 - age / 400) * 0.6) + ")";
	c.lineWidth = 1.5 * SCALE_FACTOR;
	
	c.beginPath();
	c.arc((this.x - game.cameraX) * FIELD_SIZE, ((this.y - 0.2 - game.cameraY) * FIELD_SIZE + randomYOffsetPixels) / 0.8, this.radius * FIELD_SIZE, this.angle - 0.5, this.angle + 0.5, false);
	c.arc((this.x - game.cameraX) * FIELD_SIZE, ((this.y - 0.3 - game.cameraY) * FIELD_SIZE + randomYOffsetPixels) / 0.8, this.radius * FIELD_SIZE, this.angle - 0.5, this.angle + 0.5, false);
	c.arc((this.x - game.cameraX) * FIELD_SIZE, ((this.y - 0.4 - game.cameraY) * FIELD_SIZE + randomYOffsetPixels) / 0.8, this.radius * FIELD_SIZE, this.angle - 0.5, this.angle + 0.5, false);
	c.stroke();
	
	c.scale(1, 1 / 0.8);
};