function Sprite(data)
{
	this.offsetDrawing = 5;

	extend(this, data);

	this.tickOfBirth = game.ticksCounter;
	this.ticksToLive = this.age ? this.age : 30;
	this.ticksLeft = this.ticksToLive;
	this.tickOfDeath = this.tickOfBirth + this.ticksToLive;

	this.alphaFunction = this.alphaFunction ? this.alphaFunction : function(age){ return (this.ticksToLive - age < 20) ? Math.max((this.ticksToLive - age) / 20, 0) : 1; };

	this.height = this.height ? this.height : 0;

	this.drawY = this.y;

	game.effects.push(this);
	game.addToObjectsToDraw(this);
};

Sprite.prototype.update = function()
{
	if(this.dieOnCollision)
	{
		var age = game.ticksCounter + 1 - this.tickOfBirth;

		var x = this.x;
		if(this.xFunction)
			x += this.xFunction(age);

		var y = this.y;
		if(this.yFunction)
			y += this.yFunction(age);

		return game.getFieldPath(Math.floor(x), Math.floor(y)) > 5 && this.tickOfDeath > game.ticksCounter;
	}

	return this.tickOfDeath > game.ticksCounter;
};

Sprite.prototype.getYDrawingOffset = function()
{
	if (!(this.drawY > -999999)) {
		return -1;
	}
	return this.drawY;
};

Sprite.prototype.draw = function(exactTicks, x1, y1, x2, y2)
{
	if(!(this.x + this.offsetDrawing >= x1 && this.y + this.offsetDrawing >= y1 && this.x - this.offsetDrawing <= x2 && this.y - this.offsetDrawing * 2 <= y2) || !this.img)
		return;

	var age = exactTicks - this.tickOfBirth;
	this.ticksLeft = Math.max(this.ticksToLive - age, 0);

	var alpha = this.alphaFunction ? this.alphaFunction(age) : 1;
	var scale = Math.max(this.scaleFunction(age), 0) * SCALE_FACTOR;
	var z = this.zFunction ? this.zFunction(age) : 0;

	var x = this.x;
	if(this.xFunction)
		x += this.xFunction(age);

	var y = this.y;
	if(this.yFunction)
		y += this.yFunction(age) * 0.75;

	this.drawY = y;

	if (!(y > -999999) && !(y < -999999)) {
		this.drawY = -10;
		this.ticksLeft = 0;
	}

	var drawX = g2rx(x) - (this.img.w / 2) * scale;
	var drawY = g2ry(y - z) - (this.img.h / 2) * scale;

	c.globalAlpha = alpha;
	c.drawImage(imgs.miscSheet, this.img.x, this.img.y, this.img.w, this.img.h, drawX, drawY, this.img.w * scale, this.img.h * scale);
	c.globalAlpha = 1;
};
