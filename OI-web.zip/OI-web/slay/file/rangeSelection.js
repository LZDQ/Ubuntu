(function(window, slayOne, document){

/**
 * Range selection slider
 *
 * @param parentNode: dom element to append to
 * @param options:
 *                  min: number
 *                  max: number
 *                  value: number
 *                  step: number
 *                  onChange: function(number)
 *                  customClassName: string
 */
function rangeSelection(parentNode, options) {

    var domContainer = document.createElement("div");

    var classNameOption = (options && options.customClassName)? options.customClassName : '';

    domContainer.innerHTML = "<input class='" + classNameOption + "' type='range' min='" + options.min + "' max='" + options.max + "' step='" + options.step + "' value='" + options.value + "' id='soundRange'/>";
    parentNode.appendChild(domContainer);

    domContainer.querySelector("input").onchange = function(e){
        options.onChange(e.target.value);
    };

    return domContainer;
}

//export
if(!slayOne.widgets) {
    slayOne.widgets = {};
}

slayOne.widgets.rangeSelection = rangeSelection;

})(window, window.slayOne, window.document);//end main closure