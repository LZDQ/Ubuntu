function Object_(id, owner, ability, x, y, hp, maxHP, ticks2live, aoe, tickOfDeath, targetX, targetY)
{
	this.id = id;
	this.x = parseInt(x) + 0.5;
	this.y = parseInt(y) + 0.5;
	this.z = 0;
	this.x0 = this.x;
	this.y0 = this.y;
	this.z0 = this.z;
	this.maxHP = parseFloat(maxHP);
	this.hp = hp ? parseFloat(hp) : this.maxHP;
	this.aoe = aoe ? parseFloat(aoe) : 0;
	this.owner = owner;
	this.isObject = true;
	this.ability = ability;
	this.object = objects[ability.object];
	this.barYOffset = (this.object && this.object.barYOffset) ? this.object.barYOffset : 1.55;
	this.hpPerTick = this.object ? this.object.hpPerTick : 0;
	this.dmg = this.object ? this.object.dmg : 0;
	this.animation = animationData[this.object.animation];
	this.weapon = this.object ? this.object.weapon : null;
	this.lifetime = (ticks2live ? parseFloat(ticks2live) : this.object.lifetime);
	this.tickOfDeath = tickOfDeath ? (parseInt(tickOfDeath) + game.ticksCounter) : (game.ticksCounter + this.lifetime);
	this.tickOfBirth = this.tickOfDeath - this.lifetime;
	this.particles = [];
	this.lightPillarsTop = [];
	this.lightPillarsBottom = [];
	this.imgScale = (this.object && this.object.imgScale) ? this.object.imgScale : 1;
	this.healthBarW = (this.object && this.object.healthBarW) ? this.object.healthBarW : 24;
	this.showLifeTimeBar = this.object && this.object.showLifeTimeBar;
	this.invincibleUntil = -9999;
	this.laserHitUntil = -999;
	
	if(this.ability.type == "place")
		this.createSpawnEffect();
	
	if(this.ability.type == "throw" && this.x + 3 >= game.cameraX && this.y + 3 >= game.cameraY && this.x - 3 <= game.cameraX2 && this.y - 3 <= game.cameraY2)
		soundManager.playSound(SOUND.THROW, this.x, this.y, 0.8);
	
	this.countParticles = Math.floor(this.aoe * Math.pow(Math.PI, 2) * 0.25);
	this.hitUntil = -999;
	this.bleeds = false;
	this.lastTickFire = -9999;
	this.direction = 1;
	this.lastShootX = 0;
	this.lastShootY = 0;
	this.yOffset = (this.object && this.object.yOffset) ? this.object.yOffset : 0;
	this.emitsSmoke = this.object && this.object.emitsSmoke;
	this.flash = this.object && this.object.flash;
	this.rotation = 1.0;
	
	if(ability.type == "throw")
	{
		this.x = parseFloat(x);
		this.y = parseFloat(y);
		
		this.vecX = parseFloat(targetX) - this.x;
		this.vecY = parseFloat(targetY) - this.y;
		
		var len = Math.sqrt(this.vecX * this.vecX + this.vecY * this.vecY);
		if(len == 0)
			len = 0.01;
		
		this.z = 0.6;
		
		this.vecH = Math.pow(len, 0.25) * 0.12;
		var speed = len * 0.065;
		
		this.vecX *= speed / len;
		this.vecY *= speed / len;
		
		this.groundBounceCounter = 0;
		this.lastBlockHeight = 0;
		
		this.tickOfDeath = game.ticksCounter + 999999;
		this.hasLanded = false;
	}
		
	game.addToObjectsToDraw(this);
	
	if(ability.type == "place" && this.object && game.pathingArray[x] && game.pathingArray[x][y])
		game.pathingArray[x][y] = this.object.pathing;
};

Object_.prototype.blink = function(x, y, oldX, oldY)
{
	soundManager.playSound(SOUND.BLINK, this.x, this.y, 0.6);
	createBlinkEffectSmall(parseFloat(oldX) - 0.2 + Math.random() * 0.4, parseFloat(oldY) - 0.2 + Math.random() * 0.4);
	
	this.x = parseFloat(x);
	this.y = parseFloat(y);
	
	this.x0 = this.x;
	this.y0 = this.y;
	
	soundManager.playSound(SOUND.BLINK, this.x, this.y, 0.6);
	createBlinkEffectSmall(this.x - 0.25 + Math.random() * 0.5, this.y - 0.25 + Math.random() * 0.5);
};

Object_.prototype.groundBounce = function()
{
	if(this.hasLanded)
		return;
	
	this.groundBounceCounter++;
	
	var power = Math.min(1, this.vecH * 10);
	soundManager.playSound(SOUND.GRENADE_BOUNCE, this.x, this.y, 0.45 * power);
	createPoundSmoke(this.x, this.y + 0.9, 0.35 * power, 7, 0.4);
	this.rotation = Math.random() * 2.0 - 1.0;
	
	// flash pre sound
	if(this.groundBounceCounter == 3 && this.flash && this.x + 3 >= game.cameraX && this.y + 3 >= game.cameraY && this.x - 3 <= game.cameraX2 && this.y - 3 <= game.cameraY2)
		soundManager.playSound(SOUND.FLASH_START, this.x, this.y, 1);
	
	if(this.groundBounceCounter == 5)
	{
		if(this.emitsSmoke && this.x + 3 >= game.cameraX && this.y + 3 >= game.cameraY && this.x - 3 <= game.cameraX2 && this.y - 3 <= game.cameraY2)
		{
			soundManager.playSound(SOUND.SMOKE_START, this.x, this.x, 0.15);
			createPoundSmoke(this.x, this.y + 0.5, 0.7, 9, 0.4);
		}
		
		this.tickOfDeath = game.ticksCounter + this.lifetime + 5;
		this.tickOfBirth = game.ticksCounter + 5;
	}
};

Object_.prototype.wallBounceEffect = function(oldVX, oldVY, newVX, newVY)
{
	if(game.fastForward)
		return;
	
	if(oldVX != newVX && this.tickOfBirth + 1 < game.ticksCounter)
	{
		soundManager.playSound(SOUND.GRENADE_BOUNCE, this.x, this.y, 0.45);
		this.rotation = Math.random() * 3.0 - 1.5;
		
		var x_circular = 0;
		var y_circular = 1;
		var z_circular = 1;
		
		for(var i = 0; i < Math.PI * 2; i += 0.7 + 0.4 * Math.random())
			new Sprite({
				x: this.x,
				y: this.y - this.z,
				img: imgCoords.dust2,
				scaleFunction: function(age){ return this.r4 + age * 0.04; },
				alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.2; },
				age: 20 + Math.random() * 10,
				rX: x_circular * Math.sin(i) * (Math.random() * 0.8 + 0.6),
				rY: y_circular * Math.sin(i) * (Math.random() * 0.8 + 0.6),
				rZ: z_circular * Math.cos(i) * (Math.random() * 0.8 + 0.6),
				r4: Math.random() * 0.2 + 0.5,
				xFunction: function(age){ return (-5 / (age * 0.9 + 2.5) + 2) * this.rX * 0.2; },
				yFunction: function(age){ return (-5 / (age * 0.9 + 2.5) + 2) * this.rY * 0.2; },
				zFunction: function(age){ return (-5 / (age * 0.9 + 2.5) + 2) * this.rZ * 0.2; }
			});
	}
	
	if(oldVY != newVY && this.tickOfBirth + 1 < game.ticksCounter)
	{
		soundManager.playSound(SOUND.GRENADE_BOUNCE, this.x, this.y, 0.45);
		this.rotation = Math.random() * 3.0 - 1.5;
		
		var x_circular = 1;
		var y_circular = 0;
		var z_circular = 1;
		
		for(var i = 0; i < Math.PI * 2; i += 0.7 + 0.4 * Math.random())
			new Sprite({
				x: this.x,
				y: this.y - this.z,
				img: imgCoords.dust2,
				scaleFunction: function(age){ return this.r4 + age * 0.04; },
				alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.2; },
				age: 20 + Math.random() * 10,
				rX: x_circular * Math.sin(i) * (Math.random() * 0.8 + 0.6),
				rY: y_circular * Math.sin(i) * (Math.random() * 0.8 + 0.6),
				rZ: z_circular * Math.cos(i) * (Math.random() * 0.8 + 0.6),
				r4: Math.random() * 0.2 + 0.5,
				xFunction: function(age){ return (-5 / (age * 0.9 + 2.5) + 2) * this.rX * 0.2; },
				yFunction: function(age){ return (-5 / (age * 0.9 + 2.5) + 2) * this.rY * 0.2; },
				zFunction: function(age){ return (-5 / (age * 0.9 + 2.5) + 2) * this.rZ * 0.2; }
			});
	}
};

Object_.prototype.update = function()
{
	if(this.ability.type == "throw")
	{
		this.x0 = this.x;
		this.y0 = this.y;
		this.z0 = this.z;
		
		this.x += this.vecX;
		this.y += this.vecY;
		
		var blockHeight = game.getHeight2(Math.floor(this.x), Math.floor(this.y));
		
		var hitWall = false;
		
		if(this.z < blockHeight)
		{
			if(blockHeight == this.lastBlockHeight)
			{
				if(game.getFieldPath(Math.floor(this.x), Math.floor(this.y)) == 9) // if we hit water, return false (kill this object)
				{
					if(this.x + 3 >= game.cameraX && this.y + 3 >= game.cameraY && this.x - 3 <= game.cameraX2 && this.y - 3 <= game.cameraY2)
						new Splash(this.x, this.y, imgCoords.splash);
					
					return false;
				}
				
				this.vecH *= -0.5;
				this.vecX *= 0.9;
				this.vecY *= 0.9;
				this.z = blockHeight;
				this.groundBounce();
				
				if(this.vecH < 0.002 || this.groundBounceCounter > 6 && !this.hasLanded)
				{
					this.tickOfDeath = game.ticksCounter + this.lifetime;
					this.hasLanded = true;
					return true;
				}
			}
			
			else
			{
				hitWall = true;
				
				this.x -= this.vecX * 2;
				blockHeight = game.getHeight2(Math.floor(this.x), Math.floor(this.y));
				
				if(this.z < blockHeight)
				{
					this.x += this.vecX * 2;
					this.y -= this.vecY * 2;
					blockHeight = game.getHeight2(Math.floor(this.x), Math.floor(this.y));
					
					if(this.z < blockHeight)
						this.x -= this.vecX * 2;
				}
			}
		}
		
		this.vecX = this.x - this.x0;
		this.vecY = this.y - this.y0;
		
		if(hitWall)
		{
			var oldVX = Math.sign(this.x - this.x0);
			var oldVY = Math.sign(this.y - this.y0);
			
			this.vecX *= 0.9;
			this.vecY *= 0.9;
			
			this.x = this.x0;
			this.y = this.y0;
			
			var newVX = Math.sign(this.x - this.x0);
			var newVY = Math.sign(this.y - this.y0);
			
			this.wallBounceEffect(oldVX, oldVY, newVX, newVY);
		}
		
		this.z += this.vecH;
		if(this.z < 0)
		{
			if(game.getFieldPath(Math.floor(this.x), Math.floor(this.y)) == 9) // if we hit water, return false (kill this object)
			{
				if(this.x + 3 >= game.cameraX && this.y + 3 >= game.cameraY && this.x - 3 <= game.cameraX2 && this.y - 3 <= game.cameraY2)
					new Splash(this.x, this.y, imgCoords.splash);
				
				return false;
			}
			
			this.z = 0;
			this.vecH *= -0.5;
			this.vecX *= 0.75;
			this.vecY *= 0.75;
			this.groundBounce();
			
			if(this.vecH < 0.005 || this.groundBounceCounter > 6 && !this.hasLanded)
			{
				this.tickOfDeath = game.ticksCounter + this.lifetime;
				this.hasLanded = true;
				return true;
			}
		}
		
		this.vecH -= 0.045;
		
		this.vecX *= 0.97;
		this.vecY *= 0.97;
		
		this.lastBlockHeight = blockHeight;
		
		if(!this.hasLanded && this.groundBounceCounter >= 4 && game.ticksCounter % 5 == 2 && this.emitsSmoke && this.x + 3 >= game.cameraX && this.y + 3 >= game.cameraY && this.x - 3 <= game.cameraX2 && this.y - 3 <= game.cameraY2)
			createPoundSmoke(this.x, this.y + 0.5, 0.7, 9, 0.4);
		
		if(!this.hasLanded)
			return true;
	}
	
	if(this.hpPerTick && game.ticksCounter % 7 == 0 && this.x + 5 >= game.cameraX && this.y + 5 >= game.cameraY && this.x - 5 <= game.cameraX2 && this.y - 5 <= game.cameraY2)
		soundManager.playSound(SOUND.HEAL_AURA, this.x, this.y, 0.4);
	
	// smoke
	if(this.emitsSmoke && (game.ticksCounter - this.tickOfBirth) % 20 == 0 && !game.fastForward)
	{
		new Sprite({
			x: this.x + Math.random() * 9 - 4.5,
			y: this.y + 6.0 + Math.random() * 9 - 4.5,
			x_: Math.random() * 0.05 - 0.025,
			y_: Math.random() * 0.05 - 0.025,
			img: imgCoords.hpBar4,
			scale_: Math.random() * 0.2 + 0.9,
			scaleFunction: function(age){ return (3.5 + age * 0.002) * this.scale_; },
			alphaFunction: function(age){ return Math.min(this.ticksLeft * 0.03, age * 0.05, 1); },
			xFunction: function(age){ return age * this.x_; },
			yFunction: function(age){ return age * this.y_; },
			zFunction: function(age){ return 7; },
			offsetDrawing: 12,
			age: 240
		});
		
		new Sprite({
			x: this.x + Math.random() * 0.5 - 0.25,
			y: this.y + 4.0 + Math.random() * 0.5 - 0.25,
			x_: Math.random() * 0.01 - 0.005,
			y_: Math.random() * 0.01 - 0.005,
			img: imgCoords.hpBar4,
			scale_: Math.random() * 0.2 + 0.9,
			scaleFunction: function(age){ return (0.4 + age * 0.011) * this.scale_; },
			alphaFunction: function(age){ return Math.min(this.ticksLeft * 0.1, age * 0.1, 1); },
			xFunction: function(age){ return age * this.x_; },
			yFunction: function(age){ return age * this.y_; },
			zFunction: function(age){ return 4; },
			age: 40
		});
	}
	
	// smoke loop sound
	if((this.emitsSmoke || (this.object && this.object.emitsPoison)) && (game.ticksCounter - this.tickOfBirth) % 14 == 9 && this.x + 3 >= game.cameraX && this.y + 3 >= game.cameraY && this.x - 3 <= game.cameraX2 && this.y - 3 <= game.cameraY2)
		soundManager.playSound(SOUND.SMOKE_LOOP, this.x, this.y, 0.5);
	
	if(this.ability.type == "throw" && this.aoe && this.dmg && this.tickOfDeath == game.ticksCounter && this.x + 10 >= game.cameraX && this.y + 10 >= game.cameraY && this.x - 10 <= game.cameraX2 && this.y - 10 <= game.cameraY2)
	{
		createExplosion(this.x, this.y, this.aoe, 1);
		soundManager.playSound(SOUND.EXPLODE, this.x, this.y, 0.8);
		game.corpseBounce(this.x, this.y, this.aoe);
	}
	
	if(this.object && this.object.emitsPoison && this.tickOfBirth == game.ticksCounter)
	{
		createPoundSmoke(this.x, this.y, 0.5, 8, 0.3);
		soundManager.playSound(SOUND.SMOKE_START, this.x, this.y, 0.15);
	}
	
	return game.ticksCounter < this.tickOfDeath;
};

Object_.prototype.die = function()
{
	game.objectsToDraw.erease(this);
	
	if(this.ability.type == "place")
	{
		if(game.pathingArray[Math.floor(this.x)] && game.pathingArray[Math.floor(this.x)][Math.floor(this.y)] >= 0)
			game.pathingArray[Math.floor(this.x)][Math.floor(this.y)] = 10;
		
		createExplosion(this.x, this.y, 1, 0.25);
		soundManager.playSound(SOUND.EXPLODE, this.x, this.y, 0.5);
	}
	
	if(this.ability.type == "throw" && this.object && this.object.countLasers)
	{
		createExplosion(this.x, this.y, 0.3, 0.25);
		soundManager.playSound(SOUND.EXPLODE, this.x, this.y, 0.6);
		soundManager.playSound(SOUND.LASER, this.x, this.y, 1.0);
	}
};

Object_.prototype.getYDrawingOffset = function()
{
	return this.y;
};

Object_.prototype.createSpawnEffect = function()
{
	this.lightPillarsTop = [];
	this.lightPillarsBottom = [];
	
	if(!(this.x + 5 >= game.cameraX && this.y + 5 >= game.cameraY && this.x - 5 <= game.cameraX2 && this.y - 5 <= game.cameraY2))
		return;
	
	for(var i = 0; i < Math.PI * 2; i += 0.3 + Math.random() * 0.15)
		(i <= Math.PI ? this.lightPillarsBottom : this.lightPillarsTop).push({
			x: Math.sin(i) * 0.45 + this.x,
			y: Math.cos(i) * 0.45 + this.y,
			w: 0.15 + Math.random() * 0.3,
			h: Math.random() * 1.5,
			vh: 0.04 + Math.random() * 0.08,
			vw: Math.random() * 0.01,
			age_offset: Math.random() * 8 - 4
		});
	
	soundManager.playSound((this.object && this.object.spawnSound) ? SOUND[this.object.spawnSound] : SOUND.AMMO_SPAWN, this.x, this.y, (this.object && this.object.volume) ? this.ability.volume : 0.7);
};

Object_.prototype.updateAndDrawPillar = function(p, age)
{
	p.h += p.vh * exactTickDiff;
	p.w += p.vw * exactTickDiff;
	
	var x = (p.x - p.w / 2 - game.cameraX) * FIELD_SIZE;
	var y = (p.y - p.h - game.cameraY) * FIELD_SIZE;
	var this_age = age + p.age_offset;
	
	c.globalAlpha = ((this_age < 5) ? Math.max(this_age / 5, 0) : ((this_age < 10) ? 1 : Math.max(2.0 - this_age / 10, 0))) * 0.4;
	c.drawImage(imgs.miscSheet, imgCoords.pillar_of_light.x, imgCoords.pillar_of_light.y, imgCoords.pillar_of_light.w, imgCoords.pillar_of_light.h, x, y, p.w * FIELD_SIZE, p.h * FIELD_SIZE);
};

Object_.prototype.shoot = function(x1, y1, x2, y2)
{
	this.lastTickFire = game.ticksCounter;
	this.direction = getDirectionFromAgle(x1, y1, x2, y2);
	this.lastShootX = x2;
	this.lastShootY = y2;
};

Object_.prototype.draw = function(exactTicks, x1, y1, x2, y2, percentageOfCurrentTickPassed)
{
	if(!(this.x + 5 >= x1 && this.y + 5 >= y1 && this.x - 5 <= x2 && this.y - 5 <= y2))
		return;
	
	if(this.ability.type == "throw")
	{
		if(!this.hasLanded)
		{
			var x = (this.x0 + percentageOfCurrentTickPassed * (this.x - this.x0) - game.cameraX) * FIELD_SIZE;
			var y = (this.y0 + percentageOfCurrentTickPassed * (this.y - this.y0) - game.cameraY) * FIELD_SIZE;
			var h = (this.z0 + percentageOfCurrentTickPassed * (this.z - this.z0)) * FIELD_SIZE;
			
			var img = imgCoords[this.object.img[Math.floor(exactTicks * this.rotation + 99999999) % this.object.img.length]];
			
			c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, x - img.w * SCALE_FACTOR / 2, y - img.h * SCALE_FACTOR / 2 - h, img.w * SCALE_FACTOR, img.h * SCALE_FACTOR);
			
			return;
		}
		
		var x = (this.x - game.cameraX) * FIELD_SIZE;
		var y = (this.y - game.cameraY) * FIELD_SIZE;
		var h = 0;
		
		var img = imgCoords[this.object.img[0]];
		
		if(this.object && this.object.emitsPoison)
			c.globalAlpha = Math.min(Math.max((this.tickOfDeath - exactTicks) * 0.03, 0), 1);
		
		c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, x - img.w * SCALE_FACTOR / 2, y - img.h * SCALE_FACTOR / 2 - h, img.w * SCALE_FACTOR, img.h * SCALE_FACTOR);
		c.globalAlpha = 1;
		
		return;
	}
	
	var age = exactTicks - this.tickOfBirth;
	
	if(age < 25) // play spawn effect
		for(var i = 0; i < this.lightPillarsTop.length; i++)
			this.updateAndDrawPillar(this.lightPillarsTop[i], age);
	c.globalAlpha = 1;
	
	var scale = SCALE_FACTOR * this.imgScale;
	var img = imgCoords[this.object.img[0]];
		
	if(this.object && this.object.animationType == "dmg")
	{
		img = imgCoords[this.object.img[Math.floor(this.object.img.length * (1 - this.hp / this.maxHP))]];
		if(!img)
			img = imgCoords[this.object.img[0]];
	}
	
	if(this.object && this.object.animationType == "auto")
	{
		img = imgCoords[this.object.img[Math.floor(game.ticksCounter * 0.2 + 999999) % this.object.img.length]];
		if(!img)
			img = imgCoords[this.object.img[0]];
	}
	
	var x = (this.x - game.cameraX) * FIELD_SIZE + (-img.w / 2) * scale;
	var y = (this.y + this.yOffset / 16 - 0.2 - game.cameraY) * FIELD_SIZE + (8 - img.h) * scale;
	
	c.globalAlpha = age < 8 ? Math.max(age / 8, 0) : 1;
	
	c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, x, y, img.w * scale, img.h * scale);
	c.globalAlpha = 1;
	
	var whiteness = 0;
	if(this.hitUntil >= exactTicks)
		whiteness = Math.random() < 0.5 ? 0.95 : 0.1;
	
	if(this.laserHitUntil >= exactTicks)
		whiteness = 0.95;
	
	if(whiteness > 0)
	{
		c.globalAlpha = whiteness;
		c.drawImage(imgs.miscSheetWhite, img.x, img.y, img.w, img.h, x, y, img.w * scale, img.h * scale);
		c.globalAlpha = 1;
	}
	
	// turret
	if(this.weapon)
	{
		var x_recoiled = 0;
		var y_recoiled = 0;
		
		if(this.lastTickFire >= exactTicks - 8)
		{
			x_recoiled = -this.lastShootX;
			y_recoiled = -this.lastShootY;
			
			var len = Math.sqrt(x_recoiled * x_recoiled + y_recoiled * y_recoiled);
			var len2 = 0.2 - Math.min(Math.max(exactTicks - this.lastTickFire - ((this.weapon && this.weapon.recoilTime) ? this.weapon.recoilTime : 3), 0) * 0.09, 0.2); 
			
			x_recoiled *= (len2 * FIELD_SIZE) / len;
			y_recoiled *= (len2 * FIELD_SIZE) / len;
			
			if(this.weapon.recoil)
			{
				x_recoiled *= this.weapon.recoil;
				y_recoiled *= this.weapon.recoil;
			}
		}
		
		var wpn_nr = 0;
		if(this.animation.countFrames)
			wpn_nr = (this.lastTickFire + 4 > exactTicks) ? (parseInt(exactTicks / this.weapon.cooldown) % this.animation.countFrames) : 0;
		
		var img = this.animation["imgTurret" + wpn_nr + this.direction];
		var x2 = (this.x - game.cameraX) * FIELD_SIZE + (-img.w / 2) * scale;
		var y2 = (this.y - 0.2 - game.cameraY) * FIELD_SIZE + (8 - img.h) * scale;
		c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, x2 + x_recoiled, y2 + y_recoiled, img.w * scale, img.h * scale);
		
		// muzzle flash
		if(this.animation.muzzleFlash && this.lastTickFire >= exactTicks - 2)
		{
			var mfi = this.animation.muzzleFlash;
			var mff = Math.floor(exactTicks * 0.5) % 2;
			x2 = (this.x - game.cameraX) * FIELD_SIZE - (44 / 2) * scale;
			y2 = (this.y - 0.2 - game.cameraY) * FIELD_SIZE - (44 / 2) * scale;
			
			c.drawImage(imgs.miscSheet, mfi.x + this.direction * 44, mfi.y + mff * 44, 44, 44, x2 - 0 * scale + x_recoiled, y2 - 0 * scale + y_recoiled, 44 * scale, 44 * scale);
		}
	}
	
	if(age < 25) // play spawn effect
		for(var i = 0; i < this.lightPillarsBottom.length; i++)
			this.updateAndDrawPillar(this.lightPillarsBottom[i], age);
	c.globalAlpha = 1;
	
	// circle
	if(this.ability == abilities[0])
	{
		drawCircle((this.x - game.cameraX) * FIELD_SIZE, (this.y - game.cameraY) * FIELD_SIZE, this.aoe * FIELD_SIZE, null, "rgba(30, 255, 30, 0.05)", 0.85);
		drawCircle((this.x - game.cameraX) * FIELD_SIZE, (this.y - game.cameraY) * FIELD_SIZE, this.aoe * FIELD_SIZE, "rgba(200, 200, 255, 0.1)", null, 0.85, 0.7);
		
		while(this.particles.length < this.countParticles)
		{
			var rng = Math.random() * Math.PI * 2;
			
			this.particles.push({
				x: Math.sin(rng) * this.aoe * Math.random() + this.x,
				y: Math.cos(rng) * this.aoe * Math.random() + this.y,
				tickOfCreation: exactTicks,
				tickOfDeath: exactTicks + Math.random() * 40 + 20,
				speed: (Math.random() * 0.5 + 0.35) / 1000
			});
		}
		
		c.lineWidth = SCALE_FACTOR;
		
		for(var i = 0; i < this.particles.length; i++)
		{
			var particle = this.particles[i];
			
			if(particle.tickOfDeath <= exactTicks)
			{
				this.particles.splice(i, 1);
				i--;
			}
			
			else
			{
				var age2 = (exactTicks - particle.tickOfCreation) * 50;
				
				var drawX = (particle.x - game.cameraX) * FIELD_SIZE;
				var drawX2 = drawX;
				var drawY = (particle.y - 1 - game.cameraY) * FIELD_SIZE;
					
				var drawY1 = drawY - particle.speed * age2 * FIELD_SIZE;
				var drawY2 = drawY - (particle.speed * age2 * 1.5 - 1.2) * FIELD_SIZE;
				
				if(age2 < 500)
					c.globalAlpha = age2 / 500;
				
				if(particle.tickOfDeath - exactTicks < 10)
					c.globalAlpha = (particle.tickOfDeath - exactTicks) / 10;
				
				var grad = c.createLinearGradient(drawX2, drawY2, drawX, drawY1);
				grad.addColorStop(0, "rgba(180, 255, 170, 0.0)");
				grad.addColorStop(0.5, "rgba(180, 255, 170, 0.3)");
				grad.addColorStop(1, "rgba(180, 255, 170, 0.0)");
				c.strokeStyle = grad;
				
				c.beginPath();
				c.moveTo(drawX, drawY1);
				c.lineTo(drawX2, drawY2);
				c.stroke();
				
				c.globalAlpha = 1;
			}
		}
		
		c.globalAlpha = 1;
	}
	
	if(this.object && this.object.noBars && !KeyManager.keys[KEY.ALT])
		return;
	
	var x = (this.x - game.cameraX) * FIELD_SIZE;
	var y = (this.y - game.cameraY) * FIELD_SIZE;
	
	
	
	
	// hp
	var barScale = SCALE_FACTOR * 0.55;
	var barW = this.healthBarW * 1.8;
	var barH = 8;
	
	var x2 = x - (barW * barScale) / 2;
	var y2 = y - 1.85 * FIELD_SIZE;
	
	c.fillStyle = "black";
	c.fillRect(x2, y2, barW * barScale, barH * barScale);
	
	var hp = Math.min(this.hp - (this.hpGlideEnd >= exactTicks ? (this.hpGlideAmount * (this.hpGlideEnd - exactTicks) / (this.hpGlideEnd - this.hpGlideStart)) : 0), this.maxHP);
	
	img = (!game.playingPlayer || (this.owner && this.owner.isAlliedWith(game.playingPlayer))) ? imgCoords.hpBar1 : imgCoords.hpBar3;
	
	var w = (barW - 2) * barScale * (hp / this.maxHP);
	
	c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, x2 + 1 * barScale, y2 + 1 * barScale, w, barScale * 6);
	
	// hp seperator
	c.strokeStyle = "rgba(0, 0, 0, 1)";
	c.lineWidth = barScale;
	for(var i = CONST.HP_SEPERATOR_AMOUNT; i < this.maxHP; i += CONST.HP_SEPERATOR_AMOUNT)
	{
		c.beginPath();
		// c.moveTo(x2 + 1 * barScale + (i / this.maxHP) * barW * barScale, y2 + 1 * barScale);
		// c.lineTo(x2 + 1 * barScale + (i / this.maxHP) * barW * barScale, y2 + 3 * barScale);
		c.moveTo(x2 + 1 * barScale + (i / this.maxHP) * (barW - 2) * barScale, y2 + 5 * barScale);
		c.lineTo(x2 + 1 * barScale + (i / this.maxHP) * (barW - 2) * barScale, y2 + 7 * barScale);
		c.stroke();
	}
	
	if(this.ability.noBars)
		return;
	
	// lifetime
	if(this.showLifeTimeBar)
	{
		y2 -= FIELD_SIZE * 0.375;
		c.fillStyle = "black";
		c.fillRect(x2 - FIELD_SIZE * 0.03, y2 - FIELD_SIZE * 0.03, FIELD_SIZE * 1.56, FIELD_SIZE * 0.30);
		w = 24 * ((this.tickOfDeath - exactTicks) / this.lifetime);
		c.drawImage(imgs.miscSheet, imgCoords.barBlue.x, imgCoords.barBlue.y, w, 4, x2, y2, SCALE_FACTOR * w, FIELD_SIZE * 0.24);
	}
	
	// ready up bar
	if(this.ability.initTicks && this.tickOfBirth + this.ability.initTicks > exactTicks)
	{
		y2 -= FIELD_SIZE * 0.375;
		c.fillStyle = "black";
		c.fillRect(x2 - FIELD_SIZE * 0.03, y2 - FIELD_SIZE * 0.03, FIELD_SIZE * 1.56, FIELD_SIZE * 0.30);
		w = 24 * ((exactTicks - this.tickOfBirth) / this.ability.initTicks);
		c.drawImage(imgs.miscSheet, imgCoords.barBlue.x, imgCoords.barBlue.y, w, 4, x2, y2, SCALE_FACTOR * w, FIELD_SIZE * 0.24);
	}
};