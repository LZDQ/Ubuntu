(function(window, slayOne, document){

/**
 * Dropdown menu
 *
 * @param parentNode: dom element to append to
 * @param options
 *                  selectOptions: array of objects, one for each possible option that the user can switch to. [{label:string,value:string}]
 					initIndex: init index among selectOptions
 *                  onSwitch: callback for when user switches which option is currently selected
 *                  mainButtonTip: tooltip for main button
 *                  customClassName: string
 *                  customButtonClassName: string
 *                  customButtonWidth: css property string, to be used for control hover light
 *                  customButtonHeight: css property string, to be used for control hover light
 */
function dropdownMenu(parentNode, options) {

    var domMenu = document.createElement("div");

    var domToggle = document.createElement("div");
    domToggle.className = "dropdownToggleButton";
    domMenu.appendChild(domToggle);

    var finalClassName = "dropdownMenu";
    if(options && options.customClassName)
        finalClassName += " " + options.customClassName;
    domMenu.className = finalClassName;
    
    if(options && options.cssId)
        domMenu.id = options.cssId;

    var initIndexOption = 0;
    if(options && options.initIndex) {
        initIndexOption = options.initIndex;
    }
    domMenu.selectedIndex = initIndexOption;

    var domMainButton = slayOne.widgets.standardText(domMenu, options.selectOptions[initIndexOption].label, {
    	textAlign: "left",
        customClassName: options.customButtonClassName
    });

    domMenu.optionsData = options.selectOptions;
	
    var tipWidth = (options && options.customButtonWidth) ? options.customButtonWidth : '202px';
    var tipHeight = (options && options.customButtonHeight) ? options.customButtonHeight : '40px';

    // Add all options into the list
    var domList = document.createElement("div");
    domList.className = "dropdownMenuList";
    var optionsCount = options.selectOptions.length;
    for(var optionIndex = 0; optionIndex < optionsCount; optionIndex++) {
    	var dataOption = options.selectOptions[optionIndex];
    	var domOption = slayOne.widgets.standardText(domList, dataOption.label, {
    		textAlign: "left",
    		skin: (domMenu.selectedIndex == optionIndex) ? "light" : "dark",
            customContainerClassName: "dropdownMenuListItem",
            customClassName: options.customButtonClassName
    	});
        domOption.dataset.optionIndex = optionIndex;
    	domOption.onclick = function(idx){
            return function(){
                if(domMenu.selectOption(idx)) {
                    options.onSwitch(domMenu.optionsData[idx]);    
                }
            };
        }(optionIndex);
        slayOne.widgets.hoverLight(domOption, {
            theme: 'lite',
            width: tipWidth,
            height: tipHeight,
            top: '-5px',
            left: '-5px'
        });
        slayOne.widgets.clickable(domOption);
    }
    
    domMainButton.onclick = getDropDownMenuMainButtonClickCallback(domMainButton, domList, domToggle);
    slayOne.widgets.clickable(domMainButton);
    
    domList.style.display = "none";
    domMenu.appendChild(domList);

    domMenu.selectOption = function(optionIndex) {

        if(optionIndex == domMenu.selectedIndex) {
            return false;
        }

        domList.children[domMenu.selectedIndex].setSkin("dark");
        domMenu.selectedIndex = optionIndex;
        domList.children[domMenu.selectedIndex].setSkin("light");

        var selectedOption = domMenu.optionsData[optionIndex];
        domMainButton.setText(selectedOption.label);

        return true;
        
    };

    if(options && options.mainButtonTip && options.mainButtonTip.length > 0) {
        slayOne.widgets.tooltip(domMainButton, {
            tip: options.mainButtonTip
        });
    }

    parentNode.appendChild(domMenu);

    return domMenu;
}

function getDropDownMenuMainButtonClickCallback(domMainButton, domList, domToggle) {
	return function dropDownMenuMainButtonClickCallback() {
        if(domList.style.display == "none") {
            domList.style.display = "block";
            domToggle.className = "dropdownToggleButtonActive";
            domMainButton.tipEffect && domMainButton.tipEffect.hide();
            function hideDropDownList(){
                domList.style.display = "none";
                domToggle.className = "dropdownToggleButton";
                document.removeEventListener("click", hideDropDownList);
            }
            setTimeout(function(){
                document.addEventListener("click", hideDropDownList);
            }, 0);
        } else {
            domList.style.display = "none";
            domToggle.className = "dropdownToggleButton";
            domMainButton.tipEffect && domMainButton.tipEffect.show();
        }
	};
}

//export
if(!slayOne.widgets) {
    slayOne.widgets = {};
}

slayOne.widgets.dropdownMenu = dropdownMenu;

})(window, window.slayOne, window.document);//end main closure