FunUI.layouts["gameShare"] = 
	'<div id="gameShare" class="F-Window light" data-modal="true">' +
		'<h2 class="title">_(gameShare.title)</h2>' +
		'<div class="content">' +
			'<input class="inviteLink" type="text" readonly="readonly" value="" />' +
			'<div class="buttonBar">' +
				'<div class="F-Button link">_(gameShare.btn.copy_link.label)</div>' +
				'<div class="F-Button socialMedia fb"></div>' +
				'<div class="F-Button socialMedia tw"></div>' +
			'</div>' +
		'</div>' +
		'<div class="F-Button close"></div>' +
	'</div>';
