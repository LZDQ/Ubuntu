(function(){
    var maps = new F$ArrayView();

    var normalPlayers = new F$ArrayView();

    var redTeamFilter = function(p) {
        return p.team == 1;
    };

    var blueTeamFilter = function(p) {
        return p.team == 2;
    };

    var redZombieFilter = function(p) {
        return !p.isHumanZombie;
    };

    var blueZombieFilter = function(p) {
        return p.isHumanZombie;
    };

    var redPlayers = new F$ArrayView();
    var bluePlayers = new F$ArrayView();
	
    FunUI.traits.rankInGame = {
        _redNameField: null,
        _blueNameField : null,
        _redScoreField: null,
        _blueScoreField: null,
        _redScore: 0,
        _blueScore: 0,
        _type: null,
        _hiding : false,
        _timeToNextLabel : null,
        _victoryLabel : null,
        _voteTitle : null,
        _rankArea : null,
        _game : null,
        _levelWarnField : null,
        __init__: function () {
            this._redScoreField = this.querySelector('.redTeamSummary .teamScore');
            this._blueScoreField = this.querySelector('.blueTeamSummary .teamScore');
            this._redNameField = this.querySelector('.redTeamSummary .teamName');
            this._blueNameField = this.querySelector('.blueTeamSummary .teamName');
            this._timeToNextLabel = this.querySelector('.vote .timeToNext');
            this._victoryLabel = this.querySelector('.victory');
            this._voteTitle = this.querySelector('.voteTitle');
            this._rankArea = this.querySelector('.rankArea');
            this._levelWarnField = this.querySelector('.levelWarn');
            maps.on(FunUI.events.ARRAY_VIEW_UPDATE, this.showOrHideVoteTitle);
            this.showOrHideVoteTitle();

            this.querySelector('.F-Button.spectate').on('click', joinTeam.bind(null, -1));
            this.querySelector('.F-Button.play').on('click', joinTeam.bind(null, 1));
            this.querySelector('.F-Button.red').on('click', joinTeam.bind(null, 1));
            this.querySelector('.F-Button.blue').on('click', joinTeam.bind(null, 2));
            this.querySelector('.F-Button.invite').on('click', openGameShare);
            this.querySelector('.F-Button.close').on('click', this.hide);
        },
        set timeToNext(v) {
            if(this._timeToNextLabel)
                this._timeToNextLabel.innerHTML = v;
        },
        hideRank: function() {
            this._rankArea.style.display = "none";
        },
        showRank: function() {
            this._rankArea.style.display = "";
        },
        showOrHideVoteTitle: function() {
            if(maps.length > 0)
                this._voteTitle.style.display = "";
            else
                this._voteTitle.style.display = "none";
        },
        show: function(hideRank)
        {
            if(this._game != game)
            {
                this._gameChanged = true;
                normalPlayers.sort = game.playerSortHandler;
                this._game = game;
                this.invalidate();
            }
            
            FunUI.managers.PopUpManager.addPopUp(this);
            this.refreshRank();
            this.refreshPlaying();

            if(hideRank)
                this.hideRank();
            else
                this.showRank();

            document.addEventListener('wheel', this.scrollList);
        },
        scrollList: function(event) {
            var elements = [
                F$('rankInGame_normalList'),
                F$('rankInGame_redList'),
                F$('rankInGame_blueList')
            ];

            for(var i = 0; i < elements.length; i ++)
                if(elements[i].containsMouse())
                {
                    elements[i].scrollTop += event.deltaY;
                    break;
                }
        },
        hide: function() {
            if(game.ticksCounter >= -1)
                this.doHide();
        },
        doHide: function() {
            document.removeEventListener('wheel', this.scrollList);
            F$("tooltipMap").hide();
            FunUI.managers.PopUpManager.removePopUp(this);
        },
        setVictoryMessage: function(message) {
            if(this._victoryLabel)
                this._victoryLabel.innerHTML = message;
        },
        refreshTime: function(ongoing, time)
        {
            if(this.parentNode == null)
                return;

            if(ongoing)
            {
                this.removeClass('waiting');
                this.addClass("ongoing");
            }
            else
            {
                this.removeClass('ongoing');
                this.addClass("waiting");
            }

            if(this._timeToNextLabel)
                this._timeToNextLabel.innerHTML = time;
        },
        refreshTeamScore: function()
        {
            this._scoreChanged = true;
            this.invalidate();
        },
        refreshRank: function()
        {
            normalPlayers.source = game.players;
        },
        refreshPlaying: function()
        {
            this.refreshRank();

            if(game.playingPlayerID > 0 || game.iAmSpec || game.replayMode )
            {
                this.removeClass('start');
                this.removeClass('spectate');
                this._levelWarnField.style.display = "none";
            }
            else
            {
                this.addClass('start');
                if(joinGamePurpose == "spectate")
                {
                    this._levelWarnField.innerHTML = F_('rankInGame.level.warn', {levelRange: game.tag == 'veteran' ? (CONST.VETERAN_LVL + '+') : ('1-' + (CONST.VETERAN_LVL - 1))});
                    this._levelWarnField.style.display = "block";
                    this.addClass('spectate');
                }
                else
                {
                    this._levelWarnField.style.display = "none";
                    this.removeClass('spectate');
                }
            }
        },
        commitProperties: function()
        {
            if(this._scoreChanged || this._gameChanged)
            {
                this._redScoreField.innerHTML = F_("rankInGame.summary.score", {score: game.scoreTeam1});
                this._blueScoreField.innerHTML = F_("rankInGame.summary.score", {score: game.scoreTeam2});
                this._scoreChanged = false;
            }

            if(this._gameChanged)
            {
                var gameType = this._game.type;
                if(gameType.team || gameType.coopZombieMode)
                {
                    this.addClass('team');
                    redPlayers.sourceView = normalPlayers;
                    bluePlayers.sourceView = normalPlayers;
                    F$('rankInGame_normalList').dataProvider = null;
						
                    if(gameType.coopZombieMode)
                    {
                        redPlayers.filter = redZombieFilter;
                        bluePlayers.filter = blueZombieFilter;
                        this._redScoreField.innerHTML = "";
                        this._blueScoreField.innerHTML = "";
                        this._redNameField.innerHTML = F_("rankInGame.team.humans");
                        this._blueNameField.innerHTML = F_("rankInGame.team.zombies");
                    }
                    else
                    {
                        redPlayers.filter = redTeamFilter;
                        bluePlayers.filter = blueTeamFilter;
                        this._redNameField.innerHTML = F_("rankInGame.team.red");
                        this._blueNameField.innerHTML = F_("rankInGame.team.blue");
                    }
                }
                else
                {
                    this.removeClass('team');
                    redPlayers.sourceView = null;
                    bluePlayers.sourceView = null;
                    F$('rankInGame_normalList').dataProvider = normalPlayers;
                    
	                if(gameType.lives)
	                {
	                	this.querySelector('.kill').style.display = "none";
	                	this.querySelector('.score').style.display = "none";
	                	this.querySelector('.death').innerHTML = "Lives";
	                }
	                
	                else
	                {
	                	this.querySelector('.kill').style.display = "";
	                	this.querySelector('.score').style.display = "";
	                	this.querySelector('.death').innerHTML = F_("rankInGame.thead.death");
	                }
                }
				
                if((!gameType.team && gameType.zombies) || gameType.coopZombieMode)
                    this.addClass("zombies");
                else
                    this.removeClass('zombies');
                
                if(gameType.ingameElo)
                    this.addClass('ingameElo');
                else
                    this.removeClass('ingameElo');
                
                this._gameChanged = false;
            }
        }
    };

    var itemRenderer = {
        _nameField: null,
        _clanField: null,
        _scoreField: null,
        _soulsField: null,
        _killField: null,
        _deathField: null,
        _muteField: null,
        _muteButton: null,

        __init__: function()
        {
            this._nameField = this.querySelector('.name');
            this._clanField = this.querySelector('.clan');
            this._scoreField = this.querySelector('.score');
            this._soulsField = this.querySelector('.souls');
            this._killField = this.querySelector('.kill');
            this._deathField = this.querySelector('.death');

            this._muteButton = this.querySelector('.mute');
            this._muteButton.on('click', this.toggleMute);
            
            if(game.type.lives)
            {
            	this._killField.style.display = "none";
            	this._scoreField.style.display = "none";
            }
            
            else
            {
            	this._killField.style.display = "";
            	this._scoreField.style.display = "";
            }
        },
        render: function(data)
        {
            if(data.id == game.playingPlayerID)
                this.addClass("me");
            else
                this.removeClass("me");
            
            this._nameField.innerHTML = data.name;
            // this._nameField.innerHTML = data.name + " " + data.iac;
            this._nameField.style.color = data.nameColorCode;
            this._clanField.innerHTML = data.clan_tag ? ("[" + data.clan_tag + "]") : "";
            this._scoreField.innerHTML = data.elo;
            this._soulsField.innerHTML = data.souls;
            this._killField.innerHTML = data.kills;
            
            if(game.type.lives)
            {
            	this._killField.style.display = "none";
            	this._scoreField.style.display = "none";
            	this._deathField.innerHTML = game.type.lives - data.deaths;
            }
            else
            {
            	this._deathField.innerHTML = data.deaths;
            	this._killField.style.display = "";
            	this._scoreField.style.display = "";
            }

            if(data.id != game.playingPlayerID && data.name != playerData.name && data.authLevel >= AUTH_LEVEL.GUEST)
            {
                this._muteButton.style.display = "";
                
                if(playerIsBeeingIgnored(data.name))
                    this._muteButton.addClass("muted");
                else
                    this._muteButton.removeClass("muted");
            }
            else
                this._muteButton.style.display = "none";
        },
        toggleMute: function (event) {
            var name = this.data.name;
            var isGuest = this.data.authLevel < AUTH_LEVEL.PLAYER;
            var el = event.currentTarget;

            name = name.toLowerCase();
            var index = ignoreList.indexOf(name);
            if(index >= 0)
            {
                ignoreList.splice(index, 1);
                localStorage.ignoreList = ignoreList.join(";");
                el.removeClass("muted");
                game.interface_.addMsg(slayOne.widgets.lang.get("game.msg.ignore.off", {playerName: name}), "white");
                return;
            }

            index = ignoreListTemp.indexOf(name);
            if(index >= 0)
            {
                ignoreListTemp.splice(index, 1);
                game.interface_.addMsg(slayOne.widgets.lang.get("game.msg.ignore.off", {playerName: name}), "white");
                el.removeClass("muted");
                return;
            }

            (isGuest ? ignoreListTemp : ignoreList).push(name);
            localStorage.ignoreList = ignoreList.join(";");

            el.addClass('muted');
            game.interface_.addMsg(slayOne.widgets.lang.get("game.msg.ignore.on", {playerName: name}), "white");
        },
        "<Observer event='mousedown' selector='.name' />": function()
        {
            if(this.data.db_id && this.data.db_id != "undefined")
                uiManager.showPlayerInfoById(this.data.db_id);
            
            else if(playerData.authLevel >= AUTH_LEVEL.MOD2)
            	initBanGuest(this.data.name);
        }
    };

    FunUI.traits.rankInGame_normalList = {
        dataProvider: normalPlayers,
        itemRenderer: itemRenderer
    };

    FunUI.traits.rankInGame_redList = {
        dataProvider: redPlayers,
        itemRenderer: itemRenderer
    };

    FunUI.traits.rankInGame_blueList = {
        dataProvider: bluePlayers,
        itemRenderer: itemRenderer
    };

    FunUI.traits.rankInGame_mapList = {
        dataProvider: maps,
        set maps(v) {
            this.voted = false;
            this.selectedIndices = [];
            maps.source = v;
        },
        set voted(v) {
            if(v)
                this.addClass("voted");
            else
                this.removeClass("voted");
        },
        get voted() {
            return this.hasClass('voted');
        }
    };

    FunUI.traits.rankInGame_mapList.itemRenderer = {
        _checkbox: null,
        _valueField: null,
        _nameField: null,
        __init__: function() {
            this.on('click', this.voteMap);
            this._valueField = this.querySelector('.voteValue');
            this._nameField = this.querySelector('.name');
        },
        render: function(data, index) {
            this._valueField.innerHTML = data.votes;
            this._nameField.innerHTML = data.name;
            this.tooltipData = data;

            var list = this.list;
            if(data.voted)
            {
                list.voted = true;
                this.select();
            }
            else
                this.deselect();
        },
        voteMap: function() {
            if(this.list.voted)
                return;

            var list = this.list;
            list.voted = true;

            network.send("map-vote$" + this.data.id);
        }
    };
})();