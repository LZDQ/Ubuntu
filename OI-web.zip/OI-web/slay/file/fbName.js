/**
 * View renders light weight informative screen
 *
 */
(function (window, slayOne, document) {

    var viewKey = "fbNameScreen";
    var domContainer;
    var nameInput;
    var playerEmail;
    var rendered = false;
    var callback = null;

    function render() {
        domContainer = document.createElement("div");
        domContainer.className = "container";

        var logo = document.createElement("img");
        logo.src = "imgs/welcome/logo.png";
        logo.className = "logo";
        domContainer.appendChild(logo);

        var label = document.createElement("span");
        label.className = "confirm-user-username";
        label.innerText = F_("fbName.confirm.label1");

        domContainer.appendChild(label);

        var inputContainer = document.createElement("div");
        inputContainer.className = "inputName";
        inputContainer.style.verticalAlign = "top";

        nameInput = slayOne.widgets.standardTextInput(inputContainer, {
            size: 10,
            placeholder: "",
            cssId: "inputNumBots",
            skin: "standard",
            customClassName: "botNumTextInput",
            iconClassName: "iconUserName"
        });
        domContainer.appendChild(inputContainer);

        var btn = slayOne.widgets.labelButton(domContainer, {
            label: "save",
            theme: "LargeNormal ",
            customClassName: "buttonSave",
            onClick: function () {
                btn.disabled = true;
                gaEventOnce('player-save-name-email');
                FacebookUtils.register(nameInput.value, playerEmail, function(msg) {
                    btn.disabled = false;
                    if (msg.result == 0) {
                        gaEventOnce('save-name-email-succeeded');
                        hide();
                    }

                    if (typeof callback == "function") {
                        callback(msg);
                    }
                });
            }
        });
    }

    function show(name, email, cb) {
        if (!rendered) {
            render();
        }

        callback = cb;
        if (!!name) {
            nameInput.value = name;
        }

        playerEmail = email;
        slayOne.viewHelpers.showPopup(viewKey, {
            theme: 'prompt',
            content: domContainer
        });
    }

    function hide() {
        slayOne.viewHelpers.hidePopup(viewKey);
    }

//export
    slayOne.views[viewKey] = {
        show: show,
        hide: hide
    };

})(window, window.slayOne, window.document);//end main closure