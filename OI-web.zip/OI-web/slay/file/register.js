(function(window, slayOne, document){

var viewKey = "registerScreen";

function renderUserNameInput_(parentNode)
{
    var domContainer = document.createElement('div');
    domContainer.className = "userInputRow";

    var domTextInput = slayOne.widgets.standardTextInput(domContainer, {
        size: 10,
        placeholder: slayOne.widgets.lang.get("account.views.signup.name.placeholder"),
        cssId: "inputUserName",
        skin: "standard",
        customClassName: "userLoginRegTextInput userNameTextInput",
        iconClassName: "iconUserName",
        onSubmit: function(val) {
            commitRegistration_();
        },
    });
    slayOne.widgets.tooltip(domContainer, {
        tip: slayOne.widgets.lang.get("account.views.signup.name.tooltip"),
        align: "center",
        verticalAlign: "top"
    });
    parentNode.appendChild(domContainer);
}

function renderUserPassInput_(parentNode)
{
    var domContainer = document.createElement('div');
    domContainer.className = "userInputRow";

    var domTextInput = slayOne.widgets.standardTextInput(domContainer, {
        size: 10,
        inputType: 'password',
        placeholder: slayOne.widgets.lang.get("account.views.signup.password.placeholder"),
        cssId: "inputUserPass",
        skin: "standard",
        customClassName: "userLoginRegTextInput userPassTextInput",
        iconClassName: "iconUserPass",
        onSubmit: function(val) {
            commitRegistration_();
        },
    });
    slayOne.widgets.tooltip(domContainer, {
        tip: slayOne.widgets.lang.get("account.views.signup.password.tooltip"),
        align: "center",
        verticalAlign: "top"
    });
    parentNode.appendChild(domContainer);
}

function renderUserEmailInput_(parentNode)
{
    var domContainer = document.createElement('div');
    domContainer.className = "userInputRow";

    var domTextInput = slayOne.widgets.standardTextInput(domContainer, {
        size: 10,
        placeholder: slayOne.widgets.lang.get("account.views.signup.email.placeholder"),
        cssId: "inputUserEmail",
        skin: "standard",
        customClassName: "userLoginRegTextInput userEmailTextInput",
        iconClassName: "iconUserEmail",
        onSubmit: function(val) {
            commitRegistration_();
        },
    });
    
    parentNode.appendChild(domContainer);
}

function renderRegisterButton_(parentNode)
{
    slayOne.widgets.labelButton(parentNode, {
        label: slayOne.widgets.lang.get("account.views.signup.buttons.submit.label"),
        theme: "LargeNormal",
        customClassName: "userLoginRegBtn",
        onClick: function(){
            commitRegistration_();
        }
    });
}

function renderFbSignUpButton_(parentNode)
{
    slayOne.widgets.labelButton(parentNode, {
        label: slayOne.widgets.lang.get("account.views.login.buttons.fbSignUp.label"),
        tipAlign: "center",
        theme: "LargeFBNormal",
        onClick: function () {
            FacebookUtils.loginFbThenGame(function (res) {
                if(res.result == 0)
                    slayOne.viewHelpers.hidePopup("account");
            });
        }
    });
}

function renderUserAgreementTips_(parentNode)
{
    var domTips = document.createElement('div');
    domTips.className = 'agreementTips';
    domTips.innerHTML = slayOne.widgets.lang.get("account.views.signup.agreement.template", {
        termName: '<a class="pseudoLink withClickSound" onclick="window.toggleAGB();">' + slayOne.widgets.lang.get("account.views.signup.agreement.termname") + '</a>'
    });
    parentNode.appendChild(domTips);
}

function commitRegistration_()
{
    gaEventOnce('player-register');
    
    var valUserName = trim(document.getElementById("inputUserName").value).replace(/ /g, '_');
    var valUserPass = document.getElementById("inputUserPass").value;
    var valUserEmail = document.getElementById("inputUserEmail").value;
	
    if(!validateLoginName(valUserName))
    {
        slayOne.viewHelpers.showFloatTip({
            tipType: 'error',
            content: slayOne.widgets.lang.get("account.views.signup.name.warning")
        });
        return;
    }
	
    if(!validatePW(valUserPass))
    {
        slayOne.viewHelpers.showFloatTip({
            tipType: 'error',
            content: slayOne.widgets.lang.get("account.views.signup.password.warning")
        });
        return;
    }
	
    if(!validateMail(valUserEmail))
    {
        slayOne.viewHelpers.showFloatTip({
            tipType: 'error',
            content: slayOne.widgets.lang.get("account.views.signup.email.warning")
        });
        return;
    }
    
    network.send("register$" + valUserName + "$" + valUserPass + "$" + valUserEmail);
}

function render(parentNode)
{
    var domContent = document.createElement('div');
    domContent.className = "loginRegView";
    
    var aRows = [
        [ { renderMethod: renderUserNameInput_ }],
        [ { renderMethod: renderUserPassInput_ } ],
        [ { renderMethod: renderUserEmailInput_ } ],
        (function() {
            var buttons = [ { renderMethod: renderRegisterButton_ } ];
            !isDesktop && buttons.push({renderMethod: renderFbSignUpButton_});
            return buttons;
        })(),
        [ { renderMethod: renderUserAgreementTips_ } ],
    ];

    for(var i = 0; i < aRows.length; i++)
    {
        var aCells = aRows[i];
        var domTable = document.createElement("div");
        var domRow = document.createElement("div");
        domTable.className = "mainLayoutTable";
        domRow.style.display = "table-row";
        domTable.style.marginBottom = "10px";

        for(var j = 0; j < aCells.length; j++)
        {
            var layoutCell = aCells[j];
            var domCell = document.createElement("div");
            var renderMethod = layoutCell.renderMethod ? layoutCell.renderMethod.bind(this): null;
            domCell.className  = "mainLayoutCell";
            renderMethod(domCell);
            domRow.appendChild(domCell);
        }

        domTable.appendChild(domRow);
        domContent.appendChild(domTable);
    }
    
    domContent.onCreate = function(initData){

    };
    
    domContent.onShow = function(initData){

    };
    
    domContent.onHide = function(){
    	
    };
    
    parentNode.appendChild(domContent);
    
    return domContent;
}

//export
slayOne.views[viewKey] = {
    render: render
};

})(window, window.slayOne, window.document);//end main closure
