(function(window, slayOne, document){

var factoryMethods = {
    light: lightPopupWindow,
    tabbed: tabbedPopupWindow,
    standard: standardPopupWindow,
    prompt: lightPopupWindow,
};

/**
 * PopUp Window
 *
 * @param parentNode: dom element to append to
 * @param options:
 *                  windowName: string
 *                  title: string
 *                  theme: light | standard | tabbed | prompt, default light
 *                  (theme:light|standard) content: domContent
 *                  (theme:tabbed) tabs: [{label:string,view:string}]
 *                  (theme:tabbed) initTabIndex: integer, default 0
 *                  onClose: close callback
 *                  hideCloseBtn: boolean
 */
function popupWindow(parentNode, options) {
    var themeOption = (options && options.theme) ? options.theme : "light";
    return factoryMethods[themeOption](parentNode, options);
}

function lightPopupWindow(parentNode, options) {

    var domWindow = document.createElement("div");
    domWindow.id = options.windowName;
    domWindow.className = "popupWndWrapper";

    domWindow.closePopUp = function(){
        options.onClose && options.onClose();
    };

    var themeClassName = "popupWndFrameLight";

    var domMask = document.createElement("div");
    domMask.className = "popupWndMask";
    domWindow.appendChild(domMask);

    var domContentWindow = document.createElement("div");
    domContentWindow.className = "popupWndContent " + themeClassName;
    domContentWindow.appendChild(options.content);

    if(!(options && options.hideCloseBtn))
    {
        var domCloseBtn = document.createElement("div");
        domCloseBtn.className = "popupWndCloseBtn";
        domCloseBtn.innerHTML = '<img src="imgs/main_ui/icon_close.png">';
        domCloseBtn.onclick = domWindow.closePopUp;
        slayOne.widgets.clickable(domCloseBtn);
        domContentWindow.appendChild(domCloseBtn);
    }

    domWindow.appendChild(domContentWindow);
    parentNode.appendChild(domWindow);

    return domWindow;
}

function standardPopupWindow(parentNode, options) {

    var domWindow = document.createElement("div");
    domWindow.id = options.windowName;
    domWindow.className = "popupWndWrapper";

    var themeClassName = "popupWndFrameStandard";

    var domMask = document.createElement("div");
    domMask.className = "popupWndMask";
    domWindow.appendChild(domMask);

    var domContentWindow = document.createElement("div");
    domContentWindow.className = "popupWndContent " + themeClassName;

    // Add background that has 100% W & H here, because border-image is too wide and high
    var domWindowBg = document.createElement("div");
    domWindowBg.className = "popupWndStandardBg";
    domContentWindow.appendChild(domWindowBg);

    if(options && options.title) {
        var domTitle = document.createElement("div");
        domTitle.className = "popupWndTitleWrapper";
        domTitle.innerHTML = '<div class="popupWndTitle"><div class="popupWndTitleBg"></div><div class="popupWndTitleContent">' + options.title + '</div></div>';
        domContentWindow.appendChild(domTitle);
    }
    
    var domTabContent = document.createElement("div");
    domTabContent.className = "popupWndViewContainer";
    domTabContent.appendChild(options.content);
    domContentWindow.appendChild(domTabContent);

    domWindow.closePopUp = function(){
        options.onClose && options.onClose();
    };

    var domCloseBtn = document.createElement("div");
    domCloseBtn.className = "popupWndCloseBtn pixelated";
    domCloseBtn.innerHTML = '<img src="imgs/main_ui/icon_close_tabbed.png">';
    domCloseBtn.onclick = domWindow.closePopUp;
    slayOne.widgets.clickable(domCloseBtn);
    domContentWindow.appendChild(domCloseBtn);
    slayOne.widgets.hoverLight(domCloseBtn, {
        width: '58px',
        height: '60px'
    });

    domWindow.appendChild(domContentWindow);
    parentNode.appendChild(domWindow);

    return domWindow;
}

function tabbedPopupWindow(parentNode, options) {
    
    var domWindow = document.createElement("div");
    domWindow.id = options.windowName;
    domWindow.className = "popupWndWrapper";

    var themeClassName = "popupWndFrameTabbed";

    var domMask = document.createElement("div");
    domMask.className = "popupWndMask";
    domWindow.appendChild(domMask);

    var domContentWindow = document.createElement("div");
    domContentWindow.className = "popupWndContent " + themeClassName;

    // Add background that has 100% W & H here, because border-image is too wide and high
    var domWindowBg = document.createElement("div");
    domWindowBg.className = "popupWndStandardBg";
    domContentWindow.appendChild(domWindowBg);

    if(options && options.title) {
        var domTitle = document.createElement("div");
        domTitle.className = "popupWndTitleWrapper";
        domTitle.innerHTML = '<div class="popupWndTitle"><div class="popupWndTitleBg"></div><div class="popupWndTitleContent">' + options.title + '</div></div>';
        domContentWindow.appendChild(domTitle);
    }

    var domTabButtons = document.createElement("div");
    domTabButtons.className = "popupWndTabbedButtonContainer";

    domWindow.tabButtons = [];
    var tabButtonsCount = options.tabs.length;
    for(var tabButtonIndex = 0; tabButtonIndex < tabButtonsCount; tabButtonIndex += 1) {
        var tabButton = slayOne.widgets.labelButton(domTabButtons, {
            theme: 'StandardTab',
            label: options.tabs[tabButtonIndex].label,
            onClick: function(btnIndex){
                return function(){
                    domWindow.selectTab(btnIndex);
                };
            }(tabButtonIndex),
            tip: options.tabs[tabButtonIndex].tip,
            tipAlign: "center"
        });
        domWindow.tabButtons.push(tabButton);
    }
    
    var domTabContent = document.createElement("div");
    domTabContent.className = "popupWndTabbedViewContainer";
    domContentWindow.appendChild(domTabContent);
    domContentWindow.appendChild(domTabButtons);

    domWindow.closePopUp = function(){
        if(domTabContent.firstChild) {
            domTabContent.firstChild.onHide && domTabContent.firstChild.onHide();
        }
        options.onClose && options.onClose();
    };

    var domCloseBtn = document.createElement("div");
    domCloseBtn.className = "popupWndCloseBtn pixelated";
    domCloseBtn.innerHTML = '<img src="imgs/main_ui/icon_close_tabbed.png">';
    domCloseBtn.onclick = domWindow.closePopUp;
    slayOne.widgets.clickable(domCloseBtn);
    domContentWindow.appendChild(domCloseBtn);
    slayOne.widgets.hoverLight(domCloseBtn, {
        width: '58px',
        height: '60px'
    });

    // ViewController
    domWindow.currentTabIndex = -1;
    domWindow.cachedViews = {};
    domWindow.tabsData = options.tabs;
    domWindow.selectTab = function(selectedTabIndex, tabData){
        if(selectedTabIndex == domWindow.currentTabIndex) {
            return;
        }
        // Hide old tab view
        if(domTabContent.firstChild) {
            domTabContent.firstChild.onHide && domTabContent.firstChild.onHide();
            domTabContent.removeChild(domTabContent.firstChild);
        }
        if(domWindow.currentTabIndex >= 0) {
            domWindow.tabButtons[domWindow.currentTabIndex].setTheme('StandardTab');
        }
        domWindow.currentTabIndex = selectedTabIndex;
        // Show new tab view
        var nextTabData = domWindow.tabsData[selectedTabIndex];
        var nextView = domWindow.cachedViews[nextTabData.view];
        if(nextView) {
            domTabContent.appendChild(nextView);
        } else {
            nextView = domWindow.cachedViews[nextTabData.view] = slayOne.views[nextTabData.view].render(domTabContent, {});
            nextView.onCreate && nextView.onCreate(tabData);
        }
        domWindow.tabButtons[domWindow.currentTabIndex].setTheme('StandardTabActivated');
        nextView.onShow && nextView.onShow(tabData);
    };

    domWindow.appendChild(domContentWindow);
    parentNode.appendChild(domWindow);

    var initTabIndex = 0;
    if(options && options.initTabIndex) {
        initTabIndex = options.initTabIndex;
    }
    domWindow.selectTab(initTabIndex);

    return domWindow;  

}

//export
if(!slayOne.widgets) {
    slayOne.widgets = {};
}

slayOne.widgets.popupWindow = popupWindow;

})(window, window.slayOne, window.document);//end main closure