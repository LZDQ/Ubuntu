function Beam(shooter, target, x, y, weapon)
{
	if(x || y)
	{
		this.x = parseFloat(x);
		this.y = parseFloat(y);
	}
	
	this.shooter = shooter;
	this.target = target;
	
	if(weapon && shooter && weapon.isBeam2)
	{
		this.originX = shooter.x;
		this.originY = shooter.y;
	}
	
	if(SOUND[weapon.soundName])
		soundManager.playSound(SOUND[weapon.soundName], this.shooter.x, this.shooter.y, weapon.volume ? weapon.volume : 1);
	
	this.weapon = weapon;
	
	this.tickOfCreation = game.ticksCounter;
	this.dieAt = game.ticksCounter + weapon.lifetime;
	this.muzzleFlashDisplayTime = weapon.muzzleFlashDisplayTime ? (game.ticksCounter + weapon.muzzleFlashDisplayTime) : game.ticksCounter + 99999;
	this.fadeOutAt = weapon.fadeOutAt ? (game.ticksCounter + weapon.fadeOutAt) : null;
	this.isBeam2 = weapon ? weapon.isBeam2 : false;
	
	game.addToObjectsToDraw(this);
};

Beam.prototype.getYDrawingOffset = function()
{
	return this.shooter.y;
};

Beam.prototype.update = function()
{
	return this.dieAt > game.ticksCounter;
};

Beam.prototype.draw = function(exactTicks, x1, y1, x2, y2, percentageOfCurrentTickPassed)
{
	// if(!(this.x + 10 >= x1 && this.y + 10 >= y1 && this.x - 10 <= x2 && this.y - 10 <= y2))
	//	return;
	
	var x = (this.shooter.x0 + percentageOfCurrentTickPassed * (this.shooter.x - this.shooter.x0));
	var y = (this.shooter.y0 + percentageOfCurrentTickPassed * (this.shooter.y - this.shooter.y0)) - SHOT_HEIGHT;
	
	if(this.originX)
	{
		x = this.originX;
		y = this.originY - SHOT_HEIGHT;
	}
	
	var xT = 0;
	var yT = 0;
	
	if(this.target)
	{
		xT = (this.target.x0 + percentageOfCurrentTickPassed * (this.target.x - this.target.x0));
		yT = (this.target.y0 + percentageOfCurrentTickPassed * (this.target.y - this.target.y0)) - SHOT_HEIGHT;
		
		var vecX = x - xT;
		var vecY = y - yT;
		var len = Math.sqrt(vecX * vecX + vecY * vecY);
		vecX *= 0.4 / len;
		vecY *= 0.4 / len;
		
		xT += vecX;
		yT += vecY;
	}
	else
	{
		xT = this.x;
		yT = this.y - SHOT_HEIGHT;
	}
	
	var vecX = xT - x;
	var vecY = yT - y;
	var len = Math.sqrt(vecX * vecX + vecY * vecY);
	vecX *= this.weapon.beamRenderStartOffset / len;
	vecY *= this.weapon.beamRenderStartOffset / len;
	
	x += vecX;
	y += vecY;
	
	// x + 0.5 rausgenommen
	
	if(this.fadeOutAt && this.fadeOutAt <= exactTicks)
		c.globalAlpha = Math.max(this.dieAt - exactTicks, 0) / (this.dieAt - this.fadeOutAt);
	
	for(var i = 3; i >= 1; i--)
		if(this.weapon["beamColor" + [i]])
		{
			c.strokeStyle = this.weapon["beamColor" + [i]];
			c.lineWidth = this.weapon["beamWidth" + [i]] * FIELD_SIZE * (0.8 + (game.ticksCounter % 1.2) * 0.2);
			
			c.beginPath();
			c.moveTo((x - game.cameraX) * FIELD_SIZE, (y - game.cameraY) * FIELD_SIZE);
			c.lineTo((xT - game.cameraX) * FIELD_SIZE, (yT - game.cameraY) * FIELD_SIZE);
			c.lineCap = 'round';
			c.stroke();
		}
	
	c.globalAlpha = 1;
	
	// muzzle flash
	if(this.muzzleFlashDisplayTime > exactTicks)
	{
		var img = imgCoords[this.weapon.muzzleFlashParticle];
		for(var i = 0; i < 15; i++)
		{
			c.globalAlpha = 0.8 - (((exactTicks + i) * 1.7) % 10) * 0.08;
			
			c.drawImage(
				imgs.miscSheet,
				img.x,
				img.y,
				img.w,
				img.h,
				(x + Math.cos(Math.PI * 2 * (i / 20)) * (((exactTicks + i) * 1.7) % 10) * 0.066 - game.cameraX) * FIELD_SIZE,
				(y + Math.sin(Math.PI * 2 * (i / 20)) * (((exactTicks + i) * 3.9654) % 10) * 0.066 - game.cameraY) * FIELD_SIZE,
				img.w * SCALE_FACTOR * (2.2 - (((exactTicks + i) * 1.7) % 10) * 0.1),
				img.h * SCALE_FACTOR * (2.2 - (((exactTicks + i) * 1.7) % 10) * 0.1)
			);
		}
		
		if(this.weapon.muzzleFlashParticle2)
		{
			var img = imgCoords[this.weapon.muzzleFlashParticle2];
			for(var i = 0; i < 15; i++)
			{
				c.globalAlpha = 0.8 - (((exactTicks + i) * 1.7) % 10) * 0.08;
				
				c.drawImage(
					imgs.miscSheet,
					img.x,
					img.y,
					img.w,
					img.h,
					(x + Math.cos(Math.PI * 2 * (i / 20)) * (((exactTicks + i) * 2.18) % 10) * 0.066 - game.cameraX) * FIELD_SIZE,
					(y + Math.sin(Math.PI * 2 * (i / 20)) * (((exactTicks + i) * 1.74675) % 10) * 0.066 - game.cameraY) * FIELD_SIZE,
					img.w * SCALE_FACTOR * (2.2 - (((exactTicks + i) * 1.7) % 10) * 0.1),
					img.h * SCALE_FACTOR * (2.2 - (((exactTicks + i) * 1.7) % 10) * 0.1)
				);
			}
		}
	}
	
	if(this.weapon.muzzleFlashLight && !this.muzzleFlashLightHasBeenCreated)
	{
		this.muzzleFlashLightHasBeenCreated = true;
		
		if(this.weapon.muzzleFlashLight && this.weapon.muzzleFlashLight2)
			for(var i = 0; i < 5; i++)
			{
				var randomAngle = Math.random() * Math.PI * 2;
				var randomSpeed = Math.random() * 0.09;
				
				var randomAngle2 = Math.random() * Math.PI * 2;
				var randomDistance = Math.random() * 0.34;
				
				new Sprite({
					x: x + Math.cos(randomAngle2) * randomDistance,
					y: y + Math.sin(randomAngle2) * randomDistance,
					img: imgCoords[this.weapon.muzzleFlashLight],
					scaleFunction: function(age){ return Math.max(0, 2 - age * 0.1); },
					alphaFunction: function(age) { return Math.max(0, 0.5 - age * 0.025); },
					age: (1.7 + Math.random()) * 20,
					angleX: Math.cos(randomAngle),
					angleY: Math.sin(randomAngle),
					speed: randomSpeed,
					xFunction: function(age){ return age * this.angleX * this.speed; },
					yFunction: function(age){ return age * this.angleY * this.speed; }
				});
				
				new Sprite({
					x: x + Math.cos(randomAngle2) * randomDistance,
					y: y + Math.sin(randomAngle2) * randomDistance,
					img: imgCoords[this.weapon.muzzleFlashLight2],
					scaleFunction: function(age){ return Math.max(0, (2 - age * 0.1) * 0.7); },
					alphaFunction: function(age) { return Math.max(0, 0.5 - age * 0.025); },
					age: (1.7 + Math.random()) * 20,
					angleX: Math.cos(randomAngle),
					angleY: Math.sin(randomAngle),
					speed: randomSpeed,
					xFunction: function(age){ return age * this.angleX * this.speed; },
					yFunction: function(age){ return age * this.angleY * this.speed; }
				});
			}
		
		if(this.weapon.hitLight1 && this.weapon.hitLight2)
		{
			for(var i = 0; i < 5; i++)
			{
				var randomAngle = Math.random() * Math.PI * 2;
				var randomSpeed = Math.random() * 0.09;
				
				var randomAngle2 = Math.random() * Math.PI * 2;
				var randomDistance = Math.random() * 0.34;
				
				new Sprite({
					x: xT + Math.cos(randomAngle2) * randomDistance,
					y: yT + Math.sin(randomAngle2) * randomDistance,
					img: imgCoords[this.weapon.hitLight1],
					scaleFunction: function(age){ return Math.max(0, 2 - age * 0.1); },
					alphaFunction: function(age) { return Math.max(0, 0.5 - age * 0.025); },
					age: (1.7 + Math.random()) * 20,
					angleX: Math.cos(randomAngle),
					angleY: Math.sin(randomAngle),
					speed: randomSpeed,
					xFunction: function(age){ return age * this.angleX * this.speed; },
					yFunction: function(age){ return age * this.angleY * this.speed; }
				});
				
				new Sprite({
					x: xT + Math.cos(randomAngle2) * randomDistance,
					y: yT + Math.sin(randomAngle2) * randomDistance,
					img: imgCoords[this.weapon.hitLight2],
					scaleFunction: function(age){ return Math.max(0, (2 - age * 0.1) * 0.7); },
					alphaFunction: function(age) { return Math.max(0, 0.5 - age * 0.025); },
					age: (1.7 + Math.random()) * 20,
					angleX: Math.cos(randomAngle),
					angleY: Math.sin(randomAngle),
					speed: randomSpeed,
					xFunction: function(age){ return age * this.angleX * this.speed; },
					yFunction: function(age){ return age * this.angleY * this.speed; }
				});
			}
		}
	}
	
	/*if(this.weapon.muzzleFlashLight2 && !this.muzzleFlashLightHasBeenCreated2)
	{
		this.muzzleFlashLightHasBeenCreated2 = true;
		
		for(var i = 0; i < 5; i++)
		{
			var randomAngle = Math.random() * Math.PI * 2;
			var randomSpeed = Math.random() * 0.09;
			
			var randomAngle2 = Math.random() * Math.PI * 2;
			var randomDistance = Math.random() * 0.34;
			
			new Sprite({
				x: x + Math.cos(randomAngle2) * randomDistance,
				y: y + Math.sin(randomAngle2) * randomDistance,
				img: imgCoords[this.weapon.muzzleFlashLight2],
				scaleFunction: function(age){ return Math.max(0, 2 - age * 0.1); },
				alphaFunction: function(age) { return Math.max(0, 0.5 - age * 0.025); },
				age: (1.7 + Math.random()) * 20,
				angleX: Math.cos(randomAngle),
				angleY: Math.sin(randomAngle),
				speed: randomSpeed,
				xFunction: function(age){ return age * this.angleX * this.speed; },
				yFunction: function(age){ return age * this.angleY * this.speed; }
			});
		}
	}
	*/
	c.globalAlpha = 1;
};