(function( slayOne, document ){


/**
 * In multiple UIs in this app, we have a options-selector that has the left-right arrows to choose which option
 *  so this method provides a way to generate one of these selection switchers with any set of options
 *
 * @param parentNode: dom element to append to
 * @param options
 *                  selectOptions: array of objects, one for each possible option that the user can swtich to
 *                  onSwitch: callback for when user switches which option is currently selected
 *                  initIndex: selected index
 */
function selectionSwitcher( parentNode, options ){

    var selectOptions = options.selectOptions;
    var onSwitch = options.onSwitch;
    var maxIndex = selectOptions.length - 1;
    var indexSection = 0;
    var currentSelection;
    var domSwitcher = document.createElement("div");
    var domText = slayOne.widgets.standardText(domSwitcher, '', {
        maxWidth: 300,
        textAlign: "center",
        letterSpacing: -1
    });
    var domArrowLeft = document.createElement("div");
    var domArrowRight = document.createElement("div");

    if(options && options.initIndex) {
        indexSection = options.initIndex;
    }

    var setCurrentSelection = function(){
        currentSelection = selectOptions[indexSection];
        domText.setText(currentSelection.label);
    };

    domSwitcher.className = "selectionSwitcher";
    domArrowLeft.className = "switcherLeft switcherButtons";
    domArrowRight.className = "switcherRight switcherButtons";

    domSwitcher.appendChild(domArrowLeft);
    domSwitcher.appendChild(domArrowRight);

    domArrowLeft.onclick = function(){
        indexSection--;
        if (indexSection < 0){
            indexSection = maxIndex;
        }
        setCurrentSelection();
        onSwitch( currentSelection );
    };

    domArrowRight.onclick = function(){
        indexSection++;
        if (indexSection > maxIndex) {
            indexSection = 0;
        }
        setCurrentSelection();
        onSwitch( currentSelection );
    };

    slayOne.widgets.hoverLight(domArrowLeft, {
        width: '50px',
        height: '52px'
    });

    slayOne.widgets.hoverLight(domArrowRight, {
        width: '50px',
        height: '52px'
    });

    slayOne.widgets.clickable(domArrowLeft);
    slayOne.widgets.clickable(domArrowRight);

    //set initial selection
    setCurrentSelection();

    parentNode.appendChild( domSwitcher );

}

//export

if(!slayOne.widgets) {
    slayOne.widgets = {};
}

slayOne.widgets.selectionSwitcher = selectionSwitcher;

})( window.slayOne, window.document);//end main closure