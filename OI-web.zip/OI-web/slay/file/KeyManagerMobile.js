// input manager, manages all the inputs
function KeyManagerMobile()
{
	this.x = 0;
	this.y = 0;
	
	this.leftMouse = false;
	
	this.ongoingTouches = [];
	
	this.keys = [];
};

if(isMobile)
{
	KeyManagerMobile.prototype.keyUp = function(key)
	{
		var keyCodes = keyCodes[key];
		
		if(keyCodes)
			network.send("kup$" + keyCodes);
	};
	
	KeyManagerMobile.prototype.keyDown = function(key)
	{
		var keyCode = keyCodes[key];
		
		if((key == KEY.NUM1 || key == KEY.NUM2 || key == KEY.NUM3 || key == KEY.NUM4 || key == KEY.NUM5 || key == KEY.NUM6 || key == KEY.NUM7) && game && game.playingPlayer && game.ticksCounter >= 0 && game.playingPlayerIsNotStunned()) // waffe wechseln
		{
			var nr = key - KEY.NUM1;
			
			if(weapons[nr] && weapons[nr] != game.playingPlayer.weapon)
			{
				network.send("sW$" + nr);
				soundManager.playSound(SOUND.SWITCH_WEAPON, undefined, undefined, 0.7);
				
				game.resetPlayingPlayerCooldowns();
				
				game.playingPlayer.switchWeaponUntil = game.ticksCounter + CONST.WPN_SWITCH_TICKS;
				game.playingPlayer.lastWeapon = game.playingPlayer.weapon;
				game.playingPlayer.weapon = weapons[nr];
				game.playingPlayer.isReloading = false;
				
				game.resetPlayingPlayerCooldowns();
			}
		}
		
		else if(keyCode)
			network.send("kdn$" + keyCode);
	};
	
	/*
	KeyManagerMobile.prototype.sendMousePosUpdate = function()
	{
		var x = KeyManager.x / FIELD_SIZE + game.cameraX;
		var y = KeyManager.y / FIELD_SIZE + game.cameraY + ((game.playingPlayer && game.playingPlayer.weapon && game.playingPlayer.weapon.addHeight) ? SHOT_HEIGHT : 0);
		network.send("mp$" + x + "$" + y);
	};
	*/
	
	document.ontouchstart = function(e)
	{
		for(var i = 0; i < e.touches.length; i++)
			KeyManager.ongoingTouches.push(e.touches[i]);
		
		KeyManager.leftMouse = true;
		
		if(game.iAmSpec)
		{
			switchSpec(1);
			return;
		}
		
		var x = e.touches[0].pageX / FIELD_SIZE + game.cameraX;
		var y = e.touches[0].pageY / FIELD_SIZE + game.cameraY;
		
		// check if hit key
		for(var i = 0; i < game.interface_.buttons.length; i++)
			if(game.interface_.buttons[i].contains(e.touches[0].pageX, e.touches[0].pageY))
			{
				// KeyManager.keyDown(game.interface_.buttons[i].key);
				return;
			}
		
		KeyManager.x = e.touches[0].pageX;
		KeyManager.y = e.touches[0].pageY;
		
		network.send("md$" + x + "$" + (y + ((game.playingPlayer && game.playingPlayer.weapon && game.playingPlayer.weapon.addHeight) ? SHOT_HEIGHT : 0)));
	};
	
	document.ontouchend = function(e)
	{
		for(var i = 0; i < e.changedTouches.length; i++)
			for(var k = 0; k < KeyManager.ongoingTouches.length; k++)
				if(KeyManager.ongoingTouches[k].identifier == e.changedTouches[i].identifier)
				{
					KeyManager.ongoingTouches.splice(k, 1);
					k = KeyManager.ongoingTouches.length;
				}
		
		network.send("mu");
		KeyManager.leftMouse = false;
	};
	
	// when mouse is moved, store position
	document.ontouchmove = function(e)
	{
		/*
		// Calculate pageX/Y if missing and clientX/Y available
		if(e.pageX == null && e.clientX != null)
		{
			var doc = document.documentElement;
			var body = document.body;
			e.pageX = e.clientX + (doc && doc.scrollLeft || body && body.scrollLeft || 0) - (doc && doc.clientLeft || body && body.clientLeft || 0);
			e.pageY = e.clientY + (doc && doc.scrollTop || body && body.scrollTop || 0) - (doc && doc.clientTop || body && body.clientTop || 0);
		}
		*/
		
		KeyManager.x = e.touches[0].pageX;
		KeyManager.y = e.touches[0].pageY;
	};
}