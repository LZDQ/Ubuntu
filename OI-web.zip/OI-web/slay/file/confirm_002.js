(function(){
    FunUI.traits.confirm = {
        __init__: function () {
            // todo: trait code
        }
    };
})();