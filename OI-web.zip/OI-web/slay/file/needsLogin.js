/**
 * View renders the "Need Login" UI
 *
 */
(function(window, slayOne, document) {

var viewKey = "needsLoginScreen";

function renderTitle_(parentNode) {
    parentNode.innerHTML = '<span class="needsLoginTitle">' + slayOne.widgets.lang.get("needs_login.title") + '</span>';
}

function renderImage_(parentNode) {
    var domContainer = document.createElement("div");
    domContainer.className = "needsLoginImgContainer";
    var listHTML = '<img src="imgs/windows/needs_login/intro.png">';
    listHTML += '<ul>';
    listHTML += '<li>' + slayOne.widgets.lang.get("needs_login.intro1") + '</li>';
    listHTML += '<li>' + slayOne.widgets.lang.get("needs_login.intro2") + '</li>';
    listHTML += '<li>' + slayOne.widgets.lang.get("needs_login.intro3") + '</li>';
    listHTML += '<li>' + slayOne.widgets.lang.get("needs_login.intro4") + '</li>';
    listHTML += '<li>' + slayOne.widgets.lang.get("needs_login.intro5") + '</li>';
    listHTML += '<li>' + slayOne.widgets.lang.get("needs_login.intro6") + '</li>';
    listHTML += '<li>' + slayOne.widgets.lang.get("needs_login.intro7") + '</li>';
    listHTML += '</ul>';
    domContainer.innerHTML = listHTML;
    parentNode.appendChild(domContainer);
}

function renderLoginButton_(parentNode) {
    slayOne.widgets.labelButton(parentNode, {
        label: slayOne.widgets.lang.get("needs_login.login_btn.label"),
        theme: "LightGreen",
        tip: slayOne.widgets.lang.get("needs_login.login_btn.tooltip"),
        tipAlign: "left",
        onClick: function(){
            slayOne.views.homeScreen.hideWindow(); // FIXME: remove this when whole popup stack mechanic works
            slayOne.viewHelpers.hidePopup(viewKey);
            window.uiManager.showAccountWindow(0);
        }
    });
}

function renderSignUpButton_(parentNode) {
    slayOne.widgets.labelButton(parentNode, {
        label: slayOne.widgets.lang.get("needs_login.signup_btn.label"),
        theme: "LightFacebook",
        tip: slayOne.widgets.lang.get("needs_login.signup_btn.tooltip"),
        tipAlign: "right",
        onClick: function(){
            slayOne.views.homeScreen.hideWindow(); // FIXME: remove this when whole popup stack mechanic works
            slayOne.viewHelpers.hidePopup(viewKey);
            // FacebookUtils.loginFbThenGame();
        }
    });
}

function render(viewModel)
{
    var domContent = document.createElement("div");
    domContent.className = "needsLoginWindow pixelated";

    var
        //array of arrays, each an array of layout cell settings
        aRows = [
            [
                {
                    renderMethod: renderTitle_
                }
            ],
            [
                {
                    renderMethod: renderImage_
                }
            ],
            [
                {
                    renderMethod: renderLoginButton_
                },
                {
                    renderMethod: renderSignUpButton_
                }
            ]
        ];

    //render layout rows
    for( var i = 0; i < aRows.length; i++)
    {
        var aCells = aRows[i];
        var domTable = document.createElement("div");
        var domRow = document.createElement("div");

        domTable.className = "mainLayoutTable";
        domRow.style.display = "table-row";

        domTable.style.marginBottom = "20px";

        //render layout cells
        for ( var j = 0; j < aCells.length; j++ ){

            var layoutCell = aCells[j];
            var domCell = document.createElement("div");
            // binding here allows these private methods access to the "this" scop;
            var renderMethod = layoutCell.renderMethod ? layoutCell.renderMethod.bind(this): null;

            domCell.className  = "mainLayoutCell";

            renderMethod(domCell);

            domRow.appendChild(domCell);

        }
        
        domTable.appendChild(domRow);
        domContent.appendChild(domTable);
    }
    
    slayOne.viewHelpers.showPopup(viewKey, {
        theme: 'light',
        content: domContent
    });
}

//export
slayOne.views[viewKey] = {
    render: render
};

})(window, window.slayOne, window.document);//end main closure