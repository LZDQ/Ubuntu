(function(){
    FunUI.traits.result = {
        _levelProgressBar : null,
        _rankField : null,
        _scoreArea : null,
        _scoreField : null,
        _soulsArea : null,
        _soulsField : null,
        _killsField : null,
        _deathsField : null,
        _currentLevelField : null,
        _nextLevelField : null,
        _increasedExpField : null,
        _goldArea : null,
        _goldField : null,
        _keepButton : null,
        _chestArea : null,
        _chestNameField : null,
        _chestIconField : null,
        __init__: function () {
            this._levelProgressBar = this.querySelector('.accountInfo .F-ProgressBar');
            this.querySelector('.F-Button.save').on('click', saveReplay);
            this._rankField = this.querySelector('.rankInfo');
            this._title = this.querySelector('h2');
            this._wholeArea = this.querySelector('.gameInfo, .reward');
            this._scoreArea = this.querySelector('.gameInfo .score');
            this._scoreField = this.querySelector('.gameInfo .score .value');
            this._soulsArea = this.querySelector('.gameInfo .souls');
            this._soulsField = this.querySelector('.gameInfo .souls .value');
            this._killsField = this.querySelector('.gameInfo .kills .value');
            this._deathsField = this.querySelector('.gameInfo .deaths .value');
            this._currentLevelField = this.querySelector('.levelInfo .current');
            this._nextLevelField = this.querySelector('.levelInfo .next');
            this._increasedExpField = this.querySelector('.increasedExp');
            this._goldArea = this.querySelector('.gameInfo>.gold');
            this._goldField = this.querySelector('.gameInfo>.gold>.value');
            this._keepButton = this.querySelector('.F-Button.keep');
            this._chestArea = this.querySelector('.chest.reward');
            this._chestNameField = this._chestArea.querySelector('.name');
            this._chestIcon = this._chestArea.querySelector('img');
        },
        show: function(data)
        {
            FunUI.managers.PopUpManager.addPopUp(this, data.exit);
            
			if(game.type.lives)
			{
				this._scoreArea.style.display = "none";
				this._soulsArea.style.display = "none";
				this._chestArea.style.display = "none";
				this._wholeArea.style.display = "none";
				this._title.style.display = "none";
				this.addClass('ladder');
			}
			
			else
			{
				
				this._chestArea.style.display = "";
				this._wholeArea.style.display = "";
				this._title.style.display = "";
				this.removeClass('ladder');
				
	            if(game.ticksCounter < 0)
	            {
	                if(game.type.showTop3 && game.type.winningCondition)
	                    this._rankField.innerHTML = F_('result.desc.rank', {rank: game.myRank});
	                else
	                    this._rankField.innerHTML = game.victoryMsg;
	            }
	            else
	                this._rankField.innerHTML = F_('result.desc.noEnd');
				
		        if(game.type.souls)
		        {
	                this._scoreArea.style.display = "none";
	                this._soulsArea.style.display = "";
	                this._soulsField.innerHTML = data.souls;
	            }
	            else
	            {
	                this._scoreArea.style.display = "";
	                this._soulsArea.style.display = "none";
	                this._scoreField.innerHTML = data.elo;
	            }
	            
	            this._killsField.innerHTML = data.kills;
	            this._deathsField.innerHTML = data.deaths;
		        
	            if(data.chestId < 0)
	                this._chestArea.addClass('noChest');
	            else
	            {
	                this._chestArea.removeClass('noChest');
	                
	                var chest = treasureChests[data.chestId];
	                this._chestIcon.src = "imgs/chest/chest_" + data.chestId + ".png";
	                this._chestNameField.innerHTML = getChestName(data.chestId);
	            }
	        }
            
            this._goldField.innerHTML = data.goldGained;

            this._currentLevelField.innerHTML = "Lv" + playerData.lvl;
            this._nextLevelField.innerHTML = "Lv" + (playerData.lvl + 1);

            var xp1 = playerData.xp - getTotalXPRequiredForLvl(playerData.lvl);
            var xp2 = getXPRequiredForLvl(playerData.lvl + 1);

            this._increasedExpField.innerHTML = data.xpGained;
            this._levelProgressBar.setProgresses(xp2, xp1, xp1 - data.xpGained);
            this._levelProgressBar.tooltipData = F_("result.tooltip.xp", {currentXp: xp1, nextLevelXp: xp2});
            
            this.data = data;
			
            if(game.mapId == TUTORIALS[1].mapId || data.exit)
                this._keepButton.style.display = 'none';
            else
                this._keepButton.style.display = '';
        },
        hide: function()
        {
            FunUI.managers.PopUpManager.removePopUp(this);
        },
        "<Observer event='click' selector='.F-Button.keep' /> ": function()
        {
            F$('rankInGame').showRank();
            this.hide();
        },
        "<Observer event='click' selector='.F-Button.close' />": function()
        {
            this.hide();
            
            if(this.data.exit)
                exitGame();
            else
                attemptExitGame();
        },
        "<Observer event='click' selector='.F-Button.fb' />": function()
        {
            shareToFacebook(getCurrentGameLink());
        }
    };
})();