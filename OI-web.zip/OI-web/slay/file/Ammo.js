function Ammo(weapon, x, y, id)
{
	this.x = x;
	this.y = y;
	this.id = id;
	this.weapon = weapons[weapon];
	this.itemType = this.weapon ? null : itemTypes[weapon - 1000];
	this.isAmmo = true;
	this.currentX = x;
	this.currentY = y;
	this.carriedBy = null;
	this.isActive = true;
	this.respawnAt = -9999;
	this.isFlag = this.itemType && (this.itemType.special == "redFlag" || this.itemType.special == "blueFlag");

	this.img = this.weapon ? imgCoords[this.weapon.img] : imgCoords[this.itemType.img];
	this.shine = this.weapon || this.itemType.shine;

	this.scale = 1;

	if(this.weapon)
		this.scale *= 0.55;

	if(this.itemType && this.itemType.scale)
		this.scale *= this.itemType.scale;

	this.lastSpawnTick = -99999;
	this.lightPillarsTop = [];
	this.lightPillarsBottom = [];

	var realXInt = Math.floor(this.x);
	var realYInt = Math.floor(this.y);

	if(game.pathingArray[realXInt] && game.pathingArray[realXInt][realYInt])
		game.pathingArray[realXInt][realYInt] = 11;
};

Ammo.prototype.getYDrawingOffset = function()
{
	return this.currentY - 0.7;
};

Ammo.prototype.pickUp = function(playerID, isRespawn)
{
	if(game.playingPlayer && playerID == game.playingPlayer.id)
	{
		game.lastPickUp = Date.now();

		var ammoSize = (this.weapon && this.weapon.ammoSize) ? (game.type.global_ammo_mod ? Math.ceil(this.weapon.ammoSize * game.type.global_ammo_mod) : this.weapon.ammoSize) : null;

		if(this.weapon && this.weapon.ammoSize)
		{
			if(game.playingPlayerClips[this.weapon.id] + game.playingPlayerAmmo[this.weapon.id] <= 0)
			{
				var clip = Math.min(ammoSize, this.weapon.clipSize);

				game.playingPlayerClips[this.weapon.id] = clip;
				game.playingPlayerAmmo[this.weapon.id] += ammoSize - clip;
			}

			else
				game.playingPlayerAmmo[this.weapon.id] += ammoSize;

			soundManager.playSound(SOUND.COCK, this.x, this.y, 0.6);
			game.interface_.setMainKillMsg(slayOne.widgets.lang.get("game.msg.weapon_pickup", { weapon: this.weapon.name }), "#BEBEBE", "textInGrey", false, imgCoords[this.weapon.img]);
		}

		if(this.itemType && this.itemType.pickupMsg)
		{
			soundManager.playSound(SOUND[this.itemType.pickupSound], this.x, this.y, 0.6);
			game.interface_.setMainKillMsg(this.itemType.pickupMsg, "#BEBEBE", "textInGrey", false, this.itemType.img ? imgCoords[this.itemType.img] : null);
		}
	}

	else if(this.x > game.cameraX - 2 && this.y > game.cameraY - 2 && this.x < game.cameraX2 + 2 && this.y < game.cameraY2 + 2) // if not by playing player, play pickup sound more quiet
		soundManager.playSound((this.itemType && this.itemType.pickupSound) ? SOUND[this.itemType.pickupSound] : SOUND.COCK, this.x, this.y, 0.35);

	var player = game.getPlayerFromID(playerID);
	var customRespawnTime = 0;

	if(this.itemType && player)
	{
		if(this.itemType.hpRestored)
			player.hp = Math.min(player.maxHP, player.hp + this.itemType.hpRestored);

		if(this.itemType.armorRestored)
			player.armor = Math.min(CONST.MAX_ARMOR, player.armor + this.itemType.armorRestored);

		if(this.isFlag)
		{
			var enemyFlag = this.itemType.special == "redFlag" ? game.blueFlag : game.redFlag;
			var myTeam = this.itemType.special == "redFlag" ? 1 : 2;
			var enemyTeam = this.itemType.special == "redFlag" ? 2 : 1;

			if(player.team == enemyTeam) // gegnerische Flagge aufsammeln
			{
				this.carriedBy = player;
				this.isActive = false;

				if(game.playingPlayer)
				{
					if(player == game.playingPlayer)
					{
						game.interface_.setMainKillMsg(slayOne.widgets.lang.get("game.msg.flag.self_pick_enemy"), "#36FF36", "textInGreen");
						soundManager.playSound(SOUND.FRAG2, undefined, undefined, 0.68);
					}

					else if(player.team == game.playingPlayer.team)
					{
						game.interface_.setMainKillMsg(slayOne.widgets.lang.get("game.msg.flag.others_pick_enemy", { playerName: player.name }), "#36FF36", "textInGreen");
						soundManager.playSound(SOUND.FRAG2, undefined, undefined, 0.68);
					}

					else
					{
						game.interface_.setMainKillMsg(slayOne.widgets.lang.get("game.msg.flag.others_pick_self", { playerName: player.name }), "#FF3232", "textInRed");
						soundManager.playSound(SOUND.FRAG2, undefined, undefined, 0.68);
					}
				}
			}

			else if(player.team == myTeam && (this.currentX != this.x || this.currentY != this.y)) // reset own flag
			{
				this.currentX = this.x;
				this.currentY = this.y;
				customRespawnTime = 5;

				if(game.playingPlayer)
				{
					if(player == game.playingPlayer)
					{
						game.interface_.setMainKillMsg(slayOne.widgets.lang.get("game.msg.flag.self_reset_self"), "#36FF36", "textInGreen");
						soundManager.playSound(SOUND.FRAG1, undefined, undefined, 0.68);
					}

					else if(player.team == game.playingPlayer.team)
					{
						game.interface_.setMainKillMsg(slayOne.widgets.lang.get("game.msg.flag.others_reset_self", { playerName: player.name }), "#36FF36", "textInGreen");
						soundManager.playSound(SOUND.FRAG1, undefined, undefined, 0.68);
					}

					else
					{
						game.interface_.setMainKillMsg(slayOne.widgets.lang.get("game.msg.flag.others_reset_enemy", { playerName: player.name }), "#FF3232", "textInRed");
						soundManager.playSound(SOUND.FRAG1, undefined, undefined, 0.68);
					}
				}
			}

			else if(player.team == myTeam && this.currentX == this.x && this.currentY == this.y && enemyFlag.carriedBy == player) // bring enemy flag to own flag (=score)
			{
				if(game.type.flag)
				{
					if(this.itemType.special == "redFlag")
					{
						game.scoreTeam1++;
					}
					else
					{
						game.scoreTeam2++;
					}

					F$('rankInGame').refreshTeamScore();
				}

				if(game.playingPlayer)
				{
					if(player == game.playingPlayer)
					{
	                	// count human players in game
	                	var count = 0;
	                	for(var i = 0; i < game.players.length; i++)
	                		if(game.players[i].authLevel >= AUTH_LEVEL.GUEST)
	                			count++;

	                	var xp = playerData.authLevel >= AUTH_LEVEL.PLAYER ? getFlagXPFromPlayerCount(count) : 0;

						game.interface_.setMainKillMsg(slayOne.widgets.lang.get("game.msg.teamdm.score.self_self") + ((xp > 0) ? (" (+" + xp + " xp)") : ""), "#36FF36", "textInGreen");
						soundManager.playSound(SOUND.FRAG4, undefined, undefined, 0.8);
					}

					else if(player.team == game.playingPlayer.team)
					{
						game.interface_.setMainKillMsg(slayOne.widgets.lang.get("game.msg.teamdm.score.others_self", { playerName: player.name }), "#36FF36", "textInGreen");
						soundManager.playSound(SOUND.FRAG4, undefined, undefined, 0.78);
					}

					else
					{
						game.interface_.setMainKillMsg(slayOne.widgets.lang.get("game.msg.teamdm.score.others_others", { playerName: player.name }), "#FF3232", "textInRed");
						soundManager.playSound(SOUND.FRAG3, undefined, undefined, 0.68);
					}
				}

				game.addCircle(this.x, this.y, imgCoords.whiteCircle);
				enemyFlag.isActive = true;
				enemyFlag.createSpawnEffect();
				enemyFlag.carriedBy = null;
				enemyFlag.currentX = enemyFlag.x;
				enemyFlag.currentY = enemyFlag.y;

				return false;
			}

			else
				return false;
		}
	}

	if (
		customRespawnTime
		|| !(this.itemType && this.itemType.respawnPeriod && this.itemType.respawnPeriod < 0)
	) {
		var respawnPeriod = game.ticksCounter + this.getRespawnPeriod();

		if(this.weapon && this.weapon.respawnPeriod)
			respawnPeriod = game.ticksCounter + this.weapon.respawnPeriod;

		if(this.itemType && this.itemType.respawnPeriod)
			respawnPeriod = game.ticksCounter + this.itemType.respawnPeriod;

		if (isRespawn) {
			this.respawnAt = respawnPeriod - 2;
		} else {
			this.respawnAt = 9999999999;
		}
		this.isActive = false;
	}

	return true;
};

Ammo.prototype.getRespawnPeriod = function()
{
	var respawnPeriod = CONST.ITEM_RESPAWN_TIME;

	if(this.weapon && this.weapon.respawnPeriod)
		respawnPeriod = this.weapon.respawnPeriod;

	if(this.itemType && this.itemType.respawnPeriod)
		respawnPeriod = this.itemType.respawnPeriod;

	return respawnPeriod;
};

Ammo.prototype.createSpawnEffect = function()
{
	this.lightPillarsTop = [];
	this.lightPillarsBottom = [];

	if(!(this.x + 5 >= game.cameraX && this.y + 5 >= game.cameraY && this.x - 5 <= game.cameraX2 && this.y - 5 <= game.cameraY2))
		return;

	for(var i = 0; i < Math.PI * 2; i += 0.5 + Math.random() * 0.15)
		(i <= Math.PI ? this.lightPillarsBottom : this.lightPillarsTop).push({
			x: Math.sin(i) * 0.45 + this.x,
			y: Math.cos(i) * 0.45 + this.y,
			w: 0.15 + Math.random() * 0.3,
			h: Math.random() * 1.5,
			vh: 0.04 + Math.random() * 0.08,
			vw: Math.random() * 0.01,
			age_offset: Math.random() * 8 - 4
		});

	this.lastSpawnTick = game.ticksCounter;

	soundManager.playSound(SOUND.AMMO_SPAWN, this.x, this.y, 0.6);
};

Ammo.prototype.updateAndDrawPillar = function(p, age)
{
	p.h += p.vh * exactTickDiff;
	p.w += p.vw * exactTickDiff;

	var x = (p.x - p.w / 2 - game.cameraX) * FIELD_SIZE;
	var y = (p.y - p.h - game.cameraY) * FIELD_SIZE;
	var this_age = age + p.age_offset;

	c.globalAlpha = ((this_age < 5) ? Math.max(this_age / 5, 0) : ((this_age < 10) ? 1 : Math.max(2.0 - this_age / 10, 0))) * 0.4;
	c.drawImage(imgs.miscSheet, imgCoords.pillar_of_light.x, imgCoords.pillar_of_light.y, imgCoords.pillar_of_light.w, imgCoords.pillar_of_light.h, x, y, p.w * FIELD_SIZE, p.h * FIELD_SIZE);
};

Ammo.prototype.draw = function(exactTicks, x1, y1, x2, y2)
{
	if(!(this.currentX + 3 >= x1 && this.currentY + 3 >= y1 && this.currentX - 3 <= x2 && this.currentY - 3 <= y2) || game.editingMode)
		return;

	var age = exactTicks - this.lastSpawnTick;

	// ground tile
	if(!this.isFlag)
	{
		var img = imgCoords.itemSpawn;
		var x_offset = 0;

		var timeTillRespawn = this.respawnAt - exactTicks;

		if(timeTillRespawn <= 11)
		{
			if(timeTillRespawn >= 0)
				x_offset = (1 + Math.floor((11 - timeTillRespawn) * 5 / 11)) * 16;

			else if(timeTillRespawn >= -8)
				x_offset = (1 + Math.floor((8 + timeTillRespawn) * 5 / 8)) * 16;
		}

		var x = (this.currentX - game.cameraX - 0.5) * FIELD_SIZE;
		var y = (this.currentY - game.cameraY - 0.5) * FIELD_SIZE;
		c.drawImage(imgs.miscSheet, img.x + x_offset, img.y, 16, 16, x, y, 16 * SCALE_FACTOR, 16 * SCALE_FACTOR);

		if(!this.isActive && game.showEnemiesOnMinimapUntil >= exactTicks)
		{
			var perc = Math.min(Math.max(Math.floor(((1 - timeTillRespawn / this.getRespawnPeriod())) * 9), 0), 8);
			var img = imgCoords["filler" + perc];
			var scale = SCALE_FACTOR * 0.7;
			c.globalAlpha = 0.75 + Math.sin(exactTicks * 0.2) * 0.25;
			c.drawImage(
				imgs.miscSheet,
				img.x,
				img.y,
				img.w,
				img.h,
				x + (FIELD_SIZE + 1 * SCALE_FACTOR) * 0.5 - img.w * 0.5 * scale,
				y + FIELD_SIZE * 0.38 - img.h * 0.5 * scale,
				img.w * scale,
				img.h * scale
			);
			c.globalAlpha = 1;
		}
	}

	if(!this.isActive)
		return;

	if(age < 25) // play spawn effect
		for(var i = 0; i < this.lightPillarsTop.length; i++)
			this.updateAndDrawPillar(this.lightPillarsTop[i], age);

	var scale = this.scale * SCALE_FACTOR;

	var x = (this.currentX - game.cameraX) * FIELD_SIZE + (-this.img.w / 2) * scale;
	var y = (this.currentY + ((this.itemType && this.itemType.yOffset) ? this.itemType.yOffset : 0) - 0.2 - game.cameraY) * FIELD_SIZE + ((this.weapon ? 4 : 8) - this.img.h) * scale;

	var shineAlpha = age < 15 ? 0 : Math.min((age - 15) / 10, 1);

	if(this.shine)
	{
		y += Math.sin(exactTicks * 0.35) * FIELD_SIZE * 0.15;

		// shine
		var shineImg = imgCoords.itemShineFloor;
		var x2 = (this.x - game.cameraX) * FIELD_SIZE + (-shineImg.w / 2) * SCALE_FACTOR;
		var y2 = (this.y - game.cameraY) * FIELD_SIZE + (8 - shineImg.h) * SCALE_FACTOR;
		c.globalAlpha = (0.25 + Math.sin(exactTicks * 0.45) * 0.066) * shineAlpha;
		c.drawImage(imgs.miscSheet, shineImg.x, shineImg.y, shineImg.w, shineImg.h, x2, y2, shineImg.w * SCALE_FACTOR, shineImg.h * SCALE_FACTOR);
	}

	c.globalAlpha = age < 8 ? Math.max(age / 8, 0) : 1;
	c.drawImage(imgs.miscSheet, this.img.x, this.img.y, this.img.w, this.img.h, x, y, this.img.w * scale, this.img.h * scale);

	if(age < 25) // play spawn effect
		for(var i = 0; i < this.lightPillarsBottom.length; i++)
			this.updateAndDrawPillar(this.lightPillarsBottom[i], age);

	if(this.shine)
	{
		// shine
		var shineImg = imgCoords.itemShine;
		var x2 = (this.x - game.cameraX) * FIELD_SIZE + (-shineImg.w / 2) * SCALE_FACTOR;
		var y2 = (this.y - game.cameraY) * FIELD_SIZE + (8 - shineImg.h) * SCALE_FACTOR;
		c.globalAlpha = (0.6 + Math.sin(exactTicks * 0.45) * 0.25) * shineAlpha;
		c.drawImage(imgs.miscSheet, shineImg.x, shineImg.y, shineImg.w, shineImg.h, x2, y2, shineImg.w * SCALE_FACTOR, shineImg.h * SCALE_FACTOR);
	}

	c.globalAlpha = 1;
};
