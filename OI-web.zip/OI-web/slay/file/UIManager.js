var
	currentProfile = null,
	
    SOUND = window.SOUND,
    keyNames = window.keyNames,
    
    buttonData = {
        exitGame: {
            widget: "iconButton",
            cssId: "btnExitGame",
            iconClass: "iconButtonExitGame",
            methodShow: function () {
                attemptExitGame();
            },
            methodShouldShow: function () {
                return isInGame();
            },
            label: "top.buttons.exit_game.tooltip",
        },
        exitApp: {
            widget: "iconButton",
            cssId: "btnExitApp",
            iconClass: "iconButtonExitGame",
            methodShow: function () {
                attemptExitApp();
            },
            methodShouldShow: function () {
                return !isInGame() && window.isDesktop;
            },
            label: "top.buttons.exitApp.tooltip",
        },
        gameOptions: {
            widget: "iconButton",
            cssId: "btnOptions",
            iconClass: "iconButtonOptions",
            methodShow: function () {
                toggleOptionsMenu();
            },
            label: "top.buttons.options.tooltip",
        },
        fullScreen: {
            widget: "iconButton",
            cssId: "btnSeparate",
            iconClass: "iconButtonFullScreen",
            methodShow: function () {
                toggleFullscreen(document.documentElement);
            },
            methodShouldShow: function () {
                return true;
            },
            label: "options.btn_fullscreen.tooltip",
        },
        
        rankings: {
            widget: "iconButton",
            cssId: "btnRankList",
            iconClass: "iconButtonRankList",
            methodShow: function () {
                window.uiManager.togglePlayerList();
            },
            methodShouldShow: function () {
                return !isInGame();
            },
            label: "top.buttons.ranking.tooltip",
        },

        myProfile: {
            widget: "iconButton",
            cssId: "btnProfile",
            iconClass: "iconButtonProfile",
            methodShow: function () {
                uiManager.showPlayerInfoById(playerData.db_id);
            },
            methodShouldShow: function () {
                return !isInGame() && playerData.authLevel >= AUTH_LEVEL.PLAYER;
            },
            label: "top.buttons.profile.tooltip"
        },
        myClan: {
            widget: "iconButton",
            cssId: "btnClanList",
            iconClass: "iconButtonClanList",
            methodShow: function () {
                F$('clanMain').show();
            },
            methodShouldShow: function () {
                return !isInGame() && playerData.authLevel >= AUTH_LEVEL.PLAYER;
            },
            label: "top.buttons.myclan.tooltip",
        },
        
        mapEditor: {
            widget: "iconButton",
            cssId: "btnMapEditor",
            iconClass: "iconButtonMapEditor",
            methodShow: function () {
                launchEditor();
            },
            methodShouldShow: function () {
                return !isInGame() && playerData.authLevel >= AUTH_LEVEL.ADMIN;
            },
            label: "top.buttons.map_editor.tooltip",
        },
        changelog: {
            widget: "iconButton",
            cssId: "btnChangelog",
            iconClass: "iconButtonChangelog",
            methodShow: function () {
                showChangelog();
            },
            methodShouldShow: function () {
                return !isInGame();
            },
            labelDirect: "Changelog",
        }
    };

function showChangelog()
{
	var str = "";
	
	str += "<p>22.8.2019</p>";
	str += "<p>- rebuilding the game. Several features are still missing and bugs are in the game. Once everything is back to normal, new stuff is gonna be added.</p>";
	str += "<p>&nbsp;</p>";
	str += "<p>22.3.2019</p>";
	str += "<p>- added some new skins</p>";
	str += "<p>&nbsp;</p>";
	str += "<p>6.3.2019</p>";
	str += "<p>- added some new skins</p>";
	str += "<p>- added ingame changelog</p>";
	str += "<p>- fixed some issues with custom builds not working in infection mode</p>";
	str += "<p>- fixed a bug that would cause zombies in infection mode to become invincible after been thrown into water</p>";
	str += "<p>- in team games, when a team has 2 player more than the other team (or more than 2 players) one random player is switched now</p>";
	str += "<p>&nbsp;</p>";
	str += "<p>26.2.2019</p>";
	str += "<p>- playing a game on a map that is not in the vote rotation will not have map voting anymore but replay the same map instead</p>";
	str += "<p>- fixed an issue that made joining the game via the 'play' button would not put a player in the most crowded game for some maps</p>";
	str += "<p>- guests now can pick names instead of being called 'abc'</p>";
	str += "<p>- guests dont have a '*' prior to their name anymore</p>";
	str += "<p>- removed skin builds from the game, all modes are now custom build, skins are purely for cosmetics; chests only grant gold</p>";
	str += "<p>&nbsp;</p>";
	str += "<p>25.1.2019</p>";
	str += "<p>- added some new skins</p>";
	str += "<p>- changed color of enemy sniper line from red to orange</p>";
	str += "<p>- fixed a display bug in the custom build UI</p>";
	str += "<p>- shooting now removes your spawn-invulnerability</p>";
	str += "<p>- default bot count down to 4; max bot count set to 8 (except for infection mode)</p>";
	str += "<p>- fixed a bug that made it impossible for some players to join normal Deathmatch mode</p>";
	str += "<p>&nbsp;</p>";
	str += "<p>15.1.2019</p>";
	str += "<p>- added several new skins</p>";
	str += "<p>- default Deathmatch is now 'custom build' instead of 'skin-based build' mode</p>";
	str += "<p>- fixed heal aura heal animation</p>";
	str += "<p>- fixed turret rotation animation</p>";
	str += "<p>- fixed shotgun not cancelling invisibility</p>";
	str += "<p>- reduced wall hp from 120 (+45) to 80 (+40)</p>";
	str += "<p>- lifesteal now also regenerates life when target has armor and when doing damage with acid grenades</p>";
	str += "<p>- shield: increased energy cost from 30 to 33</p>";
	str += "<p>- increased the height at which players are affected by an explosion</p>";
	str += "<p>- heal gun does not kill rockets anymore</p>";
	str += "<p>- energy rifle: reduced ammo size from 40 to 28; reduced clip size from 20 to 14; 1st fire mode is not hitscan anymore, but a projectile with high speed; 1st fire mode doesnt collide with rockets anymore</p>";
	str += "<p>- landing on the edge of water doesnt cause drowning anymore (this also means its not possible to drown in 1-tile-wide water anymore, like the 'health islands' on forest for example)</p>";
	str += "<p>- when aiming with sniper rifle, every player can see the dotted sniper line now</p>";
	
    slayOne.viewHelpers.showInfoScreen({
        title: "Changelog",
        content: str
    });
};

function renderMainMenu_(parentNode)
{
    var cssId = "menuButtonContainer";
    var menuButtonContainer = document.getElementById(cssId) || document.createElement("div");
    menuButtonContainer.id = cssId;
    menuButtonContainer.setAttribute("data-noclick", 'yes');

    // We add all buttons here. Will hide unused buttons after calling refreshMenuButton
    for (var buttonKey in buttonData) {
        var btnData = buttonData[buttonKey];
        if (btnData.widget == "iconButton") {
            btnData.instance = slayOne.widgets.iconButton(menuButtonContainer, {
                cssId: btnData.cssId,
                iconClassName: btnData.iconClass,
                onClick: btnData.methodShow,
                tip: btnData.labelDirect ? btnData.labelDirect : slayOne.widgets.lang.get(btnData.label)
            });
        } else if (btnData.widget == "labelButton") {
            btnData.instance = slayOne.widgets.labelButton(menuButtonContainer, {
                cssId: btnData.cssId,
                iconClassName: btnData.iconClass,
                onClick: btnData.methodShow,
                label: slayOne.widgets.lang.get(btnData.iconLabel),
                multiline: btnData.multiline,
                tip: slayOne.widgets.lang.get(btnData.label),
                theme: btnData.theme
            });
        }

        btnData.instance.style.display = "none";
    }
	
	if (isSteam) {
		try {
			var ele = document.createElement('div');
			ele.id = 'steam-addon';

			var btn1 = document.createElement('div');
			btn1.innerHTML = '<a href="#"><img src="imgs/btn_link.png"></img><div class="hover"></div></a>';
    	    // btn1.tooltipData = F_('home.tooltip.steam');

			btn1.onclick = () => {
				F$('goRoom').show();
			};

			ele.appendChild(btn1);

    	    menuButtonContainer.appendChild(ele);
    	} catch (err) {
    	    // Empty
    	}
	} else {
		/*
    	try {
			var ele = document.createElement('div');
			ele.id = 'greenlight-button';

			var btn1 = document.createElement('div');
			btn1.innerHTML = "<a target='_blank' href='https://store.steampowered.com/app/743350/Slayone/?utm_source=official&utm_term=index'><img width=218 height=64 src='imgs/steam.png'></img><div class='hover'></div></a>";
    	    btn1.tooltipData = F_('home.tooltip.steam');

			var btn2 = document.createElement('div');
			btn2.innerHTML = "<a target='_blank' href='https://trello.com/b/pIJc0nLA/slayone-development'><img width=142 height=64 src='imgs/patchnotes.png'></img><div class='hover'></div></a>";
    	    btn2.tooltipData = F_('home.tooltip.patchnotes');

			ele.appendChild(btn1);

    	    menuButtonContainer.appendChild(ele);
    	} catch (err) {
    	    // Empty
    	}
    	*/
	}

    parentNode.appendChild(menuButtonContainer);
};

function loadLatestReplays()
{
	soundManager.playSound(SOUND.CLICK);
	
	network.send("getVODs");
	
	var slayTV = document.getElementById("slayTV");
	slayTV.className = "";
	slayTV.onclick = null;
	
	setInterval(function(){
		network.send("getVODs");
	}, 1000 * 60 * 17);
};

function showLatestReplays(arr)
{
	var slayTV_content = document.getElementById("slayTV_content");
	
	slayTV_content.innerHTML = "";
	
	for(var i = 1; i < arr.length; i += 7)
	{
		var div = document.createElement("div");
		
		var str = '<span class="nick pseudoLink withClickSound" onclick="uiManager.showPlayerInfoById(' + arr[i + 1] + ');" style="color: rgb(255, 255, 120);">' + arr[i + 3] + '</span>';
		str += ' x ';
		str += '<span class="nick pseudoLink withClickSound" onclick="uiManager.showPlayerInfoById(' + arr[i + 2] + ');" style="color: rgb(255, 255, 120);">' + arr[i + 4] + '</span>';
		
		str += ' <span class="watchRepLink pseudoLink withClickSound" onclick="watchLaddergame(' + arr[i] + ');" style="color: rgb(255, 255, 120);">view</span>';
		
		div.innerHTML = str;
		
		slayTV_content.appendChild(div);
	}
};

function UIManager()
{
	
};

UIManager.prototype.requestMyClanInfo = function(tag)
{
	F$('clanMain').show(tag);
};

function setOptions()
{
    sound_volume = parseFloat(document.getElementById("soundRange").value);
    localStorage.setItem("sound_volume", sound_volume);

    minimapSizeFactor = parseFloat(document.getElementById("minimapSizeFactor").value);
    localStorage.setItem("minimapSizeFactor", minimapSizeFactor);

    graphicSettings = document.getElementById("graphicSettings").checked ? 0 : 10;
    localStorage.setItem("graphicSettings", graphicSettings);
	
    weaponsUnclickable = document.getElementById("weaponsUnclickable").checked;
    localStorage.setItem("weaponsUnclickable", weaponsUnclickable);
	
    hideChat = document.getElementById("hideChat").checked;
    localStorage.setItem("hideChat", hideChat);
    document.getElementById("chatDisplayDiv").style.display = hideChat ? "none" : "block";
};

function toggleOptionsMenu()
{
    slayOne.views.optionsScreen.showWindow({});
};

UIManager.prototype.togglePlayerList = function(page, alwaysOpen, elo)
{
    var el = document.getElementById("optionsWindow");
    el.className = "optionsWindow1 basicWindow";
    if(!alwaysOpen && el.style.display == "inline" && el.getAttribute("data-windowtype") == "playerlist")
    {
        el.style.display = "none";
        return;
    }
    el.style.display = "inline";
    network.send("playerList$" + (page ? page : "0") + "$" + (elo ? "1" : "0"));
};

var showTutorialWindow_ = function()
{
    var videoURLs = {
        'en': '//www.youtube.com/embed/dMtZiL1lnaM',
        'pt': '//www.youtube.com/embed/ky3uTWJIMtg',
        'es': '//www.youtube.com/embed/ieKZ0BIvNuM',
    };
	
    var videoURL = videoURLs[slayOne.widgets.lang.locale];
    if(!videoURL)
        videoURL = videoURLs['en'];
	
    localStorage.setItem("tutorialVideoShown", "true");
    uiManager.refreshMenuButtons();

    var domContent = document.createElement("div");
    var videoOrigin = window.location.protocol + "//" + window.location.host;

    var domContentHTML = '<iframe width="600" height="338" src="' + videoURL + '?autoplay=1&origin=' + videoOrigin + '" frameborder="0" allowfullscreen></iframe>';
    domContentHTML += '<div class="faqTips">';
    domContentHTML += slayOne.widgets.lang.get("faq.content", {
        fbFanPage: '<a class="withClickSound" href="https://www.facebook.com/slay.one.game/" target="_blank">' + slayOne.widgets.lang.get("faq.content.facebook") + '</a>',
        subreddit: '<a class="withClickSound" href="https://www.reddit.com/r/slayone" target="_blank">' + slayOne.widgets.lang.get("faq.content.reddit") + '</a>',
    });
    domContentHTML += '</div>';
    domContent.innerHTML = domContentHTML;

    slayOne.viewHelpers.showWindow({
        domContent: domContent,
        headerLabel: slayOne.widgets.lang.get("faq.title"),
        onClose: function () {

            slayOne.viewHelpers.hideWindow();

            if (!game || game.mapWelcome) {
                var viewModel = {
                    authLevel: playerData.authLevel
                };
                slayOne.views.homeScreen.render(viewModel);
            }
        }
    });
};

function toggleImprint()
{
    slayOne.viewHelpers.showInfoScreen({
        title: "Imprint",
        content: "<div>Slay.one is a free indie 2D multiplayer topdown shooter for browsers. For more info, you can check out our <a class='withClickSound' href=\"https://www.reddit.com/r/WebGames/comments/5b48nw/slayone_a_multiplayer_topdown_shooter_were_the/\" target=\"_blank\">Reddit AMA</a>.<br><br>Publisher:<br><br>KingsGroup Holding<br>San Francisco, CA, USA<br><br>Contact Email: <a class='withClickSound' href=\"mailto:support@slay.one\">support@slay.one</a><br></div>"
    });
};

function toggleAGB()
{
    ajax("legalities/agb.html", function (data) {
        slayOne.viewHelpers.showInfoScreen({
            title: "General Terms and Conditions",
            content: data
        });
    });
};

function showAGB2()
{
    ajax("legalities/agb.html", function (data) {
        slayOne.viewHelpers.showInfoScreen({
            title: "General Terms and Conditions",
            content: data
        });
    });
};

function toggleWRE()
{
    ajax("legalities/wre.html", function (data) {
        slayOne.viewHelpers.showInfoScreen({
            title: "Cancellation Policy",
            content: data
        });
    });
};

function toggleDSE()
{
    ajax("legalities/dse.html", function (data) {
        slayOne.viewHelpers.showInfoScreen({
            title: "Privacy Policy",
            content: data
        });
    });
};

UIManager.prototype.toggleClanList = function(page, alwaysOpen)
{
    var el = document.getElementById("optionsWindow");
    el.className = "optionsWindow1 basicWindow";
    if(!alwaysOpen && el.style.display == "inline" && el.getAttribute("data-windowtype") == "clanlist")
    {
        el.style.display = "none";
        return;
    }
    el.style.display = "inline";
    network.send("clanList$$" + (page ? page : "0") + "$10");
};

UIManager.prototype.showHatsMenu = function()
{
    F$('items').show();
};

UIManager.prototype.showLobby = function(tabIndex)
{
    slayOne.viewHelpers.showPopup("lobby", {
        theme: 'tabbed',
        initTabIndex : tabIndex || 0,
        title: slayOne.widgets.lang.get("lobby.title"),
        tabs: [
            {
                label: slayOne.widgets.lang.get("lobby.tabs.browse.label"),
                view: 'roomsListScreen',
                tip: slayOne.widgets.lang.get("lobby.tabs.browse.tooltip"),
            },
            {
                label: slayOne.widgets.lang.get("lobby.tabs.create.label"),
                view: 'roomCreateScreen',
                tip: slayOne.widgets.lang.get("lobby.tabs.create.tooltip"),
            }
        ]
    });
};

UIManager.prototype.showHotkeyWindow = function()
{
    var str = "<div class='header'>Controls</div>";

    for (var attribute in commandNames)
        if (commandNames.hasOwnProperty(attribute))
            str += "<div class='hotkeySubDiv'>" + commandNames[attribute] + " <button data-key='" + attribute + "' class='hotkey_button withClickSound' id='hotkey_" + attribute + "' onclick='changeHotkey1(" + attribute + ");'>" + keyNames[commandKeys[attribute]] + "</button></div>";

    document.getElementById("optionsWindow").innerHTML = str;
    document.getElementById("optionsWindow").appendChild(this.createCloseButton());
    document.getElementById("optionsWindow").setAttribute("data-windowtype", "hotkeys");
};

function changeHotkey1(key)
{
    var hotkey_buttons = document.getElementsByClassName("hotkey_button");
    for (var i = 0; i < hotkey_buttons.length; i++) {
        hotkey_buttons[i].style.color = "";
        hotkey_buttons[i].className = "hotkey_button";
    }
    document.getElementById("hotkey_" + key).style.color = "red";
    document.getElementById("hotkey_" + key).className = "hotkey_button hotkey_button_active";
};

UIManager.prototype.showPlayerList = function(data)
{
    var page = parseInt(data[2]);
    var lastpage = 0;
    lastPlayerListPage = page;
    var countPages = Math.ceil(parseInt(data[1]) / 10);
    var elo = data[3] == "1";

    var str = "<div style='font-size: 16px; margin-top: 16px;'>";
    str += (elo ? "<a class='pseudoLink withClickSound' onclick='uiManager.togglePlayerList(-1, true);'>" : "") + "Players (XP)" + (elo ? "</a>" : "");
    str += " | " + (!elo ? "<a class='pseudoLink withClickSound' onclick='uiManager.togglePlayerList(-1, true, true);'>" : "") + "Players (elo)" + (!elo ? "</a>" : "");
    str += " | <a class='pseudoLink withClickSound' onclick='uiManager.toggleClanList();'>Clans</a></div>";
    str += "<table id='playerListTable'><tr class='headTR'><td>Rank</td><td>Name</td><td>Clan</td><td>" + (elo ? "elo" : "level") + "</td></tr>";

    var k = 1;
    for(var i = 4; i < data.length; i += 4)
    {
        var playerId = data[i];
        var playerName = data[i + 1];
        var playerClanTag = data[i + 3];
        var playerScore = parseInt(data[i + 2]);
		
        var clan = playerClanTag ? "<td>[<a class='pseudoLink yellow withClickSound' onclick='uiManager.requestMyClanInfo(\"" + playerClanTag + "\");'>" + playerClanTag + "</a>]</td>" : "<td></td>";
        str += "<tr><td>" + (k + page * 10) + "</td><td><a class='pseudoLink withClickSound' onclick='uiManager.showPlayerInfoById(\"" + playerId + "\");'>" + escapeHtml(playerName) + "</a></td>";
        str += clan + "<td>" + (elo ? playerScore : getLvlFromXp(playerScore)) + "</td></tr>";
        k++;
    }
	
    str += "</table>";
	
    if(countPages > 1)
    {
        str += "<div id='pageSystem'>";
		
        for(i = 0; i < countPages; i++)
            if(i <= 1 || i >= (countPages - 2) || (i >= page - 3 && i <= page + 3))
            {
                if(lastpage > 0 && lastpage != i - 1)
                    str += " ... ";
                str += (i == page) ? (" " + (i + 1) + " ") : ("<button class='withClickSound' onclick='uiManager.togglePlayerList(" + i + ", true, " + (elo ? "true" : "false") + ");'>" + (i + 1) + "</button>");
                lastpage = i;
            }

        str += "</div>";
    }
	
    document.getElementById("optionsWindow").innerHTML = str;
    document.getElementById("optionsWindow").appendChild(this.createCloseButton());
    document.getElementById("optionsWindow").setAttribute("data-windowtype", "playerlist");
};

UIManager.prototype.showClanList = function(data)
{
    var page = data.page;
    var lastpage = 0;
    lastPlayerListPage = page;
    var countPages = Math.ceil(data.total / 10);
	
    var str = "<div style='font-size: 16px; margin-top: 16px;'><a class='pseudoLink withClickSound' onclick='uiManager.togglePlayerList(-1, true);'>Players (XP)</a>";
    str += " | <a class='pseudoLink withClickSound' onclick='uiManager.togglePlayerList(-1, true, true);'>Players (elo)</a>";
    str += " | Clans</div><table id='playerListTable'><tr class='headTR'><td>Rank</td><td>Tag</td><td>Name</td><td>Members</td><td>Score</td></tr>";
	
    var k = 1;
    for(var i = 0; i < data.length; i ++)
    {
        var datum = data[i];
        str += "<tr><td>" + (k + page * 10) + "</td><td>[<a class='pseudoLink withClickSound' onclick='uiManager.requestMyClanInfo(\"" + datum.tag + "\");'>" + datum.tag + "</a>]</td>";
        str += "<td>" + datum.name + "</td><td>" + datum.countMembers + "</td><td>" + datum.elo + "</td></tr>";
        k++;
    }
	
    str += "</table>";
    
    if(countPages > 1)
    {
        str += "<div id='pageSystem'>";
		
        for(i = 0; i < countPages; i++)
            if(i <= 1 || i >= (countPages - 2) || (i >= page - 3 && i <= page + 3))
            {
                if(lastpage > 0 && lastpage != i - 1)
                    str += " ... ";
                str += (i == page) ? (" " + (i + 1) + " ") : ("<button class='withClickSound' onclick='uiManager.toggleClanList(" + i + ", true);'>" + (i + 1) + "</button>");
                lastpage = i;
            }

        str += "</div>";
    }
    
    document.getElementById("optionsWindow").style.display = "inline";
    document.getElementById("optionsWindow").className = "optionsWindow1 basicWindow";
    document.getElementById("optionsWindow").innerHTML = str;
    document.getElementById("optionsWindow").appendChild(this.createCloseButton());
    document.getElementById("optionsWindow").setAttribute("data-windowtype", "playerlist");
    
    var el = document.querySelector(".F-popUpLayer");
    
    if(el)
    	el.parentNode.removeChild(el);
};

UIManager.prototype.showPlayerInfoById = function(pid)
{
    pid = pid | 0;
    if(pid < 1)
        return;
    
    network.send("plInfo$" + pid);
};

UIManager.prototype.showPlayerInfoWithData = function(data)
{
	var profile = {
		pid: data[1],
		displayName: data[2],
		exp: data[3],
		elo: parseInt(data[4]),
		clanName: data[5],
		numKills: data[6],
		numDeaths: data[7],
		tsCreated: data[8],
		desc: data[9],
		tsNick: data[10]
	};
	
	if(playerData.db_id == profile.pid)
		currentProfile = profile;
	
    slayOne.views.playerProfileScreen.show({
        perspective: (playerData.db_id == profile.pid) ? 'self' : 'guest',
        profile: profile
    });
};

UIManager.prototype.memberList = function(data)
{
    var clan_tag = data[1];
	
    if(data[0] == "memberList")
    {
    	clanMembers = [];
    	
        for(var i = 2; i < data.length; i += 3)
        {
            clanMembers.push({
                id: parseInt(data[i]),
                name: data[i + 1],
                role: authLevelNames[parseInt(data[i + 2])],
                roleNumber: parseInt(data[i + 2])
            });
        }
        
        renderClanMembers();
    }
    
    else
    {
        clanApps = [];
        
        for(var i = 2; i < data.length; i += 3)
        {
            clanApps.push({
                id: parseInt(data[i]),
                text: data[i + 2],
                name: data[i + 1]
            });
        }
        
        renderClanApps();
    }
};

function renderClanApps()
{
    var el = document.querySelector("#myClan_requestList");
    
    if(!el)
    	return;
    
    el.innerHTML = "";
	
	for(var i = 0; i < clanApps.length; i++)
	{
    	var li = document.createElement("li");
    	li.className = "F-ItemRenderer";
    	li.innerHTML = '<h4 class="name">' + clanApps[i].name + '</h4>' +
                        '<div class="F-Button reject" onclick="rejectMember(' + clanApps[i].id + ');" data-tooltip-data="_(myClan.tooltip.decline)"></div>' +
                        '<div class="F-Button accept" onclick="acceptMember(' + clanApps[i].id + ', \'' + clanApps[i].name + '\');" data-tooltip-data="_(myClan.tooltip.approve)"></div>' +
                        '<div class="F-Button info" onclick="showPlayerInfo(' + clanApps[i].id + ');" data-tooltip-data="_(myClan.tooltip.profile)"></div>';
	    
	    el.appendChild(li);
	}
};

function rejectMember(id)
{
	network.send("rejectClanMember$" + id);
};

function acceptMember(id, name)
{
	network.send("acceptClanMember$" + id + "$" + name);
};

function renderClanMembers()
{
    var el = document.querySelector("#myClan_memberList");
    
    if(!el)
    	return;
    
    el.innerHTML = "";
	
	for(var i = 0; i < clanMembers.length; i++)
	{
		var li = document.createElement("li");
		li.className = "F-ItemRenderer";
		li.innerHTML = '<div>' +
	                        '<h4 class="name">' + clanMembers[i].name + '</h4>' +
	                        '<div class="role">' + clanMembers[i].role + '</div>' +
	                    '</div>';
		
	    if(currentClan.tag == playerData.clanTag && clanMembers[i].id != playerData.db_id && playerData.clanRole >= clanMembers[i].roleNumber && playerData.clanRole >= AUTH_LEVEL.MOD)
	    	li.innerHTML += '<div class="F-Button remove" onclick="kickMember(' + clanMembers[i].id + ', \'' + clanMembers[i].name + '\');" data-tooltip-data="_(myClan.tooltip.remove)"></div>';
	    
	    if(currentClan.tag == playerData.clanTag && clanMembers[i].id != playerData.db_id && playerData.clanRole >= clanMembers[i].roleNumber && clanMembers[i].roleNumber >= AUTH_LEVEL.MOD)         
			li.innerHTML += '<div class="F-Button demote" onclick="demoteMember(' + clanMembers[i].id + ');" data-tooltip-data="_(myClan.tooltip.demote)"></div>';
		
		if(currentClan.tag == playerData.clanTag && clanMembers[i].id != playerData.db_id && playerData.clanRole > clanMembers[i].roleNumber && clanMembers[i].roleNumber < AUTH_LEVEL.ADMIN)
			li.innerHTML += '<div class="F-Button promote" onclick="promoteMember(' + clanMembers[i].id + ');" data-tooltip-data="_(myClan.tooltip.promote)"></div>';
	    
	    li.innerHTML += '<div class="F-Button info" onclick="showPlayerInfo(' + clanMembers[i].id + ');" data-tooltip-data="_(myClan.tooltip.profile)"></div>';
	    
	    el.appendChild(li);
	}
};

function kickMember(id, name)
{
    F$confirm(
        F_("myClan.kick.confirm", {playerName : name}),
        function(){ network.send("kickMember$" + id); }
    );
};

function demoteMember(id)
{
	network.send("demote$" + id);
};

function promoteMember(id)
{
	network.send("promote$" + id);
};

UIManager.prototype.createCloseButton = function(cb)
{
    var self = this;
    var closeButton = document.createElement("button");

    closeButton.innerHTML = "x";
    closeButton.className = "closeButton";
    closeButton.onclick = function()
    {
        this.parentNode.style.display = "none";
        cb && cb();
    };

    slayOne.widgets.clickable(closeButton);

    return closeButton;
};

UIManager.prototype.createButton = function(caption, className, onclick, css, appendTo, id, onmouseover, onmouseout, name, att1)
{
    var b = document.createElement("button");
    b.innerHTML = caption;

    if(css)
        b.style.cssText = css;

    if(className)
        b.className = className;

    if(id)
        b.id = id;

    b.onclick = onclick;

    if(appendTo && appendTo.appendChild)
        appendTo.appendChild(b);

    b.setAttribute("data-noclick", 'yes');

    if(onmouseover)
        b.onmouseover = onmouseover;

    if(onmouseout)
        b.onmouseout = onmouseout;

    if(name)
        b.name = name;

    if(att1)
        b.setAttribute("data-att1", att1);

    slayOne.widgets.clickable(b);

    return b;
};

/**
 *    startTab:0 -> Login
 *    startTab:1 -> Register
 */
UIManager.prototype.showAccountWindow = function(tabIndex)
{
    var self = this;
    slayOne.viewHelpers.showPopup("account", {
        theme: 'tabbed',
        tabs: [
            {label: slayOne.widgets.lang.get("account.tabs.login.label"), view: 'loginScreen'},
            {label: slayOne.widgets.lang.get("account.tabs.signup.label"), view: 'registerScreen'}
        ],
        initTabIndex: tabIndex,
        onClose: function () {
        	self.showMainScene();
        },
    });
};

UIManager.prototype.login = function()
{
    var inputUserName = document.getElementById('playerNameInput').value;
    var inputPassword = document.getElementById('playerPwInput').value;
    var inputStayLoggedIn = document.getElementById('stayLoggedIn').checked;
    network.send(['login', inputUserName, inputPassword, inputStayLoggedIn].join('$'));
};

UIManager.prototype.register = function()
{
    var inputUserName = document.getElementById('playerNameInput').value;
    var inputPassword = document.getElementById('playerPwInput').value;
    var inputEmail = document.getElementById('emailInput').value;
    network.send(['register', inputUserName, inputPassword, inputEmail, '', ''].join('$'));
};

UIManager.prototype.showEditorInfo = function(str)
{
    document.getElementById("editorInfo").innerHTML = str;
    document.getElementById("editorInfo").style.display = "block";
};

UIManager.prototype.hideEditorInfo = function()
{
    document.getElementById("editorInfo").style.display = "none";
};

function crateGamesListTable()
{
    var t = document.createElement("table");
    t.id = "mainGamesTable";
    t.className = "basicTable";
    var tr = document.createElement("tr");
    tr.innerHTML = "<tr><td>Map</td><td>Players</td><td>Mode</td><td></td>";
    t.appendChild(tr);

    document.getElementById('gamesDiv').innerHTML = "";
    document.getElementById('gamesDiv').appendChild(t);
};

function switchMode(mod)
{
    soundManager.playSound(SOUND.CLICK);

    var countModes = MAP_TYPE_SETTINGS.length;

    var newMode = (parseInt(modeSwitchDiv.getAttribute("data-mode-id")) + countModes + mod) % countModes;

    modeSwitchDiv.setAttribute("data-mode-id", newMode);
    modeSwitchDiv.innerHTML = "<span>" + MAP_TYPE_SETTINGS[newMode].name + "</span>";

    defaultGameMode = newMode;
    localStorage.setItem("defaultGameMode", defaultGameMode);
};

UIManager.prototype.showMainScene = function()
{
    //TEMPORARY document.getElementById('logindiv'). - to hide the main old-school main div after closing it - until we get rid of the old UIs
    document.getElementById('logindiv').style.display = "none";

    var viewModel = {
        authLevel: playerData.authLevel
    };

    slayOne.views.homeScreen.render(viewModel);

    this.refreshMenuButtons();
};

UIManager.prototype.showFbName = function(name, email, callback)
{
    slayOne.views.fbNameScreen.show(name, email, callback);
};

UIManager.prototype.refreshClanDiv = function()
{
    if(document.getElementById("playerNameDiv"))
    {
        var playerNameHTML = "";
        if(playerData.clanTag && playerData.clanTag.length > 0)
            playerNameHTML += "[<span id='playerClanDiv' class='yellow withClickSound' onclick='uiManager.requestMyClanInfo();'>" + playerData.clanTag + "</span>] ";
        playerNameHTML += "<span onclick='uiManager.showPlayerInfoById(\"" + playerData.db_id + "\");'>" + escapeHtml(playerData.name) + "</span>";
        document.getElementById("playerNameDiv").innerHTML = playerNameHTML;
    }
    slayOne.views.homeScreen.refreshWelcomeMessage();
};

UIManager.prototype.refreshWelcomeDiv = function () {
    if (document.getElementById('welcomeName')) {
        var clan_tag_str = ((playerData.clanTag && playerData.clanTag.length > 0) ? ("[<span class='yellow withClickSound' onclick='uiManager.requestMyClanInfo();'>" + playerData.clanTag + "</span>] ") : "");
        document.getElementById('welcomeName').innerHTML = clan_tag_str + playerData.name;
    }
};

UIManager.prototype.refreshMenuButtons = function()
{
    for(var buttonKey in buttonData)
    {
        var btnData = buttonData[buttonKey];
        if(!btnData.methodShouldShow || btnData.methodShouldShow())
            btnData.instance.style.display = "inline-block";
        else
            btnData.instance.style.display = "none";
    }
};

UIManager.prototype.setXP = function(xp)
{
    playerData.xp = parseInt(xp);
    slayOne.views["homeScreen"].refreshExp();
};

UIManager.prototype.showDeathScreen = function(killerName)
{
    F$('respawn').show(killerName);
    slayOne.viewHelpers.showAd();
};

UIManager.prototype.hideDeathScreen = function()
{
    F$('respawn').hide(true);
    F$('respawnMini').hide(true);
};

UIManager.prototype.countDownDeath = function(timeTillRespawn)
{
    F$('respawn').progress(timeTillRespawn);
};

function closeAchivementWindow()
{
    soundManager.playSound(SOUND.CLICK);

    var div = document.getElementById("unlockDiv");

    div.style.animationName = "fadeOut2";
    div.style.animationDuration = "0.4s";
    div.style.animationFillMode = "forwards";

    setTimeout(function () {
        document.getElementById("unlockDiv").style.display = "none";
    }, 500);
    setTimeout(showAchivement, 1000);
};

function showAchivement()
{
    if (unlocks2Show.length > 0 && document.getElementById("unlockDiv").style.display != "inline") {
        if (unlocks2Show[0].type == "lvlup") {
            var div = document.getElementById("unlockDiv");

            var str = "<button id='unlockCloseButton' onclick='closeAchivementWindow();'>X</button><div id='lvlUpDiv1'>Level Up</div><div id='lvlUpDiv2'>You reached level <span class='green'>";
            str += unlocks2Show[0].lvl + "</span></div><div id='lvlUpDiv3'>You gained <span class='yellow'>" + unlocks2Show[0].gold + "</span> gold</div>";
            document.getElementById("unlockDivInner").innerHTML = str;
            div.style.display = "inline";

            div.style.animationName = "fadeIn";
            div.style.animationDuration = "0.65s";
            div.style.animationFillMode = "forwards";

            div = document.getElementById("lvlUpDiv1");
            div.style.animationName = "shine";
            div.style.animationDuration = "0.8s";
            div.style.animationIterationCount = "infinite";

            soundManager.playSound(SOUND.LVLUP);

            playerData.gold = unlocks2Show[0].goldTotal;
            F$('resourceBar').refresh();
        }

        else if (unlocks2Show[0].type == "unlock") {
            var div = document.getElementById("unlockDiv");

            document.getElementById("unlockDivInner").innerHTML = "<button id='unlockCloseButton' onclick='closeAchivementWindow();'>X</button>";
            div.style.display = "inline";

            var hat = unlocks2Show[0].item;

            var ca_ = document.createElement("canvas");
            document.getElementById("unlockDivInner").appendChild(ca_);
            ca_.id = "unlockCanvas";
            ca_.width = 256;
            ca_.height = 256;
            var c_ = ca_.getContext("2d");

            c_.mozImageSmoothingEnabled = false;
            c_.msImageSmoothingEnabled = false;
            c_.imageSmoothingEnabled = false;

            var div2 = document.createElement("div");

            if (hat.isHat) {
                var direction = 2;
                var frame = 1;
                var scale = 8;

                c_.drawImage(imgs.shadow, 0, 0, 32 * scale, 32 * scale); // shadow
                c_.drawImage(imgs.weaponsMinus, direction * 32, 0, 32, 32, Math.sin(frame * (Math.PI / 2)) * scale / 3, -(frame % 2) * scale / 2, 32 * scale, 32 * scale); // weapons minuz
                c_.drawImage(imgs.legs, frame * 32, 32 * direction + hat.legs * 288, 32, 32, 0, 0, 32 * scale, 32 * scale); // legz
                if (hat.hatOnly)
                    c_.drawImage(imgs.heads, direction * 32, 0, 32, 32, 0, 0 - (frame % 2) * scale / 2, 32 * scale, 32 * scale); // default head (if required)
                c_.drawImage(imgs.heads, direction * 32, 32 * hat.offset, 32, 32, 0, 0 - (frame % 2) * scale / 2, 32 * scale, 32 * scale); // head / hat
                c_.drawImage(imgs.weaponsPlus, direction * 32, 0, 32, 32, Math.sin(frame * (Math.PI / 2)) * scale / 2, -(frame % 2) * scale / 1.8, 32 * scale, 32 * scale); // weapons pluz

                div2.innerHTML = "Unlocked skin \"<span class='green'>" + hat.name + "</span>\"";
            }

            else if (hat.isAbility) {
                var img = imgCoords[hat.icon];
                var scale = 150 / Math.max(img.w, img.h);
                c_.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, 128 - img.w * scale / 2, 118 - img.h * scale / 2, img.w * scale, img.h * scale); // shadow

                div2.innerHTML = "Unlocked ability \"<span class='green'>" + hat.name + "</span>\"";
            }

            div2.className = "fontSize20px";
            document.getElementById("unlockDivInner").appendChild(div2);

            div.style.animationName = "fadeIn";
            div.style.animationDuration = "0.65s";
            div.style.animationFillMode = "forwards";

            soundManager.playSound(SOUND.UNLOCK);
        }

        unlocks2Show.splice(0, 1);
    }
};

UIManager.prototype.lvlUp = function(arr)
{
	playerData.gold = arr[3] | 0;
	playerData.gems = arr[5] | 0;
	
	var level = arr[1];
	var rewards = [];
	
	if(arr[7])
		rewards.push({
			id: arr[6],
			type: 'chest',
			value: arr[7],
		});
	
	if(arr[2])
		rewards.push({
			type: 'gold',
			value : arr[2],
		});
	
	if(arr[4])
		rewards.push({
			type: 'gem',
			value : arr[4],
		});
	
	for(var i = 0; i < MAP_TYPE_SETTINGS.length; i ++)
	{
		var mapType = MAP_TYPE_SETTINGS[i];
		if(mapType.unlockLevel == level && !mapType.inactive)
			rewards.push({
				type: 'mode',
				value : i,
			});
	}
	
	if(arr[8] && arr[8].length)
		for(var skin of arr[8].split(";"))
			rewards.push({
				type: "hat",
				value : skin,
			});

	F$('resourceBar').refresh();

	F$('levelUp').show({
		level,
		rewards,
	});
};

UIManager.prototype.unlock = function(data)
{
    var hat = hats[data[1]];
    playerData.skinsUnlocked += ";" + hat.id;

    unlocks2Show.push({
        type: "unlock",
        item: hat
    });

    showAchivement();

    if(data[2])
    {
        playerData.gold = parseInt(data[2]);
        F$('resourceBar').refresh();
    }
};

window.UIManager = UIManager;