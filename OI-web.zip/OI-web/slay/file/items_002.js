(function(){
var skins = new F$ArrayView({
	sort: function(hat1, hat2) {
		if (player.skins_unlocked[hat1.id] && !player.skins_unlocked[hat2.id]) {
			return -1;
		}
		if (!player.skins_unlocked[hat1.id] && player.skins_unlocked[hat2.id]) {
			return 1;
		}
		return hat1.id - hat2.id;
	}
});

var colorList = new F$ArrayView({});

FunUI.traits.items = {
	__init__: function () {
	},
	show: function() {
		this.open();
		skins.source = hats;

		var list = [];
		var code;

		for(var isOwn of [true, false])
		{
			for(var i in NAME_COLOR)
			{
				if(i < 200)
					continue;
				
				if(isOwn !== (playerData.name_color.indexOf(i) >= 0))
					continue;

				var row = NAME_COLOR[i];
				row.id = i;
				row.isOwn = isOwn;
				list.push(row);
				if(row.isOwn)
					code = row.code;
			}
			
			if(isOwn)
				list.push({
					id: 0,
					name: 'auto-pick',
					isOwn: true,
					code: code,
				});
		}

		for(var row of list)
			if(row.id == playerData.name_color_select)
				row.selected = true;
		
		colorList.source = list;
	},
	refresh: function() {
		skins.invalidate();
	}
};

FunUI.traits.name_colorList = {
	dataProvider: colorList,
};

FunUI.traits.name_colorList.itemRenderer = {
	__init__: function()
	{
		this.on('click', this.select);
	},
	select: function()
	{
		if(!this.data.isOwn)
			return;
		
		this.selected = true;
		var id = this.data.id;
		if(playerData.name_color_select != id)
		{
			playerData.name_color_select = id;
			network.send('chooseNameColor$' + id);
		}
	},
	render: function(color, index)
	{
		this.data = color;
		var p = this.querySelector('p');
		if(!color.isOwn)
			this.style.opacity = 0.2;
		
		p.innerText = color.name;
		p.style.color = color.code;
		if(color.id == playerData.name_color_select) 
			this.delayCall(this.list.selectItem, this.list, index);
	},
};

FunUI.traits.items_skinList = {
	dataProvider: skins
};

FunUI.traits.items_skinList.itemRenderer = {
	_qualityLabel: null,
	_levelLabel: null,
	_levelProgressBar: null,
	_amountLabel: null,
	_titleLabel: null,
	_upgradeButton: null,
	_canvas: null,
	__init__ : function() {
		this._titleLabel = this.querySelector('h4');
		this._qualityLabel = this.querySelector('.info .qualityLabel');
		this._levelLabel = this.querySelector('.info .levelLabel');
		this._levelProgressBar = this.querySelector('.info .F-ProgressBar');
		this._amountLabel = this.querySelector('.info .amountLabel');
		this._upgradeButton = this.querySelector('.info .labelButtonUpgrade');
		this._canvas = this.querySelector('canvas').getContext('2d');
		this._canvas.mozImageSmoothingEnabled = false;
		this._canvas.msImageSmoothingEnabled = false;
		this._canvas.imageSmoothingEnabled = false;
		this.on('click', this.select);
		this.on(FunUI.events.SELECTED_CHANGED, this.setHat);
		this._upgradeButton.on('click', this.upgradeHat);
	},
	setHat : function() {
		if(this.selected && playerData.skin.id != this.data.id)
			setHat(this.data.id);
	},
	upgradeHat : function () {
		var data = player.skins_unlocked[this.data.id];
		var cfg = hats[data.id];
		var skinName = this.data.name;
		var goldCost = cfg.extra[data.level].upgradeGoldCost;
		if (goldCost > 0) {
			if (playerData.gold >= goldCost) {
				F$confirm(F_('items.upgrade.confirm', {
					gold: '<span style="color: #2ECC40">' + goldCost + '</span>',
					skinName: skinName
				}), function () {
					network.send("upgradeNewItem$" + data.id);
				});
			} else {
				F$alert(F_('items.upgrade.notEnoughGold', {
					gold: '<span style="color: #2ECC40">' + goldCost + '</span>'
				}));
			}
		} else {
			network.send("upgradeNewItem$" + data.id);
		}
	},
	render: function(hat, index) {
		var data = player.skins_unlocked[hat.id];

		if (data) {
			this.style.pointerEvents = "auto";
			this.style.opacity = 1;
		} else {
			data = {count: 0, level: 1};
			this.style.pointerEvents = "none";
			this.style.opacity = .2;
		};

		this._titleLabel.innerHTML = hat.name;
		this.className = this.className.replace(/quality_[^\s]+/g, "");
		this.addClass("quality_" + hat.quality);
		this._qualityLabel.innerHTML = F_("items.quality." + hat.quality);
		this._levelLabel.innerHTML = F_('items.level', data);

		var skinCost = hat.extra[data.level].upgradeSkinCost;
		if (skinCost > 0) {
			if (data.count < skinCost) {
				this._levelProgressBar.setProgresses(skinCost, data.count);
				this._amountLabel.innerHTML = data.count + "/" + skinCost + ' ' + F_('items.unit');
				this._levelProgressBar.style.display = "";
				this._amountLabel.style.display = "";
				this._upgradeButton.style.display = 'none';
			} else {
				this._levelProgressBar.style.display = "none";
				this._amountLabel.style.display = "none";
				this._upgradeButton.style.display = '';
			}
		} else {
			this._levelProgressBar.style.display = "none";
			this._amountLabel.style.display = "none";
			this._upgradeButton.style.display = 'none';
		}

		drawHat(this._canvas, hat, 3.5, 2, 100, 100);
		if(hat == playerData.skin)
			this.delayCall(this.list.selectItem, this.list, index);

		this.tooltipData = data;
	}
};
})();