// canvas
var canvas = document.getElementById('canvas');

// canvas2
window.canvasGIF = document.createElement('canvas');

window.c = canvas.getContext("2d");

window.WIDTH = window.innerWidth;
window.HEIGHT = window.innerHeight;
window.FIELD_SIZE = 1;
window.FIELD_SIZE_BASE = 1;
window.SCALE_FACTOR = 1;
window.SCALE_FACTOR_BASE = 1;
window.SHOT_HEIGHT = 0.39;
window.SCALE_CONST = 0.06;
window.SCALE_CONST_BASE = SCALE_CONST;


window.SERVER_ADDRESSES = (window.location && window.location.href && window.location.href.indexOf("slay.dd") >= 0) ? [
	
	{
		name: "local",
		adress: "ws://localhost:62202",
		flagImg: "imgs/flags/eu.png",
	}
	
] : [
	
	{
		name: "EU-beta",
		adress: "ws://vps721965.ovh.net:62202",
		flagImg: "imgs/flags/eu.png",
	}
	
];

window.GAME = Object.freeze({
	LOGIN: 0,
	REGISTER: 1,
	PLAYING: 3,
	LOBBY: 6,
	RECOVERY: 8,
	ACCEPT_AGB: 9
});

window.GAME_VERSION = 0.1;

// Global Variables
window.timestamp = Date.now();
window.timeDiff = 0;
window.show_fps = false;
window.timestampArchives = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
window.fps = 0;
window.newTime = 0;
window.lastFramesTick = 0;
window.lastFramesExactTick = 0;
window.tickDiff = 0;
window.exactTickDiff = 0;
window.tickTimes = [0, 0, 0, 0, 0];
window.sentActivationCode = false;
window.ressourcesToLoad = 1;
window.isMobile = false;
window.lastUpdate = 0;
window.lastPlayerListPage = 0;
window.backButtonContentStr = "";
window.currentSelectedMapID = -1;
window.unlocks2Show = [];
window.zombieSkins = [17];
window.replayFile = [];
window.playingReplay = [];
window.playingReplayVersion = 0;
window.pl_active_abilities = [];
window.serverTimeDiff = 0;
window.pl_daily_quests_refesh_timeout_id = null;
window.filterMapType = null;
window.selectedMapId = null;
window.currentMaps = null;
window.currentMapNodes = null;
window.roomListViewModel = null;
window.currentClan = null;
window.searchingLadder = false;

var clanApps = [];
var clanMembers = [];
var playerData = null;

function initPlayerObj()
{
	playerData = {
		name: "",
		authLevel: AUTH_LEVEL.GUEST,
		lvl: 1,
		xp: 0,
		gold: 0,
		clan_tag: "",
		skinsUnlocked: "",
		clanTag: "",
		clanRole: AUTH_LEVEL.NONE,
		skin: hats[0],
		chests: "",
		dailyQeusts: null
	};
};
initPlayerObj();

window.leavingGame = false;
window.joinGamePurpose = null;
window.preStore = {
	newPlayers: [],
	newZombies: [],
	pid: null
};

window.top3Colors = [
	"#f6f432",
	"#EAD497",
	"#EAD497"
];

window.top3ColorsRank = [
	"#F6F432",
	"#D0CBBF",
	"#D0CBBF"
];

window.imgCoords = {

	fire1: {x: 0, y: 4, w: 3, h: 3},
	fire2: {x: 4, y: 3, w: 4, h: 4},
	fire3: {x: 9, y: 2, w: 5, h: 5},
	fire4: {x: 15, y: 1, w: 7, h: 7},
	fire5: {x: 23, y: 0, w: 9, h: 9},

	fire1red: {x: 444, y: 95, w: 3, h: 3},
	fire2red: {x: 448, y: 94, w: 4, h: 4},
	fire3red: {x: 453, y: 93, w: 5, h: 5},
	fire4red: {x: 459, y: 921, w: 7, h: 7},
	fire5red: {x: 467, y: 91, w: 9, h: 9},

	fireGreen1: {x: 302, y: 428, w: 3, h: 3},
	fireGreen2: {x: 306, y: 427, w: 4, h: 4},
	fireGreen3: {x: 311, y: 426, w: 5, h: 5},
	fireGreen4: {x: 317, y: 425, w: 7, h: 7},
	fireGreen5: {x: 325, y: 424, w: 9, h: 9},
	
	particle: {x: 0, y: 0, w: 1, h: 1},
	particlePurple: {x: 1, y: 0, w: 1, h: 1},
	particle2: {x: 2, y: 0, w: 1, h: 1},
	particleRed: {x: 3, y: 0, w: 1, h: 1},
	particleWhite: {x: 4, y: 0, w: 1, h: 1},
	particleYellow: {x: 5, y: 0, w: 1, h: 1},
	particleBlue: {x: 6, y: 0, w: 1, h: 1},
	particleGreen: {x: 7, y: 0, w: 1, h: 1},
	particleOrange: {x: 8, y: 0, w: 1, h: 1},
	
	soot: {x: 31, y: 173, w: 59, h: 59},
	whiteCircle: {x: 266, y: 22, w: 34, h: 30},
	greenCircle: {x: 1, y: 272, w: 53, h: 45},
	laserHit: {x: 264, y: 0, w: 10, h: 10},
	pillar_of_light: {x: 299, y: 56, w: 1, h: 16},
	pillar_of_light_blue: {x: 300, y: 56, w: 1, h: 16},
	pillar_of_light_yellow: {x: 301, y: 56, w: 1, h: 16},
	heal: {x: 11, y: 34, w: 3, h: 3},
	healRed: {x: 24, y: 52, w: 3, h: 3},

	dust1: {x: 32, y: 0, w: 7, h: 7},
	dust2: {x: 32, y: 7, w: 7, h: 7},

	dust1red: {x: 477, y: 86, w: 7, h: 7},
	dust2red: {x: 477, y: 93, w: 7, h: 7},

	light_yellow: {x: 108, y: 0, w: 20, h: 20},
	light_purple: {x: 130, y: 0, w: 19, h: 19},
	light_white: {x: 149, y: 0, w: 19, h: 19},
	light_red: {x: 167, y: 0, w: 19, h: 19},
	light_blue: {x: 186, y: 0, w: 19, h: 19},
	light_green: {x: 205, y: 0, w: 19, h: 19},
	light_light_yellow: {x: 110, y: 52, w: 18, h: 18},

	weapon_laser: {x: 339, y: 0, w: 29, h: 18},
	weapon_gl: {x: 312, y: 18, w: 26, h: 15},
	weapon_flame: {x: 306, y: 36, w: 30, h: 18},
	weapon_mg: {x: 310, y: 0, w: 28, h: 14},
	weapon_rl: {x: 309, y: 57, w: 26, h: 17},
	weapon_homing: {x: 342, y: 55, w: 26, h: 17},
	weapon_homing_2: {x: 324, y: 77, w: 26, h: 17},
	weapon_laser_r: {x: 340, y: 20, w: 29, h: 18},
	weapon_sniper: {x: 324, y: 98, w: 36, h: 13},
	weapon_shotgun: {x: 344, y: 40, w: 29, h: 12},
	weapon_rapid_rl: {x: 375, y: 40, w: 27, h: 15},
	weapon_rapid_gl: {x: 370, y: 58, w: 30, h: 20},
	weapon_asmd: {x: 397, y: 139, w: 40, h: 14},
	weapon_heal: {x: 400, y: 121, w: 32, h: 15},

	waypoint: {x: 19, y: 27, w: 19, h: 14},
	spawningPoint: {x: 60, y: 20, w: 18, h: 21},
	spawningPointRed: {x: 81, y: 20, w: 18, h: 21},
	spawningPointBlue: {x: 39, y: 20, w: 18, h: 21},

	redFlag: {x: 178, y: 29, w: 13, h: 23},
	blueFlag: {x: 192, y: 29, w: 13, h: 23},

	wpn_ui: {x: 85, y: 117, w: 215, h: 25},
	button: {x: 280, y: 0, w: 20, h: 19},
	buttonBlue: {x: 135, y: 29, w: 20, h: 19},
	buttonWhite: {x: 156, y: 29, w: 20, h: 19},
	minimap_ui: {x: 236, y: 381, w: 64, h: 64},

	bullet1: {x: 274, y: 0, w: 2, h: 1},
	bullet2: {x: 274, y: 1, w: 2, h: 2},
	bullet3: {x: 275, y: 3, w: 1, h: 2},
	bullet4: {x: 274, y: 5, w: 2, h: 2},

	ammoMG: {x: 249, y: 0, w: 14, h: 11},
	ammoFlame: {x: 237, y: 0, w: 11, h: 12},
	ammoGL: {x: 248, y: 13, w: 15, h: 17},
	ammoNapalm: {x: 265, y: 76, w: 15, h: 17},
	ammoRL: {x: 248, y: 33, w: 15, h: 17},
	ammoHoming: {x: 265, y: 96, w: 15, h: 17},
	ammoLaser: {x: 247, y: 56, w: 17, h: 14},
	ammoShotgun: {x: 242, y: 86, w: 17, h: 19},
	ammoSniper: {x: 283, y: 98, w: 14, h: 12},

	ammoLaserSmall: {x: 0, y: 322, w: 9, h: 11},
	ammoGrenadeSmall: {x: 0, y: 334, w: 9, h: 9},
	ammoFlameSmall: {x: 0, y: 344, w: 9, h: 11},
	ammoMGSmall: {x: 0, y: 356, w: 7, h: 7},
	ammoRocketSmall: {x: 0, y: 365, w: 9, h: 9},
	ammoRocket2Small: {x: 0, y: 387, w: 9, h: 9},
	ammoRocket3Small: {x: 0, y: 397, w: 9, h: 9},
	ammoLaser2Small: {x: 0, y: 375, w: 9, h: 11},
	ammoShotgunSmall: {x: 0, y: 419, w: 11, h: 11},
	ammoSniperSmall: {x: 0, y: 407, w: 7, h: 10},
	ammoHealSmall: {x: 0, y: 431, w: 9, h: 11},
	ammoASMDSmall: {x: 0, y: 443, w: 9, h: 11},

	muzzleFlashMG: {x: 151, y: 679, w: 416, h: 156},
	muzzleFlashLaserBlue: {x: 151, y: 856, w: 416, h: 156},
	muzzleFlashLaserGreen: {x: 151, y: 1064, w: 416, h: 156},
	muzzleFlashMGTurret: {x: 158, y: 1314, w: 44, h: 44},

	medikit: {x: 390, y: 95, w: 20, h: 17},
	armor: {x: 364, y: 93, w: 24, h: 18},
	itemShine: {x: 377, y: 0, w: 16, h: 36},
	itemShineFloor: {x: 393, y: 0, w: 16, h: 36},

	fog: {x: 144, y: 344, w: 256, h: 256},
	filter: {x: 100, y: 144, w: 200, h: 200},

	armorBar: {x: 27, y: 57, w: 26, h: 4},
	armorBarRed: {x: 109, y: 718, w: 26, h: 4},
	armorBarBlue: {x: 109, y: 713, w: 26, h: 4},
	hpBar1: {x: 27, y: 62, w: 26, h: 4},
	hpBar2: {x: 27, y: 67, w: 26, h: 4},
	hpBar3: {x: 27, y: 72, w: 26, h: 4},
	hpBar4: {x: 18, y: 390, w: 108, h: 100},
	barBlue: {x: 54, y: 62, w: 26, h: 4},
	barGrey: {x: 54, y: 67, w: 26, h: 4},
	barPurp: {x: 54, y: 72, w: 26, h: 4},
	barBlue2: {x: 73, y: 305, w: 26, h: 4},
	barYellow: {x: 73, y: 310, w: 26, h: 4},

	aimLock: {x: 27, y: 77, w: 17, h: 21},
	aimLockGreen: {x: 11, y: 322, w: 17, h: 21},
	ok: {x: 45, y: 77, w: 10, h: 10},
	blackLine: {x: 25, y: 57, w: 1, h: 5},
	whiteLine: {x: 24, y: 57, w: 1, h: 5},

	healWard: {x: 196, y: 60, w: 20, h: 31},
	healWard2: {x: 300, y: 79, w: 20, h: 31},
	block: {x: 177, y: 62, w: 18, h: 29},
	block2: {x: 17, y: 99, w: 18, h: 29},
	block3: {x: 17, y: 130, w: 18, h: 29},
	blink: {x: 60, y: 118, w: 23, h: 22},
	scan: {x: 53, y: 143, w: 24, h: 24},
	autoTurretBase: {x: 223, y: 37, w: 13, h: 12},
	autoTurretIcon: {x: 224, y: 54, w: 19, h: 16},
	autoTurretGun00: {x: 47, y: 92, w: 24, h: 24},
	autoTurretGun01: {x: 71, y: 92, w: 24, h: 24},
	autoTurretGun02: {x: 95, y: 92, w: 24, h: 24},
	autoTurretGun03: {x: 119, y: 92, w: 24, h: 24},
	autoTurretGun04: {x: 143, y: 92, w: 24, h: 24},
	autoTurretGun05: {x: 167, y: 92, w: 24, h: 24},
	autoTurretGun06: {x: 191, y: 92, w: 24, h: 24},
	autoTurretGun07: {x: 215, y: 92, w: 24, h: 24},
	autoTurretGun10: {x: 47, y: 346, w: 24, h: 24},
	autoTurretGun11: {x: 71, y: 346, w: 24, h: 24},
	autoTurretGun12: {x: 95, y: 346, w: 24, h: 24},
	autoTurretGun13: {x: 119, y: 346, w: 24, h: 24},
	autoTurretGun14: {x: 143, y: 346, w: 24, h: 24},
	autoTurretGun15: {x: 167, y: 346, w: 24, h: 24},
	autoTurretGun16: {x: 191, y: 346, w: 24, h: 24},
	autoTurretGun17: {x: 215, y: 346, w: 24, h: 24},
	missileTurretIcon: {x: 32, y: 500, w: 15, h: 16},
	missileTurretGun0: {x: 47, y: 500, w: 24, h: 24},
	missileTurretGun1: {x: 71, y: 500, w: 24, h: 24},
	missileTurretGun2: {x: 95, y: 500, w: 24, h: 24},
	missileTurretGun3: {x: 119, y: 500, w: 24, h: 24},
	missileTurretGun4: {x: 143, y: 500, w: 24, h: 24},
	missileTurretGun5: {x: 167, y: 500, w: 24, h: 24},
	missileTurretGun6: {x: 191, y: 500, w: 24, h: 24},
	missileTurretGun7: {x: 215, y: 500, w: 24, h: 24},
	grenadeTurretIcon: {x: 33, y: 525, w: 13, h: 17},
	grenadeTurretGun0: {x: 47, y: 525, w: 24, h: 24},
	grenadeTurretGun1: {x: 71, y: 525, w: 24, h: 24},
	grenadeTurretGun2: {x: 95, y: 525, w: 24, h: 24},
	grenadeTurretGun3: {x: 119, y: 525, w: 24, h: 24},
	grenadeTurretGun4: {x: 143, y: 525, w: 24, h: 24},
	grenadeTurretGun5: {x: 167, y: 525, w: 24, h: 24},
	grenadeTurretGun6: {x: 191, y: 525, w: 24, h: 24},
	grenadeTurretGun7: {x: 215, y: 525, w: 24, h: 24},
	laserTurretIcon: {x: 351, y: 501, w: 18, h: 16},
	laserTurretGun0: {x: 347, y: 525, w: 24, h: 24},
	laserTurretGun1: {x: 371, y: 525, w: 24, h: 24},
	laserTurretGun2: {x: 395, y: 525, w: 24, h: 24},
	laserTurretGun3: {x: 419, y: 525, w: 24, h: 24},
	laserTurretGun4: {x: 443, y: 525, w: 24, h: 24},
	laserTurretGun5: {x: 467, y: 525, w: 24, h: 24},
	laserTurretGun6: {x: 491, y: 525, w: 24, h: 24},
	laserTurretGun7: {x: 515, y: 525, w: 24, h: 24},
	mine1: {x: 146, y: 75, w: 13, h: 11},
	mine2: {x: 160, y: 75, w: 13, h: 11},
	invis: {x: 82, y: 144, w: 17, h: 28},

	strength: {x: 0, y: 167, w: 21, h: 21},
	agility: {x: 0, y: 188, w: 19, h: 22},
	intelligence: {x: 0, y: 211, w: 21, h: 23},
	regeneration: {x: 4, y: 11, w: 19, h: 19},
	lifesteal: {x: 69, y: 275, w: 28, h: 26},

	grenade1: {x: 62, y: 78, w: 7, h: 10},
	grenade2: {x: 71, y: 79, w: 9, h: 9},
	grenade3: {x: 81, y: 81, w: 10, h: 7},
	grenade4: {x: 92, y: 81, w: 9, h: 9},
	grenade5: {x: 103, y: 81, w: 7, h: 10},
	grenade6: {x: 111, y: 81, w: 9, h: 9},
	grenade7: {x: 132, y: 81, w: 11, h: 7},
	grenade8: {x: 133, y: 79, w: 9, h: 9},

	grenadeYellow1: {x: 7, y: 241, w: 7, h: 10},
	grenadeYellow2: {x: 16, y: 242, w: 9, h: 9},
	grenadeYellow3: {x: 26, y: 244, w: 10, h: 7},
	grenadeYellow4: {x: 37, y: 244, w: 9, h: 9},
	grenadeYellow5: {x: 48, y: 244, w: 7, h: 10},
	grenadeYellow6: {x: 58, y: 244, w: 9, h: 9},
	grenadeYellow7: {x: 66, y: 244, w: 11, h: 7},
	grenadeYellow8: {x: 78, y: 242, w: 9, h: 9},

	grenadeBlue1: {x: 7, y: 256, w: 7, h: 10},
	grenadeBlue2: {x: 16, y: 257, w: 9, h: 9},
	grenadeBlue3: {x: 26, y: 259, w: 10, h: 7},
	grenadeBlue4: {x: 37, y: 259, w: 9, h: 9},
	grenadeBlue5: {x: 48, y: 259, w: 7, h: 10},
	grenadeBlue6: {x: 58, y: 259, w: 9, h: 9},
	grenadeBlue7: {x: 66, y: 259, w: 11, h: 7},
	grenadeBlue8: {x: 78, y: 257, w: 9, h: 9},

	bubble1: {x: 281, y: 447, w: 19, h: 19},
	bubble2: {x: 262, y: 447, w: 19, h: 19},
	bubble3: {x: 243, y: 447, w: 19, h: 19},
	bubble4: {x: 224, y: 447, w: 19, h: 19},
	bubbleRed: {x: 205, y: 447, w: 19, h: 19},
	bubbleGreen: {x: 184, y: 471, w: 19, h: 19},
	shield: {x: 205, y: 467, w: 19, h: 19},
	shield2: {x: 224, y: 467, w: 19, h: 19},
	shield3: {x: 243, y: 467, w: 19, h: 19},
	shieldIcon: {x: 178, y: 445, w: 26, h: 26},
	refShield: {x: 26, y: 1292, w: 19, h: 19},
	refShield2: {x: 45, y: 1292, w: 19, h: 19},
	refShield3: {x: 64, y: 1292, w: 19, h: 19},
	refShieldIcon: {x: 0, y: 1270, w: 26, h: 26},

	arrowLeft: {x: 185, y: 395, w: 16, h: 16},
	arrowRight: {x: 219, y: 395, w: 16, h: 16},
	arrowBottom: {x: 202, y: 395, w: 16, h: 16},
	arrowTop: {x: 202, y: 378, w: 16, h: 16},

	arrowLeftActive: {x: 185, y: 429, w: 16, h: 16},
	arrowRightActive: {x: 219, y: 429, w: 16, h: 16},
	arrowBottomActive: {x: 202, y: 429, w: 16, h: 16},
	arrowTopActive: {x: 202, y: 412, w: 16, h: 16},

	upgTop: {x: 0, y: 550, w: 100, h: 46},
	upgLine: {x: 0, y: 597, w: 87, h: 23},
	soulsBar: {x: 102, y: 550, w: 12, h: 12},
	souls: {x: 102, y: 563, w: 10, h: 12},
	star: {x: 431, y: 0, w: 13, h: 11},
	crystals: {x: 102, y: 576, w: 9, h: 9},
	plusButton: {x: 102, y: 587, w: 22, h: 17},
	crownYellow: {x: 102, y: 606, w: 13, h: 10},
	crownGreen: {x: 102, y: 617, w: 13, h: 10},
	crownWhite: {x: 116, y: 617, w: 13, h: 10},
	crownRed: {x: 130, y: 617, w: 13, h: 10},
	crosshairGreen: {x: 239, y: 636, w: 9, h: 9},
	crosshairWhite: {x: 248, y: 636, w: 9, h: 9},
	crosshairRed: {x: 257, y: 636, w: 9, h: 9},

	abilityFrame: {x: 129, y: 550, w: 34, h: 42},
	abilityFrameGreen: {x: 302, y: 550, w: 34, h: 42},
	weaponFrame: {x: 164, y: 550, w: 68, h: 42},
	weaponFrameGreen: {x: 233, y: 550, w: 68, h: 42},
	weaponFrame2: {x: 164, y: 593, w: 68, h: 39},
	weaponFrame2Green: {x: 233, y: 593, w: 68, h: 39},
	weaponFrameCurrent: {x: 161, y: 633, w: 74, h: 45},

	hpFrame: {x: 0, y: 621, w: 55, h: 15},
	hpFrame2: {x: 0, y: 637, w: 55, h: 10},
	energyBar: {x: 56, y: 621, w: 2, h: 2},

	laserBlue: {x: 319, y: 114, w: 17, h: 288},
	laserGreen: {x: 337, y: 114, w: 17, h: 288},
	laserRed: {x: 681, y: 523, w: 17, h: 288},
	projectile: {x: 301, y: 114, w: 17, h: 288},
	rocket: {x: 356, y: 115, w: 10, h: 80},
	homingRocket: {x: 368, y: 115, w: 10, h: 80},
	homingRocket2: {x: 380, y: 115, w: 10, h: 80},
	grenade: {x: 356, y: 197, w: 30, h: 80},

	shieldHit1: {x: 269, y: 475, w: 26, h: 18},
	shieldHit2: {x: 295, y: 475, w: 26, h: 18},
	shieldHit3: {x: 321, y: 475, w: 26, h: 18},
	shieldHit4: {x: 347, y: 475, w: 26, h: 18},
	shieldHit5: {x: 373, y: 475, w: 26, h: 18},
	shieldHit6: {x: 399, y: 475, w: 26, h: 18},

	newUpgFrame: {x: 0, y: 648, w: 147, h: 28},
	newStatsFrame: {x: 0, y: 677, w: 147, h: 35},
	newUpgFrameYellow: {x: 0, y: 742, w: 147, h: 28},
	newUps1: {x: 0, y: 771, w: 146, h: 30},
	newUps2: {x: 0, y: 802, w: 146, h: 30},
	newUps3: {x: 0, y: 833, w: 146, h: 30},
	cureButton: {x: 0, y: 1508, w: 110, h: 32},

	newUpsFrame1: {x: 0, y: 864, w: 150, h: 70},
	newUpsFrame2: {x: 0, y: 935, w: 150, h: 70},
	newUpsFrame3: {x: 0, y: 1006, w: 150, h: 70},
	newUpsFrame4: {x: 0, y: 1077, w: 150, h: 70},
	upgSkip: {x: 57, y: 632, w: 87, h: 16},
	upgUnskip: {x: 0, y: 713, w: 87, h: 16},

	passiveStateBoxLeft: {x: 0, y: 1147, w: 5, h: 16},
	passiveStateBoxMid: {x: 5, y: 1147, w: 1, h: 16},
	passiveStateBoxRight: {x: 31, y: 1147, w: 5, h: 16},
	abilityHover: {x: 39, y: 1147, w: 97, h: 61},
	weaponBottom: {x: 0, y: 1210, w: 68, h: 18},

	rangedZombieImpact: {x: 528, y: 48, w: 96, h: 24, frameW: 24},
	splash: {x: 246, y: 527, w: 95, h: 19, frameW: 19},
	splashSingle: {x: 268, y: 530, w: 14, h: 11},
	itemSpawn: {x: 249, y: 500, w: 96, h: 16},
	flame1: {x: 0, y: 1396, w: 144, h: 32, frameW: 24},
	flame2: {x: 0, y: 1438, w: 456, h: 40, frameW: 24},

	poisonFog1: {x: 490, y: 361, w: 59, h: 58},
	poisonFog2: {x: 550, y: 360, w: 59, h: 58},

	filler0: {x: 537, y: 0, w: 12, h: 12},
	filler1: {x: 549, y: 0, w: 12, h: 12},
	filler2: {x: 561, y: 0, w: 12, h: 12},
	filler3: {x: 573, y: 0, w: 12, h: 12},
	filler4: {x: 585, y: 0, w: 12, h: 12},
	filler5: {x: 597, y: 0, w: 12, h: 12},
	filler6: {x: 609, y: 0, w: 12, h: 12},
	filler7: {x: 621, y: 0, w: 12, h: 12},
	filler8: {x: 633, y: 0, w: 12, h: 12},

	zombie_weapon: {x: 405, y: 41, w: 24, h: 23},
	blank: {x: 0, y: 1, w: 1, h: 1},
	replayBar: {x: 417, y: 22, w: 87, h: 17},
	replayPos: {x: 505, y: 22, w: 4, h: 17},
	startGif: {x: 510, y: 22, w: 48, h: 17},
	stopGif: {x: 559, y: 22, w: 48, h: 17},
	whiteGif: {x: 608, y: 22, w: 48, h: 17},
	main_logo: {x: 433, y: 45, w: 82, h: 30},
	replayPlusMinus: {x: 657, y: 22, w: 9, h: 17},
	replayWhite: {x: 667, y: 22, w: 9, h: 8},

	playDead: {x: 159, y: 480, w: 21, h: 11},
	eatFromCorpse: {x: 159, y: 462, w: 16, h: 15},
	summonZombie: {x: 153, y: 442, w: 22, h: 15},
	summonZombie2: {x: 155, y: 420, w: 22, h: 17},
	summonZombie3: {x: 156, y: 401, w: 22, h: 15},

	zombieSpawn1: {x: 342, y: 559, w: 256, h: 32},
	zombieSpawn2: {x: 342, y: 599, w: 256, h: 32},
	zombieSpawn3: {x: 438, y: 480, w: 256, h: 32},
	zombieSpawn4: {x: 438, y: 444, w: 256, h: 32},
	zombieSenseCircle: {x: 358, y: 360, w: 26, h: 19},
	zombieSenseIcon: {x: 162, y: 384, w: 19, h: 15},

	speech: {x: 0, y: 1230, w: 87, h: 35},
	nextPlayers: {x: 0, y: 1488, w: 56, h: 7},
	crawler: {x: 268, y: 634, w: 18, h: 19},

	emotesBlink: {x: 548, y: 1246, w: 14, h: 15},
	emotesCry: {x: 572, y: 1246, w: 14, h: 15},
	emotesDevil: {x: 596, y: 1246, w: 14, h: 15},
	emotesHeart: {x: 620, y: 1246, w: 14, h: 15},
	emotesDislike: {x: 644, y: 1245, w: 16, h: 16},
	emotesSmile: {x: 537, y: 1268, w: 14, h: 15},
	emotesGrin: {x: 561, y: 1268, w: 14, h: 15},
	emotesO: {x: 585, y: 1268, w: 14, h: 15},
	emotesLike: {x: 609, y: 1268, w: 15, h: 15},
	emotesSmirk: {x: 633, y: 1268, w: 14, h: 15},
	emotesPokerface: {x: 657, y: 1268, w: 14, h: 15},
	emotesHold: {x: 539, y: 1286, w: 10, h: 14},
	emotesGo: {x: 561, y: 1290, w: 14, h: 10},
	emotesFire: {x: 584, y: 1288, w: 16, h: 12},
	emotesBack: {x: 609, y: 1289, w: 15, h: 11},
	emotesOK: {x: 635, y: 1285, w: 10, h: 15},
	emotesFist: {x: 658, y: 1288, w: 11, h: 12},
	emotesFlagWhite: {x: 569, y: 1317, w: 12, h: 13},
	emotesFlagRed: {x: 598, y: 1317, w: 12, h: 13},
	emotesSniper: {x: 624, y: 1315, w: 15, h: 15},
	emotesInfected: {x: 655, y: 1317, w: 12, h: 15},
	emotesPunch: {x: 543, y: 1350, w: 14, h: 12},
	emotesPeace: {x: 568, y: 1348, w: 11, h: 14},
	emotesCool: {x: 600, y: 1349, w: 14, h: 15},
	emotesTroll: {x: 628, y: 1348, w: 14, h: 15},
	emotesElvis: {x: 655, y: 1345, w: 15, h: 18},
	emotesFacepalm: {x: 541, y: 1372, w: 16, h: 20},
	emotesHype: {x: 569, y: 1371, w: 22, h: 20},
	emotesGG: {x: 604, y: 1370, w: 14, h: 21},
	emotesBubble: {x: 623, y: 1370, w: 19, h: 20},

	tutorialMouse: {x: 542, y: 1397, w: 16, h: 32},
	tutorialQ: {x: 561, y: 1397, w: 15, h: 14},
	tutorialMouseLeft: {x: 580, y: 1397, w: 16, h: 32},
	tutorialWASD: {x: 597, y: 1397, w: 43, h: 27},
	tutorialDMouseRight: {x: 642, y: 1396, w: 36, h: 32},

	fireballBig: {x: 395, y: 339, w: 18, h: 14},
	fireballMedium: {x: 416, y: 339, w: 9, h: 11},
	fireballSmall: {x: 427, y: 342, w: 5, h: 5}

};

// local storage
window.sound_volume = localStorage.getItem("sound_volume") === null ? 0.8 : localStorage.getItem("sound_volume");
window.minimapSizeFactor = localStorage.getItem("minimapSizeFactor") === null ? 1.13 : localStorage.getItem("minimapSizeFactor");
window.graphicSettings = localStorage.getItem("graphicSettings") === null ? 10 : (localStorage.getItem("graphicSettings")|0);

var storeWeaponsUnclickable = localStorage.getItem('weaponsUnclickable');
if (storeWeaponsUnclickable == 'true') {
	storeWeaponsUnclickable = 1;
}
window.weaponsUnclickable = (storeWeaponsUnclickable|0);

window.forcePlayerNameColor = (localStorage.getItem('forcePlayerNameColor')|0);

window.defaultGameMode = localStorage.getItem("defaultGameMode");
window.hideChat = localStorage.getItem("hideChat") == "true";
document.getElementById("chatDisplayDiv").style.display = hideChat ? "none" : "block";
window.ignoreList = localStorage.getItem("ignoreList") ? localStorage.getItem("ignoreList").split(";") : [];
window.ignoreListTemp = [];
if (!MAP_TYPE_SETTINGS[defaultGameMode]) {
    window.defaultGameMode = MAP_TYPE.TOURNAMENT_UNRANKED;
}

// graphic settings

window.graphics = [];

// low graphics
graphics[0] = {
	exposionParticles: 10,
	torchEmitTime: 11,
	spawnBullets: false,
	additionalFTFire: false
};

// high graphics
graphics[10] = {
	exposionParticles: 30,
	torchEmitTime: 5,
	spawnBullets: true,
	additionalFTFire: true
};

window.replayOptions = [

	{
		tickTime: 200,
		loops: 0,
		display: 0
	},

	{
		tickTime: 200,
		loops: 1,
		display: 0.25
	},

	{
		tickTime: 100,
		loops: 1,
		display: 0.5
	},

	{
		tickTime: 50,
		loops: 1,
		display: 1
	},

	{
		tickTime: 25,
		loops: 1,
		display: 2
	},

	{
		tickTime: 12,
		loops: 1,
		display: 4
	},

	{
		tickTime: 6,
		loops: 1,
		display: 8
	},

	{
		tickTime: 6,
		loops: 2,
		display: 16
	},

	{
		tickTime: 6,
		loops: 4,
		display: 32
	},

	{
		tickTime: 6,
		loops: 8,
		display: 64
	},

	{
		tickTime: 6,
		loops: 32,
		display: 128
	}

];

window.replayOptionsIndex = 3;
window.oldReplayOptionsIndex = 3;
window.replayOption = window.replayOptions[window.replayOptionsIndex];
window.lastReplaySpeedChange = -9999;

window.authLevelNames = window.authLevelNames = [];
authLevelNames[AUTH_LEVEL.NONE] = "Member";
authLevelNames[AUTH_LEVEL.GUEST] = "";
authLevelNames[AUTH_LEVEL.PLAYER] = "";
authLevelNames[AUTH_LEVEL.MOD] = "Moderator";
authLevelNames[AUTH_LEVEL.ADMIN] = "Admin";

//TO DO - consider moving these to "Player.js", since that's the only place that it's referenced
window.teamColors = [
	"rgba(255, 255, 255, 0)",
	"rgba(255, 107, 107, 0.25)",
	"rgba(153, 153, 255, 0.35)"
];

window.teamColors2 = [
	"rgba(255, 255, 255, 0.2)",
	"rgba(255, 107, 107, 0.85)",
	"rgba(153, 153, 255, 0.9)"
];

window.animationData = {

	autoturret: {
		imgTurret00: imgCoords.autoTurretGun00,
		imgTurret01: imgCoords.autoTurretGun01,
		imgTurret02: imgCoords.autoTurretGun02,
		imgTurret03: imgCoords.autoTurretGun03,
		imgTurret04: imgCoords.autoTurretGun04,
		imgTurret05: imgCoords.autoTurretGun05,
		imgTurret06: imgCoords.autoTurretGun06,
		imgTurret07: imgCoords.autoTurretGun07,
		imgTurret10: imgCoords.autoTurretGun10,
		imgTurret11: imgCoords.autoTurretGun11,
		imgTurret12: imgCoords.autoTurretGun12,
		imgTurret13: imgCoords.autoTurretGun13,
		imgTurret14: imgCoords.autoTurretGun14,
		imgTurret15: imgCoords.autoTurretGun15,
		imgTurret16: imgCoords.autoTurretGun16,
		imgTurret17: imgCoords.autoTurretGun17,
		countFrames: 2,
		muzzleFlash: imgCoords.muzzleFlashMGTurret
	},

	missileturret: {
		imgTurret00: imgCoords.missileTurretGun0,
		imgTurret01: imgCoords.missileTurretGun1,
		imgTurret02: imgCoords.missileTurretGun2,
		imgTurret03: imgCoords.missileTurretGun3,
		imgTurret04: imgCoords.missileTurretGun4,
		imgTurret05: imgCoords.missileTurretGun5,
		imgTurret06: imgCoords.missileTurretGun6,
		imgTurret07: imgCoords.missileTurretGun7
	},

	grenadeturret: {
		imgTurret00: imgCoords.grenadeTurretGun0,
		imgTurret01: imgCoords.grenadeTurretGun1,
		imgTurret02: imgCoords.grenadeTurretGun2,
		imgTurret03: imgCoords.grenadeTurretGun3,
		imgTurret04: imgCoords.grenadeTurretGun4,
		imgTurret05: imgCoords.grenadeTurretGun5,
		imgTurret06: imgCoords.grenadeTurretGun6,
		imgTurret07: imgCoords.grenadeTurretGun7
	},

	laserturret: {
		imgTurret00: imgCoords.laserTurretGun0,
		imgTurret01: imgCoords.laserTurretGun1,
		imgTurret02: imgCoords.laserTurretGun2,
		imgTurret03: imgCoords.laserTurretGun3,
		imgTurret04: imgCoords.laserTurretGun4,
		imgTurret05: imgCoords.laserTurretGun5,
		imgTurret06: imgCoords.laserTurretGun6,
		imgTurret07: imgCoords.laserTurretGun7
	}
};

window.SOUND = Object.freeze({
	GREANDE_LAUNCH: 1,
	EXPLODE: 2,
	LASER: 3,
	SWITCH_WEAPON: 4,
	KICK: 5,
	SIZZLE: 6,
	FRAG1: 7,
	FRAG2: 8,
	FRAG3: 9,
	FRAG4: 10,
	FRAG5: 11,
	FLAMETHROWER: 12,
	MG: 13,
	GRENADE_BOUNCE: 14,
	PLACE: 15,
	CLICK: 16,
	CARTRIDGE1: 17,
	CARTRIDGE2: 18,
	SIZZLE2: 19,
	GUN_IMPACT: 20,
	GUN_IMPACT_2: 21,
	PUNCH: 22,
	COCK: 23,
	EMPTY_CLIP: 24,
	RELOAD_MG: 25,
	RELOAD_FLAME: 26,
	RELOAD_GL: 27,
	ROCKET_LAUNCH: 29,
	ROCKET_FLY: 30,
	RELOAD_RL: 31,
	REFLECT: 32,
	AMMO_SPAWN: 33,
	PLAYER_SPAWN: 34,
	LASER_RECHARGE: 35,
	HEAL: 36,
	ARMOR: 37,
	ROCKET_BEEP: 38,
	FLAME_BURN: 39,
	FLAME_EXPLODE: 40,
	SNIPER: 41,
	BING: 42,
	SHOTGUN: 43,
	SHOTGUN_RELOAD: 44,
	SHOTGUN_RELOAD_LONG: 45,
	ZOOM: 46,
	ZIP: 47,
	LVLUP: 48,
	UNLOCK: 49,
	HEAL_AURA: 50,
	BLINK: 51,
	TURRET_INIT: 52,
	NEGATIVE: 53,
	INVIS1: 54,
	INVIS2: 55,
	SPELL: 56,
	SWITCH: 57,
	CHAT1: 58,
	DOUBLE_KILL: 59,
	MULTI_KILL: 60,
	ULTRA_KILL: 61,
	MONSTER_KILL: 62,
	KILLING_SPREE: 63,
	RAMPAGE: 64,
	DOMINATING: 65,
	UNSTOPPABLE: 66,
	GODLIKE: 67,
	SMOKE_START: 68,
	SMOKE_LOOP: 69,
	THROW: 70,
	FLASH: 71,
	FLASH_START: 72,
	STEP: 73,
	SCAN: 74,
	WIN: 75,
	LOSE: 76,
	END: 77,
	START: 78,
	TEAMKILL: 79,
	RELOAD_RL_2: 80,
	ZOMBIE_BITE: 81,
	ZOMBIE_DEATH: 82,
	LVL_UP: 83,
	ATT_UP: 84,
	BEEBEEP: 85,
	ZOMBIE_ATT: 86,
	SPLASH: 87,
	SHIELD: 88,
	SHIELD_HIT: 89,
	WOODCRACK: 90,
	MECH_IMPACT: 91,
	CRAWLER_IMPACT: 92,
	OPEN_CHEST: 93,
	UPGRADE_ITEM: 94,
	ZOMBIE_BOSS_HIT: 95,
	ZOMBIE_TRANSFORM: 96,
	HUMAN_TRANSFORM: 97,
	HEAL_WPN: 98,
	ASMD1: 99,
	ASMD2: 100,
	ASMD_RELOAD: 101,
	ASMD_FLY: 102,
	ASMD_BALL_LAUNCH: 103,
	ASMD_EXPLO_1: 104,
	ASMD_EXPLO_2: 105,
	LADDER_WIN: 106,
	LADDER_LOSS: 107,
	LADDER_START: 108,
	TICK: 109,
	LADDER_GONG: 110
});

window.KEY = Object.freeze({
	UP: 38,
	DOWN: 40,
	LEFT: 37,
	RIGHT: 39,
	A: 65,
	B: 66,
	C: 67,
	D: 68,
	E: 69,
	F: 70,
	G: 71,
	H: 72,
	I: 73,
	J: 74,
	K: 75,
	L: 76,
	M: 77,
	N: 78,
	O: 79,
	P: 80,
	Q: 81,
	R: 82,
	S: 83,
	T: 84,
	U: 85,
	V: 86,
	W: 87,
	X: 88,
	Y: 89,
	Z: 90,
	SHIFT: 16,
	CTRL: 17,
	ALT: 18,
	NUM1: 49,
	NUM2: 50,
	NUM3: 51,
	NUM4: 52,
	NUM5: 53,
	NUM6: 54,
	NUM7: 55,
	NUM8: 56,
	NUM9: 57,
	NUM0: 48,
	CIRCUMFLEX: window.chrome ? 220 : 160,
	ENTER: 13,
	BACKSPACE: 8,
	DELETE: 46,
	PAUSE: 19,
	F1: 112,
	F2: 113,
	F3: 114,
	F4: 115,
	F5: 116,
	F6: 117,
	F7: 118,
	F8: 119,
	F9: 120,
	F10: 121,
	ESC: 27,
	TAB: 9,
	PLUS: 107,
	MINUS: 109,
	SPACE: 32,
	CAPSLOCK: 20,
	AE: 192,
	RIGHTMOUSE: 1002
});

var keyNames = window.keyNames = [];

keyNames[9] = "TAB";

keyNames[16] = "SHIFT";
keyNames[17] = "CTRL";
keyNames[18] = "ALT";

keyNames[19] = "PAUSE";
keyNames[20] = "CAPSLOCK";
keyNames[32] = "SPACE";

keyNames[37] = "LEFT";
keyNames[38] = "UP";
keyNames[39] = "RIGHT";
keyNames[40] = "DOWN";

keyNames[46] = "DEL";

keyNames[48] = "0";
keyNames[49] = "1";
keyNames[50] = "2";
keyNames[51] = "3";
keyNames[52] = "4";
keyNames[53] = "5";
keyNames[54] = "6";
keyNames[55] = "7";
keyNames[56] = "8";
keyNames[57] = "9";

keyNames[8] = "BACKSPACE";
keyNames[13] = "ENTER";
keyNames[27] = "ESC";

keyNames[65] = "A";
keyNames[66] = "B";
keyNames[67] = "C";
keyNames[68] = "D";
keyNames[69] = "E";
keyNames[70] = "F";
keyNames[71] = "G";
keyNames[72] = "H";
keyNames[73] = "I";
keyNames[74] = "J";
keyNames[75] = "K";
keyNames[76] = "L";
keyNames[77] = "M";
keyNames[78] = "N";
keyNames[79] = "O";
keyNames[80] = "P";
keyNames[81] = "Q";
keyNames[82] = "R";
keyNames[83] = "S";
keyNames[84] = "T";
keyNames[85] = "U";
keyNames[86] = "V";
keyNames[87] = "W";
keyNames[88] = "X";
keyNames[89] = "Y";
keyNames[90] = "Z";

keyNames[112] = "F1";
keyNames[113] = "F2";
keyNames[114] = "F3";
keyNames[115] = "F4";
keyNames[116] = "F5";
keyNames[117] = "F6";
keyNames[118] = "F7";
keyNames[119] = "F8";
keyNames[120] = "F9";
keyNames[121] = "F10";

keyNames[192] = "`";

keyNames[window.chrome ? 220 : 160] = "^";

keyNames[1002] = "Right Mouse";

window.getKeyName = function(key)
{
	return F_("keys." + key) || keyNames[key] || "";
};

window.COMMAND = Object.freeze({
	UP: 1,
	DOWN: 2,
	LEFT: 3,
	RIGHT: 4,
	RELOAD: 5,
	STAND: 6,
	ABILITY1: 7,
	ABILITY2: 8,
	WPN1: 9,
	WPN2: 10,
	WPN3: 11,
	WPN4: 12,
	WPN5: 13,
	WPN6: 14,
	WPN7: 15,
	WPN8: 16,
	WPN9: 17,
	WPN10: 18,
	WPN11: 19,
	WPN12: 20,
	WPN16: 21,
	JUMP: 100,
	PICK_UPGRADE: 101,
	FIRE_2: 102
});

var commandKeys = window.commandKeys = [];
commandKeys[COMMAND.UP] = KEY.W;
commandKeys[COMMAND.DOWN] = KEY.S;
commandKeys[COMMAND.LEFT] = KEY.A;
commandKeys[COMMAND.RIGHT] = KEY.D;
commandKeys[COMMAND.RELOAD] = KEY.R;
commandKeys[COMMAND.STAND] = KEY.F;
commandKeys[COMMAND.FIRE_2] = KEY.Y;
commandKeys[COMMAND.ABILITY1] = KEY.Q;
commandKeys[COMMAND.ABILITY2] = KEY.E;
commandKeys[COMMAND.JUMP] = KEY.RIGHTMOUSE;
commandKeys[COMMAND.PICK_UPGRADE] = KEY.SPACE;
commandKeys[COMMAND.WPN1] = KEY.NUM1;
commandKeys[COMMAND.WPN2] = KEY.NUM2;
commandKeys[COMMAND.WPN3] = KEY.NUM3;
commandKeys[COMMAND.WPN4] = KEY.NUM4;
commandKeys[COMMAND.WPN5] = KEY.NUM5;
commandKeys[COMMAND.WPN6] = KEY.NUM6;
commandKeys[COMMAND.WPN7] = KEY.NUM7;
commandKeys[COMMAND.WPN8] = KEY.NUM8;
commandKeys[COMMAND.WPN9] = KEY.NUM9;
commandKeys[COMMAND.WPN10] = KEY.NUM0;
commandKeys[COMMAND.WPN11] = KEY.N;
commandKeys[COMMAND.WPN12] = KEY.M;
commandKeys[COMMAND.WPN16] = KEY.H;

var commandNames = window.commandNames = {};
commandNames[COMMAND.UP] = "Move Up";
commandNames[COMMAND.DOWN] = "Move down";
commandNames[COMMAND.LEFT] = "Move left";
commandNames[COMMAND.RIGHT] = "Move right";
commandNames[COMMAND.RELOAD] = "Reload";
commandNames[COMMAND.STAND] = "Stand / aim with sniper";
commandNames[COMMAND.ABILITY1] = "Use ability 1";
commandNames[COMMAND.ABILITY2] = "Use ability 2";
commandNames[COMMAND.JUMP] = "Jump";
commandNames[COMMAND.PICK_UPGRADE] = "Pick upgrade";
commandNames[COMMAND.FIRE_2] = "2nd fire mode";

var commandNameLabels = window.commandNameLabels = [];
commandNameLabels[COMMAND.UP] = "config.keyname.up";
commandNameLabels[COMMAND.DOWN] = "config.keyname.down";
commandNameLabels[COMMAND.LEFT] = "config.keyname.left";
commandNameLabels[COMMAND.RIGHT] = "config.keyname.right";
commandNameLabels[COMMAND.RELOAD] = "config.keyname.reload";
commandNameLabels[COMMAND.STAND] = "config.keyname.stand";
commandNameLabels[COMMAND.ABILITY1] = "config.keyname.ability1";
commandNameLabels[COMMAND.ABILITY2] = "config.keyname.ability2";
commandNameLabels[COMMAND.JUMP] = "config.keyname.jump";
commandNameLabels[COMMAND.PICK_UPGRADE] = "config.keyname.pickupgrade";
commandNameLabels[COMMAND.FIRE_2] = "config.keyname.fire2";

function getCommandName(i) {
    return "Select " + weapons[i].name;
}

for(var weapon of weapons)
{
	if(weapon.noWeapon)
		continue;

	var cmd = COMMAND["WPN" + (weapon.id + 1)];
	Object.defineProperty(commandNames, cmd, {
		enumerable: true,
		get : getCommandName.bind(null, i)
	});
	commandNameLabels[cmd] = {
		'weapon': weapon.id,
	};
}

var lsHotkeyStr = localStorage.getItem("hotkeys");
if(lsHotkeyStr && lsHotkeyStr.length > 0)
{
	var hotkeys = lsHotkeyStr.split("_");
	for(var i = 0; i < hotkeys.length; i++)
	{
		var hotkeysplit = hotkeys[i].split(":");
		if(hotkeysplit[0] && hotkeysplit[1])
			commandKeys[parseInt(hotkeysplit[0])] = parseInt(hotkeysplit[1]);
	}
}

window.keyCodes = [];

window.scf1 = "showEn";
window.scf2 = "emiesOnMinimapUntil";

function refreshKeyCodes()
{
	var keyCodes = window.keyCodes = [];

	keyCodes[KEY.UP] = 1;
	keyCodes[KEY.DOWN] = 2;
	keyCodes[KEY.LEFT] = 3;
	keyCodes[KEY.RIGHT] = 4;

	for(var i = 1; i < commandKeys.length; i++)
		keyCodes[commandKeys[i]] = i;
};
refreshKeyCodes();

/*
window.tutorialMessages = [

	{
		x: 8.5,
		y: 5.5,
		msg: "Use WASD to move around. Now walk to the portal."
	},

	{
		x: 26.5,
		y: 6.5,
		msg: "You can use right click + movement to jump over these tables and spikes."
	},

	{
		x: 38.5,
		y: 6.5,
		msg: "Walk over the weapon to pick it up. Try to destroy some barrels at the right."
	},

	{
		x: 44.5,
		y: 24.5,
		msg: "Try to survive for 30 seconds. You can use your ability 'Q' to place turrets to aid you."
	}

];
*/
