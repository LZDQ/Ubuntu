FunUI.layouts["newGame"] = 
'<div id="newGame" class="F-Window light ffa">' +
    '<div class="title ribbon">_(newGame.title)</div>' +
    '<div class="F-Button close"></div>' +
    '<div class="content">' +
        '<div class="row first">' +
            '<div class="item custom">' +
                '<span class="icon"></span>' +
                '_(newGame.label.custom)' +
                '<div class="hover"></div>' +
            '</div>' +
        '</div>' +
        '<div class="row second">' +
            '<div class="item ranked">' +
                '1v1 Ranked' +
                '<span class="icon"></span>' +
                '<div class="hover"></div>' +
            '</div>' +
            '<div class="item ffa">' +
                '_(newGame.label.ffa)' +
                '<span class="icon"></span>' +
                '<div class="hover"></div>' +
            '</div>' +
            '<div class="item zombie">' +
                '_(newGame.label.zombie)' +
                '<span class="icon"></span>' +
                '<div class="hover"></div>' +
            '</div>' +
            '<div class="item team">' +
                '_(newGame.label.team)' +
                '<span class="icon"></span>' +
                '<div class="hover"></div>' +
            '</div>' +
        '</div>' +
        '<div class="row third">' +
            '<p class="zombie">_(newGame.desc.zombie)</p>' +
            '<p class="team">_(newGame.desc.team)</p>' +
            '<p class="ffa">' +
                'Free for all Deathmatch mode. Kill as many enemies as you can and try do die as little as possible. <font style="color: #a72f2f;">Dont team in this mode. Its all vs all!</font>' +
            '</p>' +
            '<p class="ranked">' +
                '1 versus 1 ranked mode. You get matched against another player in a 1 versus 1 battle. Both players have 5 lives. First player who dies 5 times, loses. Winner wins elo points and loser loses elo points.' +
            '</p>' +
        '</div>' +
        '<div class="row fourth">' +
            '<div class="F-Button light zombie" data-game-mode="5">_(newGame.button.infection)</div>' +
            '<div class="F-Button light team" data-game-mode="2">_(newGame.button.flag)</div>' +
            '<div class="F-Button light team" data-game-mode="1">_(newGame.button.team)</div>' +
            '<div class="F-Button light ffa" data-game-mode="4">_(newGame.button.normal)</div>' +
            '<div class="F-Button light ranked" data-game-mode="3">Play 1v1</div>' +
        '</div>' +
    '</div>' +
'</div>';
