(function(window, slayOne, document){

/**
 * TopLabelled Widget
 * Add a label at the top
 *
 * @param options:
 *                  customClassName: string
 *                  label: string
 *                  content: domContent
 * @returns wrapped node
 */
function topLabelled(options) {

    var domContainer = document.createElement('div');
    var finalClassName = "labelledContainer";
    if(options && options.customClassName) {
        finalClassName += " " + options.customClassName;
    }
    domContainer.className = finalClassName;

    var domLabel = document.createElement('div');
    domLabel.className = "widgetLabel";
    domLabel.innerHTML = options.label;
    domContainer.appendChild(domLabel);

    var domWidget = document.createElement('div');
    domWidget.className = "widgetContainer";
    domWidget.appendChild(options.content);
    domContainer.appendChild(domWidget);

    return domContainer;
}

//export
if(!slayOne.widgets) {
    slayOne.widgets = {};
}

slayOne.widgets.topLabelled = topLabelled;

})(window, window.slayOne, window.document);//end main closure