FunUI.layouts["rankInGame"] =
'<div id="rankInGame" class="ongoing start">' +
    '<div class="vote">' +
        '<h2><span class="voteTitle">_(rankInGame.title.voteMap)</span><span class="ongoing">_(rankInGame.title.countdown.current)</span><span class="waiting">_(rankInGame.title.countdown.next)</span><span class="timeToNext"></span></h2>' +
        '<ul id="rankInGame_mapList" class="F-List">' +
            '<li class="F-ItemRenderer" data-tooltip-renderer="tooltipMap">' +
                '<div class="hover"></div>' +
                '<div class="checkbox"></div>' +
                '<div class="name"></div>' +
                '<div class="voteLabel">_(rankInGame.title.voteLabel)</div>' +
                '<div class="voteValue"></div>' +
            '</li>' +
        '</ul>' +
    '</div>' +
    '<div class="victory"></div>' +
    '<div class="rankArea">' +
        '<table class="normal">' +
            '<caption id="rankTableTitle"></caption>' +
            '<thead>' +
            '<tr>' +
                '<th class="name">_(rankInGame.thead.name)</th>' +
                '<th class="clan">_(rankInGame.thead.clan)</th>' +
                '<th class="score">_(rankInGame.thead.score)</th>' +
                '<th class="souls">_(rankInGame.thead.souls)</th>' +
                '<th class="kill">_(rankInGame.thead.kill)</th>' +
                '<th class="death">_(rankInGame.thead.death)</th>' +
                '<th class="muteCell">_(rankInGame.thead.mute)</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody id="rankInGame_normalList" class="F-List">' +
            '<tr class="F-ItemRenderer">' +
                '<td class="name"></td>' +
                '<td class="clan"><span>[</span><span class="clan"></span><span>]</span></td>' +
                '<td class="score"></td>' +
                '<td class="souls"></td>' +
                '<td class="kill"></td>' +
                '<td class="death"></td>' +
                '<td class="muteCell">' +
                    '<div class="F-Button mute">' +
                        '<div class="hover lite"></div>' +
                    '</div>' +
                '</td>' +
            '</tr>' +
            '</tbody>' +
        '</table>' +
        '<table class="team">' +
            '<caption>_(rankInGame.title)</caption>' +
            '<thead>' +
            '<tr>' +
                '<th class="name">_(rankInGame.thead.name)</th>' +
                '<th class="clan">_(rankInGame.thead.clan)</th>' +
                '<th class="score">_(rankInGame.thead.score)</th>' +
                '<th class="souls">_(rankInGame.thead.souls)</th>' +
                '<th class="kill">_(rankInGame.thead.kill)</th>' +
                '<th class="death">_(rankInGame.thead.death)</th>' +
                '<th class="muteCell">_(rankInGame.thead.mute)</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody class="redTeamSummary">' +
            '<tr>' +
                '<td colspan="6">' +
                    '<span class="teamName"></span>' +
                    '<span class="teamScore"></span>' +
                '</td>' +
            '</tr>' +
            '</tbody>' +
            '<tbody id="rankInGame_redList" class="F-List">' +
            '<tr class="F-ItemRenderer">' +
                '<td class="name"></td>' +
                '<td class="clan"></td>' +
                '<td class="score"></td>' +
                '<td class="souls"></td>' +
                '<td class="kill"></td>' +
                '<td class="death"></td>' +
                '<td class="muteCell">' +
                    '<div class="F-Button mute">' +
                        '<div class="hover lite"></div>' +
                    '</div>' +
                '</td>' +
            '</tr>' +
            '</tbody>' +
            '<tbody class="blueTeamSummary">' +
            '<tr>' +
                '<td colspan="6">' +
                    '<span class="teamName"></span>' +
                    '<span class="teamScore"></span>' +
                '</td>' +
            '</tr>' +
            '</tbody>' +
            '<tbody id="rankInGame_blueList" class="F-List">' +
            '<tr class="F-ItemRenderer">' +
                '<td class="name"></td>' +
                '<td class="clan"></td>' +
                '<td class="score"></td>' +
                '<td class="souls"></td>' +
                '<td class="kill"></td>' +
                '<td class="death"></td>' +
                '<td class="muteCell">' +
                    '<div class="F-Button mute">' +
                        '<div class="hover lite"></div>' +
                    '</div>' +
                '</td>' +
            '</tr>' +
            '</tbody>' +
        '</table>' +
        '<div class="topButtonBar">' +
            '<div class="F-Button tiny invite">_(rankInGame.button.invite)</div>' +
            '<div class="F-Button close ongoing"></div>' +
        '</div>' +
        '<div class="levelWarn">_(rankInGame.level.warn)</div>' +
        '<div class="F-Button gameCtrl green medium start spectate">_(rankInGame.button.spectate)</div>' +
        '<div class="F-Button gameCtrl yellow medium start normal play">_(rankInGame.button.play)</div>' +
        '<div class="F-Button gameCtrl red medium start team">_(rankInGame.button.join.red)</div>' +
        '<div class="F-Button gameCtrl blue medium start team">_(rankInGame.button.join.blue)</div>' +
    '</div>' +
'</div>';