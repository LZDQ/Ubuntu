"use strict";

class NameColor {

	static show() {
		var o = this.get();
		this.refresh();
		o.style.display = 'block';
	}

	static get() {
		var o = document.getElementById('nameColor');
		if (!o) {
			o = this._create();
		}
		return o;
	}

	static getColor() {

		var color = NAME_COLOR[playerData.name_color_select];

		if(!color)
		{
			if(playerData.name_color[0])
				return NAME_COLOR[playerData.name_color[0]].code;
			
			return '#fff';
		}
		
		return color.code;
	}

	static refreshPanel() {

		var color = this.getColor();

		var profile = document.body.querySelector('.playerProfileView > .playerMeta .playerNick');
		if(profile)
			profile.style.color = color;

		var welcome = document.body.querySelector('.homeWelcomeMsgWrapper > .msgBody');
		if(welcome)
		{
			var span = welcome.querySelectorAll('span');
			for(var a of span)
				a.style.color = color;
		}
	}

	static refresh() {

		this.get();

		var content = document.getElementById('nameColorContent');
		content.innerHTML = '';

		for(let id in NAME_COLOR)
		{
			if(id < 200)
				continue;

			var a = NAME_COLOR[id];
			
			var row = document.createElement('div');
			row.innerText = a.name;
			row.style.color = a.code;

			var select = playerData.name_color_select;
			if(!select)
				select = playerData.name_color[0];

			if(id == select)
			{
				row.className = 'selected';
				row.onclick = () => {
					this.hide();
				};
			}
			else if(playerData.name_color.includes(id))
			{
				row.className = 'can-select';
				row.onclick = () => {
					playerData.name_color_select = id;
					network.send('chooseNameColor$' + id);
					this.refreshPanel();
					this.hide();
				};

			}
			else
				row.className = 'invalid';

			content.appendChild(row);
		}
	}

	static _create() {

		var box = document.createElement('div');
		box.id = 'nameColor';
		box.className = 'F-Window light';

		var close = document.createElement('div');
		close.className = 'F-Button close';
		close.onclick = () => {
			this.hide();
		};
		box.appendChild(close);

		var content = document.createElement('div');
		content.className = 'content';
		content.id = 'nameColorContent';

		box.appendChild(content);

		document.body.appendChild(box);

		F$(box.id);

		return box;
	}

	static hide() {
		var o = document.getElementById('nameColor');
		if(o)
			o.style.display = 'none';
	}
}
