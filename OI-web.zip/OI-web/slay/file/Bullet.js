function Bullet(x, y)
{
	this.x = x;
	this.y = y;
	this.z = 1;
	
	this.vx = (Math.random() * 1 - 0.5) * 0.05;
	this.vy = (Math.random() * 1 - 0.5) * 0.05;
	
	this.vx2 = (Math.random() * 1 - 0.5) * 0.15;
	this.vy2 = (Math.random() * 1 - 0.5) * 0.15;
	
	this.spread = 0.15;
	
	this.tickOfBirth = game.ticksCounter;
	this.tickOfDeath = this.tickOfBirth + 67;
	this.lastPhase = 1;
	this.rand = Math.floor(Math.random() * 100);
	
	game.effects.push(this);
	game.addToObjectsToDraw(this);
};

Bullet.prototype.update = function(ticksCounter)
{
	return this.tickOfDeath > ticksCounter;
};

Bullet.prototype.getYDrawingOffset = function()
{
	return this.y;
};

Bullet.prototype.draw = function(exactTicks, x1, y1, x2, y2)
{
	if(!(this.x + 3 >= x1 && this.y + 3 >= y1 && this.x - 3 <= x2 && this.y - 3 <= y2))
		return;
	
	var age = exactTicks - this.tickOfBirth - 7;
	
	var z = 0;
	var x = 0;
	var y = 0;
	
	var img = imgCoords["bullet" + ((99999999 + this.rand + Math.floor(exactTicks)) % 4 + 1)];
	
	if(age > Math.sqrt(1.2) / this.spread + 2 * Math.sqrt(0.3) / this.spread) // phase 3
	{
		z = 0;
		
		img = imgCoords["bullet" + (this.rand % 4 + 1)];
		
		if(img == imgCoords.bullet3)
			img = imgCoords.bullet1;
		
		x = (Math.sqrt(1.2) / this.spread) * this.vx + this.x + this.vx2 * (2 * Math.sqrt(0.3) / this.spread);
		y = (Math.sqrt(1.2) / this.spread) * this.vy + this.y + this.vy2 * (2 * Math.sqrt(0.3) / this.spread);
		
		if(this.lastPhase == 2)
		{
			this.lastPhase = 3;
			soundManager.playSound(SOUND.CARTRIDGE2, x, y, 0.3);
		}
	}
	
	else if(age > Math.sqrt(1.2) / this.spread) // phase 2
	{
		img = imgCoords["bullet" + ((99999999 + this.rand - Math.floor(exactTicks)) % 4 + 1)];
		
		z = -Math.pow(this.spread * (age - Math.sqrt(1.2) / this.spread - Math.sqrt(0.3) / this.spread), 2) + 0.3;
		x = (Math.sqrt(1.2) / this.spread) * this.vx + this.x + this.vx2 * (age - Math.sqrt(1.2) / this.spread);
		y = (Math.sqrt(1.2) / this.spread) * this.vy + this.y + this.vy2 * (age - Math.sqrt(1.2) / this.spread);
		
		if(this.lastPhase == 1)
		{
			this.lastPhase = 2;
			soundManager.playSound(SOUND.CARTRIDGE1, x, y, 0.1);
		}
	}
	
	else // phase 1
	{
		z = -Math.pow(this.spread * age, 2) + 1.2;
		x = this.x + this.vx * age;
		y = this.y + this.vy * age;
	}
	
	
	var scale = SCALE_FACTOR;
	
	var drawX = g2rx(x) - (img.w / 2) * scale;
	var drawY = g2ry(y - z) - (img.h / 2) * scale;
	
	c.globalAlpha = age > 35 ? Math.max((55 - age) / 20, 0) : 1;
	c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, drawX, drawY, img.w * scale, img.h * scale);
	c.globalAlpha = 1;
};