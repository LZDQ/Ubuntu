/**
 * View renders the "Player Profile" UI
 *
 */
(function(window, slayOne, document) {

	var viewKey = "playerProfileScreen";

	function renderPlayerMeta_ (parentNode, viewModel) {

		var profile = viewModel.profile;
		var str = '';

		var self = !!(profile.pid == playerData.db_id && game.mapWelcome && !isSteam);

		str += '<div class="fullLine">Nickname: <span class="playerNick" style="color: ' + NameColor.getColor() + '">' + escapeHtml(profile.displayName) + '</span> ';
		if(self)
		{
			str += '<div class="F-Button changeNick info withClickSound">';
			str += '<div class="label"></div>';
			str += '<div class="hover"></div>';
			str += '</div>';
		}
		str += '</div>';
		
		var modButtons = "";
		
		if(playerData.authLevel >= AUTH_LEVEL.MOD2)
		{
			modButtons += "<button class='modButton' onclick='modPlInfo(" + profile.pid + ");'>/plinfo</button>";
			modButtons += "<button class='modButton' onclick='initBan(" + profile.pid + ");'>/ban</button>";
		}
		
		str += '<div class="fullLine">Player ID: <span class="highlightedNum">' + profile.pid + '</span>' + modButtons + '</div>';

		var dateCreated = new Date(parseInt(profile.tsCreated));

		if(profile.clanName && profile.clanName.length > 0) {
			str += "<div class='fullLine'>" + F_("profile.clan.label", {
				clanName: "[<a class='playerClanName pseudoLink yellow withClickSound'>" + profile.clanName + "</a>]"
			}) + "</div>";
		}

		str += "<div class='smallHalf'>" + F_("profile.level.label", {
			level: "<span class='highlightedNum'>" + getLvlFromXp(profile.exp) + "</span>"
		}) + "</div>";

		str += "<div class='largeHalf'>" + F_("profile.elo.label", {
			elo: "<span class='highlightedNum'>" + profile.elo + "</span> (<a class='pseudoLink yellow withClickSound' onclick='network.send(\"getLaddergames$" + profile.pid + "\");'>Ranked games list</a>)"
		}) + "</div>";

		str += "<div class='smallHalf'>" + F_("profile.num_kills.label", {
			numKills: "<span class='boldText green'>" + profile.numKills + "</span>"
		}) + "</div>";

		var kdRateStr = "";
		if(profile.numDeaths > 0) {
			kdRateStr = ' ' + F_("profile.kdrate.label", {
				rate: "<span class=''>" + (Math.floor((parseInt(profile.numKills) / parseInt(profile.numDeaths)) * 10) / 10) + "</span>"
			});
		}

		str += "<div class='largeHalf'>" + F_("profile.num_death.label", {
			numDeaths: "<span class='boldText red'>" + profile.numDeaths + "</span>"
		}) + kdRateStr + "</div>";

		var spawnTimeStr = dateCreated.getDate() + "/" + (dateCreated.getMonth() + 1) + "/" + dateCreated.getFullYear();
		str += "<div class='fullLine'>" + F_("profile.spawn_time.label", {
			spawnTime: "<span class='highlightedNum'>" + spawnTimeStr + "</span>"
		}) + "</div>";

		parentNode.innerHTML = str;

		if(self)
			parentNode.querySelector('.changeNick').addEventListener('click', function() {
				F$('changeNick').open();
			});
		
		var clanLink = parentNode.querySelector(".playerClanName");
		if(clanLink)
			clanLink.addEventListener("click", function(){
				F$('clanMain').show(profile.clanName);
				hide();
			});
	}

	function renderChangeNameColor_(parentNode, viewModel)
	{
		var profile = viewModel.profile;
		var self = !!(profile.pid == playerData.db_id && game.mapWelcome);
		if(!self)
			return;
		
		if(playerData.name_color.length < 2)
			return;
		
		var domBtnContainer = document.createElement('div');
		domBtnContainer.className = "nameColorContainer";
		
		viewModel.btnChangeColor = slayOne.widgets.labelButton(domBtnContainer, {
			label: 'change name color',
			theme: "LightGreen",
			customClassName: "changeNameColor",
			onClick: () => {
				NameColor.show();
			}
		});
		
		parentNode.appendChild(domBtnContainer);
	}

	function renderPlayerDescription_(parentNode, viewModel)
	{
		var profile = viewModel.profile;

		var domDesc = document.createElement('div');

		var str = "";
		str += "<textarea spellcheck='false' class='playerDesc'";
		str += " maxlength='255' readonly id='personal_text'>" + escapeHtml(profile.desc) + "</textarea>";
		domDesc.innerHTML = str;

		viewModel.taDesc = domDesc.querySelector(".playerDesc");

		parentNode.appendChild(domDesc);
	}

	function renderOperationsButtons_ (parentNode, viewModel)
	{
		var profile = viewModel.profile;

		var domBtnContainer = document.createElement('div');
		domBtnContainer.className = "buttonsContainer";

		viewModel.btnEditDesc = slayOne.widgets.labelButton(domBtnContainer, {
			label: F_("profile.btn_desc_edit.label"),
			theme: "LightGreen",
			customClassName: "editDescButton",
			onClick: function(){
				setDescEditEnabled_(viewModel, true);
				refreshButtonStatus_(viewModel);
			}
		});

		viewModel.btnSaveDesc = slayOne.widgets.labelButton(domBtnContainer, {
			label: F_("profile.btn_desc_save.label"),
			theme: "LightGreen",
			customClassName: "editDescButton",
			onClick: function(){
				setDescEditEnabled_(viewModel, false);
				refreshButtonStatus_(viewModel);
				window.network.send("update-profile-text$" + viewModel.taDesc.value);
			}
		});

		parentNode.appendChild(domBtnContainer);

		setDescEditEnabled_(viewModel, false);
		refreshButtonStatus_(viewModel);
	}

	function setDescEditEnabled_ (viewModel, enabled) {
		viewModel.editingDesc = enabled;
		if(enabled) {
			viewModel.taDesc.readOnly = false;
			addClassToDom(viewModel.taDesc, "editableDesc");
			viewModel.taDesc.focus();
		} else {
			viewModel.taDesc.readOnly = true;
			removeClassFromDom(viewModel.taDesc, "editableDesc");
		}
	}

	function refreshButtonStatus_ (viewModel) {

		viewModel.btnEditDesc.style.display = 'none';
		viewModel.btnSaveDesc.style.display = 'none';

		switch(viewModel.perspective) {
			case 'self': {
				viewModel.btnEditDesc.style.display = viewModel.editingDesc ? 'none' : 'block';
				viewModel.btnSaveDesc.style.display = viewModel.editingDesc ? 'block' : 'none';
				break;
			}
			case 'guest': {
				break;
			}
			case 'clan_admin': {
				break;
			}
		}
	}

	/**
	 * Show player profile window
	 *
	 * @param options:
	 *        - perspective: string enum, self | guest | clan_admin
	 *        - profile: {displayName, exp, elo, clanName, numKills, numDeaths, tsCreated, desc}
	 */
	function show(options)
	{
		var domContent = document.createElement('div');
		domContent.className = "playerProfileView";

		var viewModel = {
			btnEditDesc: null,
			btnSaveDesc: null,
			taDesc: null,
			editingDesc: false,
			perspective: (options && options.perspective) ? options.perspective : 'guest',
			profile: options.profile
		};

		var domPlayerMeta = document.createElement('div');
		domPlayerMeta.className = "playerMeta";
		renderPlayerMeta_(domPlayerMeta, viewModel);

		domContent.appendChild(domPlayerMeta);

		renderChangeNameColor_(domContent, viewModel);

		var domPlayerDescWrapper = document.createElement('div');
		domPlayerDescWrapper.className = "playerDescWrapper";
		renderPlayerDescription_(domPlayerDescWrapper, viewModel);
		if(game.mapWelcome)
			renderOperationsButtons_(domPlayerDescWrapper, viewModel);
		
		domContent.appendChild(domPlayerDescWrapper);
		
		slayOne.viewHelpers.showPopup(viewKey, {
			theme: 'light',
			content: domContent,
			onClose: () => {
				NameColor.hide();
			}
		});
	}

	function hide() {
		slayOne.viewHelpers.hidePopup(viewKey);
	}

	//export
	slayOne.views[viewKey] = {
		show: show,
		hide: hide
	};

})(window, window.slayOne, window.document);//end main closure
