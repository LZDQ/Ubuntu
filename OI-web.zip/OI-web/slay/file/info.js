/**
 * View renders light weight informative screen
 *
 */
(function(window, slayOne, document) {

var viewKey = "infoScreen";

function render(screenTitle, screenContent){

    var domContainer = document.createElement("div");
    domContainer.className = "infoScreen pixelated";

    var domWindowTitle = document.createElement("div");
    domWindowTitle.className = "infoScreenTitle";
    domWindowTitle.innerHTML = screenTitle;
    domContainer.appendChild(domWindowTitle);

    var domContentWrap = document.createElement("div");
    domContentWrap.className = "infoScreenContentWrap";

    var domContent = document.createElement("div");
    domContent.className = "infoScreenContent";
    domContent.innerHTML = screenContent;
    domContentWrap.appendChild(domContent);

    domContainer.appendChild(domContentWrap);

    //one everything is rendered, show the window
    slayOne.viewHelpers.showPopup(viewKey, {
        theme: 'light',
        content: domContainer
    });

}

//export
slayOne.views[viewKey] = {
    render: render
};

})(window, window.slayOne, window.document);//end main closure