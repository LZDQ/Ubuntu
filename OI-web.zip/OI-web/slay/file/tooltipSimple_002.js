(function(){
    FunUI.traits.tooltipSimple = {
        __init__: function () {
            // todo: trait code
        }
    };
})();