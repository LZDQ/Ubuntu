(function(){
    FunUI.traits.openChest = {
        _goldAmountField: null,
        _goldYoursAmountField: null,
        _hatNameField: null,
        _hatQualityField: null,
        _hatLevelField: null,
        _hatProgressBar: null,
        _hatProgressField: null,
        _hatCanvas: null,
        _showTime: null,
        __init__: function()
        {
            this._goldAmountField = this.querySelector('.rewards .reward.gold .amount');
            this._goldYoursAmountField = this.querySelector('.rewards .reward.gold .yoursAmount');
        },
        show: function(chestId, gold)
        {
			Skin.close();
			
            FunUI.managers.PopUpManager.addPopUp(this, false, FunUI.utils.LAYER_TOP);
            
            this.className = this.className.replace(/chest_\d+/g, "");
            this.addClass("chest_" + chestId);
            
            this._goldAmountField.innerHTML = gold;
            this._goldYoursAmountField.innerHTML = playerData.gold;
            this._showTime = Date.now();
        },
        "<Observer event='click'/>": function()
        {
            if(Date.now() - this._showTime >= 1000)
                FunUI.managers.PopUpManager.removePopUp(this);
        }
    };
})();