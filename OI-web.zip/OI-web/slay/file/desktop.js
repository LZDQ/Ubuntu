"use strict";

var win;
if (window.nw) {
	win = nw.Window.get();
}

if (isDesktop && isSteam) {
	if (win) {
		SteamInfo = win.onSteam();
		if (SteamInfo) {
			if (!(localStorage.getItem('not-fullscreen')|0)) {
				win.enterFullscreen();
			}
		}
	} else {
		ipcRenderer.on('steam', (_, arg) => {
			SteamInfo = arg;
		});
		ipcRenderer.send('steam', true);
	}
}

class Desktop {

	static close() {
		if (win) {
			win.close();
		} else {
			Desktop._cmd('toggleFullscreen');
		}
	}

	static toggleFullscreen() {
		if (win) {

			localStorage.setItem('not-fullscreen', win.isFullscreen|0);
			win.toggleFullscreen();

		} else {
			Desktop._cmd('toggleFullscreen');
		}
	}

	static _cmd(s) {
		if (win) {
			return false;
		}
		ipcRenderer.send('cmd', s);
	}
}

class Steam {
	static login() {
		var data = {
			id: SteamInfo.user.steamId,
			nick: SteamInfo.user.screenName,
			ticket: SteamInfo.ticket,
		};
		network.send('loginSteam$' + JSON.stringify(data));
	}
}

function steamInitWait(box) {

	if (!isSteam) {
		return;
	}

	if (localStorage.getItem('steamPrepareLoading')) {
		return;
	}

	var o = steamInitWaitText();

	if (box) {
		o.className = 'steamPrepareLoading';
		box.appendChild(o);
		return;
	}

	if (document.getElementById('steamPrepareLoading')) {
		return;
	}

	o.id = 'steamPrepareLoading';

	document.body.appendChild(o);
}

function steamInitWaitHide() {

	localStorage.setItem('steamPrepareLoading', 1);

	var o = document.getElementById('steamPrepareLoading');
	if (o) {
		o.style.display = 'none';
	}
}

function steamInitWaitText() {
	var o = document.createElement('div');
	o.innerText = F_('steam.text.createWait');

	return o;
}

var isSteamBindSend = false;
