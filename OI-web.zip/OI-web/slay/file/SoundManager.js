// plays and manages all the sounds
function SoundManager()
{
	this.sounds = [];

	this.sounds[SOUND.GRENADE_LAUNCH] = [
		"sounds/grenade_launch_1.ogg",
		"sounds/grenade_launch_2.ogg",
		"sounds/grenade_launch_3.ogg"
	];

	this.sounds[SOUND.EXPLODE] = [
		"sounds/explo1.ogg",
		"sounds/explo2.ogg"
	];

	this.sounds[SOUND.LASER] = [
		"sounds/laser1.ogg",
		"sounds/laser1.ogg",
		"sounds/laser2.ogg",
		"sounds/laser2.ogg"
	];

	this.sounds[SOUND.SWITCH_WEAPON] = [
		"sounds/switch_weapon.ogg",
		"sounds/switch_weapon.ogg"
	];

	this.sounds[SOUND.COCK] = [
		"sounds/cock1.ogg",
		"sounds/cock1.ogg"
	];

	this.sounds[SOUND.EMPTY_CLIP] = [
		"sounds/empty-clip.ogg",
		"sounds/empty-clip.ogg"
	];

	this.sounds[SOUND.SIZZLE] = [
		"sounds/sizzle1.ogg",
		"sounds/sizzle2.ogg",
		"sounds/sizzle2.ogg"
	];

	this.sounds[SOUND.SIZZLE2] = [
		"sounds/sizzle3.ogg",
		"sounds/sizzle3.ogg",
		"sounds/sizzle3.ogg"
	];

	this.sounds[SOUND.GUN_IMPACT] = [
		"sounds/gun_hit_wall.ogg",
		"sounds/gun_hit_wall.ogg",
		"sounds/gun_hit_wall.ogg",
		"sounds/gun_hit_wall.ogg"
	];

	this.sounds[SOUND.GUN_IMPACT_2] = [
		"sounds/gun_impact_x.ogg",
		"sounds/gun_impact_x.ogg",
		"sounds/gun_impact_x.ogg",
		"sounds/gun_impact_x.ogg"
	];

	this.sounds[SOUND.PUNCH] = [
		"sounds/punch1.ogg",
		"sounds/punch2.ogg",
		"sounds/punch1.ogg",
		"sounds/punch2.ogg",
		"sounds/punch1.ogg",
		"sounds/punch2.ogg"
	];

	this.sounds[SOUND.KICK] = [
		"sounds/kick1.ogg",
		"sounds/kick2.ogg",
		"sounds/kick3.ogg",
		"sounds/kick4.ogg"
	];

	this.sounds[SOUND.CLICK] = [
		"sounds/click1.ogg",
		"sounds/click1.ogg"
	];

	this.sounds[SOUND.ROCKET_LAUNCH] = [
		"sounds/rocket-launch.ogg",
		"sounds/rocket-launch.ogg",
		"sounds/rocket-launch.ogg"
	];

	this.sounds[SOUND.ROCKET_FLY] = [
		"sounds/rocket-fly.ogg",
		"sounds/rocket-fly.ogg",
		"sounds/rocket-fly.ogg"
	];

	this.sounds[SOUND.FRAG1] = [
		"sounds/kill1.ogg"
	];

	this.sounds[SOUND.FRAG2] = [
		"sounds/kill2.ogg"
	];

	this.sounds[SOUND.FRAG3] = [
		"sounds/kill3.ogg"
	];

	this.sounds[SOUND.FRAG4] = [
		"sounds/kill4.ogg"
	];

	this.sounds[SOUND.FRAG5] = [
		"sounds/kill5.ogg"
	];

	this.sounds[SOUND.RELOAD_MG] = [
		"sounds/reload_mg.ogg"
	];

	this.sounds[SOUND.RELOAD_GL] = [
		"sounds/reload_gl.ogg"
	];

	this.sounds[SOUND.RELOAD_RL] = [
		"sounds/reload_rl.ogg"
	];

	this.sounds[SOUND.RELOAD_RL_2] = [
		"sounds/reload_rl_2.ogg"
	];

	this.sounds[SOUND.LASER_RECHARGE] = [
		"sounds/laser-recharge.ogg"
	];

	this.sounds[SOUND.RELOAD_FLAME] = [
		"sounds/reload_flame.ogg"
	];

	this.sounds[SOUND.LADDER_WIN] = [
		"sounds/ladder_win.ogg"
	];

	this.sounds[SOUND.LADDER_LOSS] = [
		"sounds/ladder_loss.ogg"
	];

	this.sounds[SOUND.LADDER_START] = [
		"sounds/ladder-start.ogg"
	];

	this.sounds[SOUND.LADDER_GONG] = [
		"sounds/ladder-gong.ogg"
	];

	this.sounds[SOUND.TICK] = [
		"sounds/tick1.ogg",
		"sounds/tick2.ogg",
		"sounds/tick3.ogg"
	];
	
	this.sounds[SOUND.HEAL_WPN] = [
		"sounds/heal_wpn.ogg",
		"sounds/heal_wpn.ogg",
		"sounds/heal_wpn.ogg"
	];

	this.sounds[SOUND.SHOTGUN] = [
		"sounds/shotgun.ogg",
		"sounds/shotgun2.ogg"
	];

	this.sounds[SOUND.SHOTGUN_RELOAD] = [
		"sounds/shotgun_reload_2.ogg"
	];

	this.sounds[SOUND.SHOTGUN_RELOAD_LONG] = [
		"sounds/shotgun_reload_long.ogg"
	];

	this.sounds[SOUND.ZIP] = [
		"sounds/zip.ogg"
	];

	this.sounds[SOUND.LVLUP] = [
		"sounds/archivement3.ogg"
	];

	this.sounds[SOUND.UPGRADE_ITEM] = [
		"sounds/archivement2.ogg"
	];

	this.sounds[SOUND.OPEN_CHEST] = [
		"sounds/archivement3.ogg"
	];

	this.sounds[SOUND.UNLOCK] = [
		"sounds/archivement2.ogg"
	];

	this.sounds[SOUND.ZOOM] = [
		"sounds/zoom.ogg"
	];

	this.sounds[SOUND.BING] = [
		"sounds/bing.ogg",
		"sounds/bing.ogg"
	];

	this.sounds[SOUND.FLAME_BURN] = [
		"sounds/flame.ogg",
		"sounds/flame.ogg",
		"sounds/flame.ogg",
		"sounds/flame.ogg"
	];

	this.sounds[SOUND.FLAME_EXPLODE] = [
		"sounds/flame_explo.ogg",
		"sounds/flame_explo.ogg"
	];

	this.sounds[SOUND.SNIPER] = [
		"sounds/sniper3.ogg",
		"sounds/sniper4.ogg"
	];

	this.sounds[SOUND.ROCKET_BEEP] = [
		"sounds/rocket-beep.ogg",
		"sounds/rocket-beep.ogg"
	];

	this.sounds[SOUND.HEAL] = [
		"sounds/heal.ogg",
		"sounds/heal.ogg"
	];

	this.sounds[SOUND.ARMOR] = [
		"sounds/armor.ogg",
		"sounds/armor.ogg"
	];

	this.sounds[SOUND.AMMO_SPAWN] = [
		"sounds/ammo-spawn.ogg",
		"sounds/ammo-spawn.ogg",
		"sounds/ammo-spawn.ogg"
	];

	this.sounds[SOUND.PLAYER_SPAWN] = [
		"sounds/warp-in.ogg",
		"sounds/warp-in.ogg",
		"sounds/warp-in.ogg"
	];

	this.sounds[SOUND.REFLECT] = [
		"sounds/plasma-shield.ogg",
		"sounds/plasma-shield2.ogg",
		"sounds/plasma-shield3.ogg",
		"sounds/plasma-shield.ogg",
		"sounds/plasma-shield2.ogg",
		"sounds/plasma-shield3.ogg"
	];

	this.sounds[SOUND.FLAMETHROWER] = [
		"sounds/flamethrower.ogg",
		"sounds/flamethrower.ogg"
	];

	this.sounds[SOUND.GRENADE_BOUNCE] = [
		"sounds/grenade-bounce.ogg",
		"sounds/grenade-bounce.ogg",
		"sounds/grenade-bounce.ogg"
	];

	this.sounds[SOUND.PLACE] = [
		"sounds/clic02.ogg",
		"sounds/clic02.ogg"
	];

	this.sounds[SOUND.SWITCH] = [
		"sounds/switch.ogg",
		"sounds/switch.ogg",
		"sounds/switch.ogg",
		"sounds/switch.ogg"
	];

	this.sounds[SOUND.CHAT1] = [
		"sounds/chat-1.ogg",
		"sounds/chat-1.ogg",
		"sounds/chat-1.ogg",
		"sounds/chat-1.ogg"
	];

	this.sounds[SOUND.INVIS1] = [
		"sounds/invis1.ogg",
		"sounds/invis1.ogg"
	];

	this.sounds[SOUND.STEP] = [
		"sounds/step1.ogg",
		"sounds/step2.ogg",
		"sounds/step3.ogg",
		"sounds/step4.ogg",
		"sounds/step1.ogg",
		"sounds/step2.ogg",
		"sounds/step3.ogg",
		"sounds/step4.ogg"
	];

	this.sounds[SOUND.THROW] = [
		"sounds/throw-1.ogg",
		"sounds/throw-2.ogg"
	];

	this.sounds[SOUND.FLASH] = [
		"sounds/flash.ogg",
		"sounds/flash.ogg"
	];

	this.sounds[SOUND.FLASH_START] = [
		"sounds/flash_start.ogg",
		"sounds/flash_start.ogg"
	];

	this.sounds[SOUND.SMOKE_START] = [
		"sounds/smoke_start.ogg",
		"sounds/smoke_start.ogg"
	];

	this.sounds[SOUND.SMOKE_LOOP] = [
		"sounds/smoke_loop.ogg",
		"sounds/smoke_loop.ogg",
		"sounds/smoke_loop.ogg",
		"sounds/smoke_loop.ogg"
	];

	this.sounds[SOUND.SPELL] = [
		"sounds/spell.ogg",
		"sounds/spell.ogg"
	];

	this.sounds[SOUND.INVIS2] = [
		"sounds/invis2.ogg",
		"sounds/invis2.ogg"
	];

	this.sounds[SOUND.NEGATIVE] = [
		"sounds/negative.ogg",
		"sounds/negative.ogg",
		"sounds/negative.ogg",
		"sounds/negative.ogg"
	];

	this.sounds[SOUND.BLINK] = [
		"sounds/blink.ogg",
		"sounds/blink.ogg"
	];

	this.sounds[SOUND.TURRET_INIT] = [
		"sounds/turret-init.ogg",
		"sounds/turret-init.ogg"
	];

	this.sounds[SOUND.HEAL_AURA] = [
		"sounds/heal-aura.ogg",
		"sounds/heal-aura.ogg",
		"sounds/heal-aura.ogg",
		"sounds/heal-aura.ogg"
	];

	this.sounds[SOUND.CLICK] = [
		"sounds/click1.ogg"
	];

	this.sounds[SOUND.MG] = [
		"sounds/mg4.ogg",
		"sounds/mg4.ogg",
		"sounds/mg4.ogg",
		"sounds/mg4.ogg",
		"sounds/mg5.ogg",
		"sounds/mg5.ogg",
		"sounds/mg5.ogg",
		"sounds/mg5.ogg",
		"sounds/mg4.ogg",
		"sounds/mg4.ogg",
		"sounds/mg4.ogg",
		"sounds/mg5.ogg",
		"sounds/mg5.ogg",
		"sounds/mg5.ogg",
		"sounds/mg5.ogg"
	];

	this.sounds[SOUND.CARTRIDGE1] = [
		"sounds/cartridge1.ogg",
		"sounds/cartridge2.ogg",
		"sounds/cartridge4.ogg",
		"sounds/cartridge1.ogg",
		"sounds/cartridge2.ogg",
		"sounds/cartridge4.ogg",
		"sounds/cartridge1.ogg",
		"sounds/cartridge2.ogg"
	];

	this.sounds[SOUND.CARTRIDGE2] = [
		"sounds/cartridge3.ogg",
		"sounds/cartridge5.ogg",
		"sounds/cartridge3.ogg",
		"sounds/cartridge5.ogg",
		"sounds/cartridge3.ogg",
		"sounds/cartridge5.ogg",
		"sounds/cartridge3.ogg",
		"sounds/cartridge5.ogg"
	];

	this.sounds[SOUND.DOUBLE_KILL] = [
		"sounds/kills/doublekill.ogg"
	];

	this.sounds[SOUND.MULTI_KILL] = [
		"sounds/kills/multikill.ogg"
	];

	this.sounds[SOUND.ULTRA_KILL] = [
		"sounds/kills/ultrakill.ogg"
	];

	this.sounds[SOUND.MONSTER_KILL] = [
		"sounds/kills/monsterkill.ogg"
	];

	this.sounds[SOUND.KILLING_SPREE] = [
		"sounds/kills/killingspree.ogg"
	];

	this.sounds[SOUND.RAMPAGE] = [
		"sounds/kills/rampage.ogg"
	];

	this.sounds[SOUND.DOMINATING] = [
		"sounds/kills/dominating.ogg"
	];

	this.sounds[SOUND.UNSTOPPABLE] = [
		"sounds/kills/unstoppable.ogg"
	];

	this.sounds[SOUND.GODLIKE] = [
		"sounds/kills/godlike.ogg"
	];

	this.sounds[SOUND.SCAN] = [
		"sounds/scan.ogg"
	];

	this.sounds[SOUND.START] = [
		"sounds/game_start.ogg"
	];

	this.sounds[SOUND.END] = [
		"sounds/end.ogg",
		"sounds/end2.ogg"
	];

	this.sounds[SOUND.WIN] = [
		"sounds/win.ogg"
	];

	this.sounds[SOUND.LOSE] = [
		"sounds/lose.ogg"
	];

	this.sounds[SOUND.TEAMKILL] = [
		"sounds/teamkill.ogg"
	];

	this.sounds[SOUND.ZOMBIE_BITE] = [
		"sounds/zombie_bite.ogg",
		"sounds/zombie_bite.ogg",
		"sounds/zombie_bite_3.ogg",
		"sounds/zombie_bite_3.ogg"
	];

	this.sounds[SOUND.ZOMBIE_DEATH] = [
		"sounds/zombie-21.ogg",
		"sounds/zombie-8.ogg"
	];

	this.sounds[SOUND.ZOMBIE_ATT] = [
		"sounds/zombie-1.ogg",
		"sounds/zombie-11.ogg",
		"sounds/zombie-9.ogg"
	];

	this.sounds[SOUND.LVL_UP] = [
		"sounds/lvlUp.ogg",
		"sounds/lvlUp.ogg"
	];

	this.sounds[SOUND.ATT_UP] = [
		"sounds/att_up.ogg"
	];

	this.sounds[SOUND.BEEBEEP] = [
		"sounds/beebeep.ogg"
	];

	this.sounds[SOUND.SPLASH] = [
		"sounds/splash.ogg"
	];

	this.sounds[SOUND.SHIELD] = [
		"sounds/shield.ogg",
		"sounds/shield.ogg"
	];

	this.sounds[SOUND.SHIELD_HIT] = [
		"sounds/shield_hit.ogg",
		"sounds/shield_hit.ogg"
	];

	this.sounds[SOUND.WOODCRACK] = [
		"sounds/woodcrack1.ogg",
		"sounds/woodcrack2.ogg",
		"sounds/woodcrack3.ogg"
	];

	this.sounds[SOUND.MECH_IMPACT] = [
		"sounds/mech-impact-1.ogg",
		"sounds/mech-impact-2.ogg"
	];

	this.sounds[SOUND.CRAWLER_IMPACT] = [
		"sounds/crawler-impact.ogg",
		"sounds/crawler-impact.ogg"
	];

	this.sounds[SOUND.ZOMBIE_BOSS_HIT] = [
		"sounds/zombie_boss_hit.ogg",
		"sounds/zombie_boss_hit.ogg"
	];

	this.sounds[SOUND.ZOMBIE_TRANSFORM] = [
		"sounds/zombietransform.ogg",
		"sounds/zombietransform.ogg"
	];

	this.sounds[SOUND.HUMAN_TRANSFORM] = [
		"sounds/humantransform.ogg",
		"sounds/humantransform.ogg"
	];

	this.sounds[SOUND.ASMD1] = [
		"sounds/asmd1.ogg",
		"sounds/asmd2.ogg",
		"sounds/asmd1.ogg",
		"sounds/asmd2.ogg"
	];

	this.sounds[SOUND.ASMD2] = [
		"sounds/humantransform.ogg",
		"sounds/humantransform.ogg"
	];

	this.sounds[SOUND.ASMD_RELOAD] = [
		"sounds/asmd_reload.ogg"
	];
	
	this.sounds[SOUND.ASMD_FLY] = [
		"sounds/asmd_fly.ogg",
		"sounds/asmd_fly.ogg",
		"sounds/asmd_fly.ogg",
		"sounds/asmd_fly.ogg"
	];
	
	this.sounds[SOUND.ASMD_BALL_LAUNCH] = [
		"sounds/asmd_2.ogg",
		"sounds/asmd_2.ogg"
	];
	
	this.sounds[SOUND.ASMD_EXPLO_1] = [
		"sounds/asmd_explo_1.ogg",
		"sounds/asmd_explo_1.ogg"
	];
	
	this.sounds[SOUND.ASMD_EXPLO_2] = [
		"sounds/asmd_explo_2.ogg",
		"sounds/asmd_explo_2.ogg"
	];
}

SoundManager.prototype.loadSound = function(files)
{
	var target = [];

	for(var i = 0; i < files.length; i++)
		target.push(new Audio(files[i]));

	return target;
};

SoundManager.prototype.getVolumeModifier = function(x, y)
{
	var volume = 1;

	var left = game.cameraX;
	var top = game.cameraY;
	var right = game.cameraX + WIDTH / FIELD_SIZE;
	var bottom = game.cameraY + HEIGHT / FIELD_SIZE;

	var distX = 0;
	if(x < left || x > right)
		distX = Math.min(Math.abs(x - left), Math.abs(x - right));

	var distY = 0;
	if(y < top || y > bottom)
		distY = Math.min(Math.abs(y - top), Math.abs(y - bottom));

	var dist = Math.sqrt(distX * distX + distY * distY);

	if(dist > 0)
		volume = 1 - dist / 5;

	// make sounds a little bit lower, when zoomed out
	volume *= Math.min(SCALE_FACTOR / 15 + 0.6, 1);

	return volume;
};

// pos has influence on the volume; if a pos is given, the distance from the screen to pos is checked, and the volume is lower, the higher the distance is
SoundManager.prototype.playSound = function(sound, x, y, volumeModifier) {

	// if sound is disabled (by the user in options) return
	if(!(sound_volume > 0) || !this.sounds[sound] || game.fastForward)
		return;

	// check distance => volume
	var volume = (typeof x != 'undefined') ? this.getVolumeModifier(x, y) : 1;

	volume = volumeModifier ? (volume * volumeModifier) : volume;

	if(volume <= 0)
		return;

	var s = this.sounds[sound];
	if (typeof s[0] == "string") {
		s = this.loadSound(s);
		this.sounds[sound] = s;
	}
	var readySounds = [];

	// find sound(s), which are / is ready
	for(var i = 0; i < s.length; i++)
		if(s[i].currentTime >= s[i].duration || s[i].currentTime == 0 || !s[i].currentTime)
			readySounds.push(s[i]);

	// all sounds still in use, return
	if(readySounds.length == 0)
		return;

	// random one of the ready sounds
	var soundToPlay = readySounds[Math.floor(Math.random() * readySounds.length)];

	// play sound
	// soundToPlay.load();
	soundToPlay.loop = false;
	// soundToPlay.currentTime = 0;
	// soundToPlay.src = soundToPlay.src;
    // setTimeout(function () {
        // if (soundToPlay.paused) {
	soundToPlay.play();
        // }
    // }, 0);

	volume = volume * sound_volume * 0.70;

    if (volume > 1) {
        volume = 1;
    } else if (!volume > 0) {
        volume = 0;
    }
	soundToPlay.volume = volume;

	return soundToPlay;
};
