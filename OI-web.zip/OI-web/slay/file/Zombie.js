Zombie.prototype = new Humanoid();
function Zombie(id, x, y, hp, x0, y0, maxHP, hpRegeneration, randomizer, imgScale, masterId, name) {

	this.isZombie = true;
	this.id = parseInt(id);
	this.team = -1;
	this.name = name;

	this.x = x;
	this.y = y;
	this.x0 = x0 ? x0 : x;
	this.y0 = y0 ? y0 : y;
	this.x00 = x0;
	this.y00 = y0;
	this.legFrame = 0;

	this.masterId = masterId;

	this.hp = parseFloat(hp);
	this.maxHP = parseFloat(maxHP);
	this.hpRegeneration = parseFloat(hpRegeneration);
	randomizer = parseFloat(randomizer);

	if(randomizer == 3)
	{
		this.head = 36;
		this.hat = null;
		this.legs = 9;
		this.imgScale = 1;
		this.handsOffset = 512;
		this.isDarkZombie = true;
	}

	else if(randomizer == 4) // ranged zombie
	{
		this.head = 23;
		this.hat = null;
		this.legs = 10;
		this.imgScale = 1;
		this.handsOffset = 256;
		this.isRangedZombie = true;
		this.specialImg = imgs.rangedZombie;
		this.specialImgWhite = imgs.rangedZombieWhite;
		this.frameOffset = 48;
		this.frameW = 24;
		this.moveFrames = 7;
		this.specialScale = 1;
		this.specialHight = 8;
	}

	else if(randomizer == 5) // crawler
	{
		this.head = 23;
		this.hat = null;
		this.legs = 10;
		this.imgScale = 1;
		this.handsOffset = 256;
		this.isCrawler = true;
		this.frameOffset = 0;
		this.specialImg = imgs.crawler;
		this.specialImgWhite = imgs.crawlerWhite;
		this.frameW = 30;
		this.specialHight = 11;

		this.moveFrames = 3;
		this.specialScale = 0.85;
	}

	else
	{
		this.head = 23;
		this.hat = randomizer < 0.2 ? hats[zombieSkins[Math.floor(randomizer * 5 * zombieSkins.length)]] : null;
		this.legs = this.hat ? this.hat.legs : 10;
		this.imgScale = imgScale;
		this.handsOffset = 256;
	}

	this.targetX = 0;
	this.targetY = 0;

	this.bleeds = true;

	this.z = 0;
	this.vz = 0;
	this.z0 = 0;
	this.dieAt = 0;

	this.direction = 0;
	this.lastTickFire = -999;
	this.lastPosUpdate = -999;
	this.stepOffset = Math.floor(Math.random() * 5);
	this.smokeTimeOffset = Math.floor(Math.random() * 10);
	this.playSpawnAnimation = masterId > 0;
	this.tickOfSpawn = game.ticksCounter;

	this.bouncePoints = [];
	this.flameDeath = false;
	this.flameDeathAndNowBouncing = false;
	this.path = [];
	this.laserHitUntil = -999;
	this.lastHit = -999;
	this.lockDirection2 = 0;
	this.lockDirection = 0;
	this.finallyRemoveAt = 0;
	this.hitUntil = -999;

	this.lastSpawnTick = -99999;
	this.lightPillarsTop = [];
	this.lightPillarsBottom = [];

	this.invincibleUntil = -9999;

	if(this.hp <= 0)
	{
		this.dieAt = game.ticksCounter;
		this.finallyRemoveAt = game.ticksCounter + 50;
	}

	game.addToObjectsToDraw(this);
};

Zombie.prototype.hpUpdate = function(hp)
{
	this.hp = parseFloat(hp);

	if(this.hp <= 0 && this.isCrawler)
		createExplosionGreen(this.x, this.y, 2.3);
};

Zombie.prototype.die = function(projectile, murderWeaponId, objX, objY, objAOE, killer, obj, startX, startY, vecX, vecY, vecH)
{
	this.dieAt = game.ticksCounter;
	this.finallyRemoveAt = game.ticksCounter + 100;

	if(this.isCrawler)
		this.finallyRemoveAt = game.ticksCounter;

	soundManager.playSound(SOUND.ZOMBIE_DEATH, this.x, this.y, 0.6);

	if(game.targetLockedPlayer == this)
		game.targetLockedPlayer = null;

	/*
	if(murderWeaponId && weapons[murderWeaponId] && weapons[murderWeaponId].flameDeath)
	{
		this.flameDeath = true;
		this.finallyRemoveAt = game.ticksCounter + 150;

		var x = this.x;
		var y = this.y;
		this.path = [{x: x, y: y}];

		for(var i = 0; i < 8; i++)
		{
			var found = false;
			var rand = Math.floor(Math.random() * 8);
			var counter = 0;
			while(!found)
			{
				var cx = circleX[rand];
				var cy = circleY[rand];

				if(game.getPathForPos(cx + x, cy + y) >= 10)
				{
					x += cx;
					y += cy;
					found = true;
					this.path.push({x: x, y: y});
				}
				else
					rand = (rand + 1) % 8;

				counter++;
				if(counter >= 8)
					found = true;
			}
		}

		var lastField = this.path[this.path.length - 1];
		var secLastField = this.path[this.path.length - 2] ? this.path[this.path.length - 2] : {x: -1, y: -1};

		this.bouncePoints = this.createBounce(lastField.x, lastField.y, lastField.x - secLastField.x, lastField.y - secLastField.y, 0.1, 0.15);

		return;
	}
	*/

	if(murderWeaponId && weapons[murderWeaponId] && weapons[murderWeaponId].flameDeath)
		this.flameDeath = true;

	if(startX || startY || vecX || vecY || vecH)
	{
		this.bouncePoints = createBounce2(startX, startY, vecX, vecY, vecH, game);
		this.noCorpseBounce = true;
	}

	else
	{
		var vec = createBounce(this, projectile, objX, objY, objAOE, killer, obj);
		this.bouncePoints = createBounce2(this.x, this.y, vec.x, vec.y, vec.z, game);
	}
};

Zombie.prototype.update = function()
{
	if(this.finallyRemoveAt && this.finallyRemoveAt <= game.ticksCounter)
	{
		if(game.type.coopZombieMode && !this.isCrawler)
			this.createCorpse();

		return false;
	}

	if(this.dieAt)
	{
		if(this.flameDeath)
		{
			var timeDead = game.ticksCounter - this.dieAt;

			var pos = Math.floor(timeDead / 5);

			if(pos > this.path.length - 2)
			{
				this.updateBounce();
				this.flameDeathAndNowBouncing = true;
			}

			else
			{
				this.x0 = this.x;
				this.y0 = this.y;

				this.x = this.path[pos].x + (this.path[pos + 1].x - this.path[pos].x) * ((timeDead / 5) % 1);
				this.y = this.path[pos].y + (this.path[pos + 1].y - this.path[pos].y) * ((timeDead / 5) % 1);

				this.direction = getDirectionFromAgle(this.x0, this.y0, this.x, this.y);
			}

			if(!game.fastForward && game.ticksCounter % 3 == 1 && this.x + 3 >= game.cameraX && this.y + 3 >= game.cameraY && this.x - 3 <= game.cameraX2 && this.y - 3 <= game.cameraY2)
			{
				new Sprite({
					x: this.x + Math.random() * 0.6 - 0.3,
					y: this.y + Math.random() * 0.6 - 0.3,
					img: imgCoords["fire" + (Math.floor(Math.random() * 4) + 1)],
					scaleFunction: function(age){ return Math.max(0.75 - age / 20, 0) * this.r1; },
					alphaFunction: function(age){ return Math.max(0.75 - age / 20, 0); },
					r1: 3 + Math.random() * 1,
					zFunction: function(age){ return age * 0.1; },
				});

				new Sprite({
					x: this.x + Math.random() * 0.6 - 0.3,
					y: this.y + Math.random() * 0.6 - 0.3,
					img: imgCoords.dust1,
					scaleFunction: function(age){ return Math.max(0.75 - age / 70, 0) * this.r1; },
					alphaFunction: function(age){ return Math.max(0.40 - age / 90, 0); },
					r1: 3 + Math.random() * 1,
					zFunction: function(age){ return age * 0.1; },
				});

				// light
				new Sprite({
					x: this.x,
					y: this.y - 0.5,
					img: imgCoords.light_yellow,
					scaleFunction: function(age){ return Math.max(1 - age / 30, 0) * 4; },
					alphaFunction: function(age){ return Math.max(1 - age / 25, 0) * 0.16; }
				});
			}
		}

		else
		{
			this.updateBounce();

			if(this.isRangedZombie && this.dieAt + 5 == game.ticksCounter)
			{
				soundManager.playSound(SOUND.ZOMBIE_BITE, this.x, this.y, 0.8);
				soundManager.playSound(SOUND.ZOMBIE_ATT, this.x, this.y, 0.9);
			}
		}
	}

	else if(this.bouncePoints.length > 0)
		this.updateBounce();

	if(!this.dieAt)
	{
		if(this.x != this.x0 || this.y != this.y0)
			this.direction = getDirectionFromAgle(this.x0, this.y0, this.x, this.y);

		this.z0 = this.z;

		if(this.z > 0)
		{
			this.z = Math.max(this.z + this.vz, 0);
			this.vz -= CONST.GRAVITY;
		}

		this.spillBloodFromMeleeAttack();
	}

	if(!this.dieAt && this.bouncePoints.length == 0 && this.lastPosUpdate < game.ticksCounter)
	{
		if(Math.sqrt(Math.pow(this.x - this.x0, 2) + Math.pow(this.y - this.y0, 2)) < 0.005)
		{
			this.x0 = this.x;
			this.y0 = this.y;
		}

		var x0 = this.x;
		var y0 = this.y;

		this.x += this.x - this.x0;
		this.y += this.y - this.y0;

		this.x0 = x0;
		this.y0 = y0;

		if(this.z <= 0 && (this.x != this.x0 || this.y != this.y0) && this.stepOffset == (game.ticksCounter % 5))
			soundManager.playSound(SOUND.STEP, this.x, this.y, 0.65);
	}

	this.hp = Math.min(this.hp + this.hpRegeneration, this.maxHP);

	return true;
};

Zombie.prototype.isAlliedWith = function(player)
{
	return player && player.isHumanZombie;
};

Zombie.prototype.performPreHit = function(victim)
{
	this.lastTickFire = game.ticksCounter;
	this.targetX = victim.x;
	this.targetY = victim.y;
	this.victim = victim;

	if(this.isCrawler)
		this.dieAt = game.ticksCounter;

	if(this.x + 3 >= game.cameraX && this.y + 3 >= game.cameraY && this.x - 3 <= game.cameraX2 && this.y - 3 <= game.cameraY2)
		soundManager.playSound(SOUND.ZOMBIE_ATT, victim.x, victim.y);
};

Zombie.prototype.draw = function(exactTicks, x1, y1, x2, y2, percentageOfCurrentTickPassed)
{
	if(!(this.x + 3 >= x1 && this.y + 3 >= y1 && this.x - 3 <= x2 && this.y - 3 <= y2))
		return;

	if(this.laserHitUntil >= exactTicks || this.hitUntil >= exactTicks)
	{
		percentageOfCurrentTickPassed = 0;
		exactTicks = this.lastHit;
	}

	var scale = SCALE_FACTOR * 1.4 * this.imgScale;
	var frame = 0;

	var x = (this.x0 + percentageOfCurrentTickPassed * (this.x - this.x0) - game.cameraX) * FIELD_SIZE;
	var y = (this.y0 + percentageOfCurrentTickPassed * (this.y - this.y0) - game.cameraY) * FIELD_SIZE;
	var h = (this.z0 + percentageOfCurrentTickPassed * (this.z - this.z0)) * FIELD_SIZE;

	var x_ = x - 32 / 2 * scale;
	var y_ = y - (32 - 12) * scale;

	var bounce = false;
	var blackness = 0;
	var whiteness = 0;

	if(this.flameDeath && !this.flameDeathAndNowBouncing)
	{
		var timeDead = exactTicks - this.dieAt;

		blackness = Math.min(timeDead / 50, 0.9);

		if(timeDead < (this.path.length - 1) * 10)
			frame = parseInt((exactTicks * 0.6) % 8);
	}

    else if(this.dieAt || this.bouncePoints.length > 0)
    {
        if(this.x != this.x0)
            this.direction = (this.x > this.x0) ? 0 : 2;
        else if(this.direction != 2 && this.direction != 0)
            this.direction = 2;

        frame = (this.z >= this.z0 || this.z < 0.1) ? 1 : 0;
        bounce = true;
    }

	else
	{
		var shiftX = 0;
		var shiftY = 0;

		// shift
		if(this.z <= 0)
		{
			var shift = game.shiftArray[Math.floor(this.x)] ? game.shiftArray[Math.floor(this.x)][Math.floor(this.y)] : null;

			if(shift && shift[0])
				shiftX = shift[0];

			if(shift && shift[1])
				shiftY = shift[1];
		}

		if(Math.abs(this.x0 + shiftX - this.x) > 0.01 || Math.abs(this.y0 + shiftY - this.y) > 0.01)
		{
			var dist = Math.sqrt(Math.pow(this.x - this.x0, 2) + Math.pow(this.y - this.y0, 2));

			if(game.ticksCounter > 0)
			{
				if(this.z > 0)
					this.legFrame += timeDiff * 0.0025;
				else
					this.legFrame += timeDiff * 0.012 * dist / 0.202;
			}

			frame = Math.floor(this.legFrame) % 8;

			// running smoke effekt
			if(tickDiff > 0 && game.ticksCounter >= 0 && (game.ticksCounter + this.smokeTimeOffset) % 6 == 1 && !game.fastForward)
				new Sprite({
					x: this.x + Math.random() * 0.6 - 0.3,
					y: this.y + Math.random() * 0.6 - 0.3,
					img: imgCoords.dust1,
					scaleFunction: function(age){ return this.scale_ - age * 0.01; },
					scale_: Math.random() + 0.75,
					alphaFunction: function(age) { return Math.max(0, 1 - age / this.ticksToLive) * 0.23; },
					age: (1.7 + Math.random()) * 20,
					z_: Math.random() * 40 + 32,
					zFunction: function(age){ return age / this.z_; }
				});
		}
		else
			frame = 3;
	}

	if(this.flameDeathAndNowBouncing)
		blackness = 0.9;

	if(this.hitUntil >= exactTicks)
		whiteness = (Math.random() < 0.5) ? 0.95 : 0.1;

	var direction = this.direction;

	if(this.laserHitUntil >= exactTicks)
	{
		whiteness = 0.95;
		direction = this.lockDirection;
	}

	var vanishingAlpha = this.getVanishingAlpha(exactTicks);

	// shadow
	c.globalAlpha = 0.4 * vanishingAlpha;
	c.drawImage(imgs.shadow, x_, y_, 32 * scale, 32 * scale);
	c.globalAlpha = 1.0;

	var age = exactTicks - this.lastSpawnTick;

	if(age < 25) // play spawn effect
		for(var i = 0; i < this.lightPillarsTop.length; i++)
			this.updateAndDrawPillar(this.lightPillarsTop[i], age);

	if(bounce)
	{
		if(this.specialImg)
		{
			var rFrame = Math.floor(Math.min(Math.max((exactTicks - this.dieAt - 2) * 0.35, 0), 8));
			x_ = x - this.frameW / 2 * scale * this.specialScale;
			y_ = y - (this.frameW - this.specialHight) * scale * this.specialScale;

			c.drawImage(this.specialImg, rFrame * this.frameW, 8 * this.frameW, this.frameW, this.frameW, x_, y_, this.frameW * scale * this.specialScale, this.frameW * scale * this.specialScale);
		}

		else
		{
	        var yFrame = this.direction;
	        if(yFrame >= 1)
	        	yFrame = 1;
	        var xFrame = Math.floor(Math.min(Math.max((exactTicks - this.dieAt) * 0.25, 0), 7));

	        c.globalAlpha = vanishingAlpha;
	        c.drawImage(imgs.zombieDeath, xFrame * 32, 32 * yFrame, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
	        c.globalAlpha = 1;

	        if(this.flameDeath)
	        {
	            c.globalAlpha = blackness * vanishingAlpha;
	            c.drawImage(imgs.zombieDeathBlack, xFrame * 32, 32 * yFrame, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
	            c.globalAlpha = 1;
	        }

			/*
	        var legFrame = this.direction + frame;

	        c.globalAlpha = vanishingAlpha;
	        c.drawImage(imgs.legs, (legFrame + 3) * 32, 32 * 8 + this.legs * 288, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
	        c.drawImage(imgs.heads, 512 + legFrame * 32, 32 * this.head, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
	        if(this.hat)
	        	c.drawImage(imgs.heads, 512 + legFrame * 32, 32 * this.hat.offset, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
	        c.globalAlpha = 1;

	        if(this.flameDeath)
	        {
	            c.globalAlpha = blackness * vanishingAlpha;
	            c.drawImage(imgs.legsBlack, (legFrame + 3) * 32, 32 * 8 + this.legs * 288, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
	            c.drawImage(imgs.headsBlack, 512 + legFrame * 32, 32 * this.head, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
	            if(this.hat)
	            	c.drawImage(imgs.headsBlack, 512 + legFrame * 32, 32 * this.hat.offset, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
	            c.globalAlpha = 1;
	        }

	        if(whiteness > 0)
	        {
	            c.globalAlpha = whiteness;
	            c.drawImage(imgs.legsWhite, (legFrame + 3) * 32, 32 * 8 + this.legs * 288, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
	            c.drawImage(imgs.headsWhite, 512 + legFrame * 32, 32 * this.head, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
	            if(this.hat)
	            	c.drawImage(imgs.headsWhite, 512 + legFrame * 32, 32 * this.hat.offset, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
	            c.globalAlpha = 1;
	        }
	        */
	     }
	}

	else
	{
		// spawn animation
		if(this.playSpawnAnimation && this.tickOfSpawn + 30 >= exactTicks)
		{
			var spawnAge = game.ticksCounter - this.tickOfSpawn;
			var frame2 = Math.floor(Math.min((spawnAge / 30) * 8, 7));
			var imgS = this.isRangedZombie ? imgCoords.zombieSpawn2 : imgCoords.zombieSpawn1;

			if(this.isDarkZombie)
				imgS = imgCoords.zombieSpawn3;

			if(this.isCrawler)
				imgS = imgCoords.zombieSpawn4;

			// legs
			c.drawImage(imgs.miscSheet, imgS.x + frame2 * 32, imgS.y, 32, imgS.h, x_, y_ - h, 32 * scale * this.specialScale, 32 * scale * this.specialScale);

			if(whiteness > 0)
			{
				c.globalAlpha = whiteness;
				c.drawImage(imgs.miscSheetWhite, imgS.x + frame2 * 32, imgS.y, 32, imgS.h, x_, y_ - h, 32 * scale * this.specialScale, 32 * scale * this.specialScale);
				c.globalAlpha = 1;
			}
		}

		else if(this.lastTickFire + 12 > game.ticksCounter && !this.flameDeath)
		{
			var attackAge = game.ticksCounter - this.lastTickFire;
			direction = getDirectionFromAgle(this.x, this.y, this.targetX, this.targetY);
			this.direction = direction;

			if(this.specialImg)
			{
				// shadow
				c.globalAlpha = 0.4 * vanishingAlpha;
				c.drawImage(imgs.shadow, x_, y_ + 4 * scale, 32 * scale, 32 * scale);
				c.globalAlpha = 1.0;

				var rFrame = attackAge <= 4 ? 0 : 1;
				x_ = x - this.frameW / 2 * scale * this.specialScale;
				y_ = y - (this.frameW - this.specialHight) * scale * this.specialScale;

				c.drawImage(this.specialImg, rFrame * this.frameW, direction * this.frameW, this.frameW, this.frameW, x_, y_ - h, this.frameW * scale * this.specialScale, this.frameW * scale * this.specialScale);

				if(whiteness > 0)
				{
					c.globalAlpha = whiteness;
					c.drawImage(this.specialImgWhite, rFrame * this.frameW, direction * this.frameW, this.frameW, this.frameW, x_, y_ - h, this.frameW * scale * this.specialScale, this.frameW * scale * this.specialScale);
					c.globalAlpha = 1;
				}
			}

			else
			{
				var frame2 = attackAge < 4 ? 0 : 256;
				frame = 2;

				// legs
				c.drawImage(imgs.legs, frame * 32, 32 * direction + this.legs * 288, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);

				if(whiteness > 0)
				{
					c.globalAlpha = whiteness;
					c.drawImage(imgs.legsWhite, frame * 32, 32 * direction + this.legs * 288, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
					c.globalAlpha = 1;
				}

				c.drawImage(imgs.heads, 32 * direction + frame2, (this.head + 1) * 32, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
				if(this.hat)
					c.drawImage(imgs.heads, 32 * direction + frame2, 32 * (1 + this.hat.offset), 32, 32, x_, y_ - h - (frame % 2) * scale / 2, 32 * scale, 32 * scale);

				if(whiteness > 0)
				{
					c.globalAlpha = whiteness;
					c.drawImage(imgs.headsWhite, 32 * direction + frame2, (this.head + 1) * 32, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
					if(this.hat)
						c.drawImage(imgs.headsWhite, 32 * direction + frame2, 32 * (1 + this.hat.offset), 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
					c.globalAlpha = 1;
				}
			}
		}

		else
		{
			if(this.specialImg)
			{
				// shadow
				c.globalAlpha = 0.4 * vanishingAlpha;
				c.drawImage(imgs.shadow, x_, y_ + 4 * scale, 32 * scale, 32 * scale);
				c.globalAlpha = 1.0;

				var rFrame = (frame == 3) ? 0 : (Math.floor(exactTicks * 0.6) % this.moveFrames);
				x_ = x - this.frameW / 2 * scale * this.specialScale;
				y_ = y - (this.frameW - this.specialHight) * scale * this.specialScale;

				c.drawImage(this.specialImg, rFrame * this.frameW + this.frameOffset, direction * this.frameW, this.frameW, this.frameW, x_, y_ - h, this.frameW * scale * this.specialScale, this.frameW * scale * this.specialScale);

				if(whiteness > 0)
				{
					c.globalAlpha = whiteness;
					c.drawImage(this.specialImgWhite, rFrame * this.frameW + this.frameOffset, direction * this.frameW, this.frameW, this.frameW, x_, y_ - h, this.frameW * scale * this.specialScale, this.frameW * scale * this.specialScale);
					c.globalAlpha = 1;
				}
			}

			else
			{
				// legs
				c.drawImage(imgs.legs, frame * 32, 32 * direction + this.legs * 288, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);

				if(this.flameDeath)
				{
					c.globalAlpha = blackness;
					c.drawImage(imgs.legsBlack, frame * 32, 32 * direction + this.legs * 288, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
					c.globalAlpha = 1;
				}

				if(whiteness > 0)
				{
					c.globalAlpha = whiteness;
					c.drawImage(imgs.legsWhite, frame * 32, 32 * direction + this.legs * 288, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
					c.globalAlpha = 1;
				}

				// head
				c.drawImage(imgs.heads, direction * 32, 32 * this.head, 32, 32, x_, y_ - h - (frame % 2) * scale / 2, 32 * scale, 32 * scale);
				if(this.hat)
					c.drawImage(imgs.heads, direction * 32, 32 * this.hat.offset, 32, 32, x_, y_ - h - (frame % 2) * scale / 2, 32 * scale, 32 * scale);

				if(this.flameDeath)
				{
					c.globalAlpha = blackness;
					c.drawImage(imgs.headsBlack, direction * 32, 32 * this.head, 32, 32, x_, y_ - h - (frame % 2) * scale / 2, 32 * scale, 32 * scale);
					if(this.hat)
						c.drawImage(imgs.headsBlack, direction * 32, 32 * this.hat.offset, 32, 32, x_, y_ - h - (frame % 2) * scale / 2, 32 * scale, 32 * scale);
					c.globalAlpha = 1;
				}

				if(whiteness > 0)
				{
					c.globalAlpha = whiteness;
					c.drawImage(imgs.headsWhite, direction * 32, 32 * this.head, 32, 32, x_, y_ - h - (frame % 2) * scale / 2, 32 * scale, 32 * scale);
					if(this.hat)
						c.drawImage(imgs.headsWhite, direction * 32, 32 * this.hat.offset, 32, 32, x_, y_ - h - (frame % 2) * scale / 2, 32 * scale, 32 * scale);
					c.globalAlpha = 1;
				}

				// hands
				c.drawImage(imgs.hands, frame * 32, 32 * direction + this.handsOffset, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);

				if(this.flameDeath)
				{
					c.globalAlpha = blackness;
					c.drawImage(imgs.handsBlack, frame * 32, 32 * direction + this.handsOffset, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
					c.globalAlpha = 1;
				}

				if(whiteness > 0)
				{
					c.globalAlpha = whiteness;
					c.drawImage(imgs.handsWhite, frame * 32, 32 * direction + this.handsOffset, 32, 32, x_, y_ - h, 32 * scale, 32 * scale);
					c.globalAlpha = 1;
				}
			}
		}
	}

	if(age < 25) // play spawn effect
		for(var i = 0; i < this.lightPillarsBottom.length; i++)
			this.updateAndDrawPillar(this.lightPillarsBottom[i], age);

	var x = (this.x0 + percentageOfCurrentTickPassed * (this.x - this.x0) - game.cameraX) * FIELD_SIZE;
	var y = (this.y0 + percentageOfCurrentTickPassed * (this.y - this.y0) - game.cameraY) * FIELD_SIZE;

	if(this.dieAt)
		return;

	// hp
	var barScale = SCALE_FACTOR * 0.55;
	var barW = 42;
	var barH = 8;

	var x2 = x - (barW * barScale) / 2;
	var y2 = y - 1.85 * FIELD_SIZE - h;

	var nameColor = NAME_COLOR[50].code;

	// player name
	if(this.name && this.name.length > 0)
	{
		var nameX = x;
		var nameAlign = 'center';
		if (game.type.souls) {
			nameX = x2 + FIELD_SIZE * 0.1;
			nameAlign = 'left';
		}
		drawText(
			c,
			this.name,
			nameColor,
			FIELD_SIZE * 0.22,
			nameX,
			y2 - FIELD_SIZE * 0.05,
			null,
			nameAlign,
			null,
			null,
			null,
			(barW - 4) * barScale
		);
	}

	c.fillStyle = "black";
	c.fillRect(x2, y2, barW * barScale, barH * barScale);

	var hp = Math.min(this.hp - (this.hpGlideEnd >= exactTicks ? (this.hpGlideAmount * (this.hpGlideEnd - exactTicks) / (this.hpGlideEnd - this.hpGlideStart)) : 0), this.maxHP);

	var img = (game.playingPlayer && this.isAlliedWith(game.playingPlayer)) ? imgCoords.hpBar1 : imgCoords.hpBar3;

	var w = (barW - 2) * barScale * (hp / this.maxHP);

	c.drawImage(imgs.miscSheet, img.x, img.y, img.w, img.h, x2 + 1 * barScale, y2 + 1 * barScale, w, barScale * 6);

	// hp seperator
	c.strokeStyle = "rgba(0, 0, 0, 1)";
	c.lineWidth = barScale;
	for(var i = CONST.HP_SEPERATOR_AMOUNT; i < this.maxHP; i += CONST.HP_SEPERATOR_AMOUNT)
	{
		c.beginPath();
		c.moveTo(x2 + 1 * barScale + (i / this.maxHP) * (barW - 2) * barScale, y2 + 5 * barScale);
		c.lineTo(x2 + 1 * barScale + (i / this.maxHP) * (barW - 2) * barScale, y2 + 7 * barScale);
		c.stroke();
	}
};
