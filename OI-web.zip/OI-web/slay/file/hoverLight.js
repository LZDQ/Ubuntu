(function(window, slayOne, document){

var themeBorderSizes = {
    normal: { w: '32px', h: '32px' },
    lite: { w: '24px', h: '24px' },
};

/**
 * Hover light
 *
 * @param parentNode: dom element to append to
 * @param options:
 *                  width: css property string, container overall width
 *                  height: css property string, container overall height
 *                  left: css property string, position adjustments
 *                  top: css property string, position adjustments
 *                  theme: string enum, normal|lite, default normal
 */
function hoverLight(parentNode, options) {

    var themeOption = (options && options.theme) ? options.theme : 'normal';
    
    var domHover = parentNode.querySelector(".hoverLight");
    if(!domHover) {
        domHover = document.createElement("div");
        domHover.className = "hoverLight hoverLight" + capitalize(themeOption);
        parentNode.appendChild(domHover);
        parentNode.addEventListener("mouseover", function(){
            domHover.style.display = "block";    
        });
        parentNode.addEventListener("mouseout", function(){
            domHover.style.display = "none";
        });
    }

    domHover.style.width = 'calc(' + options.width + ' - ' + themeBorderSizes[themeOption].w + ')';
    domHover.style.height = 'calc(' + options.height + ' - ' + themeBorderSizes[themeOption].h + ')';
    if(options.left) {
        domHover.style.left = options.left;
    }
    if(options.top) {
        domHover.style.top = options.top;
    }
    domHover.style.display = "none";

    return domHover;
}

//export
if(!slayOne.widgets) {
    slayOne.widgets = {};
}

slayOne.widgets.hoverLight = hoverLight;

})(window, window.slayOne, window.document);//end main closure